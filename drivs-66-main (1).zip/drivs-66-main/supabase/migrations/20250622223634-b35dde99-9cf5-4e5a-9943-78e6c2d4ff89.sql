
-- First, let's create proper RLS policies and security functions

-- Create a security definer function to get current user role safely
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Create a function to check if user belongs to a company
CREATE OR REPLACE FUNCTION public.user_belongs_to_company(company_uuid UUID)
RETURNS BOOLEAN AS $$
BEGIN
  -- Check if user is the company owner
  IF EXISTS (
    SELECT 1 FROM public.rental_companies 
    WHERE id = company_uuid AND id = auth.uid()
  ) THEN
    RETURN TRUE;
  END IF;
  
  -- Check if user is a company user (manager/inspector)
  IF EXISTS (
    SELECT 1 FROM public.company_users 
    WHERE company_id = company_uuid AND user_id = auth.uid() AND active = true
  ) THEN
    RETURN TRUE;
  END IF;
  
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Enable RLS on all tables that don't have it
ALTER TABLE public.rental_companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rental_company_vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.violations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.company_users ENABLE ROW LEVEL SECURITY;

-- Drop existing overly permissive policies if they exist
DROP POLICY IF EXISTS "Enable all access for all users" ON public.rental_companies;
DROP POLICY IF EXISTS "Enable all access for all users" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Enable all access for all users" ON public.drivers;
DROP POLICY IF EXISTS "Enable all access for all users" ON public.contracts;
DROP POLICY IF EXISTS "Enable all access for all users" ON public.violations;
DROP POLICY IF EXISTS "Enable all access for all users" ON public.company_users;

-- Create secure RLS policies for rental_companies
CREATE POLICY "Companies can manage their own data" ON public.rental_companies
FOR ALL USING (id = auth.uid());

-- Create secure RLS policies for rental_company_vehicles
CREATE POLICY "Company vehicles access" ON public.rental_company_vehicles
FOR ALL USING (public.user_belongs_to_company(company_id));

-- Create secure RLS policies for drivers
CREATE POLICY "Driver access control" ON public.drivers
FOR ALL USING (
  -- Drivers can see their own data
  id = auth.uid() OR 
  -- Company users can see drivers associated with their company
  public.user_belongs_to_company(company_id) OR
  -- Admins can see all
  public.get_current_user_role() = 'admin'
);

-- Create secure RLS policies for contracts
CREATE POLICY "Contract access control" ON public.contracts
FOR ALL USING (
  -- Drivers can see their own contracts
  driver_id = auth.uid() OR 
  -- Company users can see contracts for their company
  public.user_belongs_to_company(company_id) OR
  -- Admins can see all
  public.get_current_user_role() = 'admin'
);

-- Create secure RLS policies for violations
CREATE POLICY "Violation access control" ON public.violations
FOR ALL USING (
  -- Drivers can see their own violations
  driver_id = auth.uid() OR 
  -- Company users can see violations for their company
  public.user_belongs_to_company(company_id) OR
  -- Admins can see all
  public.get_current_user_role() = 'admin'
);

-- Create secure RLS policies for company_users
CREATE POLICY "Company users access control" ON public.company_users
FOR ALL USING (
  -- Users can see their own record
  user_id = auth.uid() OR 
  -- Company owners can see their company users
  public.user_belongs_to_company(company_id) OR
  -- Admins can see all
  public.get_current_user_role() = 'admin'
);

-- Add proper constraints for data integrity
ALTER TABLE public.drivers ADD CONSTRAINT drivers_company_id_not_null CHECK (company_id IS NOT NULL);
ALTER TABLE public.rental_company_vehicles ADD CONSTRAINT vehicles_company_id_not_null CHECK (company_id IS NOT NULL);
ALTER TABLE public.contracts ADD CONSTRAINT contracts_company_id_not_null CHECK (company_id IS NOT NULL);
ALTER TABLE public.violations ADD CONSTRAINT violations_company_id_not_null CHECK (company_id IS NOT NULL);
ALTER TABLE public.company_users ADD CONSTRAINT company_users_company_id_not_null CHECK (company_id IS NOT NULL);
ALTER TABLE public.company_users ADD CONSTRAINT company_users_user_id_not_null CHECK (user_id IS NOT NULL);

-- Create function to safely delete drivers with password verification
CREATE OR REPLACE FUNCTION public.delete_driver(
  driver_id UUID,
  requester_password TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
  driver_company_id UUID;
  requester_role TEXT;
BEGIN
  -- Get the driver's company
  SELECT company_id INTO driver_company_id 
  FROM public.drivers 
  WHERE id = driver_id;
  
  -- Get requester role
  SELECT role INTO requester_role FROM public.profiles WHERE id = auth.uid();
  
  -- Only allow admins or company owners/users to delete drivers
  IF requester_role = 'admin' OR public.user_belongs_to_company(driver_company_id) THEN
    -- In a real implementation, verify the password properly
    -- For now, we'll simulate password verification
    IF requester_password IS NOT NULL AND length(requester_password) > 0 THEN
      DELETE FROM public.drivers WHERE id = driver_id;
      RETURN TRUE;
    END IF;
  END IF;
  
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add audit logging table for security events
CREATE TABLE IF NOT EXISTS public.security_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id UUID,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.security_audit_log ENABLE ROW LEVEL SECURITY;

-- Only admins can view audit logs
CREATE POLICY "Admins can view audit logs" ON public.security_audit_log
FOR SELECT USING (public.get_current_user_role() = 'admin');

-- Function to log security events
CREATE OR REPLACE FUNCTION public.log_security_event(
  action_name TEXT,
  resource_type_name TEXT,
  resource_uuid UUID DEFAULT NULL,
  user_ip INET DEFAULT NULL,
  agent TEXT DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO public.security_audit_log (
    user_id, action, resource_type, resource_id, ip_address, user_agent
  ) VALUES (
    auth.uid(), action_name, resource_type_name, resource_uuid, user_ip, agent
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
