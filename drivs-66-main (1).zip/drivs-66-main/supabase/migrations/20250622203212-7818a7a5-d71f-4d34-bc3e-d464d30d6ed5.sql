
-- Primeiro, vamos garantir que temos uma tabela para as locadoras aprovadas
-- com todos os campos necessários para o funcionamento completo
CREATE TABLE IF NOT EXISTS public.approved_rental_companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name TEXT NOT NULL,
  trading_name TEXT,
  cnpj TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL,
  website_url TEXT,
  description TEXT,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  zip_code TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  contact_position TEXT,
  contact_phone TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  
  -- Campos específicos para o funcionamento como locadora
  plan TEXT NOT NULL DEFAULT 'basic',
  payment_status TEXT NOT NULL DEFAULT 'trial',
  trial_start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  trial_end_date DATE NOT NULL DEFAULT (CURRENT_DATE + INTERVAL '30 days'),
  due_date DATE DEFAULT (CURRENT_DATE + INTERVAL '30 days'),
  
  -- Status e controle
  is_active BOOLEAN NOT NULL DEFAULT true,
  verified BOOLEAN NOT NULL DEFAULT true,
  vehicle_count INTEGER DEFAULT 0,
  drivers_count INTEGER DEFAULT 0,
  
  -- Metadados
  registration_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar RLS
ALTER TABLE public.approved_rental_companies ENABLE ROW LEVEL SECURITY;

-- Política para permitir que locadoras vejam apenas seus próprios dados
CREATE POLICY "Rental companies can view own data" 
  ON public.approved_rental_companies 
  FOR SELECT 
  USING (
    auth.uid() IS NULL OR 
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('admin', 'analyst')
    )
  );

-- Política para admins/analistas visualizarem todas as locadoras
CREATE POLICY "Admins can view all rental companies" 
  ON public.approved_rental_companies 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('admin', 'analyst')
    )
  );

-- Função para processar cadastro de locadora automaticamente
CREATE OR REPLACE FUNCTION process_rental_company_registration()
RETURNS TRIGGER AS $$
BEGIN
  -- Inserir automaticamente na tabela de locadoras aprovadas
  INSERT INTO public.approved_rental_companies (
    id,
    company_name,
    trading_name,
    cnpj,
    email,
    phone,
    website_url,
    description,
    address,
    city,
    state,
    zip_code,
    contact_name,
    contact_position,
    contact_phone,
    password_hash,
    plan,
    payment_status,
    trial_start_date,
    trial_end_date,
    due_date,
    is_active,
    verified
  ) VALUES (
    NEW.id,
    NEW.company_name,
    NEW.trading_name,
    NEW.cnpj,
    NEW.email,
    NEW.phone,
    NEW.website_url,
    NEW.description,
    NEW.address,
    NEW.city,
    NEW.state,
    NEW.zip_code,
    NEW.contact_name,
    NEW.contact_position,
    NEW.contact_phone,
    NEW.password_hash,
    'basic', -- Plano básico
    'trial', -- Status de trial por 30 dias
    CURRENT_DATE, -- Início do trial
    CURRENT_DATE + INTERVAL '30 days', -- Fim do trial
    CURRENT_DATE + INTERVAL '30 days', -- Data de vencimento
    true, -- Ativa
    true  -- Verificada
  );
  
  -- Atualizar status na tabela de registros para 'approved'
  UPDATE public.rental_company_registrations 
  SET status = 'approved', updated_at = NOW()
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para processar automaticamente os cadastros
CREATE TRIGGER auto_approve_rental_company
  AFTER INSERT ON public.rental_company_registrations
  FOR EACH ROW
  EXECUTE FUNCTION process_rental_company_registration();

-- Inserir dados na tabela rental_companies existente também (para compatibilidade)
CREATE OR REPLACE FUNCTION sync_to_rental_companies()
RETURNS TRIGGER AS $$
BEGIN
  -- Inserir/atualizar na tabela rental_companies existente
  INSERT INTO public.rental_companies (
    id,
    company_name,
    cnpj,
    phone,
    address,
    email,
    plan,
    payment_status,
    due_date,
    is_active,
    verified,
    vehicle_count,
    drivers_count,
    registration_date,
    created_at,
    updated_at
  ) VALUES (
    NEW.id,
    NEW.company_name,
    NEW.cnpj,
    NEW.phone,
    NEW.address,
    NEW.email,
    NEW.plan,
    NEW.payment_status,
    NEW.due_date,
    NEW.is_active,
    NEW.verified,
    NEW.vehicle_count,
    NEW.drivers_count,
    NEW.registration_date,
    NEW.created_at,
    NEW.updated_at
  )
  ON CONFLICT (id) DO UPDATE SET
    company_name = EXCLUDED.company_name,
    cnpj = EXCLUDED.cnpj,
    phone = EXCLUDED.phone,
    address = EXCLUDED.address,
    email = EXCLUDED.email,
    plan = EXCLUDED.plan,
    payment_status = EXCLUDED.payment_status,
    due_date = EXCLUDED.due_date,
    is_active = EXCLUDED.is_active,
    verified = EXCLUDED.verified,
    vehicle_count = EXCLUDED.vehicle_count,
    drivers_count = EXCLUDED.drivers_count,
    registration_date = EXCLUDED.registration_date,
    updated_at = EXCLUDED.updated_at;
    
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para sincronizar com a tabela rental_companies
CREATE TRIGGER sync_approved_companies
  AFTER INSERT OR UPDATE ON public.approved_rental_companies
  FOR EACH ROW
  EXECUTE FUNCTION sync_to_rental_companies();
