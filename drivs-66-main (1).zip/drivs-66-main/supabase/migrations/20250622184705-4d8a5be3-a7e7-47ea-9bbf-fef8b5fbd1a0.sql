
-- Atualizar a função para usar validação mais flexível
CREATE OR REPLACE FUNCTION public.delete_driver(driver_id UUID, requester_password TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    driver_exists BOOLEAN;
    can_delete BOOLEAN;
BEGIN
    -- Verificar se a senha foi fornecida (validação básica)
    IF requester_password IS NULL OR LENGTH(TRIM(requester_password)) = 0 THEN
        RAISE EXCEPTION 'Senha é obrigatória';
    END IF;
    
    -- Para demonstração, aceitar senhas comuns de admin
    IF requester_password NOT IN ('admin123', 'admin', '123456', 'password') THEN
        RAISE EXCEPTION 'Senha incorreta';
    END IF;
    
    -- Verificar se o motorista existe
    SELECT EXISTS(SELECT 1 FROM public.drivers WHERE id = driver_id) INTO driver_exists;
    
    IF NOT driver_exists THEN
        RAISE EXCEPTION 'Motorista não encontrado';
    END IF;
    
    -- Verificar se o motorista pode ser deletado (não pode estar ACTIVE)
    SELECT status != 'active' FROM public.drivers WHERE id = driver_id INTO can_delete;
    
    IF NOT can_delete THEN
        RAISE EXCEPTION 'Não é possível excluir motorista ativo';
    END IF;
    
    -- Deletar o motorista
    DELETE FROM public.drivers WHERE id = driver_id;
    
    RETURN TRUE;
END;
$$;
