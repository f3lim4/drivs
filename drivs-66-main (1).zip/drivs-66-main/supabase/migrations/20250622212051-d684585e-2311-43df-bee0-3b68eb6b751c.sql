
-- Criar tabela para infrações de trânsito
CREATE TABLE public.violations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id UUID,
  vehicle_id UUID,
  driver_id UUID,
  company_id UUID NOT NULL,
  violation_type TEXT NOT NULL,
  location TEXT NOT NULL,
  date DATE NOT NULL,
  description TEXT NOT NULL,
  points INTEGER DEFAULT 0,
  amount NUMERIC(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  payment_deadline DATE,
  evidence_files TEXT[],
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT violations_status_check CHECK (status IN ('pending', 'paid', 'contested', 'resolved')),
  CONSTRAINT violations_points_check CHECK (points >= 0),
  CONSTRAINT violations_amount_check CHECK (amount >= 0)
);

-- Habilitar RLS
ALTER TABLE public.violations ENABLE ROW LEVEL SECURITY;

-- Política para locadoras verem apenas suas infrações
CREATE POLICY "Rental companies can view own violations" 
  ON public.violations 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'rental_company'
      AND company_id = auth.uid()
    )
  );

-- Política para locadoras criarem infrações
CREATE POLICY "Rental companies can create violations" 
  ON public.violations 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'rental_company'
      AND company_id = auth.uid()
    )
  );

-- Política para locadoras atualizarem suas infrações
CREATE POLICY "Rental companies can update own violations" 
  ON public.violations 
  FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'rental_company'
      AND company_id = auth.uid()
    )
  );

-- Política para admins e gestores verem todas as infrações
CREATE POLICY "Admins can view all violations" 
  ON public.violations 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role IN ('admin', 'manager', 'analyst')
    )
  );

-- Inserir dados de exemplo para teste
INSERT INTO public.violations (
  contract_id,
  vehicle_id, 
  driver_id,
  company_id,
  violation_type,
  location,
  date,
  description,
  points,
  amount,
  status,
  payment_deadline
) VALUES 
  (
    gen_random_uuid(),
    gen_random_uuid(),
    gen_random_uuid(),
    '550e8400-e29b-41d4-a716-446655440001', -- ID da locadora demo
    'Excesso de velocidade',
    'Av. Paulista, 1000 - São Paulo/SP',
    '2024-01-15',
    'Excesso de velocidade - 20km/h acima do limite permitido',
    4,
    195.23,
    'pending',
    '2024-02-15'
  ),
  (
    gen_random_uuid(),
    gen_random_uuid(),
    gen_random_uuid(),
    '550e8400-e29b-41d4-a716-446655440001',
    'Estacionamento irregular',
    'Rua Augusta, 500 - São Paulo/SP',
    '2024-01-20',
    'Estacionamento em local proibido durante horário de pico',
    3,
    130.16,
    'paid',
    '2024-02-20'
  );
