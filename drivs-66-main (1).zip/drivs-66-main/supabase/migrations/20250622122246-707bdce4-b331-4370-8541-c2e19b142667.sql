
-- Criar tabela para gestores e vistoriadores das locadoras
CREATE TABLE public.company_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.rental_companies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('manager', 'inspector')),
  active BOOLEAN NOT NULL DEFAULT true,
  permissions JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_login TIMESTAMP WITH TIME ZONE
);

-- Criar índices para performance
CREATE INDEX idx_company_users_company_id ON public.company_users(company_id);
CREATE INDEX idx_company_users_user_id ON public.company_users(user_id);
CREATE INDEX idx_company_users_role ON public.company_users(role);

-- Adicionar campos que faltam na tabela rental_companies
ALTER TABLE public.rental_companies 
ADD COLUMN IF NOT EXISTS plan TEXT DEFAULT 'basic' CHECK (plan IN ('basic', 'premium', 'enterprise')),
ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'pending' CHECK (payment_status IN ('paid', 'pending', 'overdue')),
ADD COLUMN IF NOT EXISTS due_date DATE,
ADD COLUMN IF NOT EXISTS drivers_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS registration_date DATE DEFAULT CURRENT_DATE,
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS email TEXT,
ADD COLUMN IF NOT EXISTS permissions JSONB;

-- Criar tabela para usuários admin do sistema
CREATE TABLE public.admin_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_login TIMESTAMP WITH TIME ZONE
);

-- Habilitar RLS nas novas tabelas
ALTER TABLE public.company_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- Policies para company_users
CREATE POLICY "Users can view company users from their company" 
  ON public.company_users 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.rental_companies rc 
      WHERE rc.id = company_users.company_id 
      AND rc.id = auth.uid()
    )
  );

CREATE POLICY "Company owners can manage their users" 
  ON public.company_users 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.rental_companies rc 
      WHERE rc.id = company_users.company_id 
      AND rc.id = auth.uid()
    )
  );

-- Policies para admin_users (apenas admins podem acessar)
CREATE POLICY "Only admins can view admin users" 
  ON public.admin_users 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );

CREATE POLICY "Only admins can manage admin users" 
  ON public.admin_users 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );
