
-- Adicionar campos para logo e outras configurações na tabela rental_companies
ALTER TABLE public.rental_companies 
ADD COLUMN IF NOT EXISTS logo_url TEXT,
ADD COLUMN IF NOT EXISTS website TEXT,
ADD COLUMN IF NOT EXISTS whatsapp TEXT,
ADD COLUMN IF NOT EXISTS emergency_phone TEXT,
ADD COLUMN IF NOT EXISTS cep TEXT,
ADD COLUMN IF NOT EXISTS city TEXT,
ADD COLUMN IF NOT EXISTS state TEXT,
ADD COLUMN IF NOT EXISTS description TEXT,
ADD COLUMN IF NOT EXISTS operating_hours TEXT;

-- Criar bucket para logos das locadoras
INSERT INTO storage.buckets (id, name, public)
VALUES ('company-logos', 'company-logos', true)
ON CONFLICT (id) DO NOTHING;

-- Criar política para permitir que locadoras façam upload de suas logos
CREATE POLICY "Rental companies can upload their logos" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'company-logos' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Criar política para permitir que locadoras atualizem suas logos
CREATE POLICY "Rental companies can update their logos" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'company-logos' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Criar política para permitir que todos vejam as logos (público)
CREATE POLICY "Anyone can view company logos" ON storage.objects
FOR SELECT USING (bucket_id = 'company-logos');

-- Criar política para permitir que locadoras deletem suas logos
CREATE POLICY "Rental companies can delete their logos" ON storage.objects
FOR DELETE USING (
  bucket_id = 'company-logos' AND
  auth.uid()::text = (storage.foldername(name))[1]
);
