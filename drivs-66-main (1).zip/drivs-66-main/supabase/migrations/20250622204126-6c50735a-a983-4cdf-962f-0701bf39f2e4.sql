
-- Adicionar política para permitir inserções na tabela approved_rental_companies
-- Isso é necessário para que o trigger possa inserir dados automaticamente
CREATE POLICY "Allow public inserts on approved_rental_companies" 
  ON public.approved_rental_companies 
  FOR INSERT 
  WITH CHECK (true);

-- Também vamos adicionar uma política para permitir inserções na tabela rental_company_registrations
-- para garantir que o cadastro funcione corretamente
DROP POLICY IF EXISTS "Allow public inserts on rental_company_registrations" ON public.rental_company_registrations;
CREATE POLICY "Allow public inserts on rental_company_registrations" 
  ON public.rental_company_registrations 
  FOR INSERT 
  WITH CHECK (true);

-- Permitir que qualquer um veja os registros pendentes (necessário para o processo)
DROP POLICY IF EXISTS "Allow public select on rental_company_registrations" ON public.rental_company_registrations;
CREATE POLICY "Allow public select on rental_company_registrations" 
  ON public.rental_company_registrations 
  FOR SELECT 
  USING (true);
