
-- Criar tabela de vistorias
CREATE TABLE public.inspections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  vehicle_id UUID REFERENCES public.rental_company_vehicles(id) NOT NULL,
  company_id UUID REFERENCES public.rental_companies(id) NOT NULL,
  driver_id UUID REFERENCES public.drivers(id),
  type TEXT NOT NULL DEFAULT 'Inicial',
  status TEXT NOT NULL DEFAULT 'pending',
  assigned_to TEXT NOT NULL DEFAULT 'driver',
  inspector TEXT NOT NULL DEFAULT 'Sistema',
  observations TEXT,
  photos_count INTEGER DEFAULT 0,
  inspection_date DATE NOT NULL DEFAULT CURRENT_DATE,
  contract_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;

-- Política para locadoras verem apenas suas vistorias
CREATE POLICY "Rental companies can view their own inspections" 
  ON public.inspections 
  FOR SELECT 
  USING (company_id = auth.uid());

-- Política para locadoras criarem vistorias
CREATE POLICY "Rental companies can create inspections" 
  ON public.inspections 
  FOR INSERT 
  WITH CHECK (company_id = auth.uid());

-- Política para locadoras atualizarem suas vistorias
CREATE POLICY "Rental companies can update their own inspections" 
  ON public.inspections 
  FOR UPDATE 
  USING (company_id = auth.uid());
