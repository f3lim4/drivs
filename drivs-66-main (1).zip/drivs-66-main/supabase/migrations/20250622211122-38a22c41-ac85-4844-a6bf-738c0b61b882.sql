
-- Primeiro, vamos verificar qual constraint está causando o problema e ajustar
-- Vamos remover a constraint existente e criar uma nova que aceite 'trial'
ALTER TABLE public.rental_companies 
DROP CONSTRAINT IF EXISTS rental_companies_payment_status_check;

-- Criar nova constraint que aceita os valores corretos incluindo 'trial'
ALTER TABLE public.rental_companies 
ADD CONSTRAINT rental_companies_payment_status_check 
CHECK (payment_status IN ('trial', 'paid', 'pending', 'overdue', 'cancelled'));

-- Alternativamente, se a constraint não permitir 'trial', vamos ajustar o trigger
-- para usar 'pending' em vez de 'trial' na tabela rental_companies
CREATE OR REPLACE FUNCTION public.sync_to_rental_companies()
RETURNS TRIGGER AS $$
BEGIN
  -- Inserir/atualizar na tabela rental_companies existente
  -- Mapear 'trial' para 'pending' para compatibilidade
  INSERT INTO public.rental_companies (
    id,
    company_name,
    cnpj,
    phone,
    address,
    email,
    plan,
    payment_status,
    due_date,
    is_active,
    verified,
    vehicle_count,
    drivers_count,
    registration_date,
    created_at,
    updated_at
  ) VALUES (
    NEW.id,
    NEW.company_name,
    NEW.cnpj,
    NEW.phone,
    NEW.address,
    NEW.email,
    NEW.plan,
    CASE 
      WHEN NEW.payment_status = 'trial' THEN 'pending'
      ELSE NEW.payment_status 
    END,
    NEW.due_date,
    NEW.is_active,
    NEW.verified,
    NEW.vehicle_count,
    NEW.drivers_count,
    NEW.registration_date,
    NEW.created_at,
    NEW.updated_at
  )
  ON CONFLICT (id) DO UPDATE SET
    company_name = EXCLUDED.company_name,
    cnpj = EXCLUDED.cnpj,
    phone = EXCLUDED.phone,
    address = EXCLUDED.address,
    email = EXCLUDED.email,
    plan = EXCLUDED.plan,
    payment_status = EXCLUDED.payment_status,
    due_date = EXCLUDED.due_date,
    is_active = EXCLUDED.is_active,
    verified = EXCLUDED.verified,
    vehicle_count = EXCLUDED.vehicle_count,
    drivers_count = EXCLUDED.drivers_count,
    registration_date = EXCLUDED.registration_date,
    updated_at = EXCLUDED.updated_at;
    
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
