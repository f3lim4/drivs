
-- Primeiro, vamos remover todas as tabelas existentes e recriar do zero
DROP TABLE IF EXISTS public.violations CASCADE;
DROP TABLE IF EXISTS public.payments CASCADE;
DROP TABLE IF EXISTS public.contracts CASCADE;
DROP TABLE IF EXISTS public.inspections CASCADE;
DROP TABLE IF EXISTS public.maintenance CASCADE;
DROP TABLE IF EXISTS public.vehicles CASCADE;
DROP TABLE IF EXISTS public.drivers CASCADE;
DROP TABLE IF EXISTS public.rental_companies CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;
DROP TABLE IF EXISTS public.activities CASCADE;
DROP TABLE IF EXISTS public.site_settings CASCADE;

-- Criar tabela de perfis (essencial para autenticação)
CREATE TABLE public.profiles (
  id uuid REFERENCES auth.users NOT NULL PRIMARY KEY,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL,
  full_name text,
  avatar_url text,
  role text DEFAULT 'driver'::text NOT NULL
);

-- Criar tabela de locadoras
CREATE TABLE public.rental_companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  cnpj text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  logo text,
  verified boolean DEFAULT false,
  vehicle_count integer DEFAULT 0,
  rating numeric DEFAULT 0,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Criar tabela de motoristas
CREATE TABLE public.drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  cpf text NOT NULL,
  rg text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  cnh text NOT NULL,
  cnh_expires date NOT NULL,
  status text DEFAULT 'pending'::text NOT NULL,
  available boolean DEFAULT false,
  rating numeric DEFAULT 0,
  violations integer DEFAULT 0,
  profile_photo text,
  app_screenshot text,
  address_proof text,
  rejection_reason text,
  rejection_date timestamp with time zone,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Criar tabela de veículos
CREATE TABLE public.vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES public.rental_companies(id) NOT NULL,
  plate text NOT NULL,
  brand text NOT NULL,
  model text NOT NULL,
  color text NOT NULL,
  year integer NOT NULL,
  status text DEFAULT 'available'::text NOT NULL,
  daily_rate numeric NOT NULL,
  photo text,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Criar tabela de contratos
CREATE TABLE public.contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid REFERENCES public.drivers(id) NOT NULL,
  company_id uuid REFERENCES public.rental_companies(id) NOT NULL,
  vehicle_id uuid REFERENCES public.vehicles(id) NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  monthly_amount numeric NOT NULL,
  status text DEFAULT 'pending'::text NOT NULL,
  document_url text,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Criar tabela de configurações do site
CREATE TABLE public.site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_title text DEFAULT 'DRIVS - Sistema de Gestão'::text NOT NULL,
  site_description text DEFAULT 'Plataforma para gestão de locação de veículos'::text,
  site_keywords text DEFAULT 'locação, veículos, motoristas'::text,
  site_logo text,
  primary_color text DEFAULT '#3b82f6'::text,
  secondary_color text DEFAULT '#1e40af'::text,
  accent_color text DEFAULT '#60a5fa'::text,
  banner_images text[],
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Habilitar RLS em todas as tabelas
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rental_companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para profiles (todos podem ver e editar seu próprio perfil)
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Políticas RLS para outras tabelas (acesso público para demonstração)
CREATE POLICY "Allow all access to rental_companies" ON public.rental_companies
  FOR ALL USING (true);

CREATE POLICY "Allow all access to drivers" ON public.drivers
  FOR ALL USING (true);

CREATE POLICY "Allow all access to vehicles" ON public.vehicles
  FOR ALL USING (true);

CREATE POLICY "Allow all access to contracts" ON public.contracts
  FOR ALL USING (true);

CREATE POLICY "Allow all access to site_settings" ON public.site_settings
  FOR ALL USING (true);

-- Inserir configurações padrão do site
INSERT INTO public.site_settings (site_title, site_description) 
VALUES ('DRIVS - Sistema de Gestão', 'Plataforma para gestão de locação de veículos');

-- Inserir dados de exemplo para locadoras
INSERT INTO public.rental_companies (id, company_name, cnpj, phone, address, verified, vehicle_count, rating) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'Auto Rental Plus', '12.345.678/0001-90', '(11) 3456-7890', 'Av. Paulista, 1000 - São Paulo, SP', true, 25, 4.5),
('550e8400-e29b-41d4-a716-446655440002', 'Speed Car Rental', '98.765.432/0001-10', '(11) 2345-6789', 'Rua Augusta, 500 - São Paulo, SP', true, 18, 4.2),
('550e8400-e29b-41d4-a716-446655440003', 'Premium Motors', '11.222.333/0001-44', '(11) 1234-5678', 'Av. Faria Lima, 2000 - São Paulo, SP', true, 30, 4.8);

-- Função para criar perfil automaticamente quando um usuário se registra
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', COALESCE(new.raw_user_meta_data->>'role', 'driver'));
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para criar perfil automaticamente
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
