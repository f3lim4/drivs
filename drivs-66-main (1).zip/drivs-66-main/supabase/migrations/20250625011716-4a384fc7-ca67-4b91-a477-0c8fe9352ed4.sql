
-- Primeiro, atualizar registros existentes que têm CNH NULL
UPDATE public.driver_registrations 
SET cnh = COALESCE(cnh, '') 
WHERE cnh IS NULL;

-- Atualizar registros existentes que têm zip_code NULL
UPDATE public.driver_registrations 
SET zip_code = COALESCE(zip_code, '') 
WHERE zip_code IS NULL;

-- Agora aplicar as restrições NOT NULL
ALTER TABLE public.driver_registrations 
ALTER COLUMN zip_code SET NOT NULL,
ALTER COLUMN cnh SET NOT NULL;

-- Adicionar comentários para documentar os campos
COMMENT ON COLUMN public.driver_registrations.zip_code IS 'CEP do motorista';
COMMENT ON COLUMN public.driver_registrations.cnh IS 'Número da CNH do motorista';
COMMENT ON COLUMN public.driver_registrations.cnh_expires IS 'Data de vencimento da CNH';

-- Atualizar a tabela drivers para garantir consistência
ALTER TABLE public.drivers 
ADD COLUMN IF NOT EXISTS zip_code TEXT;

-- Atualizar registros existentes na tabela drivers que têm CNH NULL
UPDATE public.drivers 
SET cnh = COALESCE(cnh, '') 
WHERE cnh IS NULL;

-- Aplicar restrição NOT NULL na tabela drivers
ALTER TABLE public.drivers 
ALTER COLUMN cnh SET NOT NULL;

-- Adicionar comentários para a tabela drivers também
COMMENT ON COLUMN public.drivers.zip_code IS 'CEP do motorista';
COMMENT ON COLUMN public.drivers.cnh IS 'Número da CNH do motorista';
COMMENT ON COLUMN public.drivers.cnh_expires IS 'Data de vencimento da CNH';

-- Criar índices para melhorar performance nas consultas
CREATE INDEX IF NOT EXISTS idx_driver_registrations_zip_code ON public.driver_registrations(zip_code);
CREATE INDEX IF NOT EXISTS idx_driver_registrations_cnh ON public.driver_registrations(cnh);
CREATE INDEX IF NOT EXISTS idx_drivers_zip_code ON public.drivers(zip_code);
CREATE INDEX IF NOT EXISTS idx_drivers_cnh ON public.drivers(cnh);
