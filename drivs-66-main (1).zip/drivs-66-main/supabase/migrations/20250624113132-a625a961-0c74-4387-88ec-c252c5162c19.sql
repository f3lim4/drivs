
-- Verificar usuários na tabela auth.users e seus perfis
SELECT 
  u.id,
  u.email,
  u.email_confirmed_at,
  u.created_at,
  p.full_name,
  p.role
FROM auth.users u
LEFT JOIN public.profiles p ON p.id = u.id
ORDER BY u.created_at DESC
LIMIT 10;

-- Verificar locadoras registradas
SELECT 
  id,
  company_name,
  email,
  created_at
FROM public.rental_companies
ORDER BY created_at DESC
LIMIT 10;

-- Verificar motoristas registrados
SELECT 
  id,
  full_name,
  created_at
FROM public.drivers
ORDER BY created_at DESC
LIMIT 10;
