
-- Criar tabela de manutenções
CREATE TABLE public.maintenances (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL,
  vehicle_id UUID,
  driver_id UUID,
  maintenance_type TEXT NOT NULL,
  description TEXT NOT NULL,
  scheduled_date DATE,
  completed_date DATE,
  completed_time TEXT,
  estimated_cost NUMERIC DEFAULT 0,
  actual_cost NUMERIC DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'scheduled',
  location_id TEXT,
  odometer INTEGER DEFAULT 0,
  notes TEXT,
  items JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de locais/oficinas de manutenção
CREATE TABLE public.maintenance_locations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL,
  name TEXT NOT NULL,
  address TEXT,
  phone TEXT,
  email TEXT,
  specialties TEXT[],
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de tipos de manutenção
CREATE TABLE public.maintenance_types (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID,
  name TEXT NOT NULL,
  description TEXT,
  is_system_default BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Inserir tipos de manutenção padrão do sistema
INSERT INTO public.maintenance_types (name, description, is_system_default, company_id) VALUES
('preventiva', 'Manutenção preventiva programada', true, NULL),
('corretiva', 'Manutenção corretiva para reparo', true, NULL),
('revisao', 'Revisão periódica do veículo', true, NULL),
('pneus', 'Manutenção relacionada a pneus', true, NULL),
('oleo', 'Troca de óleo e filtros', true, NULL);

-- Adicionar RLS (Row Level Security)
ALTER TABLE public.maintenances ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maintenance_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maintenance_types ENABLE ROW LEVEL SECURITY;

-- Políticas para maintenances
CREATE POLICY "Rental companies can view their own maintenances" 
  ON public.maintenances 
  FOR SELECT 
  USING (
    company_id = auth.uid() OR
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Rental companies can create their own maintenances" 
  ON public.maintenances 
  FOR INSERT 
  WITH CHECK (company_id = auth.uid());

CREATE POLICY "Rental companies can update their own maintenances" 
  ON public.maintenances 
  FOR UPDATE 
  USING (company_id = auth.uid());

CREATE POLICY "Rental companies can delete their own maintenances" 
  ON public.maintenances 
  FOR DELETE 
  USING (company_id = auth.uid());

-- Políticas para maintenance_locations
CREATE POLICY "Rental companies can view their own locations" 
  ON public.maintenance_locations 
  FOR SELECT 
  USING (
    company_id = auth.uid() OR
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Rental companies can create their own locations" 
  ON public.maintenance_locations 
  FOR INSERT 
  WITH CHECK (company_id = auth.uid());

CREATE POLICY "Rental companies can update their own locations" 
  ON public.maintenance_locations 
  FOR UPDATE 
  USING (company_id = auth.uid());

CREATE POLICY "Rental companies can delete their own locations" 
  ON public.maintenance_locations 
  FOR DELETE 
  USING (company_id = auth.uid());

-- Políticas para maintenance_types
CREATE POLICY "Everyone can view maintenance types" 
  ON public.maintenance_types 
  FOR SELECT 
  USING (
    is_system_default = true OR 
    company_id = auth.uid() OR
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Rental companies can create their own maintenance types" 
  ON public.maintenance_types 
  FOR INSERT 
  WITH CHECK (company_id = auth.uid());

CREATE POLICY "Rental companies can update their own maintenance types" 
  ON public.maintenance_types 
  FOR UPDATE 
  USING (company_id = auth.uid());

CREATE POLICY "Rental companies can delete their own maintenance types" 
  ON public.maintenance_types 
  FOR DELETE 
  USING (company_id = auth.uid());

-- Adicionar função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar triggers para atualizar updated_at
CREATE TRIGGER handle_maintenances_updated_at
  BEFORE UPDATE ON public.maintenances
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER handle_maintenance_locations_updated_at
  BEFORE UPDATE ON public.maintenance_locations
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
