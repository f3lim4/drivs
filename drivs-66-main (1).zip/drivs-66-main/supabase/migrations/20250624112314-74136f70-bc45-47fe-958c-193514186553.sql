
-- Verificar políticas existentes e criar apenas as que não existem

-- Criar política para inserção se não existir
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'profiles' 
        AND policyname = 'Users can insert own profile'
    ) THEN
        CREATE POLICY "Users can insert own profile" ON public.profiles
        FOR INSERT WITH CHECK (auth.uid() = id);
    END IF;
END $$;

-- Criar política para atualização se não existir
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'profiles' 
        AND policyname = 'Users can update own profile'
    ) THEN
        CREATE POLICY "Users can update own profile" ON public.profiles
        FOR UPDATE USING (auth.uid() = id);
    END IF;
END $$;

-- Habilitar RLS e criar políticas para tabela drivers
ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;

DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'drivers' 
        AND policyname = 'Users can view own driver data'
    ) THEN
        CREATE POLICY "Users can view own driver data" ON public.drivers
        FOR SELECT USING (auth.uid() = id);
    END IF;
END $$;

DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'drivers' 
        AND policyname = 'Users can insert own driver data'
    ) THEN
        CREATE POLICY "Users can insert own driver data" ON public.drivers
        FOR INSERT WITH CHECK (auth.uid() = id);
    END IF;
END $$;

DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'drivers' 
        AND policyname = 'Users can update own driver data'
    ) THEN
        CREATE POLICY "Users can update own driver data" ON public.drivers
        FOR UPDATE USING (auth.uid() = id);
    END IF;
END $$;

-- Habilitar RLS e criar políticas para tabela rental_companies
ALTER TABLE public.rental_companies ENABLE ROW LEVEL SECURITY;

DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'rental_companies' 
        AND policyname = 'Users can view own company data'
    ) THEN
        CREATE POLICY "Users can view own company data" ON public.rental_companies
        FOR SELECT USING (auth.uid() = id);
    END IF;
END $$;

DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'rental_companies' 
        AND policyname = 'Users can insert own company data'
    ) THEN
        CREATE POLICY "Users can insert own company data" ON public.rental_companies
        FOR INSERT WITH CHECK (auth.uid() = id);
    END IF;
END $$;

DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'rental_companies' 
        AND policyname = 'Users can update own company data'
    ) THEN
        CREATE POLICY "Users can update own company data" ON public.rental_companies
        FOR UPDATE USING (auth.uid() = id);
    END IF;
END $$;
