
-- Primeiro, vamos remover as políticas existentes que estão causando o problema
DROP POLICY IF EXISTS "Locadoras podem ver seus próprios locais" ON public.maintenance_locations;
DROP POLICY IF EXISTS "Locadoras podem criar seus próprios locais" ON public.maintenance_locations;
DROP POLICY IF EXISTS "Locadoras podem atualizar seus próprios locais" ON public.maintenance_locations;
DROP POLICY IF EXISTS "Locadoras podem deletar seus próprios locais" ON public.maintenance_locations;

-- Criar função para verificar se é modo demo ou empresa válida (similar à que já existe para veículos)
CREATE OR REPLACE FUNCTION public.is_demo_mode_or_valid_maintenance_company(company_id_param UUID)
RETURNS BOOLEAN AS $$
BEGIN
  -- Se não há usuário autenticado (modo demo), permitir
  IF auth.uid() IS NULL THEN
    RETURN TRUE;
  END IF;
  
  -- Se há usuário autenticado, verificar se é a mesma empresa ou admin
  RETURN (
    auth.uid() = company_id_param OR
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Criar políticas mais flexíveis que funcionem tanto com auth quanto sem (modo demo)
CREATE POLICY "Companies can view maintenance locations (demo compatible)" 
  ON public.maintenance_locations 
  FOR SELECT 
  USING (public.is_demo_mode_or_valid_maintenance_company(company_id));

CREATE POLICY "Companies can create maintenance locations (demo compatible)" 
  ON public.maintenance_locations 
  FOR INSERT 
  WITH CHECK (public.is_demo_mode_or_valid_maintenance_company(company_id));

CREATE POLICY "Companies can update maintenance locations (demo compatible)" 
  ON public.maintenance_locations 
  FOR UPDATE 
  USING (public.is_demo_mode_or_valid_maintenance_company(company_id));

CREATE POLICY "Companies can delete maintenance locations (demo compatible)" 
  ON public.maintenance_locations 
  FOR DELETE 
  USING (public.is_demo_mode_or_valid_maintenance_company(company_id));
