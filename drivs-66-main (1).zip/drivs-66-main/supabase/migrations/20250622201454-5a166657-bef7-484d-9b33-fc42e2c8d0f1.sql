
-- Criar tabela para armazenar dados de cadastro de locadoras
CREATE TABLE IF NOT EXISTS public.rental_company_registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name TEXT NOT NULL,
  trading_name TEXT,
  cnpj TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  website_url TEXT,
  description TEXT,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  zip_code TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  contact_position TEXT,
  contact_phone TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Criar tabela para armazenar dados de cadastro de motoristas
CREATE TABLE IF NOT EXISTS public.driver_registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  cpf TEXT NOT NULL,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  zip_code TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  referral_company_id UUID,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar RLS nas tabelas
ALTER TABLE public.rental_company_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_registrations ENABLE ROW LEVEL SECURITY;

-- Políticas para permitir inserção de novos cadastros (modo demo)
CREATE POLICY "Anyone can create rental company registration" 
  ON public.rental_company_registrations 
  FOR INSERT 
  WITH CHECK (true);

CREATE POLICY "Anyone can create driver registration" 
  ON public.driver_registrations 
  FOR INSERT 
  WITH CHECK (true);

-- Políticas para admins visualizarem os cadastros
CREATE POLICY "Admins can view rental company registrations" 
  ON public.rental_company_registrations 
  FOR SELECT 
  USING (
    auth.uid() IS NULL OR 
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );

CREATE POLICY "Admins can view driver registrations" 
  ON public.driver_registrations 
  FOR SELECT 
  USING (
    auth.uid() IS NULL OR 
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );
