
-- Add missing cnh and cnh_expires columns to driver_registrations table
ALTER TABLE public.driver_registrations 
ADD COLUMN IF NOT EXISTS cnh TEXT,
ADD COLUMN IF NOT EXISTS cnh_expires DATE;
