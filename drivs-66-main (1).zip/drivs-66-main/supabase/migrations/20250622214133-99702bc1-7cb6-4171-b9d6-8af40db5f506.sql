
-- Drop existing policies that may be causing issues
DROP POLICY IF EXISTS "Rental companies can upload their logos" ON storage.objects;
DROP POLICY IF EXISTS "Rental companies can update their logos" ON storage.objects;
DROP POLICY IF EXISTS "Rental companies can delete their logos" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can view company logos" ON storage.objects;

-- Create corrected policies for company logo uploads
-- Policy to allow rental companies to insert their logos
CREATE POLICY "Enable upload for authenticated users on company-logos" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'company-logos' AND 
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy to allow rental companies to update their logos
CREATE POLICY "Enable update for authenticated users on company-logos" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'company-logos' AND 
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy to allow rental companies to delete their logos
CREATE POLICY "Enable delete for authenticated users on company-logos" ON storage.objects
FOR DELETE USING (
  bucket_id = 'company-logos' AND 
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- Policy to allow public viewing of company logos
CREATE POLICY "Enable public read access on company-logos" ON storage.objects
FOR SELECT USING (bucket_id = 'company-logos');
