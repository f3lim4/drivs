
-- First, let's check and fix the RLS policies for rental_company_vehicles table

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Rental companies can view their own vehicles" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Rental companies can create their own vehicles" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Rental companies can update their own vehicles" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Rental companies can delete their own vehicles" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Admins can view all vehicles" ON public.rental_company_vehicles;

-- Create a security definer function to get the current user's role and company access
CREATE OR REPLACE FUNCTION public.get_user_company_access()
RETURNS TABLE(company_id UUID, user_role TEXT) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    CASE 
      WHEN p.role = 'rental_company' THEN auth.uid()
      WHEN p.role = 'admin' THEN NULL::UUID -- Admins can access all
      ELSE NULL::UUID
    END as company_id,
    p.role as user_role
  FROM public.profiles p 
  WHERE p.id = auth.uid();
END;
$$;

-- Create new RLS policies using the security definer function

-- Policy for SELECT (viewing vehicles)
CREATE POLICY "Users can view vehicles based on role" 
  ON public.rental_company_vehicles 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.get_user_company_access() access
      WHERE access.user_role = 'admin' 
      OR access.company_id = rental_company_vehicles.company_id
    )
  );

-- Policy for INSERT (creating vehicles)
CREATE POLICY "Users can create vehicles based on role" 
  ON public.rental_company_vehicles 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.get_user_company_access() access
      WHERE access.user_role = 'admin' 
      OR access.company_id = rental_company_vehicles.company_id
    )
  );

-- Policy for UPDATE (updating vehicles)
CREATE POLICY "Users can update vehicles based on role" 
  ON public.rental_company_vehicles 
  FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM public.get_user_company_access() access
      WHERE access.user_role = 'admin' 
      OR access.company_id = rental_company_vehicles.company_id
    )
  );

-- Policy for DELETE (deleting vehicles)
CREATE POLICY "Users can delete vehicles based on role" 
  ON public.rental_company_vehicles 
  FOR DELETE 
  USING (
    EXISTS (
      SELECT 1 FROM public.get_user_company_access() access
      WHERE access.user_role = 'admin' 
      OR access.company_id = rental_company_vehicles.company_id
    )
  );
