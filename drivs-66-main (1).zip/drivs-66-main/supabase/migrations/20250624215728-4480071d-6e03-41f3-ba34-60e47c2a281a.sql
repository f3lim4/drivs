
-- Insert a test driver registration for the email crivelari.junior@hotmail.com
INSERT INTO driver_registrations (
  full_name,
  email, 
  phone,
  cpf,
  address,
  city,
  state,
  zip_code,
  password_hash,
  status,
  date_of_birth
) VALUES (
  'Crivelari Junior',
  'crivelari.junior@hotmail.com',
  '11999999999',
  '12345678901',
  'Rua Teste, 123',
  'São Paulo',
  'SP', 
  '01234-567',
  '123456', -- Simple password for testing
  'approved',
  '1990-01-01'
);

-- Also insert a test rental company registration  
INSERT INTO rental_company_registrations (
  company_name,
  trading_name,
  cnpj,
  email,
  phone,
  contact_phone,
  address,
  city,
  state,
  zip_code,
  contact_name,
  contact_position,
  password_hash,
  status
) VALUES (
  'Empresa Teste Ltda',
  'Empresa Teste',
  '12345678000123',
  'empresa@teste.com',
  '11988887777',
  '11988887777',
  'Av. Teste, 456',
  'São Paulo',
  'SP',
  '01234-567',
  'João da Silva',
  'Gerente',
  'senha123', -- Simple password for testing
  'approved'
);
