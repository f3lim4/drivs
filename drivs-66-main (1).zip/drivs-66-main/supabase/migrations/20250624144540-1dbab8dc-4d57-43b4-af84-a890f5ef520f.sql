
-- Adicionar constraint de CPF único na tabela drivers se não existir
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'drivers_cpf_key'
    ) THEN
        ALTER TABLE public.drivers 
        ADD CONSTRAINT drivers_cpf_key UNIQUE (cpf);
    END IF;
END $$;

-- Adicionar constraint de CPF único na tabela driver_registrations se não existir
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'driver_registrations_cpf_key'
    ) THEN
        ALTER TABLE public.driver_registrations 
        ADD CONSTRAINT driver_registrations_cpf_key UNIQUE (cpf);
    END IF;
END $$;
