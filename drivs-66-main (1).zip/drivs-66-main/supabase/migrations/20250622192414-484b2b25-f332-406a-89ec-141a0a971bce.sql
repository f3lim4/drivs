
-- Vamos corrigir com o valor correto para payment_status
INSERT INTO public.rental_companies (
  id,
  company_name,
  cnpj,
  phone,
  address,
  email,
  plan,
  payment_status,
  verified,
  is_active
) VALUES (
  '550e8400-e29b-41d4-a716-446655440001',
  'Auto Rental Plus',
  '12.345.678/0001-90',
  '(11) 99999-9999',
  'Rua das Locadoras, 123 - São Paulo, SP',
  'contato@autorentalplus.com',
  'premium',
  'paid',
  true,
  true
) ON CONFLICT (id) DO NOTHING;

-- Agora atualizar os veículos para usar o ID correto da locadora
UPDATE public.rental_company_vehicles 
SET company_id = '550e8400-e29b-41d4-a716-446655440001'
WHERE company_id = '550e8400-e29b-41d4-a716-446655440001' OR brand IN ('Toyota', 'Honda', 'Volkswagen', 'Chevrolet', 'Fiat');
