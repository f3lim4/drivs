
-- Criar função RPC para atualizar status de motorista com bypass de RLS
CREATE OR REPLACE FUNCTION public.update_driver_status(
  driver_id UUID,
  new_status TEXT,
  table_name TEXT,
  user_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  rows_affected INTEGER;
  existing_record RECORD;
BEGIN
  -- Log da tentativa
  RAISE NOTICE 'Tentando atualizar motorista % na tabela % para status %', driver_id, table_name, new_status;
  
  -- Verificar se o usuário tem permissão
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = user_id 
    AND role IN ('rental_company', 'admin', 'analyst')
  ) THEN
    RAISE EXCEPTION 'Usuário sem permissão para esta operação';
  END IF;
  
  -- Verificar se o registro existe e se o usuário tem acesso
  IF table_name = 'driver_registrations' THEN
    SELECT * INTO existing_record
    FROM public.driver_registrations
    WHERE id = driver_id;
    
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Registro não encontrado na tabela driver_registrations';
    END IF;
    
    -- Verificar se é rental_company e se tem acesso a este motorista
    IF EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = user_id AND role = 'rental_company'
    ) AND existing_record.referral_company_id != user_id THEN
      RAISE EXCEPTION 'Usuário não tem permissão para alterar este motorista';
    END IF;
    
    -- Executar a atualização
    UPDATE public.driver_registrations
    SET status = new_status, updated_at = NOW()
    WHERE id = driver_id;
    
    GET DIAGNOSTICS rows_affected = ROW_COUNT;
    
  ELSIF table_name = 'drivers' THEN
    SELECT * INTO existing_record
    FROM public.drivers
    WHERE id = driver_id;
    
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Registro não encontrado na tabela drivers';
    END IF;
    
    -- Verificar se é rental_company e se tem acesso a este motorista
    IF EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = user_id AND role = 'rental_company'
    ) AND existing_record.company_id != user_id THEN
      RAISE EXCEPTION 'Usuário não tem permissão para alterar este motorista';
    END IF;
    
    -- Executar a atualização
    UPDATE public.drivers
    SET status = new_status, updated_at = NOW()
    WHERE id = driver_id;
    
    GET DIAGNOSTICS rows_affected = ROW_COUNT;
    
  ELSE
    RAISE EXCEPTION 'Nome de tabela inválido: %', table_name;
  END IF;
  
  -- Log do resultado
  RAISE NOTICE 'Linhas afetadas: %', rows_affected;
  
  RETURN rows_affected > 0;
END;
$$;

-- Conceder permissão para usuários autenticados executarem a função
GRANT EXECUTE ON FUNCTION public.update_driver_status TO authenticated;
