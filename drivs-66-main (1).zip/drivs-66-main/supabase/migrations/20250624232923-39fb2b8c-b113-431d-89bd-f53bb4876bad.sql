
-- Adicionar colunas para documentos na tabela driver_registrations (somente as que não existem)
ALTER TABLE public.driver_registrations 
ADD COLUMN IF NOT EXISTS cnh_document TEXT,
ADD COLUMN IF NOT EXISTS address_proof TEXT,
ADD COLUMN IF NOT EXISTS selfie_document TEXT,
ADD COLUMN IF NOT EXISTS app_profile_screenshot TEXT;

-- Adicionar colunas para documentos na tabela drivers (somente as que não existem)
ALTER TABLE public.drivers 
ADD COLUMN IF NOT EXISTS cnh_document TEXT,
ADD COLUMN IF NOT EXISTS selfie_document TEXT,
ADD COLUMN IF NOT EXISTS app_profile_screenshot TEXT;
