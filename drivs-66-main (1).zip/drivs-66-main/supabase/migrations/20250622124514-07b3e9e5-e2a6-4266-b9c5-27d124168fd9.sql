
-- Criar tabela de veículos para locadoras
CREATE TABLE public.rental_company_vehicles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.rental_companies(id) ON DELETE CASCADE,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  plate TEXT NOT NULL UNIQUE,
  year INTEGER NOT NULL,
  color TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'rented', 'maintenance', 'stopped', 'damaged', 'sold')),
  vehicle_type TEXT NOT NULL,
  fuel_type TEXT,
  transmission_type TEXT NOT NULL,
  mileage INTEGER DEFAULT 0,
  weekly_value DECIMAL(10,2) NOT NULL,
  deposit_value DECIMAL(10,2) NOT NULL,
  vehicle_value DECIMAL(10,2),
  is_financed BOOLEAN DEFAULT false,
  monthly_installment DECIMAL(10,2),
  monthly_insurance DECIMAL(10,2),
  monthly_tracker DECIMAL(10,2) DEFAULT 45,
  ipva_value DECIMAL(10,2),
  km_type TEXT NOT NULL DEFAULT 'unlimited' CHECK (km_type IN ('limited', 'unlimited')),
  km_limit INTEGER,
  licensing_status TEXT DEFAULT 'up_to_date' CHECK (licensing_status IN ('up_to_date', 'overdue')),
  document_expiry DATE,
  maintenance_responsibility TEXT DEFAULT 'rental_company' CHECK (maintenance_responsibility IN ('rental_company', 'fifty_fifty', 'driver')),
  allow_reservation BOOLEAN DEFAULT true,
  description TEXT,
  images TEXT[],
  renavam TEXT,
  chassi TEXT,
  licensing_expiry DATE,
  last_revision_km INTEGER,
  observations TEXT,
  driver_id UUID REFERENCES public.drivers(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.rental_company_vehicles ENABLE ROW LEVEL SECURITY;

-- Política para locadoras verem apenas seus veículos
CREATE POLICY "Rental companies can view their own vehicles" 
  ON public.rental_company_vehicles 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.rental_companies rc 
      WHERE rc.id = rental_company_vehicles.company_id 
      AND rc.id = auth.uid()
    )
  );

-- Política para locadoras criarem veículos
CREATE POLICY "Rental companies can create their own vehicles" 
  ON public.rental_company_vehicles 
  FOR INSERT 
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.rental_companies rc 
      WHERE rc.id = rental_company_vehicles.company_id 
      AND rc.id = auth.uid()
    )
  );

-- Política para locadoras atualizarem seus veículos
CREATE POLICY "Rental companies can update their own vehicles" 
  ON public.rental_company_vehicles 
  FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM public.rental_companies rc 
      WHERE rc.id = rental_company_vehicles.company_id 
      AND rc.id = auth.uid()
    )
  );

-- Política para locadoras excluírem seus veículos
CREATE POLICY "Rental companies can delete their own vehicles" 
  ON public.rental_company_vehicles 
  FOR DELETE 
  USING (
    EXISTS (
      SELECT 1 FROM public.rental_companies rc 
      WHERE rc.id = rental_company_vehicles.company_id 
      AND rc.id = auth.uid()
    )
  );

-- Política para admins verem todos os veículos
CREATE POLICY "Admins can view all vehicles" 
  ON public.rental_company_vehicles 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );

-- Índices para performance
CREATE INDEX idx_rental_company_vehicles_company_id ON public.rental_company_vehicles(company_id);
CREATE INDEX idx_rental_company_vehicles_status ON public.rental_company_vehicles(status);
CREATE INDEX idx_rental_company_vehicles_plate ON public.rental_company_vehicles(plate);
