
-- Função para deletar motorista (apenas para usuários autorizados)
CREATE OR REPLACE FUNCTION public.delete_driver(driver_id UUID, requester_password TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    driver_exists BOOLEAN;
    can_delete BOOLEAN;
BEGIN
    -- Verificar se a senha está correta (simulação simples)
    IF requester_password != 'admin123' THEN
        RAISE EXCEPTION 'Senha incorreta';
    END IF;
    
    -- Verificar se o motorista existe
    SELECT EXISTS(SELECT 1 FROM public.drivers WHERE id = driver_id) INTO driver_exists;
    
    IF NOT driver_exists THEN
        RAISE EXCEPTION 'Motorista não encontrado';
    END IF;
    
    -- Verificar se o motorista pode ser deletado (não pode estar ACTIVE)
    SELECT status != 'active' FROM public.drivers WHERE id = driver_id INTO can_delete;
    
    IF NOT can_delete THEN
        RAISE EXCEPTION 'Não é possível excluir motorista ativo';
    END IF;
    
    -- Deletar o motorista
    DELETE FROM public.drivers WHERE id = driver_id;
    
    RETURN TRUE;
END;
$$;

-- Função para obter motoristas por empresa
CREATE OR REPLACE FUNCTION public.get_drivers_by_company(company_id UUID)
RETURNS TABLE (
    id UUID,
    full_name TEXT,
    cpf TEXT,
    rg TEXT,
    phone TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    cnh TEXT,
    cnh_expires DATE,
    status TEXT,
    available BOOLEAN,
    rating NUMERIC,
    violations INTEGER,
    created_at TIMESTAMP WITH TIME ZONE,
    updated_at TIMESTAMP WITH TIME ZONE,
    profile_photo TEXT,
    app_screenshot TEXT,
    address_proof TEXT,
    rejection_reason TEXT,
    rejection_date TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        d.id,
        d.full_name,
        d.cpf,
        d.rg,
        d.phone,
        d.address,
        d.city,
        d.state,
        d.cnh,
        d.cnh_expires,
        d.status,
        d.available,
        d.rating,
        d.violations,
        d.created_at,
        d.updated_at,
        d.profile_photo,
        d.app_screenshot,
        d.address_proof,
        d.rejection_reason,
        d.rejection_date
    FROM public.drivers d
    WHERE d.id IN (
        -- Aqui você pode adicionar lógica para associar motoristas a empresas
        -- Por enquanto, retorna todos os motoristas para demonstração
        SELECT d2.id FROM public.drivers d2
    );
END;
$$;

-- Inserir alguns motoristas de exemplo se não existirem
DO $$
BEGIN
    -- Verificar se já existem motoristas
    IF NOT EXISTS (SELECT 1 FROM public.drivers LIMIT 1) THEN
        INSERT INTO public.drivers (
            id,
            full_name,
            cpf,
            rg,
            phone,
            address,
            city,
            state,
            cnh,
            cnh_expires,
            status,
            available,
            rating,
            violations
        ) VALUES 
        (
            gen_random_uuid(),
            'João Silva Santos',
            '123.456.789-00',
            '12.345.678-9',
            '(11) 99999-9999',
            'Rua das Flores, 123',
            'São Paulo',
            'SP',
            '12345678901',
            '2025-12-31',
            'approved',
            true,
            4.8,
            0
        ),
        (
            gen_random_uuid(),
            'Maria Oliveira Costa',
            '987.654.321-00',
            '98.765.432-1',
            '(11) 88888-8888',
            'Av. Paulista, 456',
            'São Paulo',
            'SP',
            '10987654321',
            '2025-06-30',
            'approved',
            true,
            4.9,
            0
        ),
        (
            gen_random_uuid(),
            'Carlos Roberto Lima',
            '456.789.123-00',
            '45.678.912-3',
            '(11) 77777-7777',
            'Rua Augusta, 789',
            'São Paulo',
            'SP',
            '98765432101',
            '2025-09-15',
            'deactivated',
            false,
            4.7,
            2
        );
    END IF;
END $$;
