
-- Primeiro, vamos verificar as políticas existentes e criar políticas mais flexíveis
-- que permitam operações em modo demo (quando auth.uid() é null)

-- Remover políticas existentes que são muito restritivas
DROP POLICY IF EXISTS "Rental companies can view their own vehicles" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Rental companies can create their own vehicles" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Rental companies can update their own vehicles" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Rental companies can delete their own vehicles" ON public.rental_company_vehicles;
DROP POLICY IF EXISTS "Admins can view all vehicles" ON public.rental_company_vehicles;

-- Criar função para verificar se é modo demo ou usuário autenticado válido
CREATE OR REPLACE FUNCTION public.is_demo_mode_or_valid_company(company_id_param UUID)
RETURNS BOOLEAN AS $$
BEGIN
  -- Se não há usuário autenticado (modo demo), permitir
  IF auth.uid() IS NULL THEN
    RETURN TRUE;
  END IF;
  
  -- Se há usuário autenticado, verificar se é a mesma empresa ou admin
  RETURN (
    auth.uid() = company_id_param OR
    EXISTS (
      SELECT 1 FROM public.profiles p 
      WHERE p.id = auth.uid() 
      AND p.role = 'admin'
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Criar políticas mais flexíveis que funcionem tanto com auth quanto sem
CREATE POLICY "Companies can view vehicles (demo mode compatible)" 
  ON public.rental_company_vehicles 
  FOR SELECT 
  USING (public.is_demo_mode_or_valid_company(company_id));

CREATE POLICY "Companies can create vehicles (demo mode compatible)" 
  ON public.rental_company_vehicles 
  FOR INSERT 
  WITH CHECK (public.is_demo_mode_or_valid_company(company_id));

CREATE POLICY "Companies can update vehicles (demo mode compatible)" 
  ON public.rental_company_vehicles 
  FOR UPDATE 
  USING (public.is_demo_mode_or_valid_company(company_id));

CREATE POLICY "Companies can delete vehicles (demo mode compatible)" 
  ON public.rental_company_vehicles 
  FOR DELETE 
  USING (public.is_demo_mode_or_valid_company(company_id));
