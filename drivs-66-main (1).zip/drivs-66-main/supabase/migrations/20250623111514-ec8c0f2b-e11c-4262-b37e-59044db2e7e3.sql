
-- Create payments table for rental companies
CREATE TABLE public.payments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  driver_id UUID NOT NULL,
  driver_name TEXT NOT NULL,
  company_id UUID NOT NULL,
  vehicle_info TEXT NOT NULL,
  vehicle_plate TEXT NOT NULL,
  due_date DATE NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('paid', 'pending', 'overdue', 'partial')),
  paid_date DATE,
  paid_amount NUMERIC(10,2),
  payment_method TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create vehicle expenses table
CREATE TABLE public.vehicle_expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL,
  vehicle_id UUID,
  vehicle_plate TEXT NOT NULL,
  expense_type TEXT NOT NULL,
  description TEXT NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
  category TEXT NOT NULL DEFAULT 'maintenance',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on payments table
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for payments
CREATE POLICY "Companies can view their own payments" 
  ON public.payments 
  FOR SELECT 
  USING (
    company_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Companies can create payments for their drivers" 
  ON public.payments 
  FOR INSERT 
  WITH CHECK (
    company_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Companies can update their own payments" 
  ON public.payments 
  FOR UPDATE 
  USING (
    company_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Enable RLS on vehicle_expenses table
ALTER TABLE public.vehicle_expenses ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for vehicle_expenses
CREATE POLICY "Companies can view their own vehicle expenses" 
  ON public.vehicle_expenses 
  FOR SELECT 
  USING (
    company_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Companies can create vehicle expenses" 
  ON public.vehicle_expenses 
  FOR INSERT 
  WITH CHECK (
    company_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Companies can update their own vehicle expenses" 
  ON public.vehicle_expenses 
  FOR UPDATE 
  USING (
    company_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Insert some sample payment data for testing
INSERT INTO public.payments (driver_id, driver_name, company_id, vehicle_info, vehicle_plate, due_date, amount, status, paid_date, paid_amount) VALUES
(gen_random_uuid(), 'João Silva', (SELECT id FROM public.rental_companies LIMIT 1), 'Honda Civic 2022', 'ABC-1234', CURRENT_DATE - INTERVAL '5 days', 1200.00, 'paid', CURRENT_DATE - INTERVAL '3 days', 1200.00),
(gen_random_uuid(), 'Maria Santos', (SELECT id FROM public.rental_companies LIMIT 1), 'Toyota Corolla 2021', 'XYZ-5678', CURRENT_DATE + INTERVAL '10 days', 1350.00, 'pending', NULL, NULL),
(gen_random_uuid(), 'Carlos Lima', (SELECT id FROM public.rental_companies LIMIT 1), 'Nissan Sentra 2020', 'DEF-9012', CURRENT_DATE - INTERVAL '15 days', 980.00, 'overdue', NULL, NULL),
(gen_random_uuid(), 'Ana Costa', (SELECT id FROM public.rental_companies LIMIT 1), 'Chevrolet Onix 2023', 'GHI-3456', CURRENT_DATE - INTERVAL '2 days', 1100.00, 'partial', CURRENT_DATE - INTERVAL '1 day', 550.00);
