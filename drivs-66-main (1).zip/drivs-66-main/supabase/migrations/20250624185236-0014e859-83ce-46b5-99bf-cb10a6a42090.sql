
-- Adicionar coluna email na tabela drivers
ALTER TABLE public.drivers ADD COLUMN email TEXT;

-- Criar índice para melhorar performance de busca por email
CREATE INDEX idx_drivers_email ON public.drivers(email);

-- Atualizar a função handle_new_user_auth para incluir o email ao criar motorista
CREATE OR REPLACE FUNCTION public.handle_new_user_auth()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    new.id, 
    COALESCE(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', 'User'),
    COALESCE(new.raw_user_meta_data->>'role', 'driver')
  );

  -- If user is a driver, create driver record with pending status
  IF COALESCE(new.raw_user_meta_data->>'role', 'driver') = 'driver' THEN
    INSERT INTO public.drivers (
      id, 
      full_name, 
      email,
      cpf, 
      rg, 
      phone, 
      address,
      cnh,
      cnh_expires,
      city,
      state,
      date_of_birth,
      status
    ) 
    VALUES (
      new.id,
      COALESCE(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', 'User'),
      new.email,
      COALESCE(new.raw_user_meta_data->>'cpf', ''),
      COALESCE(new.raw_user_meta_data->>'rg', ''),
      COALESCE(new.raw_user_meta_data->>'phone', ''),
      COALESCE(new.raw_user_meta_data->>'address', ''),
      COALESCE(new.raw_user_meta_data->>'cnh', ''),
      COALESCE(new.raw_user_meta_data->>'cnh_expires', CURRENT_DATE + interval '1 year'),
      COALESCE(new.raw_user_meta_data->>'city', ''),
      COALESCE(new.raw_user_meta_data->>'state', ''),
      CASE 
        WHEN new.raw_user_meta_data->>'date_of_birth' IS NOT NULL 
        THEN (new.raw_user_meta_data->>'date_of_birth')::DATE 
        ELSE NULL 
      END,
      'pending'
    );
  END IF;

  -- If user is a rental company, create company record
  IF COALESCE(new.raw_user_meta_data->>'role', 'driver') = 'rental_company' THEN
    INSERT INTO public.rental_companies (
      id, 
      company_name, 
      cnpj, 
      phone, 
      address,
      email
    ) 
    VALUES (
      new.id,
      COALESCE(new.raw_user_meta_data->>'company_name', new.raw_user_meta_data->>'name', 'Company'),
      COALESCE(new.raw_user_meta_data->>'cnpj', ''),
      COALESCE(new.raw_user_meta_data->>'phone', ''),
      COALESCE(new.raw_user_meta_data->>'address', ''),
      new.email
    );
  END IF;

  RETURN new;
END;
$$;
