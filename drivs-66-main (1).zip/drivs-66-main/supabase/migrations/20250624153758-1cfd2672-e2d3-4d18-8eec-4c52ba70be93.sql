
-- Remover a constraint que exige company_id não nulo na tabela drivers
-- Isso permite que motoristas se cadastrem independentemente de uma empresa
ALTER TABLE public.drivers 
DROP CONSTRAINT IF EXISTS drivers_company_id_not_null;

-- Tornar a coluna company_id opcional (nullable)
ALTER TABLE public.drivers 
ALTER COLUMN company_id DROP NOT NULL;

-- Adicionar um comentário explicativo
COMMENT ON COLUMN public.drivers.company_id IS 'ID da empresa locadora. Pode ser nulo para motoristas que ainda não foram associados a uma empresa.';
