
-- Adicionar coluna company_id na tabela drivers para associar motoristas às locadoras
ALTER TABLE public.drivers 
ADD COLUMN company_id uuid REFERENCES public.rental_companies(id);

-- Criar índice para melhorar performance nas consultas
CREATE INDEX idx_drivers_company_id ON public.drivers(company_id);

-- Inserir dados de exemplo associando os motoristas existentes a locadoras
UPDATE public.drivers 
SET company_id = (
  SELECT id FROM public.rental_companies 
  WHERE company_name = 'Auto Rental Plus' 
  LIMIT 1
)
WHERE full_name = 'João Silva Santos';

UPDATE public.drivers 
SET company_id = (
  SELECT id FROM public.rental_companies 
  WHERE company_name = 'Auto Rental Plus' 
  LIMIT 1
)
WHERE full_name = 'Carlos Roberto Lima';
