
-- Tornar o campo RG opcional na tabela drivers
ALTER TABLE public.drivers ALTER COLUMN rg DROP NOT NULL;

-- Definir um valor padrão vazio para RG
ALTER TABLE public.drivers ALTER COLUMN rg SET DEFAULT '';

-- Atualizar registros existentes que possam ter RG nulo
UPDATE public.drivers SET rg = '' WHERE rg IS NULL;
