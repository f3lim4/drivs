
-- Enable RLS on driver_registrations table if not already enabled
ALTER TABLE public.driver_registrations ENABLE ROW LEVEL SECURITY;

-- Allow rental companies to view driver registrations that reference them
CREATE POLICY "Rental companies can view their referred drivers" 
  ON public.driver_registrations 
  FOR SELECT 
  USING (referral_company_id = auth.uid() OR auth.uid() IN (
    SELECT id FROM public.profiles WHERE role = 'admin'
  ));

-- Allow rental companies to update driver registrations that reference them
CREATE POLICY "Rental companies can update their referred drivers" 
  ON public.driver_registrations 
  FOR UPDATE 
  USING (referral_company_id = auth.uid() OR auth.uid() IN (
    SELECT id FROM public.profiles WHERE role = 'admin'
  ));

-- Allow admins and analysts to view all driver registrations
CREATE POLICY "Admins and analysts can view all driver registrations" 
  ON public.driver_registrations 
  FOR SELECT 
  USING (auth.uid() IN (
    SELECT id FROM public.profiles WHERE role IN ('admin', 'analyst')
  ));

-- Allow admins and analysts to update all driver registrations
CREATE POLICY "Admins and analysts can update all driver registrations" 
  ON public.driver_registrations 
  FOR UPDATE 
  USING (auth.uid() IN (
    SELECT id FROM public.profiles WHERE role IN ('admin', 'analyst')
  ));
