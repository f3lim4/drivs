
-- Habilitar RLS na tabela maintenance_locations se ainda não estiver habilitado
ALTER TABLE public.maintenance_locations ENABLE ROW LEVEL SECURITY;

-- Política para permitir que locadoras vejam apenas seus próprios locais
CREATE POLICY "Locadoras podem ver seus próprios locais" 
ON public.maintenance_locations 
FOR SELECT 
USING (
  company_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.id = auth.uid() 
    AND p.role = 'admin'
  )
);

-- Política para permitir que locadoras criem seus próprios locais
CREATE POLICY "Locadoras podem criar seus próprios locais" 
ON public.maintenance_locations 
FOR INSERT 
WITH CHECK (
  company_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.id = auth.uid() 
    AND p.role = 'admin'
  )
);

-- Política para permitir que locadoras atualizem seus próprios locais
CREATE POLICY "Locadoras podem atualizar seus próprios locais" 
ON public.maintenance_locations 
FOR UPDATE 
USING (
  company_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.id = auth.uid() 
    AND p.role = 'admin'
  )
);

-- Política para permitir que locadoras deletem seus próprios locais
CREATE POLICY "Locadoras podem deletar seus próprios locais" 
ON public.maintenance_locations 
FOR DELETE 
USING (
  company_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.id = auth.uid() 
    AND p.role = 'admin'
  )
);
