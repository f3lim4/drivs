
-- Verificar se existem usuários criados na tabela auth.users
SELECT 
  id,
  email,
  created_at,
  email_confirmed_at,
  last_sign_in_at
FROM auth.users
ORDER BY created_at DESC
LIMIT 10;

-- Verificar se existem perfis criados na tabela profiles
SELECT 
  p.id,
  p.full_name,
  p.role,
  p.created_at,
  u.email
FROM public.profiles p
LEFT JOIN auth.users u ON u.id = p.id
ORDER BY p.created_at DESC
LIMIT 10;

-- Verificar se existem motoristas na tabela drivers
SELECT 
  id,
  full_name,
  cpf,
  status,
  created_at
FROM public.drivers
ORDER BY created_at DESC
LIMIT 10;

-- Verificar se existem locadoras na tabela rental_companies
SELECT 
  id,
  company_name,
  cnpj,
  email,
  created_at
FROM public.rental_companies
ORDER BY created_at DESC
LIMIT 10;

-- Verificar registros de motoristas pendentes
SELECT 
  id,
  full_name,
  email,
  status,
  created_at
FROM public.driver_registrations
ORDER BY created_at DESC
LIMIT 10;

-- Verificar registros de locadoras pendentes
SELECT 
  id,
  company_name,
  email,
  status,
  created_at
FROM public.rental_company_registrations
ORDER BY created_at DESC
LIMIT 10;
