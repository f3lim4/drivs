
-- Verificar as políticas RLS atuais na tabela driver_registrations
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check 
FROM pg_policies 
WHERE tablename = 'driver_registrations';

-- Remover todas as políticas existentes para recriar
DROP POLICY IF EXISTS "Allow rental companies to view their referred drivers" ON public.driver_registrations;
DROP POLICY IF EXISTS "Allow rental companies to update their referred drivers" ON public.driver_registrations;
DROP POLICY IF EXISTS "Allow rental companies to insert driver registrations" ON public.driver_registrations;
DROP POLICY IF EXISTS "Rental companies can view their referred drivers" ON public.driver_registrations;
DROP POLICY IF EXISTS "Rental companies can update their referred drivers" ON public.driver_registrations;
DROP POLICY IF EXISTS "Admins and analysts can view all driver registrations" ON public.driver_registrations;
DROP POLICY IF EXISTS "Admins and analysts can update all driver registrations" ON public.driver_registrations;

-- Criar políticas RLS mais específicas e funcionais para SELECT
CREATE POLICY "rental_companies_can_view_their_drivers" 
  ON public.driver_registrations 
  FOR SELECT 
  USING (
    referral_company_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role IN ('admin', 'analyst')
    )
  );

-- Criar políticas RLS mais específicas e funcionais para UPDATE
CREATE POLICY "rental_companies_can_update_their_drivers" 
  ON public.driver_registrations 
  FOR UPDATE 
  USING (
    referral_company_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role IN ('admin', 'analyst')
    )
  )
  WITH CHECK (
    referral_company_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role IN ('admin', 'analyst')
    )
  );

-- Criar políticas RLS para INSERT
CREATE POLICY "rental_companies_can_insert_driver_registrations" 
  ON public.driver_registrations 
  FOR INSERT 
  WITH CHECK (
    referral_company_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role IN ('admin', 'analyst')
    )
  );

-- Verificar se RLS está habilitado na tabela
ALTER TABLE public.driver_registrations ENABLE ROW LEVEL SECURITY;

-- Verificar se as políticas foram criadas corretamente
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check 
FROM pg_policies 
WHERE tablename = 'driver_registrations';
