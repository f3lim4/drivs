
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.a174acd4450344d69cde41e2c9177498',
  appName: 'drivs-71',
  webDir: 'dist',
  server: {
    url: 'https://a174acd4-4503-44d6-9cde-41e2c9177498.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    Camera: {
      permissions: ['camera', 'photos']
    }
  }
};

export default config;
