export interface InspectionPhoto {
  id: string;
  url: string;
  timestamp: string;
  location: string;
  observations?: string;
}

export interface StandardPhotoRequirement {
  id: string;
  title: string;
  description: string;
  required: boolean;
  category: 'exterior' | 'interior' | 'mechanical' | 'accessories';
}

export interface ExtraPhoto extends InspectionPhoto {
  observations: string;
}

export interface InspectionData {
  id: string;
  type: 'inicial' | 'entrega' | 'manutencao' | 'eventual';
  vehiclePlate: string;
  vehicleModel: string;
  driverName: string;
  inspectorName?: string;
  standardPhotos: InspectionPhoto[];
  extraPhotos: ExtraPhoto[];
  generalObservations: string;
  status: 'pending' | 'in_progress' | 'completed';
  createdAt: string;
  completedAt?: string;
  deadline?: string;
  title?: string;
  description?: string;
}

interface Inspection {
  id: number;
  vehiclePlate: string;
  vehicleModel: string;
  driverName: string;
  type: string;
  status: "Concluída" | "Pendente" | "Em Andamento" | "Aguardando Aprovação";
  inspector: string;
  vistoriador?: string; // Quem fez a vistoria (motorista ou vistoriador)
  observations: string;
  photos: number;
  photosData?: InspectionPhoto[]; // Array das fotos enviadas
  recipient?: "inspector" | "driver";
  contractId?: string;
}

export const STANDARD_PHOTO_REQUIREMENTS: StandardPhotoRequirement[] = [
  {
    id: 'frente',
    title: 'Foto Frente',
    description: 'Foto completa da frente do veículo',
    required: true,
    category: 'exterior'
  },
  {
    id: 'lateral-motorista',
    title: 'Foto Lateral Motorista',
    description: 'Foto do lado do motorista do veículo',
    required: true,
    category: 'exterior'
  },
  {
    id: 'traseira',
    title: 'Foto Traseira',
    description: 'Foto completa da traseira do veículo',
    required: true,
    category: 'exterior'
  },
  {
    id: 'lateral-passageiro',
    title: 'Foto Lateral Passageiro',
    description: 'Foto do lado do passageiro do veículo',
    required: true,
    category: 'exterior'
  },
  {
    id: 'motor',
    title: 'Foto Motor',
    description: 'Foto do compartimento do motor',
    required: true,
    category: 'mechanical'
  },
  {
    id: 'bateria',
    title: 'Foto Bateria',
    description: 'Foto da bateria do veículo',
    required: true,
    category: 'mechanical'
  },
  {
    id: 'estepe',
    title: 'Foto Estepe',
    description: 'Foto do pneu estepe',
    required: true,
    category: 'accessories'
  },
  {
    id: 'macaco-chave',
    title: 'Foto Macaco e Chave de Roda',
    description: 'Foto do macaco e chave de roda',
    required: true,
    category: 'accessories'
  },
  {
    id: 'pneu-1',
    title: 'Foto Pneu 1',
    description: 'Foto do pneu dianteiro esquerdo',
    required: true,
    category: 'mechanical'
  },
  {
    id: 'pneu-2',
    title: 'Foto Pneu 2',
    description: 'Foto do pneu dianteiro direito',
    required: true,
    category: 'mechanical'
  },
  {
    id: 'pneu-3',
    title: 'Foto Pneu 3',
    description: 'Foto do pneu traseiro esquerdo',
    required: true,
    category: 'mechanical'
  },
  {
    id: 'pneu-4',
    title: 'Foto Pneu 4',
    description: 'Foto do pneu traseiro direito',
    required: true,
    category: 'mechanical'
  },
  {
    id: 'painel',
    title: 'Foto Painel',
    description: 'Foto do painel de instrumentos',
    required: true,
    category: 'interior'
  },
  {
    id: 'interna',
    title: 'Foto Interna',
    description: 'Foto do interior do veículo',
    required: true,
    category: 'interior'
  }
];
