
export enum UserRole {
  ADMIN = "admin",
  DRIVER = "driver",
  RENTAL_COMPANY = "rental_company",
  MANAGER = "manager",
  INSPECTOR = "inspector",
  ANALYST = "analyst",
}

export enum DriverStatus {
  PENDING = "pending",
  UNDER_REVIEW = "under_review",
  APPROVED = "approved",
  ACTIVE = "active",
  REJECTED = "rejected",
  DEACTIVATED = "deactivated",
  BLACKLISTED = "blacklisted",
}

export enum PaymentStatus {
  PAID = "paid",
  OPEN = "open",
  OVERDUE = "overdue",
  BLACKLISTED = "blacklisted",
}

interface Permission {
  motoristas: boolean;
  veiculos: boolean;
  contratos: boolean;
  pagamentos: boolean;
  financeiro: boolean;
  infracoes: boolean;
  manutencao: boolean;
  vistorias: boolean;
  negativar: boolean;
  ranking: boolean;
  relatorios: boolean;
  configuracoes: boolean;
}

interface User {
  id: string;
  email: string;
  role: UserRole;
  name?: string;
  active?: boolean;
  createdAt?: string;
  lastLogin?: string;
}

interface ActiveContract {
  companyId: number;
  companyName: string;
  vehicleModel: string;
  contractStart: string;
  contractEnd: string;
  paymentStatus?: PaymentStatus;
}

export interface Driver {
  id: string;
  email: string;
  role: UserRole.DRIVER;
  fullName: string;
  cpf: string;
  rg: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  cnh: string;
  cnh_expires: string;
  status: DriverStatus;
  available?: boolean;
  rating?: number;
  violations?: number;
  created_at?: string;
  updated_at?: string;
  profile_photo?: string;
  app_screenshot?: string;
  address_proof?: string;
  rejection_reason?: string;
  rejection_date?: string;
  documents_requested?: boolean;
  activeContract?: ActiveContract;
  debt_amount?: number;
  pix_key?: string;
  deactivation_reason?: string;
  deactivated_at?: string;
  deactivated_by?: string;
}

export interface RentalCompany {
  id: string;
  name?: string;
  companyName: string;
  email: string;
  role: UserRole.RENTAL_COMPANY;
  cnpj: string;
  phone: string;
  address: string;
  logo?: string;
  verified: boolean;
  vehicleCount: number;
  rating: number;
  created_at?: string;
  updated_at?: string;
}

export interface Manager {
  id: string;
  email: string;
  role: UserRole.MANAGER;
  name: string;
  companyId: string;
  active: boolean;
  createdAt: string;
  lastLogin?: string;
  permissions?: Permission;
}

export interface Inspector {
  id: string;
  email: string;
  role: UserRole.INSPECTOR;
  name: string;
  companyId: string;
  active: boolean;
  createdAt: string;
  lastLogin?: string;
}

interface Analyst {
  id: string;
  email: string;
  role: UserRole.ANALYST;
  name: string;
  active: boolean;
  createdAt: string;
  lastLogin?: string;
}

interface Payment {
  id: string;
  amount: number;
  date: string;
  status: PaymentStatus;
  driverId: string;
  rentalCompanyId: string;
  contractId: string;
  dueDate?: Date;
  blacklistReason?: string;
  blacklistDescription?: string;
  blacklistFile?: string;
}

export interface RentalVehicle {
  id: string;
  brand: string;
  model: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold";
  documentExpiry: string;
  vehicleValue: number;
  isFinanced: boolean;
  monthlyInstallment?: number;
  monthlyInsurance: number;
  monthlyTracker: number;
  images: string[];
  depositValue: number;
  weeklyValue: number;
  vehicleType: string;
  mileage?: number;
  fuelType?: string;
  transmissionType?: string;
  ipvaValue?: number;
  licensingStatus?: "up_to_date" | "overdue";
  kmLimit?: number;
  kmType?: "limited" | "unlimited";
  maintenanceResponsibility?: "rental_company" | "fifty_fifty" | "driver";
  description?: string;
  allowReservation?: boolean;
}
