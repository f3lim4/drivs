
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthWrapper } from "@/contexts/auth/AuthWrapper";
import AppLayout from "@/components/layout/AppLayout";
import Login from "@/pages/Auth/Login";
import DriverRegister from "@/pages/Auth/DriverRegister";
import DriverRegistration from "@/pages/Auth/DriverRegistration";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import AuthRoutes from "@/routes/AuthRoutes";
import { useAuth } from "@/contexts/AuthContext";

const queryClient = new QueryClient();

function AppContent() {
  const { user, loading } = useAuth();

  console.log('🚀 [APP] Renderizando AppContent', { user: !!user, loading });

  if (loading) {
    console.log('⏳ [APP] Mostrando loading...');
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      {/* Rotas de autenticação (públicas) */}
      <Route path="/login" element={<Login />} />
      <Route path="/auth/*" element={<AuthRoutes />} />
      <Route path="/cadastro-motorista" element={<DriverRegistration />} />
      <Route path="/driver-registration" element={<DriverRegistration />} />
      <Route path="/cadastro-locadora" element={<AuthRoutes />} />
      <Route path="/driver-register" element={<DriverRegister />} />
      <Route path="/company-register" element={<AuthRoutes />} />
      <Route path="/forgot-password" element={<AuthRoutes />} />
      
      {/* Todas as outras rotas requerem autenticação */}
      <Route path="/*" element={
        <ProtectedRoute>
          <AppLayout />
        </ProtectedRoute>
      } />
    </Routes>
  );
}

function App() {
  console.log('🎯 [APP] Inicializando aplicação...');
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BrowserRouter>
          <AuthWrapper>
            <AppContent />
            <Toaster />
          </AuthWrapper>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
