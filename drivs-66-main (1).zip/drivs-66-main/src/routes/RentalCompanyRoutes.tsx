
import { Suspense, lazy } from "react";
import { Route } from "react-router-dom";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";

const Dashboard = lazy(() => import("@/pages/Dashboard"));
const RentalCompanyDrivers = lazy(() => import("@/pages/RentalCompanies/Drivers"));
const DriversAnalysis = lazy(() => import("@/pages/DriversAnalysis"));
const RentalCompanyVehicles = lazy(() => import("@/pages/RentalCompanies/Vehicles"));
const Contracts = lazy(() => import("@/pages/Contracts"));
const ContractGeneratorPage = lazy(() => import("@/pages/Contracts/ContractGeneratorPage"));
const RentalCompanyInspections = lazy(() => import("@/pages/RentalCompanies/RentalCompanyInspections"));
const RentalCompanyPayments = lazy(() => import("@/pages/RentalCompanies/RentalCompanyPayments"));
const RentalCompanyMaintenance = lazy(() => import("@/pages/RentalCompanies/RentalCompanyManuntecoes"));
const RentalCompanyViolations = lazy(() => import("@/pages/RentalCompanies/RentalCompanyViolations"));
const Ranking = lazy(() => import("@/pages/Ranking"));
const Financial = lazy(() => import("@/pages/Financial"));
const Reports = lazy(() => import("@/pages/Reports"));
const RentalCompanyNegotiations = lazy(() => import("@/pages/RentalCompanies/RentalCompanyNegotiations"));
const Plans = lazy(() => import("@/pages/Plans"));
const Settings = lazy(() => import("@/pages/Settings"));
const CompanyUsers = lazy(() => import("@/pages/CompanyUsers"));
const CompanySettings = lazy(() => import("@/pages/CompanySettings"));

export const RentalCompanyRoutes = () => (
  <>
    {/* Rental company routes */}
    <Route path="locadora/dashboard" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Dashboard />
      </Suspense>
    } />
    <Route path="locadora/motorista" element={
      <Suspense fallback={<FuturisticLoading />}>
        <RentalCompanyDrivers />
      </Suspense>
    } />
    <Route path="locadora/analise-de-motorista" element={
      <Suspense fallback={<FuturisticLoading />}>
        <DriversAnalysis />
      </Suspense>
    } />
    <Route path="locadora/veiculos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <RentalCompanyVehicles />
      </Suspense>
    } />
    <Route path="locadora/contratos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Contracts />
      </Suspense>
    } />
    <Route path="locadora/gerar-contrato" element={
      <Suspense fallback={<FuturisticLoading />}>
        <ContractGeneratorPage />
      </Suspense>
    } />
    <Route path="locadora/vistorias" element={
      <Suspense fallback={<FuturisticLoading />}>
        <RentalCompanyInspections />
      </Suspense>
    } />
    <Route path="locadora/pagamentos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <RentalCompanyPayments />
      </Suspense>
    } />
    <Route path="locadora/usuarios" element={
      <Suspense fallback={<FuturisticLoading />}>
        <CompanyUsers />
      </Suspense>
    } />
    {/* Manutenções - aceita tanto a grafia correta quanto a incorreta */}
    <Route path="locadora/manutencoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <RentalCompanyMaintenance />
      </Suspense>
    } />
    <Route path="locadora/manuntecoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <RentalCompanyMaintenance />
      </Suspense>
    } />
    <Route path="locadora/infracoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <RentalCompanyViolations />
      </Suspense>
    } />
    <Route path="locadora/ranking" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Ranking />
      </Suspense>
    } />
    <Route path="locadora/financeiro" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Financial />
      </Suspense>
    } />
    <Route path="locadora/relatorios" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Reports />
      </Suspense>
    } />
    <Route path="locadora/negociacoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <RentalCompanyNegotiations />
      </Suspense>
    } />
    <Route path="locadora/planos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Plans />
      </Suspense>
    } />
    <Route path="locadora/configuracoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <CompanySettings />
      </Suspense>
    } />
    <Route path="locadora/settings" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Settings />
      </Suspense>
    } />
  </>
);
