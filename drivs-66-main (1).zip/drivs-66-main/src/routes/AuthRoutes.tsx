
import { Routes, Route } from "react-router-dom";
import Login from "@/pages/Auth/Login";
import Register from "@/pages/Auth/Register";
import DriverRegister from "@/pages/Auth/DriverRegister";
import DriverRegistration from "@/pages/Auth/DriverRegistration";
import CompanyRegister from "@/pages/Auth/CompanyRegister";
import ForgotPassword from "@/pages/Auth/ForgotPassword";

const AuthRoutes = () => {
  console.log('🔐 [AUTH ROUTES] Renderizando rotas de autenticação...');
  
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/cadastro-motorista" element={<DriverRegister />} />
      <Route path="/driver-registration" element={<DriverRegistration />} />
      <Route path="/cadastro-locadora" element={<CompanyRegister />} />
      <Route path="/driver-register" element={<DriverRegister />} />
      <Route path="/company-register" element={<CompanyRegister />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
    </Routes>
  );
};

export default AuthRoutes;
