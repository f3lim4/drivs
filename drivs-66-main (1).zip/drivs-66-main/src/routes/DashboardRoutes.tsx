
import { Suspense, lazy } from "react";
import { Route } from "react-router-dom";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";

const Dashboard = lazy(() => import("@/pages/Dashboard"));
const Profile = lazy(() => import("@/pages/Profile"));
const Settings = lazy(() => import("@/pages/Settings"));

export const DashboardRoutes = () => (
  <>
    {/* Main dashboard route */}
    <Route path="dashboard" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Dashboard />
      </Suspense>
    } />
    
    {/* Additional dashboard routes */}
    <Route path="painel" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Dashboard />
      </Suspense>
    } />
    
    <Route path="perfil" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Profile />
      </Suspense>
    } />
    
    <Route path="configuracoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Settings />
      </Suspense>
    } />
  </>
);
