
import { Suspense, lazy } from "react";
import { Route } from "react-router-dom";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";

const Dashboard = lazy(() => import("@/pages/Dashboard"));
const Profile = lazy(() => import("@/pages/Profile"));
const Settings = lazy(() => import("@/pages/Settings"));
const DriverInspections = lazy(() => import("@/pages/Drivers/DriverInspections"));
const ViewVehicles = lazy(() => import("@/pages/Vehicles/ViewVehicles"));
const Payments = lazy(() => import("@/pages/Payments"));
const MyRentalCompany = lazy(() => import("@/pages/RentalCompanies/MyRentalCompany"));
const Violations = lazy(() => import("@/pages/Violations"));
const DriverMaintenance = lazy(() => import("@/pages/Drivers/DriverMaintenance"));
const Ranking = lazy(() => import("@/pages/Ranking"));
const Contracts = lazy(() => import("@/pages/Contracts"));
const MyVehicle = lazy(() => import("@/pages/Drivers/MyVehicle"));
const DriverNegotiations = lazy(() => import("@/pages/Drivers/DriverNegotiations"));
const DriverDocuments = lazy(() => import("@/pages/Drivers/DriverDocuments"));

export const DriverRoutes = () => (
  <>
    {/* Dashboard específico do motorista */}
    <Route path="motorista/dashboard" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Dashboard />
      </Suspense>
    } />
    
    {/* Perfil do motorista */}
    <Route path="motorista/perfil" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Profile />
      </Suspense>
    } />
    
    {/* Configurações do motorista */}
    <Route path="motorista/configuracoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Settings />
      </Suspense>
    } />
    
    {/* Documentos do motorista */}
    <Route path="motorista/documentos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <DriverDocuments />
      </Suspense>
    } />
    
    {/* Meu veículo */}
    <Route path="motorista/veiculo" element={
      <Suspense fallback={<FuturisticLoading />}>
        <MyVehicle />
      </Suspense>
    } />
    
    {/* Contratos do motorista */}
    <Route path="motorista/contratos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Contracts />
      </Suspense>
    } />
    
    {/* Pagamentos do motorista */}
    <Route path="motorista/pagamentos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Payments />
      </Suspense>
    } />
    
    {/* Infrações do motorista */}
    <Route path="motorista/infracoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Violations />
      </Suspense>
    } />
    
    {/* Driver-specific routes (old paths for compatibility) */}
    <Route path="motoristas/pagamentos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Payments />
      </Suspense>
    } />
    <Route path="motoristas/vistorias-motorista" element={
      <Suspense fallback={<FuturisticLoading />}>
        <DriverInspections />
      </Suspense>
    } />
    <Route path="motoristas/ver-veiculos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <ViewVehicles />
      </Suspense>
    } />
    <Route path="motoristas/minha-locadora" element={
      <Suspense fallback={<FuturisticLoading />}>
        <MyRentalCompany />
      </Suspense>
    } />
    <Route path="motoristas/infracoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Violations />
      </Suspense>
    } />
    <Route path="motoristas/manutencoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <DriverMaintenance />
      </Suspense>
    } />
    <Route path="motoristas/ranking" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Ranking />
      </Suspense>
    } />
    <Route path="motoristas/contrato" element={
      <Suspense fallback={<FuturisticLoading />}>
        <Contracts />
      </Suspense>
    } />
    <Route path="motoristas/meu-veiculo" element={
      <Suspense fallback={<FuturisticLoading />}>
        <MyVehicle />
      </Suspense>
    } />
    <Route path="motoristas/negociacoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <DriverNegotiations />
      </Suspense>
    } />
    <Route path="motoristas/documentos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <DriverDocuments />
      </Suspense>
    } />
  </>
);
