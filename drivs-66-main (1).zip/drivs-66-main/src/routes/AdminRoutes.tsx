
import { Suspense, lazy } from "react";
import { Route } from "react-router-dom";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";

const AdminPainel = lazy(() => import("@/pages/Admin/AdminDashboard"));
const AdminPlanos = lazy(() => import("@/pages/AdminPlans/index"));
const AdminUsuarios = lazy(() => import("@/pages/Admin/Usuarios"));
const AdminMotoristas = lazy(() => import("@/pages/Admin/Motoristas"));
const AdminLocadoras = lazy(() => import("@/pages/Admin/Locadoras"));
const AdminVeiculos = lazy(() => import("@/pages/Admin/Veiculos"));
const AdminAnaliseDeMotoristas = lazy(() => import("@/pages/Admin/AnaliseDeMotoristas"));
const AdminContratos = lazy(() => import("@/pages/Admin/Contratos"));
const AdminVistorias = lazy(() => import("@/pages/Admin/Vistorias"));
const AdminPagamentos = lazy(() => import("@/pages/Admin/Pagamentos"));
const AdminManutencoes = lazy(() => import("@/pages/Admin/Manutencoes"));
const AdminInfracoes = lazy(() => import("@/pages/Admin/Infracoes"));
const AdminFinanceiro = lazy(() => import("@/pages/Admin/Financeiro"));
const AdminNegativados = lazy(() => import("@/pages/Admin/Negativados"));
const AdminRelatorios = lazy(() => import("@/pages/Admin/Relatorios"));
const AdminNegociacoes = lazy(() => import("@/pages/Admin/Negotiations"));

export const AdminRoutes = () => (
  <>
    {/* Admin routes */}
    <Route path="admin/painel" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminPainel />
      </Suspense>
    } />
    <Route path="admin/planos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminPlanos />
      </Suspense>
    } />
    <Route path="admin/usuarios" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminUsuarios />
      </Suspense>
    } />
    <Route path="admin/motoristas" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminMotoristas />
      </Suspense>
    } />
    <Route path="admin/locadoras" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminLocadoras />
      </Suspense>
    } />
    <Route path="admin/veiculos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminVeiculos />
      </Suspense>
    } />
    <Route path="admin/analise-de-motoristas" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminAnaliseDeMotoristas />
      </Suspense>
    } />
    <Route path="admin/contratos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminContratos />
      </Suspense>
    } />
    <Route path="admin/vistorias" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminVistorias />
      </Suspense>
    } />
    <Route path="admin/pagamentos" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminPagamentos />
      </Suspense>
    } />
    <Route path="admin/manutencoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminManutencoes />
      </Suspense>
    } />
    <Route path="admin/infracoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminInfracoes />
      </Suspense>
    } />
    <Route path="admin/financeiro" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminFinanceiro />
      </Suspense>
    } />
    <Route path="admin/negativados" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminNegativados />
      </Suspense>
    } />
    <Route path="admin/relatorios" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminRelatorios />
      </Suspense>
    } />
    <Route path="admin/negociacoes" element={
      <Suspense fallback={<FuturisticLoading />}>
        <AdminNegociacoes />
      </Suspense>
    } />
  </>
);
