
import { UserRole, DriverStatus } from "@/types";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  
  // Campos específicos para motoristas
  fullName?: string;
  cpf?: string;
  rg?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  cnh?: string;
  cnh_expires?: string;
  date_of_birth?: string;
  status?: DriverStatus;
  available?: boolean;
  rating?: number;
  violations?: number;
  created_at?: string;
  updated_at?: string;
  profile_photo?: string;
  app_screenshot?: string;
  address_proof?: string;
  rejection_reason?: string;
  rejection_date?: string;
  debt_amount?: number;
  pix_key?: string;
  documents_requested?: boolean;
  deactivation_reason?: string;
  deactivated_at?: string;
  activeContract?: any;
  
  // Campos específicos para locadoras
  companyName?: string;
  cnpj?: string;
  logo?: string;
  verified?: boolean;
  vehicleCount?: number;
  
  // Campos específicos da locadora aprovada
  tradingName?: string;
  websiteUrl?: string;
  description?: string;
  zipCode?: string;
  contactPosition?: string;
  plan?: string;
  paymentStatus?: string;
  trialStartDate?: string;
  trialEndDate?: string;
  dueDate?: string;
  driversCount?: number;
  registrationDate?: string;
  
  // Campos específicos para usuários do sistema
  company_id?: string;
  permissions?: any;
  active?: boolean;
  createdAt?: string;
  lastLogin?: string;
}

export interface AuthContextType {
  user: AuthUser | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
}
