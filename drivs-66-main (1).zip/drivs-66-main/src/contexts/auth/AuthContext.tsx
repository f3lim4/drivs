
import React, { createContext, useContext, useState, useEffect } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { UserRole } from "@/types";
import { AuthUser, AuthContextType } from "./types";
import { handleLogin } from "./loginHandler";

// Importar utilitários separados
import { checkTokenValidity, isSessionValid } from "./utils/sessionValidation";
import { clearAuthState, isCustomUser } from "./utils/authStateManager";
import { createAuthUserFromProfile } from "./utils/userProfileManager";
import { maintainSession, validateSession } from "./utils/sessionManager";

/**
 * Context de autenticação
 * Gerencia estado global de usuário logado
 */
const AuthContext = createContext<AuthContextType>({
  user: null,
  login: async () => {},
  logout: async () => {},
  loading: false,
});

/**
 * Provider de autenticação
 * Componente principal que gerencia toda a lógica de autenticação
 */
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  console.log('AuthProvider: Starting with loading=true');

  /**
   * Inicializa o sistema de autenticação
   * Verifica tokens válidos e configura listeners
   */
  useEffect(() => {
    console.log('AuthProvider: useEffect running');
    
    const initializeAuth = async () => {
      const isValidToken = await checkTokenValidity();
      
      if (!isValidToken) {
        clearAuthState();
        setLoading(false);
        return;
      }
    };
    
    // Executar verificação inicial
    initializeAuth();
    
    // Configurar listener de mudança de autenticação
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('🔄 [AUTH] Estado de autenticação mudou:', event, session?.user?.email);
        
        if (event === 'SIGNED_OUT') {
          console.log('🚪 [AUTH] Usuário fez logout, limpando estado...');
          clearAuthState();
          setUser(null);
          setSession(null);
          setLoading(false);
          return;
        }
        
        if (event === 'TOKEN_REFRESHED') {
          console.log('🔄 [AUTH] Token renovado com sucesso');
        }
        
        setSession(session);
        
        if (session?.user && isSessionValid(session)) {
          console.log('✅ [AUTH] Sessão válida encontrada, criando usuário...');
          const authUser = await createAuthUserFromProfile(session.user);
          console.log('Setting user with email:', authUser?.email);
          setUser(authUser);
        } else {
          // Só limpar o estado se não for um usuário customizado
          if (user && !isCustomUser(user.id) && user.role !== 'rental_company') {
            console.log('❌ [AUTH] Sessão inválida, limpando estado do usuário');
            clearAuthState();
            setUser(null);
            setSession(null);
          }
        }
        
        setLoading(false);
        console.log('Auth loading set to false');
      }
    );

    // Verificar sessão existente
    console.log('Checking existing session...');
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (error) {
        console.error('Error getting session:', error);
        clearAuthState();
        setLoading(false);
        return;
      }
      
      console.log('Existing session:', session?.user?.email || 'No session');
      if (session?.user && isSessionValid(session)) {
        setSession(session);
        createAuthUserFromProfile(session.user).then((authUser) => {
          console.log('Setting user from existing session with email:', authUser?.email);
          setUser(authUser);
          setLoading(false);
        });
      } else {
        if (session && !isSessionValid(session)) {
          console.warn('⚠️ [AUTH] Sessão existente está expirada, limpando...');
          clearAuthState();
        }
        setLoading(false);
      }
    });

    // Configurar verificação automática de token a cada 2 minutos
    const tokenCheckInterval = setInterval(async () => {
      if (user && session) {
        const isValid = await checkTokenValidity();
        if (!isValid) {
          clearAuthState();
          setUser(null);
          setSession(null);
        }
      }
    }, 2 * 60 * 1000);

    // Configurar renovação automática da sessão a cada 15 minutos
    const sessionInterval = setInterval(() => {
      maintainSession(user, session, setSession);
    }, 15 * 60 * 1000);

    // Configurar validação de sessão a cada 2 minutos
    const validationInterval = setInterval(() => {
      validateSession(user, session);
    }, 2 * 60 * 1000);

    return () => {
      subscription.unsubscribe();
      clearInterval(tokenCheckInterval);
      clearInterval(sessionInterval);
      clearInterval(validationInterval);
    };
  }, []);

  /**
   * Função de login
   * Gerencia autenticação de diferentes tipos de usuário
   */
  const login = async (email: string, password: string) => {
    try {
      console.log('AuthProvider: Iniciando login para:', email);
      
      // Limpar estado anterior antes do login
      clearAuthState();
      setUser(null);
      setSession(null);
      
      // Verificar se é o admin de demonstração
      if (email.toLowerCase() === 'admin@drivs.com.br' && password === 'admin') {
        const adminUser: AuthUser = {
          id: 'admin-demo-user',
          email: 'admin@drivs.com.br',
          name: 'Administrador DRIVS',
          role: UserRole.ADMIN,
          fullName: 'Administrador DRIVS',
          active: true
        };
        setUser(adminUser);
        console.log('AuthProvider: Admin demo login successful');
        return;
      }

      // Verificar se é o super admin
      if (email.toLowerCase() === 'superadmin@drivs.com.br' && password === 'F3lim@4510') {
        console.log('🔥 [SUPER ADMIN] Login do super admin detectado');
        const superAdminUser: AuthUser = {
          id: 'super-admin-user',
          email: 'superadmin@drivs.com.br',
          name: 'Super Administrador DRIVS',
          role: UserRole.ADMIN,
          fullName: 'Super Administrador DRIVS',
          active: true
        };
        setUser(superAdminUser);
        console.log('🔥 [SUPER ADMIN] Login bem-sucedido');
        return;
      }

      // Usar o sistema de login centralizado
      await handleLogin(email, password, setUser, setLoading);
      
      // Log do usuário após login para debug
      setTimeout(() => {
        console.log('👤 [LOGIN SUCCESS] Usuário logado:', {
          email: email,
          userSetInContext: !!user,
          userRole: user?.role
        });
      }, 100);
      
    } catch (error: any) {
      console.error('AuthProvider: Login error:', error);
      clearAuthState();
      setUser(null);
      setSession(null);
      
      // Mostrar mensagem de erro amigável
      if (error.message?.includes('Invalid login credentials')) {
        throw new Error('Email ou senha incorretos');
      } else if (error.message?.includes('Email not confirmed')) {
        throw new Error('Por favor, confirme seu email antes de fazer login');
      } else {
        throw new Error(error.message || 'Erro ao fazer login. Tente novamente.');
      }
    }
  };

  /**
   * Função de logout
   * Limpa estado e redireciona para login
   */
  const logout = async () => {
    console.log('🚪 [AUTH] Iniciando logout...');
    try {
      // Limpar estado primeiro
      clearAuthState();
      setUser(null);
      setSession(null);
      
      // Se for usuário demo ou mock, apenas redirecionar
      if (user && (isCustomUser(user.id) || !session)) {
        window.location.href = '/login';
        return;
      }

      // Para usuários reais, fazer logout do Supabase
      const { error } = await supabase.auth.signOut({ scope: 'global' });
      if (error) {
        console.error('Logout error:', error);
      }
      
      // Sempre redirecionar para login após logout
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
      window.location.href = '/login';
    }
  };

  const value = {
    user,
    login,
    logout,
    loading
  };

  console.log('AuthProvider: Rendering with:', { 
    hasUser: !!user, 
    loading, 
    userRole: user?.role, 
    userEmail: user?.email 
  });

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

/**
 * Hook para usar o contexto de autenticação
 * @returns AuthContextType - Contexto de autenticação
 */
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
