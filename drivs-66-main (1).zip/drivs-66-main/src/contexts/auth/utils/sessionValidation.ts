
/**
 * Utilitários para validação e gerenciamento de sessões de usuário
 * Responsável por verificar se tokens estão válidos e renovar sessões quando necessário
 */

import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import { toast } from "sonner";

/**
 * Verifica se uma sessão está válida baseada no tempo de expiração
 * @param session - Sessão do Supabase para validar
 * @returns true se a sessão está válida, false caso contrário
 */
export const isSessionValid = (session: Session | null): boolean => {
  if (!session) return false;
  
  const now = Math.floor(Date.now() / 1000);
  const expiresAt = session.expires_at || 0;
  
  // Verificar se a sessão expira em menos de 5 minutos
  const isExpiring = (expiresAt - now) < 300; // 5 minutos
  
  if (isExpiring) {
    console.warn('⚠️ [AUTH] Sessão expirando em breve ou já expirada');
    return false;
  }
  
  return true;
};

/**
 * Verifica a validade do token atual automaticamente
 * @returns Promise<boolean> - true se o token está válido
 */
export const checkTokenValidity = async (): Promise<boolean> => {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    
    if (error || !session) {
      console.log('🔒 [TOKEN CHECK] Nenhuma sessão ativa encontrada');
      return false;
    }
    
    const now = Math.floor(Date.now() / 1000);
    const expiresAt = session.expires_at || 0;
    
    if (expiresAt <= now) {
      console.warn('🔒 [TOKEN CHECK] Token expirado');
      toast.error('Sessão expirada. Faça login novamente.');
      setTimeout(() => {
        window.location.href = '/login';
      }, 1500);
      return false;
    }
    
    // Se expira em menos de 5 minutos, tentar renovar
    if ((expiresAt - now) < 300) {
      console.log('🔄 [TOKEN CHECK] Token próximo do vencimento, renovando...');
      const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
      
      if (refreshError || !refreshData.session) {
        console.error('❌ [TOKEN CHECK] Falha ao renovar token');
        toast.error('Sessão expirada. Faça login novamente.');
        setTimeout(() => {
          window.location.href = '/login';
        }, 1500);
        return false;
      }
      
      console.log('✅ [TOKEN CHECK] Token renovado com sucesso');
    }
    
    return true;
  } catch (error) {
    console.error('🔒 [TOKEN CHECK] Erro ao verificar token:', error);
    return false;
  }
};
