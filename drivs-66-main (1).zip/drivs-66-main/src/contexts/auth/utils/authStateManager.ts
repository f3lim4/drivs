
/**
 * Gerenciador de estado de autenticação
 * Responsável por limpar dados de autenticação e gerenciar localStorage
 */

/**
 * Limpa completamente o estado de autenticação do usuário
 * Remove tokens do localStorage e reseta estados
 */
export const clearAuthState = (): void => {
  console.log('🧹 [AUTH] Limpando estado de autenticação...');
  
  // Limpar localStorage de tokens antigos
  Object.keys(localStorage).forEach((key) => {
    if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
      localStorage.removeItem(key);
    }
  });
};

/**
 * Verifica se o usuário é um usuário customizado (demo/admin)
 * @param userId - ID do usuário para verificar
 * @returns true se for usuário customizado
 */
export const isCustomUser = (userId: string): boolean => {
  return userId === 'admin-demo-user' || 
         userId === 'super-admin-user';
};

/**
 * Verifica se o usuário é um admin
 * @param userId - ID do usuário para verificar
 * @returns true se for admin
 */
const isAdminUser = (userId: string): boolean => {
  return userId === 'admin-demo-user' || 
         userId === 'super-admin-user';
};
