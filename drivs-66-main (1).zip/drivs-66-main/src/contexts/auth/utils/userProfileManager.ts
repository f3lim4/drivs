
/**
 * Gerenciador de perfis de usuário
 * Responsável por criar objetos AuthUser a partir de dados do Supabase
 */

import { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { UserRole, DriverStatus } from "@/types";
import { AuthUser } from "../types";

/**
 * Cria um objeto AuthUser baseado no perfil do Supabase
 * @param supabaseUser - Usuário do Supabase
 * @returns Promise<AuthUser | null> - Objeto AuthUser completo ou null
 */
export const createAuthUserFromProfile = async (supabaseUser: User): Promise<AuthUser | null> => {
  try {
    console.log('Creating auth user for:', supabaseUser.email);
    
    // Buscar perfil do usuário
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', supabaseUser.id)
      .maybeSingle();

    if (profileError) {
      console.error('Error fetching profile:', profileError);
      return null;
    }

    if (!profile) {
      console.log('No profile found for user, creating basic user');
      return createBasicAuthUser(supabaseUser);
    }

    console.log('Profile found:', profile);

    let authUser: AuthUser = {
      id: supabaseUser.id,
      email: supabaseUser.email || '',
      name: profile.full_name || supabaseUser.email?.split('@')[0] || 'Usuário',
      role: profile.role as UserRole,
      fullName: profile.full_name,
      active: true
    };

    // Enriquecer dados baseado no tipo de usuário
    if (profile.role === UserRole.RENTAL_COMPANY) {
      authUser = await enrichRentalCompanyData(authUser, supabaseUser.id);
    } else if (profile.role === UserRole.DRIVER) {
      authUser = await enrichDriverData(authUser, supabaseUser.id);
    }

    console.log('Final auth user:', authUser);
    return authUser;
  } catch (error) {
    console.error('Error creating auth user from profile:', error);
    return null;
  }
};

/**
 * Cria um usuário básico quando não há perfil específico
 * @param supabaseUser - Usuário do Supabase
 * @returns AuthUser básico
 */
const createBasicAuthUser = (supabaseUser: User): AuthUser => {
  return {
    id: supabaseUser.id,
    email: supabaseUser.email || '',
    name: supabaseUser.email?.split('@')[0] || 'Usuário',
    role: UserRole.DRIVER,
    fullName: supabaseUser.email?.split('@')[0] || 'Usuário',
    active: true
  };
};

/**
 * Enriquece dados do usuário com informações de locadora
 * @param authUser - Usuário base
 * @param userId - ID do usuário
 * @returns Promise<AuthUser> - Usuário com dados de locadora
 */
const enrichRentalCompanyData = async (authUser: AuthUser, userId: string): Promise<AuthUser> => {
  console.log('Fetching rental company data...');
  const { data: company } = await supabase
    .from('rental_companies')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (company) {
    console.log('Company data found:', company);
    return {
      ...authUser,
      companyName: company.company_name,
      cnpj: company.cnpj,
      verified: company.verified,
      vehicleCount: company.vehicle_count,
      phone: company.phone,
      address: company.address,
      logo: company.logo,
      plan: company.plan,
      paymentStatus: company.payment_status,
      city: company.city,
      state: company.state
    };
  }

  return authUser;
};

/**
 * Enriquece dados do usuário com informações de motorista
 * @param authUser - Usuário base
 * @param userId - ID do usuário
 * @returns Promise<AuthUser> - Usuário com dados de motorista
 */
const enrichDriverData = async (authUser: AuthUser, userId: string): Promise<AuthUser> => {
  console.log('Fetching driver data...');
  const { data: driver } = await supabase
    .from('drivers')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (driver) {
    console.log('Driver data found:', driver);
    return {
      ...authUser,
      email: driver.email || authUser.email,
      fullName: driver.full_name,
      cpf: driver.cpf,
      rg: driver.rg,
      phone: driver.phone,
      address: driver.address,
      city: driver.city,
      state: driver.state,
      cnh: driver.cnh,
      cnh_expires: driver.cnh_expires,
      date_of_birth: driver.date_of_birth,
      status: driver.status as DriverStatus,
      available: driver.available,
      rating: driver.rating,
      violations: driver.violations,
      profile_photo: driver.profile_photo,
      app_screenshot: driver.app_screenshot,
      address_proof: driver.address_proof,
      rejection_reason: driver.rejection_reason,
      rejection_date: driver.rejection_date
    };
  }

  return authUser;
};
