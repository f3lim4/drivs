
/**
 * Gerenciador de sessões
 * Responsável por manter sessões ativas e validar periodicamente
 */

import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import { toast } from "sonner";
import { AuthUser } from "../types";
import { isSessionValid } from "./sessionValidation";
import { clearAuthState, isCustomUser } from "./authStateManager";

/**
 * Mantém a sessão ativa e renova automaticamente quando necessário
 * @param user - Usuário atual
 * @param session - Sessão atual
 * @param setSession - Função para atualizar a sessão
 */
export const maintainSession = async (
  user: AuthUser | null,
  session: Session | null,
  setSession: (session: Session | null) => void
): Promise<void> => {
  try {
    // Se é usuário customizado (admin demo, locadora ou motorista), não precisa renovar sessão do Supabase
    if (user && (isCustomUser(user.id) || !session)) {
      console.log('Usuário customizado detectado, mantendo sessão ativa');
      return;
    }

    // Para usuários reais do Supabase, verificar e renovar sessão
    if (session && !isSessionValid(session)) {
      console.log('🔄 [AUTH] Tentando renovar sessão...');
      const { data, error } = await supabase.auth.refreshSession();
      if (error) {
        console.error('❌ [AUTH] Erro ao renovar sessão:', error);
        handleSessionError();
      } else if (data.session) {
        console.log('✅ [AUTH] Sessão renovada com sucesso');
        setSession(data.session);
      }
    }
  } catch (error) {
    console.error('Erro ao manter sessão:', error);
    clearAuthState();
  }
};

/**
 * Valida se a sessão atual ainda está válida
 * @param user - Usuário atual
 * @param session - Sessão atual
 */
export const validateSession = async (
  user: AuthUser | null,
  session: Session | null
): Promise<void> => {
  try {
    if (!user) return;

    // Se é usuário customizado, apenas verificar se ainda existe
    if (isCustomUser(user.id)) {
      console.log('🔒 [SESSION] Admin demo/super - sessão sempre válida');
      return;
    }

    // Para locadoras customizadas, verificar se ainda existem no sistema
    if (user.role === 'rental_company' && !session) {
      console.log('🔒 [SESSION] Validando locadora customizada:', user.email);
      return;
    }

    // Para usuários do Supabase, verificar sessão
    if (session && !isSessionValid(session)) {
      console.error('🔒 [SESSION] Sessão inválida ou expirada');
      handleSessionError();
    }
  } catch (error) {
    console.error('🔒 [SESSION] Erro ao validar sessão:', error);
    clearAuthState();
  }
};

/**
 * Manipula erros de sessão redirecionando para login
 */
const handleSessionError = (): void => {
  clearAuthState();
  toast.error('Sua sessão expirou. Faça login novamente.');
  setTimeout(() => {
    window.location.href = '/login';
  }, 2000);
};
