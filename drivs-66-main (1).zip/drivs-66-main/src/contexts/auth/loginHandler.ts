import { getApprovedCompanyByEmail, checkCompanyCredentials, getRegisteredCompanyByEmail, checkRegisteredCompanyCredentials } from "./companyAuthUtils";
import { getDriverByEmail, checkDriverCredentials } from "./driverAuthUtils";
import { AuthUser } from "./types";
import { supabase } from "@/integrations/supabase/client";
import { UserRole } from "@/types";

export const handleLogin = async (
  email: string, 
  password: string,
  setUser: (user: AuthUser | null) => void,
  setLoading: (loading: boolean) => void
): Promise<void> => {
  console.log('=== INÍCIO DO LOGIN ===');
  console.log('Email recebido:', email);
  setLoading(true);
  
  try {
    const normalizedEmail = email.toLowerCase().trim();
    console.log('Email normalizado:', normalizedEmail);

    // Validação inicial
    if (!normalizedEmail || normalizedEmail.length < 3 || !normalizedEmail.includes('@')) {
      console.log('❌ Email inválido');
      throw new Error("Por favor, insira um email válido");
    }

    if (!password || password.length === 0) {
      console.log('❌ Senha não fornecida');
      throw new Error("Por favor, insira uma senha");
    }

    // PRIMEIRO: Tentar autenticação com Supabase Auth
    console.log('🔐 Tentando autenticação com Supabase Auth...');
    try {
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password: password,
      });

      if (authData?.user && !authError) {
        console.log('✅ Autenticação Supabase bem-sucedida para:', authData.user.email);
        
        // Criar AuthUser a partir dos dados do Supabase
        const supabaseUser: AuthUser = {
          id: authData.user.id,
          email: authData.user.email || normalizedEmail,
          name: authData.user.user_metadata?.name || authData.user.email?.split('@')[0] || 'Usuário',
          role: (authData.user.user_metadata?.role as UserRole) || 'driver',
          companyName: authData.user.user_metadata?.companyName,
          isApproved: authData.user.user_metadata?.isApproved || true,
        };
        
        console.log('✅ Login com Supabase Auth realizado com sucesso');
        setUser(supabaseUser);
        return;
      }

      // Se chegou aqui, a autenticação Supabase falhou
      console.log('ℹ️ Autenticação Supabase falhou, tentando métodos customizados...');
      console.log('Erro Supabase:', authError?.message);
      
    } catch (supabaseError) {
      console.log('ℹ️ Erro na autenticação Supabase, tentando métodos customizados...');
      console.log('Erro:', supabaseError);
    }

    // SEGUNDO: Verificar se é uma locadora aprovada
    console.log('🏢 Verificando se é locadora aprovada...');
    const approvedCompany = await getApprovedCompanyByEmail(normalizedEmail);
    
    if (approvedCompany) {
      console.log('✅ Locadora aprovada encontrada:', approvedCompany.companyName);
      
      const validCredentials = await checkCompanyCredentials(normalizedEmail, password);
      
      if (!validCredentials) {
        console.log('❌ Credenciais inválidas para locadora aprovada');
        throw new Error("Email ou senha incorretos");
      }
      
      console.log('✅ Credenciais da locadora aprovada válidas! Fazendo login...');
      setUser(approvedCompany);
      console.log('✅ Login de locadora aprovada realizado com sucesso');
      return;
    }

    console.log('ℹ️ Não é locadora aprovada, verificando registros de locadoras...');

    // TERCEIRO: Verificar se é uma locadora registrada
    console.log('🏢 Verificando se é locadora registrada...');
    const registeredCompany = await getRegisteredCompanyByEmail(normalizedEmail);
    
    if (registeredCompany) {
      console.log('✅ Locadora registrada encontrada:', registeredCompany.companyName);
      
      const validCredentials = await checkRegisteredCompanyCredentials(normalizedEmail, password);
      
      if (!validCredentials) {
        console.log('❌ Credenciais inválidas para locadora registrada');
        throw new Error("Email ou senha incorretos");
      }
      
      console.log('✅ Credenciais da locadora registrada válidas! Fazendo login...');
      setUser(registeredCompany);
      console.log('✅ Login de locadora registrada realizado com sucesso');
      return;
    }

    console.log('ℹ️ Não é locadora registrada, verificando motoristas...');

    // QUARTO: Verificar se é motorista registrado
    console.log('🚗 Verificando se é motorista registrado...');
    const driver = await getDriverByEmail(normalizedEmail);
    
    if (driver) {
      console.log('✅ Motorista encontrado:', driver.name);
      
      const validCredentials = await checkDriverCredentials(normalizedEmail, password);
      
      if (!validCredentials) {
        console.log('❌ Credenciais inválidas para motorista');
        throw new Error("Email ou senha incorretos");
      }
      
      console.log('✅ Credenciais do motorista válidas! Fazendo login...');
      setUser(driver);
      console.log('✅ Login de motorista realizado com sucesso');
      return;
    }

    console.log('❌ Email não encontrado no sistema:', normalizedEmail);
    throw new Error("Email não encontrado. Verifique se você já possui cadastro no sistema.");
    
  } catch (error) {
    console.error('❌ Erro no login:', error);
    throw error;
  } finally {
    setLoading(false);
    console.log('=== FIM DO LOGIN ===');
  }
};