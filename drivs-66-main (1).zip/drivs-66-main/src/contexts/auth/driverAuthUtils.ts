
import { supabase } from "@/integrations/supabase/client";
import { UserRole, DriverStatus } from "@/types";
import { AuthUser } from "./types";

export const getDriverByEmail = async (email: string): Promise<AuthUser | null> => {
  try {
    console.log('Checking for driver with email:', email);
    
    const normalizedEmail = email.toLowerCase().trim();
    
    // Primeiro, buscar na tabela driver_registrations
    const { data: driverRegistration, error: regError } = await supabase
      .from('driver_registrations')
      .select('*')
      .eq('email', normalizedEmail)
      .maybeSingle();

    if (regError) {
      console.error('Error fetching driver registration:', regError);
    }

    if (driverRegistration) {
      console.log('Found driver registration:', driverRegistration);

      const authUser: AuthUser = {
        id: driverRegistration.id,
        email: driverRegistration.email,
        name: driverRegistration.full_name,
        role: UserRole.DRIVER,
        fullName: driverRegistration.full_name,
        cpf: driverRegistration.cpf,
        phone: driverRegistration.phone,
        address: driverRegistration.address,
        city: driverRegistration.city,
        state: driverRegistration.state,
        date_of_birth: driverRegistration.date_of_birth,
        status: driverRegistration.status as DriverStatus,
        active: true,
        available: false,
        rating: 0,
        violations: 0
      };

      return authUser;
    }

    // Se não encontrou em driver_registrations, buscar na tabela drivers
    const { data: driver, error: driverError } = await supabase
      .from('drivers')
      .select('*')
      .eq('email', normalizedEmail)
      .maybeSingle();

    if (driverError) {
      console.error('Error fetching driver:', driverError);
      return null;
    }

    if (!driver) {
      console.log('No driver found for email:', normalizedEmail);
      return null;
    }

    console.log('Found driver:', driver);

    const authUser: AuthUser = {
      id: driver.id,
      email: driver.email,
      name: driver.full_name,
      role: UserRole.DRIVER,
      fullName: driver.full_name,
      cpf: driver.cpf,
      rg: driver.rg,
      phone: driver.phone,
      address: driver.address,
      city: driver.city,
      state: driver.state,
      cnh: driver.cnh,
      cnh_expires: driver.cnh_expires,
      date_of_birth: driver.date_of_birth,
      status: driver.status as DriverStatus,
      available: driver.available,
      rating: driver.rating,
      violations: driver.violations,
      profile_photo: driver.profile_photo,
      app_screenshot: driver.app_screenshot,
      address_proof: driver.address_proof,
      rejection_reason: driver.rejection_reason,
      rejection_date: driver.rejection_date,
      active: true
    };

    return authUser;
  } catch (error) {
    console.error('Error in getDriverByEmail:', error);
    return null;
  }
};

export const checkDriverCredentials = async (email: string, password: string): Promise<boolean> => {
  try {
    console.log('=== VERIFICAÇÃO DE CREDENCIAIS (MOTORISTA) ===');
    console.log('Email:', email);
    console.log('Senha fornecida:', password);
    
    const normalizedEmail = email.toLowerCase().trim();
    
    // Primeiro, verificar na tabela driver_registrations
    const { data: driverRegistration, error: regError } = await supabase
      .from('driver_registrations')
      .select('*')
      .eq('email', normalizedEmail)
      .maybeSingle();

    if (!regError && driverRegistration) {
      console.log('Driver registration encontrado:', driverRegistration.full_name);
      console.log('Senha armazenada:', driverRegistration.password_hash);
      console.log('Senha fornecida:', password);
      
      // Comparação simples de strings
      const isValid = password === driverRegistration.password_hash;
      console.log('Resultado da comparação:', isValid ? '✅ VÁLIDA' : '❌ INVÁLIDA');
      
      return isValid;
    }

    // Se não encontrou em driver_registrations, verificar na tabela drivers
    // Nota: drivers normalmente usam o sistema de auth do Supabase, então pode não ter password_hash
    const { data: driver, error: driverError } = await supabase
      .from('drivers')
      .select('*')
      .eq('email', normalizedEmail)
      .maybeSingle();

    if (driverError) {
      console.error('Erro ao buscar motorista:', driverError);
      return false;
    }

    if (!driver) {
      console.log('❌ Motorista não encontrado');
      return false;
    }

    // Para motoristas na tabela drivers, se não houver password_hash,
    // pode ser que usem o sistema de auth do Supabase
    // Por enquanto, vamos retornar false para forçar o uso de driver_registrations
    console.log('❌ Motorista encontrado mas sem sistema de senha próprio');
    return false;
  } catch (error) {
    console.error('Erro na verificação de credenciais do motorista:', error);
    return false;
  }
};
