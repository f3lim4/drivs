
import { supabase } from "@/integrations/supabase/client";
import { UserRole } from "@/types";
import { AuthUser } from "./types";

export const getApprovedCompanyByEmail = async (email: string): Promise<AuthUser | null> => {
  try {
    console.log('Checking for approved company with email:', email);
    
    const normalizedEmail = email.toLowerCase().trim();
    
    const { data: company, error } = await supabase
      .from('approved_rental_companies')
      .select('*')
      .eq('email', normalizedEmail)
      .maybeSingle();

    if (error) {
      console.error('Error fetching approved company:', error);
      return null;
    }

    if (!company) {
      console.log('No approved company found for email:', normalizedEmail);
      return null;
    }

    console.log('Found approved company:', company);

    const authUser: AuthUser = {
      id: company.id,
      email: company.email,
      name: company.contact_name,
      role: UserRole.RENTAL_COMPANY,
      companyName: company.company_name,
      cnpj: company.cnpj,
      verified: company.verified,
      vehicleCount: company.vehicle_count,
      active: company.is_active,
      fullName: company.contact_name,
      phone: company.contact_phone,
      
      // Campos específicos da locadora aprovada
      tradingName: company.trading_name,
      websiteUrl: company.website_url,
      description: company.description,
      address: company.address,
      city: company.city,
      state: company.state,
      zipCode: company.zip_code,
      contactPosition: company.contact_position,
      plan: company.plan,
      paymentStatus: company.payment_status,
      trialStartDate: company.trial_start_date,
      trialEndDate: company.trial_end_date,
      dueDate: company.due_date,
      driversCount: company.drivers_count,
      registrationDate: company.registration_date
    };

    return authUser;
  } catch (error) {
    console.error('Error in getApprovedCompanyByEmail:', error);
    return null;
  }
};

export const getRegisteredCompanyByEmail = async (email: string): Promise<AuthUser | null> => {
  try {
    console.log('Checking for registered company with email:', email);
    
    const normalizedEmail = email.toLowerCase().trim();
    
    const { data: company, error } = await supabase
      .from('rental_company_registrations')
      .select('*')
      .eq('email', normalizedEmail)
      .maybeSingle();

    if (error) {
      console.error('Error fetching registered company:', error);
      return null;
    }

    if (!company) {
      console.log('No registered company found for email:', normalizedEmail);
      return null;
    }

    console.log('Found registered company:', company);

    const authUser: AuthUser = {
      id: company.id,
      email: company.email,
      name: company.contact_name,
      role: UserRole.RENTAL_COMPANY,
      companyName: company.company_name,
      cnpj: company.cnpj,
      verified: false, // Registradas não são verificadas ainda
      vehicleCount: 0,
      active: true,
      fullName: company.contact_name,
      phone: company.contact_phone,
      
      // Campos específicos da locadora registrada
      tradingName: company.trading_name,
      websiteUrl: company.website_url,
      description: company.description,
      address: company.address,
      city: company.city,
      state: company.state,
      zipCode: company.zip_code,
      contactPosition: company.contact_position,
      plan: 'basic',
      paymentStatus: 'trial'
    };

    return authUser;
  } catch (error) {
    console.error('Error in getRegisteredCompanyByEmail:', error);
    return null;
  }
};

export const checkCompanyCredentials = async (email: string, password: string): Promise<boolean> => {
  try {
    console.log('=== VERIFICAÇÃO DE CREDENCIAIS (APROVADA) ===');
    console.log('Email:', email);
    console.log('Senha fornecida:', password);
    
    const normalizedEmail = email.toLowerCase().trim();
    
    // PRIMEIRO: Verificar se o email existe
    const { data: company, error } = await supabase
      .from('approved_rental_companies')
      .select('*')
      .eq('email', normalizedEmail)
      .maybeSingle();

    if (error) {
      console.error('Erro ao buscar empresa aprovada:', error);
      return false;
    }

    if (!company) {
      console.log('❌ Empresa aprovada não encontrada para email:', normalizedEmail);
      return false;
    }

    console.log('Empresa aprovada encontrada:', company.company_name);
    console.log('Email da empresa:', company.email);
    console.log('Senha armazenada:', company.password_hash);
    console.log('Senha fornecida:', password);
    
    // VALIDAÇÃO RIGOROSA: Email E senha devem corresponder EXATAMENTE
    const emailMatches = company.email === normalizedEmail;
    const passwordMatches = password === company.password_hash;
    
    console.log('Email corresponde:', emailMatches);
    console.log('Senha corresponde:', passwordMatches);
    
    const isValid = emailMatches && passwordMatches;
    console.log('Resultado da validação:', isValid ? '✅ VÁLIDA' : '❌ INVÁLIDA');
    
    if (!isValid) {
      console.log('❌ Credenciais inválidas - email ou senha incorretos');
    }
    
    return isValid;
  } catch (error) {
    console.error('Erro na verificação de credenciais aprovada:', error);
    return false;
  }
};

export const checkRegisteredCompanyCredentials = async (email: string, password: string): Promise<boolean> => {
  try {
    console.log('=== VERIFICAÇÃO DE CREDENCIAIS (REGISTRADA) ===');
    console.log('Email:', email);
    console.log('Senha fornecida:', password);
    
    const normalizedEmail = email.toLowerCase().trim();
    
    // PRIMEIRO: Verificar se o email existe
    const { data: company, error } = await supabase
      .from('rental_company_registrations')
      .select('*')
      .eq('email', normalizedEmail)
      .maybeSingle();

    if (error) {
      console.error('Erro ao buscar empresa registrada:', error);
      return false;
    }

    if (!company) {
      console.log('❌ Empresa registrada não encontrada para email:', normalizedEmail);
      return false;
    }

    console.log('Empresa registrada encontrada:', company.company_name);
    console.log('Email da empresa:', company.email);
    console.log('Senha armazenada:', company.password_hash);
    console.log('Senha fornecida:', password);
    
    // VALIDAÇÃO RIGOROSA: Email E senha devem corresponder EXATAMENTE
    const emailMatches = company.email === normalizedEmail;
    const passwordMatches = password === company.password_hash;
    
    console.log('Email corresponde:', emailMatches);
    console.log('Senha corresponde:', passwordMatches);
    
    const isValid = emailMatches && passwordMatches;
    console.log('Resultado da validação:', isValid ? '✅ VÁLIDA' : '❌ INVÁLIDA');
    
    if (!isValid) {
      console.log('❌ Credenciais inválidas - email ou senha incorretos');
    }
    
    return isValid;
  } catch (error) {
    console.error('Erro na verificação de credenciais registrada:', error);
    return false;
  }
};
