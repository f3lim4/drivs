
import React from 'react';
import { AuthProvider } from './AuthContext';
import { SessionManager } from '@/components/auth/SessionManager';

interface AuthWrapperProps {
  children: React.ReactNode;
}

export const AuthWrapper: React.FC<AuthWrapperProps> = ({ children }) => {
  return (
    <AuthProvider>
      <SessionManager />
      {children}
    </AuthProvider>
  );
};
