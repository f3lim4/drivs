
import React, { createContext, useContext, useState, useEffect } from "react";

interface SiteSettings {
  id: string;
  site_title: string;
  site_description: string;
  site_keywords: string;
  site_logo: string | null;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  banner_images: string[] | null;
  created_at: string;
  updated_at: string;
}

interface SiteSettingsContextType {
  settings: SiteSettings | null;
  loading: boolean;
  updateSettings: (values: Partial<SiteSettings>) => Promise<void>;
}

const defaultSettings: SiteSettings = {
  id: "1",
  site_title: "Drivs - Plataforma que conecta locadoras e motoristas",
  site_description: "Plataforma que conecta locadoras e motoristas",
  site_keywords: "aluguel, motoristas, aplicativo, veículos",
  site_logo: null,
  primary_color: "#3b82f6",
  secondary_color: "#1e40af",
  accent_color: "#60a5fa",
  banner_images: null,
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString()
};

const SiteSettingsContext = createContext<SiteSettingsContextType>({
  settings: defaultSettings,
  loading: false,
  updateSettings: async () => {}
});

const SiteSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SiteSettings | null>(defaultSettings);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // For now, just use default settings without database
    setSettings(defaultSettings);
    
    // Update document title
    document.title = defaultSettings.site_title;
  }, []);

  const updateSettings = async (values: Partial<SiteSettings>) => {
    try {
      // For now, just update local state without database
      const updatedSettings = {
        ...settings!,
        ...values,
        updated_at: new Date().toISOString()
      };
      
      setSettings(updatedSettings);
      
      // Update document title if the title was updated
      if (values.site_title) {
        document.title = values.site_title;
      }
    } catch (error) {
      console.error("Error updating site settings:", error);
      throw error;
    }
  };

  return (
    <SiteSettingsContext.Provider value={{ settings: settings || defaultSettings, loading, updateSettings }}>
      {children}
    </SiteSettingsContext.Provider>
  );
};

export const useSiteSettings = () => useContext(SiteSettingsContext);
