// Re-export everything from the refactored auth module
export { useAuth } from "./auth/AuthContext";