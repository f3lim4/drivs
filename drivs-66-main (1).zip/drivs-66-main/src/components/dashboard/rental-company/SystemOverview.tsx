
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { 
  Car, Users, FileText, DollarSign, Wrench, AlertTriangle, 
  CheckCircle, Clock, Search, Calendar, TrendingUp, Bell,
  Plus, Eye, BarChart3, Shield, MapPin
} from "lucide-react";

const SystemOverview = () => {
  const navigate = useNavigate();

  const quickStats = [
    { title: "Contratos Ativos", value: 18, icon: FileText, color: "text-blue-600", bg: "bg-blue-100" },
    { title: "Vistorias Pendentes", value: 5, icon: Search, color: "text-amber-600", bg: "bg-amber-100" },
    { title: "Manutenções Agendadas", value: 3, icon: Wrench, color: "text-orange-600", bg: "bg-orange-100" },
    { title: "Infrações Pendentes", value: 2, icon: AlertTriangle, color: "text-red-600", bg: "bg-red-100" },
  ];

  const recentActivities = [
    { text: "Novo motorista aprovado - João Silva", time: "2h atrás", type: "success" },
    { text: "Vistoria agendada - Honda Civic ABC-1234", time: "4h atrás", type: "info" },
    { text: "Pagamento recebido - R$ 2.500", time: "6h atrás", type: "success" },
    { text: "Manutenção concluída - Toyota Corolla DEF-5678", time: "1d atrás", type: "info" },
  ];

  const quickActions = [
    { title: "Cadastrar Veículo", icon: Plus, action: () => navigate("/veiculos"), color: "bg-blue-500 hover:bg-blue-600" },
    { title: "Gerenciar Motoristas", icon: Users, action: () => navigate("/motoristas"), color: "bg-green-500 hover:bg-green-600" },
    { title: "Ver Relatórios", icon: BarChart3, action: () => navigate("/relatorios"), color: "bg-purple-500 hover:bg-purple-600" },
    { title: "Configurações", icon: Shield, action: () => navigate("/configuracoes"), color: "bg-gray-500 hover:bg-gray-600" },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Rápidas do Sistema */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickStats.map((stat, index) => (
          <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-full ${stat.bg}`}>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Atividades Recentes */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-semibold">Atividades Recentes</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => navigate("/atividades")}>
              <Eye className="h-4 w-4 mr-1" />
              Ver todas
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50">
                <div className={`w-2 h-2 rounded-full mt-2 ${
                  activity.type === 'success' ? 'bg-green-500' : 'bg-blue-500'
                }`} />
                <div className="flex-1">
                  <p className="text-sm font-medium">{activity.text}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Ações Rápidas */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Ações Rápidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {quickActions.map((action, index) => (
                <Button
                  key={index}
                  onClick={action.action}
                  className={`${action.color} text-white h-16 flex flex-col items-center justify-center gap-1`}
                >
                  <action.icon className="h-5 w-5" />
                  <span className="text-xs text-center">{action.title}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Resumo de Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Car className="h-4 w-4" />
              Status dos Veículos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Disponíveis</span>
              <Badge className="bg-green-100 text-green-800">12</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Alugados</span>
              <Badge className="bg-blue-100 text-blue-800">8</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Manutenção</span>
              <Badge className="bg-orange-100 text-orange-800">3</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Parados</span>
              <Badge className="bg-gray-100 text-gray-800">1</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4" />
              Status dos Motoristas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Aprovados</span>
              <Badge className="bg-green-100 text-green-800">15</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Em análise</span>
              <Badge className="bg-yellow-100 text-yellow-800">3</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Pendentes</span>
              <Badge className="bg-blue-100 text-blue-800">2</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Bloqueados</span>
              <Badge className="bg-red-100 text-red-800">1</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Resumo Financeiro
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Receita do Mês</span>
              <span className="font-semibold text-green-600">R$ 45.600</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Pagamentos Pendentes</span>
              <span className="font-semibold text-amber-600">R$ 8.200</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Despesas</span>
              <span className="font-semibold text-red-600">R$ 12.400</span>
            </div>
            <div className="flex justify-between items-center border-t pt-2">
              <span className="text-sm font-medium">Lucro Líquido</span>
              <span className="font-bold text-blue-600">R$ 33.200</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SystemOverview;
