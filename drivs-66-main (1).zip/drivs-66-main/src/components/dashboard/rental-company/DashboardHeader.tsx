
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Users, Car, DollarSign, Settings } from "lucide-react";
import { toast } from "sonner";
import EditDashboardDialog from './EditDashboardDialog';
import ReferralLinkBox from './ReferralLinkBox';
import { useAuth } from "@/contexts/AuthContext";
import { getVehiclesByCompany } from "@/pages/RentalCompanies/data/mockVehicles";
import { useDriverData } from "@/pages/Drivers/hooks/useDriverData";
import { DriverStatus } from "@/types";

const DashboardHeader = () => {
  const [showEditDialog, setShowEditDialog] = useState(false);
  const { user } = useAuth();
  const { drivers } = useDriverData();

  // Obter veículos específicos da locadora logada
  const companyVehicles = user?.role === "rental_company" ? getVehiclesByCompany(user.id) : [];
  
  // Calcular estatísticas reais
  const totalVehicles = companyVehicles.length;
  const rentedVehicles = companyVehicles.filter(v => v.status === "rented").length;
  const activeDrivers = drivers.filter(d => d.status === DriverStatus.ACTIVE).length;
  const monthlyRevenue = rentedVehicles * 350 * 4; // Aproximadamente 4 semanas por mês
  const occupancyRate = totalVehicles > 0 ? Math.round((rentedVehicles / totalVehicles) * 100) : 0;

  const handleEditDashboard = () => {
    setShowEditDialog(true);
  };

  return (
    <>
      <div className="space-y-6">
        <div className="page-header">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                PAINEL DA LOCADORA
              </h1>
              <p className="page-subtitle">
                Visão geral completa do desempenho da sua locadora
              </p>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={handleEditDashboard}
                title="Editar Dashboard"
              >
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Link de Referência para Motoristas - COMPONENTE PRINCIPAL EM DESTAQUE */}
        <ReferralLinkBox />

        {/* Main Stats Cards - Visão Geral */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Veículos Ativos</CardTitle>
              <Car className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-700">{totalVehicles}</div>
              <p className="text-xs text-muted-foreground">
                {rentedVehicles} alugados
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-green-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Motoristas Ativos</CardTitle>
              <Users className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-700">{activeDrivers}</div>
              <p className="text-xs text-muted-foreground">
                Com contratos vigentes
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-yellow-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Receita Mensal</CardTitle>
              <DollarSign className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-700">R$ {monthlyRevenue.toLocaleString('pt-BR')}</div>
              <p className="text-xs text-muted-foreground">
                Baseado em {rentedVehicles} veículos alugados
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taxa de Ocupação</CardTitle>
              <Building2 className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-700">{occupancyRate}%</div>
              <p className="text-xs text-muted-foreground">
                {rentedVehicles} de {totalVehicles} veículos
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <EditDashboardDialog 
        open={showEditDialog} 
        onOpenChange={setShowEditDialog}
      />
    </>
  );
};

export default DashboardHeader;
