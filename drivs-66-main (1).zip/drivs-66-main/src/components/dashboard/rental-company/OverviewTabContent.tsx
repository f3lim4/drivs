
import DashboardCharts from './DashboardCharts';
import SystemOverview from './SystemOverview';

const OverviewTabContent = () => {
  return (
    <div className="space-y-6">
      {/* Visão Geral Completa do Sistema */}
      <SystemOverview />
      
      {/* Gráficos e Análises */}
      <DashboardCharts />
    </div>
  );
};

export default OverviewTabContent;
