
import { useNavigate } from "react-router-dom";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Car, Wrench, FileText, AlertTriangle, DollarSign, X, BarChart3, FileCheck } from "lucide-react";
import { toast } from "sonner";

const QuickAccess = () => {
  const navigate = useNavigate();
  
  const quickLinks = [{
    title: "Gerenciar Motoristas",
    icon: Users,
    path: "/motoristas-admin",
    color: "from-blue-500 to-blue-600",
    description: "Lista, aprovação e gestão de motoristas"
  }, {
    title: "Gerenciar Veículos",
    icon: Car,
    path: "/veiculos",
    color: "from-green-500 to-green-600",
    description: "Cadastro e manutenção da frota"
  }, {
    title: "Manutenções",
    icon: Wrench,
    path: "/manutencao",
    color: "from-amber-500 to-amber-600",
    description: "Registro e histórico de serviços"
  }, {
    title: "Pagamentos",
    icon: DollarSign,
    path: "/pagamentos",
    color: "from-purple-500 to-purple-600",
    description: "Controle financeiro e cobranças"
  }, {
    title: "Infrações",
    icon: AlertTriangle,
    path: "/infracoes",
    color: "from-red-500 to-red-600",
    description: "Registro de multas e ocorrências"
  }, {
    title: "Contratos",
    icon: FileText,
    path: "/contratos",
    color: "from-teal-500 to-teal-600",
    description: "Geração e acompanhamento"
  }, {
    title: "Negativar Motoristas",
    icon: X,
    path: "/negativar",
    color: "from-rose-500 to-rose-600",
    description: "Processo de negativação"
  }, {
    title: "Relatórios",
    icon: BarChart3,
    path: "/painel?tab=reports",
    color: "from-cyan-500 to-cyan-600",
    description: "Análises e exportações"
  }];

  // Card de status da documentação
  const statusCard = {
    title: "Status da Documentação",
    icon: FileCheck,
    path: "/documentacao",
    color: "from-green-500 to-green-600",
    description: "Verificar status dos documentos",
    progress: 100
  };

  const handleCardClick = (path: string, title: string) => {
    navigate(path);
    toast.success(`Redirecionando para ${title}`);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Acesso Rápido</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Card de Status - 100% da largura */}
        <div 
          className="w-full p-4 border rounded-lg cursor-pointer hover:shadow-md transition-shadow bg-gradient-to-r from-green-50 to-green-100 border-green-200"
          onClick={() => handleCardClick(statusCard.path, statusCard.title)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`p-3 rounded-full bg-gradient-to-r ${statusCard.color}`}>
                <statusCard.icon className="h-5 w-5 text-white" />
              </div>
              <div>
                <h4 className="font-medium">{statusCard.title}</h4>
                <p className="text-sm text-muted-foreground">{statusCard.description}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-600">{statusCard.progress}%</div>
              <p className="text-xs text-green-600">Completo</p>
            </div>
          </div>
        </div>

        {/* Grid de links rápidos */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {quickLinks.map((link, index) => (
            <Button
              key={index}
              variant="outline"
              className="h-auto p-4 justify-start"
              onClick={() => handleCardClick(link.path, link.title)}
            >
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-md bg-gradient-to-r ${link.color}`}>
                  <link.icon className="h-4 w-4 text-white" />
                </div>
                <div className="text-left">
                  <div className="font-medium">{link.title}</div>
                  <div className="text-xs text-muted-foreground">{link.description}</div>
                </div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickAccess;
