
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User, Car, Clock, CheckCircle, DollarSign, AlertTriangle } from "lucide-react";

// Mock data for recent activities
const recentActivities = [
  {
    id: "act1",
    type: "driver",
    title: "Novo motorista pendente",
    description: "João Silva enviou uma solicitação de cadastro",
    time: "Há 10 minutos",
    status: "pending",
  },
  {
    id: "act2",
    type: "payment",
    title: "Pagamento recebido",
    description: "R$ 1.200,00 - Maria Oliveira",
    time: "Há 2 horas",
    status: "completed",
  },
  {
    id: "act3",
    type: "vehicle",
    title: "Veículo em manutenção",
    description: "Toyota Corolla - Placa ABC-1234",
    time: "Há 5 horas",
    status: "warning",
  },
  {
    id: "act4",
    type: "inspection",
    title: "Vistoria concluída",
    description: "Honda Civic - Placa DEF-5678",
    time: "Há 1 dia",
    status: "completed",
  },
  {
    id: "act5",
    type: "violation",
    title: "Nova infração registrada",
    description: "Renault Kwid - Placa GHI-9012",
    time: "Há 2 dias",
    status: "warning",
  }
];

const RecentActivities = () => {
  const navigate = useNavigate();

  // Helper function to get appropriate icon
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "driver":
        return <User className="h-5 w-5 text-blue-600" />;
      case "vehicle":
        return <Car className="h-5 w-5 text-green-600" />;
      case "payment":
        return <DollarSign className="h-5 w-5 text-purple-600" />;
      case "inspection":
        return <CheckCircle className="h-5 w-5 text-teal-600" />;
      case "violation":
        return <AlertTriangle className="h-5 w-5 text-red-600" />;
      default:
        return <Clock className="h-5 w-5 text-gray-600" />;
    }
  };

  // Helper function to get appropriate badge
  const getActivityBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-600 border-yellow-200">Pendente</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">Concluído</Badge>;
      case "warning":
        return <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">Atenção</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Atividades Recentes</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentActivities.map((activity) => (
            <div 
              key={activity.id}
              className="flex items-start gap-4 p-3 bg-muted/40 rounded-lg hover:bg-muted/60 transition-colors"
            >
              <div className="p-2 bg-white rounded-full shadow-sm">
                {getActivityIcon(activity.type)}
              </div>
              
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">{activity.title}</h4>
                  {getActivityBadge(activity.status)}
                </div>
                <p className="text-sm text-muted-foreground">{activity.description}</p>
                <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
              </div>
            </div>
          ))}
          
          <Button 
            variant="ghost" 
            className="w-full mt-2 text-muted-foreground hover:text-foreground"
            onClick={() => navigate("/atividades")}
          >
            Ver todas as atividades
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentActivities;
