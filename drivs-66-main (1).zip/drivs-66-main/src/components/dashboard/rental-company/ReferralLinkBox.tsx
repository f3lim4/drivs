
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { Link, Share2, Copy, Check } from "lucide-react";
import { toast } from "sonner";

const ReferralLinkBox = () => {
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);
  
  // Gerar link único baseado no ID da locadora
  const referralLink = `${window.location.origin}/cadastro-motorista?ref=${user?.id || 'demo'}`;
  
  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopied(true);
      toast.success("Link copiado para a área de transferência!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Erro ao copiar o link");
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Cadastro de Motorista - Nossa Locadora',
          text: 'Cadastre-se como motorista em nossa locadora',
          url: referralLink,
        });
      } catch (err) {
        toast.error("Erro ao compartilhar");
      }
    } else {
      handleCopyLink();
    }
  };

  return (
    <Card className="border-l-4 border-l-blue-500">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium">Link de Cadastro para Motoristas</CardTitle>
        <Link className="h-5 w-5 text-blue-600" />
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Compartilhe este link com motoristas interessados. Eles aparecerão automaticamente na sua análise de motoristas.
        </p>
        
        <div className="flex gap-2">
          <Input
            value={referralLink}
            readOnly
            className="font-mono text-sm"
          />
          <Button
            onClick={handleCopyLink}
            variant="outline"
            size="sm"
            className="shrink-0"
          >
            {copied ? (
              <Check className="h-4 w-4 text-green-600" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
          </Button>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleCopyLink}
            variant="default"
            size="sm"
            className="flex-1"
          >
            <Copy className="h-4 w-4 mr-2" />
            Copiar Link
          </Button>
          <Button
            onClick={handleShare}
            variant="outline"
            size="sm"
            className="flex-1"
          >
            <Share2 className="h-4 w-4 mr-2" />
            Compartilhar
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ReferralLinkBox;
