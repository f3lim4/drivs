
import { useNavigate } from "react-router-dom";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

export interface DashboardAlert {
  type: 'warning' | 'info' | 'default';
  title: string;
  description: string;
  action: string;
  date?: string;
  read?: boolean;
}

interface DashboardAlertsProps {
  alerts: DashboardAlert[];
  onMarkAsRead?: (index: number) => void;
}

const DashboardAlerts = ({ alerts, onMarkAsRead }: DashboardAlertsProps) => {
  const navigate = useNavigate();
  
  const handleAction = (index: number, action: string) => {
    if (onMarkAsRead) {
      onMarkAsRead(index);
    }
    
    toast({
      title: "Alerta verificado",
      description: "Você será redirecionado para a página relacionada."
    });
    
    navigate(action);
  };
  
  if (alerts.length === 0) {
    return (
      <div className="text-center p-4 border rounded-md bg-muted/20">
        <p className="text-muted-foreground">Nenhum alerta pendente</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-3 mb-6">
      {alerts.map((alert, index) => (
        <Alert key={index} variant={alert.type as any} className={alert.read ? "opacity-70" : ""}>
          <AlertTitle className="flex items-center justify-between">
            {alert.title}
            <Button variant="ghost" size="sm" className="h-7" onClick={() => handleAction(index, alert.action)}>
              Ver detalhes
            </Button>
          </AlertTitle>
          <AlertDescription className="flex justify-between items-start">
            <div>
              {alert.description}
              {alert.date && <div className="text-xs mt-1 text-muted-foreground">{alert.date}</div>}
            </div>
            {alert.read && (
              <span className="text-xs bg-muted px-2 py-0.5 rounded-full">Verificado</span>
            )}
          </AlertDescription>
        </Alert>
      ))}
    </div>
  );
};

export default DashboardAlerts;
