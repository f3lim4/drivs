
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Search, Filter, Eye, Calendar, User, Car } from 'lucide-react';

interface VehicleHistoryRecord {
  id: string;
  vehiclePlate: string;
  vehicleModel: string;
  driverName: string;
  action: 'rental_start' | 'rental_end' | 'maintenance_start' | 'maintenance_end' | 'inspection' | 'violation';
  date: string;
  time: string;
  details: string;
  status: 'completed' | 'pending' | 'cancelled';
}

// Mock data para histórico de veículos
const mockVehicleHistory: VehicleHistoryRecord[] = [
  {
    id: "1",
    vehiclePlate: "ABC-1234",
    vehicleModel: "Toyota Corolla",
    driverName: "João Silva Santos",
    action: "rental_start",
    date: "2024-01-15",
    time: "09:30",
    details: "Início do contrato de locação semanal",
    status: "completed"
  },
  {
    id: "2",
    vehiclePlate: "DEF-5678",
    vehicleModel: "Honda Civic",
    driverName: "Maria Oliveira",
    action: "rental_end",
    date: "2024-01-14",
    time: "18:00",
    details: "Fim do contrato de locação - veículo devolvido",
    status: "completed"
  },
  {
    id: "3",
    vehiclePlate: "GHI-9012",
    vehicleModel: "Volkswagen Jetta",
    driverName: "-",
    action: "maintenance_start",
    date: "2024-01-13",
    time: "14:20",
    details: "Veículo enviado para manutenção preventiva",
    status: "completed"
  },
  {
    id: "4",
    vehiclePlate: "ABC-1234",
    vehicleModel: "Toyota Corolla",
    driverName: "João Silva Santos",
    action: "inspection",
    date: "2024-01-12",
    time: "11:15",
    details: "Vistoria semanal aprovada",
    status: "completed"
  },
  {
    id: "5",
    vehiclePlate: "JKL-3456",
    vehicleModel: "Chevrolet Onix",
    driverName: "Pedro Costa",
    action: "violation",
    date: "2024-01-11",
    time: "16:45",
    details: "Multa por excesso de velocidade registrada",
    status: "pending"
  },
  {
    id: "6",
    vehiclePlate: "DEF-5678",
    vehicleModel: "Honda Civic",
    driverName: "Maria Oliveira",
    action: "rental_start",
    date: "2024-01-08",
    time: "10:00",
    details: "Início do contrato de locação semanal",
    status: "completed"
  }
];

const VehicleHistoryTabContent = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [actionFilter, setActionFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedRecord, setSelectedRecord] = useState<VehicleHistoryRecord | null>(null);

  const getActionBadge = (action: VehicleHistoryRecord["action"]) => {
    switch (action) {
      case "rental_start":
        return <Badge className="bg-green-100 text-green-800">Início Locação</Badge>;
      case "rental_end":
        return <Badge className="bg-blue-100 text-blue-800">Fim Locação</Badge>;
      case "maintenance_start":
        return <Badge className="bg-yellow-100 text-yellow-800">Manutenção</Badge>;
      case "maintenance_end":
        return <Badge className="bg-purple-100 text-purple-800">Fim Manutenção</Badge>;
      case "inspection":
        return <Badge className="bg-cyan-100 text-cyan-800">Vistoria</Badge>;
      case "violation":
        return <Badge className="bg-red-100 text-red-800">Violação</Badge>;
    }
  };

  const getStatusBadge = (status: VehicleHistoryRecord["status"]) => {
    switch (status) {
      case "completed":
        return <Badge variant="outline" className="bg-green-50 text-green-700">Concluído</Badge>;
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Pendente</Badge>;
      case "cancelled":
        return <Badge variant="outline" className="bg-red-50 text-red-700">Cancelado</Badge>;
    }
  };

  const filteredHistory = mockVehicleHistory.filter(record => {
    const matchesSearch = 
      record.vehiclePlate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.vehicleModel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.driverName.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesAction = actionFilter === "all" || record.action === actionFilter;
    const matchesStatus = statusFilter === "all" || record.status === statusFilter;
    
    return matchesSearch && matchesAction && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Histórico de Veículos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar por placa, modelo ou motorista..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="w-full md:w-48">
              <Select value={actionFilter} onValueChange={setActionFilter}>
                <SelectTrigger>
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filtrar por ação" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as Ações</SelectItem>
                  <SelectItem value="rental_start">Início Locação</SelectItem>
                  <SelectItem value="rental_end">Fim Locação</SelectItem>
                  <SelectItem value="maintenance_start">Manutenção</SelectItem>
                  <SelectItem value="inspection">Vistoria</SelectItem>
                  <SelectItem value="violation">Violação</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full md:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Status</SelectItem>
                  <SelectItem value="completed">Concluído</SelectItem>
                  <SelectItem value="pending">Pendente</SelectItem>
                  <SelectItem value="cancelled">Cancelado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data/Hora</TableHead>
                  <TableHead>Veículo</TableHead>
                  <TableHead>Motorista</TableHead>
                  <TableHead>Ação</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Detalhes</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredHistory.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      Nenhum registro encontrado
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredHistory.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">
                            {new Date(record.date).toLocaleDateString('pt-BR')}
                          </span>
                          <span className="text-sm text-muted-foreground">{record.time}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Car className="h-4 w-4 text-blue-500" />
                          <div>
                            <p className="font-medium">{record.vehiclePlate}</p>
                            <p className="text-sm text-muted-foreground">{record.vehicleModel}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-green-500" />
                          <span>{record.driverName === "-" ? "N/A" : record.driverName}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getActionBadge(record.action)}</TableCell>
                      <TableCell>{getStatusBadge(record.status)}</TableCell>
                      <TableCell className="max-w-xs">
                        <p className="truncate" title={record.details}>
                          {record.details}
                        </p>
                      </TableCell>
                      <TableCell className="text-right">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => setSelectedRecord(record)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Detalhes do Registro</DialogTitle>
                            </DialogHeader>
                            {selectedRecord && (
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Data</label>
                                    <p>{new Date(selectedRecord.date).toLocaleDateString('pt-BR')}</p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Hora</label>
                                    <p>{selectedRecord.time}</p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Veículo</label>
                                    <p>{selectedRecord.vehiclePlate} - {selectedRecord.vehicleModel}</p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Motorista</label>
                                    <p>{selectedRecord.driverName === "-" ? "N/A" : selectedRecord.driverName}</p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Ação</label>
                                    <div className="mt-1">{getActionBadge(selectedRecord.action)}</div>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Status</label>
                                    <div className="mt-1">{getStatusBadge(selectedRecord.status)}</div>
                                  </div>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-muted-foreground">Detalhes</label>
                                  <p className="mt-1 text-sm">{selectedRecord.details}</p>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VehicleHistoryTabContent;
