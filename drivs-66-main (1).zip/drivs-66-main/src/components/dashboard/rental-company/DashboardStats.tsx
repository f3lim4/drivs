
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Car, Users, DollarSign, Percent } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { getVehiclesByCompany } from "@/pages/RentalCompanies/data/mockVehicles";
import { useDriverData } from "@/pages/Drivers/hooks/useDriverData";
import { DriverStatus } from "@/types";

export const DashboardStats = () => {
  const { user } = useAuth();
  const { drivers } = useDriverData();

  // Obter dados reais da locadora
  const companyVehicles = user?.role === "rental_company" ? getVehiclesByCompany(user.id) : [];
  const totalVehicles = companyVehicles.length;
  const rentedVehicles = companyVehicles.filter(v => v.status === "rented").length;
  const activeDrivers = drivers.filter(d => d.status === DriverStatus.ACTIVE).length;
  const monthlyRevenue = rentedVehicles * 350 * 4; // Aproximação
  const occupancyRate = totalVehicles > 0 ? Math.round((rentedVehicles / totalVehicles) * 100) : 0;

  const statsData = [
    {
      title: "Veículos Ativos",
      value: totalVehicles,
      description: `${rentedVehicles} alugados`,
      icon: Car,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200"
    },
    {
      title: "Motoristas Ativos", 
      value: activeDrivers,
      description: "Com contratos vigentes",
      icon: Users,
      color: "text-green-600",
      bgColor: "bg-green-50", 
      borderColor: "border-green-200"
    },
    {
      title: "Receita Mensal",
      value: `R$ ${monthlyRevenue.toLocaleString('pt-BR')}`,
      description: `Baseado em ${rentedVehicles} veículos`,
      icon: DollarSign,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200"
    },
    {
      title: "Taxa de Ocupação",
      value: `${occupancyRate}%`,
      description: `${rentedVehicles} de ${totalVehicles} veículos`,
      icon: Percent,
      color: "text-purple-600", 
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsData.map((stat, index) => (
        <Card key={index} className={`${stat.borderColor} border-l-4`}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {stat.title}
            </CardTitle>
            <div className={`p-2 rounded-full ${stat.bgColor}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${stat.color}`}>
              {stat.value}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {stat.description}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

