
import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { 
  Car, Users, DollarSign, Building2, FileText, Wrench, 
  AlertTriangle, CheckCircle, BarChart3, Bell, Calendar 
} from 'lucide-react';

interface EditDashboardDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const EditDashboardDialog = ({ open, onOpenChange }: EditDashboardDialogProps) => {
  // Estado para controlar quais seções estão visíveis
  const [dashboardSettings, setDashboardSettings] = useState({
    // Cards principais do cabeçalho
    mainStats: {
      vehicles: true,
      drivers: true,
      revenue: true,
      occupancy: true,
    },
    // Seções da visão geral
    sections: {
      quickStats: true,
      recentActivities: true,
      quickActions: true,
      vehicleStatus: true,
      driverStatus: true,
      financialSummary: true,
    },
    // Gráficos e relatórios
    charts: {
      revenueChart: true,
      performanceChart: true,
      vehicleUsageChart: true,
    }
  });

  const handleSettingChange = (category: string, setting: string, value: boolean) => {
    setDashboardSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [setting]: value
      }
    }));
  };

  const handleSaveSettings = () => {
    // Aqui você salvaria as configurações (localStorage, banco de dados, etc.)
    localStorage.setItem('dashboardSettings', JSON.stringify(dashboardSettings));
    toast.success("Configurações do dashboard salvas com sucesso!");
    onOpenChange(false);
  };

  const handleResetToDefault = () => {
    setDashboardSettings({
      mainStats: {
        vehicles: true,
        drivers: true,
        revenue: true,
        occupancy: true,
      },
      sections: {
        quickStats: true,
        recentActivities: true,
        quickActions: true,
        vehicleStatus: true,
        driverStatus: true,
        financialSummary: true,
      },
      charts: {
        revenueChart: true,
        performanceChart: true,
        vehicleUsageChart: true,
      }
    });
    toast.info("Configurações restauradas para o padrão");
  };

  const mainStatsOptions = [
    { key: 'vehicles', label: 'Veículos Ativos', icon: Car },
    { key: 'drivers', label: 'Motoristas Ativos', icon: Users },
    { key: 'revenue', label: 'Receita Mensal', icon: DollarSign },
    { key: 'occupancy', label: 'Taxa de Ocupação', icon: Building2 },
  ];

  const sectionOptions = [
    { key: 'quickStats', label: 'Estatísticas Rápidas', icon: BarChart3 },
    { key: 'recentActivities', label: 'Atividades Recentes', icon: Bell },
    { key: 'quickActions', label: 'Ações Rápidas', icon: CheckCircle },
    { key: 'vehicleStatus', label: 'Status dos Veículos', icon: Car },
    { key: 'driverStatus', label: 'Status dos Motoristas', icon: Users },
    { key: 'financialSummary', label: 'Resumo Financeiro', icon: DollarSign },
  ];

  const chartOptions = [
    { key: 'revenueChart', label: 'Gráfico de Receita', icon: DollarSign },
    { key: 'performanceChart', label: 'Gráfico de Performance', icon: BarChart3 },
    { key: 'vehicleUsageChart', label: 'Uso dos Veículos', icon: Car },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Editar Dashboard</DialogTitle>
          <DialogDescription>
            Personalize quais informações aparecem no seu dashboard
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Cards Principais */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Cards Principais
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mainStatsOptions.map((stat) => (
                  <div key={stat.key} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <stat.icon className="h-4 w-4 text-blue-600" />
                      <Label htmlFor={`main-${stat.key}`} className="font-medium">
                        {stat.label}
                      </Label>
                    </div>
                    <Switch
                      id={`main-${stat.key}`}
                      checked={dashboardSettings.mainStats[stat.key as keyof typeof dashboardSettings.mainStats]}
                      onCheckedChange={(checked) => 
                        handleSettingChange('mainStats', stat.key, checked)
                      }
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Seções da Visão Geral */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                Seções da Visão Geral
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sectionOptions.map((section) => (
                  <div key={section.key} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <section.icon className="h-4 w-4 text-green-600" />
                      <Label htmlFor={`section-${section.key}`} className="font-medium">
                        {section.label}
                      </Label>
                    </div>
                    <Switch
                      id={`section-${section.key}`}
                      checked={dashboardSettings.sections[section.key as keyof typeof dashboardSettings.sections]}
                      onCheckedChange={(checked) => 
                        handleSettingChange('sections', section.key, checked)
                      }
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Gráficos */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Gráficos e Relatórios
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {chartOptions.map((chart) => (
                  <div key={chart.key} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <chart.icon className="h-4 w-4 text-purple-600" />
                      <Label htmlFor={`chart-${chart.key}`} className="font-medium">
                        {chart.label}
                      </Label>
                    </div>
                    <Switch
                      id={`chart-${chart.key}`}
                      checked={dashboardSettings.charts[chart.key as keyof typeof dashboardSettings.charts]}
                      onCheckedChange={(checked) => 
                        handleSettingChange('charts', chart.key, checked)
                      }
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Botões de Ação */}
        <div className="flex justify-between pt-6 border-t">
          <Button variant="outline" onClick={handleResetToDefault}>
            Restaurar Padrão
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveSettings}>
              Salvar Configurações
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EditDashboardDialog;
