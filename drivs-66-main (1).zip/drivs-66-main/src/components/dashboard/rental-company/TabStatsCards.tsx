
import { useAuth } from "@/contexts/AuthContext";
import { getVehiclesByCompany } from "@/pages/RentalCompanies/data/mockVehicles";
import { useDriverData } from "@/pages/Drivers/hooks/useDriverData";
import { DriverStatus } from "@/types";
import { StatsCard } from "@/components/shared/StatsCard";
import { Car, Users, DollarSign, FileText, Wrench, CheckCircle, AlertTriangle, Clock } from 'lucide-react';

interface TabStatsCardsProps {
  type: 'vehicles' | 'drivers' | 'financial';
}

const TabStatsCards = ({ type }: TabStatsCardsProps) => {
  const { user } = useAuth();
  const { drivers } = useDriverData();
  
  const companyVehicles = user?.role === "rental_company" ? getVehiclesByCompany(user.id) : [];
  
  const getStatsData = () => {
    switch (type) {
      case 'vehicles':
        const totalVehicles = companyVehicles.length;
        const availableVehicles = companyVehicles.filter(v => v.status === "available").length;
        const rentedVehicles = companyVehicles.filter(v => v.status === "rented").length;
        const maintenanceVehicles = companyVehicles.filter(v => v.status === "maintenance").length;
        
        return [
          {
            title: "Total de Veículos",
            value: totalVehicles,
            description: "Sua frota completa",
            icon: Car,
            borderColor: "border-l-blue-500",
            iconColor: "text-blue-600",
            valueColor: "text-blue-700"
          },
          {
            title: "Disponíveis",
            value: availableVehicles,
            description: "Prontos para alugar",
            icon: CheckCircle,
            borderColor: "border-l-green-500",
            iconColor: "text-green-600",
            valueColor: "text-green-700"
          },
          {
            title: "Alugados",
            value: rentedVehicles,
            description: "Com motoristas",
            icon: Users,
            borderColor: "border-l-purple-500",
            iconColor: "text-purple-600",
            valueColor: "text-purple-700"
          },
          {
            title: "Em Manutenção",
            value: maintenanceVehicles,
            description: "Fora de operação",
            icon: Wrench,
            borderColor: "border-l-amber-500",
            iconColor: "text-amber-600",
            valueColor: "text-amber-700"
          }
        ];
      case 'drivers':
        const totalDrivers = drivers.length;
        const approvedDrivers = drivers.filter(d => d.status === DriverStatus.APPROVED).length;
        const underReviewDrivers = drivers.filter(d => d.status === DriverStatus.UNDER_REVIEW).length;
        const activeDrivers = drivers.filter(d => d.status === DriverStatus.ACTIVE).length;
        
        return [
          {
            title: "Total Motoristas",
            value: totalDrivers,
            description: "Cadastrados no sistema",
            icon: Users,
            borderColor: "border-l-blue-500",
            iconColor: "text-blue-600",
            valueColor: "text-blue-700"
          },
          {
            title: "Aprovados",
            value: approvedDrivers,
            description: "Liberados para alugar",
            icon: CheckCircle,
            borderColor: "border-l-green-500",
            iconColor: "text-green-600",
            valueColor: "text-green-700"
          },
          {
            title: "Em Análise",
            value: underReviewDrivers,
            description: "Aguardando aprovação",
            icon: Clock,
            borderColor: "border-l-yellow-500",
            iconColor: "text-yellow-600",
            valueColor: "text-yellow-700"
          },
          {
            title: "Ativos",
            value: activeDrivers,
            description: "Com contratos vigentes",
            icon: Car,
            borderColor: "border-l-purple-500",
            iconColor: "text-purple-600",
            valueColor: "text-purple-700"
          }
        ];
      case 'financial':
        const financialRentedVehicles = companyVehicles.filter(v => v.status === "rented").length;
        const monthlyRevenue = financialRentedVehicles * 350 * 4;
        const totalRevenue = monthlyRevenue * 6;
        const pendingPayments = Math.floor(financialRentedVehicles * 0.15);
        const activeContracts = financialRentedVehicles;
        
        return [
          {
            title: "Receita Total",
            value: `R$ ${totalRevenue.toLocaleString('pt-BR')}`,
            description: "Últimos 6 meses",
            icon: DollarSign,
            borderColor: "border-l-green-500",
            iconColor: "text-green-600",
            valueColor: "text-green-700"
          },
          {
            title: "Receita Mensal",
            value: `R$ ${monthlyRevenue.toLocaleString('pt-BR')}`,
            description: "Mês atual",
            icon: DollarSign,
            borderColor: "border-l-blue-500",
            iconColor: "text-blue-600",
            valueColor: "text-blue-700"
          },
          {
            title: "Pagamentos Pendentes",
            value: pendingPayments,
            description: "Aguardando pagamento",
            icon: AlertTriangle,
            borderColor: "border-l-red-500",
            iconColor: "text-red-600",
            valueColor: "text-red-700"
          },
          {
            title: "Contratos Ativos",
            value: activeContracts,
            description: "Em andamento",
            icon: FileText,
            borderColor: "border-l-purple-500",
            iconColor: "text-purple-600",
            valueColor: "text-purple-700"
          }
        ];
      default:
        return [];
    }
  };

  const statsData = getStatsData();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsData.map((stat, index) => (
        <StatsCard key={index} {...stat} />
      ))}
    </div>
  );
};

export default TabStatsCards;
