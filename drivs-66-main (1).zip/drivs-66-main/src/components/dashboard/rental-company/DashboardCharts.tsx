
import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { AreaChart, Area, LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { Calendar } from "lucide-react";

// Dados zerados para os gráficos
const revenueData = [
  { name: 'Jan', receita: 0 },
  { name: 'Fev', receita: 0 },
  { name: 'Mar', receita: 0 },
  { name: 'Abr', receita: 0 },
  { name: 'Mai', receita: 0 },
  { name: 'Jun', receita: 0 },
];

const vehiclesData = [
  { name: 'Jan', total: 0, disponivel: 0, alugado: 0 },
  { name: 'Fev', total: 0, disponivel: 0, alugado: 0 },
  { name: 'Mar', total: 0, disponivel: 0, alugado: 0 },
  { name: 'Abr', total: 0, disponivel: 0, alugado: 0 },
  { name: 'Mai', total: 0, disponivel: 0, alugado: 0 },
  { name: 'Jun', total: 0, disponivel: 0, alugado: 0 },
];

const driversData = [
  { name: 'Jan', novos: 0, ativos: 0 },
  { name: 'Fev', novos: 0, ativos: 0 },
  { name: 'Mar', novos: 0, ativos: 0 },
  { name: 'Abr', novos: 0, ativos: 0 },
  { name: 'Mai', novos: 0, ativos: 0 },
  { name: 'Jun', novos: 0, ativos: 0 },
];

const revenueConfig = {
  receita: {
    label: "Receita",
    color: "#8884d8",
  },
};

const vehiclesConfig = {
  total: {
    label: "Total",
    color: "#8884d8",
  },
  disponivel: {
    label: "Disponíveis",
    color: "#82ca9d",
  },
  alugado: {
    label: "Alugados",
    color: "#ffc658",
  },
};

const driversConfig = {
  novos: {
    label: "Novos Motoristas",
    color: "#82ca9d",
  },
  ativos: {
    label: "Motoristas Ativos",
    color: "#8884d8",
  },
};

const DashboardCharts = () => {
  const [timeRange, setTimeRange] = useState("mensal");

  return (
    <div className="mb-8">
      <Card className="shadow-sm border-2 border-gray-200 rounded-lg">
        <CardHeader className="pb-0">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Análise de Desempenho</CardTitle>
            <div className="flex space-x-1">
              <Button 
                variant={timeRange === "mensal" ? "default" : "outline"} 
                size="sm" 
                onClick={() => setTimeRange("mensal")}
                className="text-xs"
              >
                <Calendar className="mr-1 h-3 w-3" />
                Mensal
              </Button>
              <Button 
                variant={timeRange === "trimestral" ? "default" : "outline"} 
                size="sm" 
                onClick={() => setTimeRange("trimestral")}
                className="text-xs"
              >
                <Calendar className="mr-1 h-3 w-3" />
                Trimestral
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4 border border-gray-300 rounded-md mx-4 mb-4 bg-gray-50/30">
          <Tabs defaultValue="revenue" className="space-y-4">
            <ScrollArea className="w-full">
              <TabsList className="min-w-max">
                <TabsTrigger value="revenue">Receita</TabsTrigger>
                <TabsTrigger value="vehicles">Veículos</TabsTrigger>
                <TabsTrigger value="drivers">Motoristas</TabsTrigger>
              </TabsList>
              <ScrollBar orientation="horizontal" className="md:hidden" />
            </ScrollArea>
            
            <TabsContent value="revenue" className="space-y-4">
              <ScrollArea className="w-full">
                <div className="h-80 min-w-[600px] md:min-w-0">
                  <ChartContainer config={revenueConfig} className="h-full">
                    <AreaChart
                      data={revenueData}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <defs>
                        <linearGradient id="colorReceit" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="name" />
                      <YAxis />
                      <CartesianGrid strokeDasharray="3 3" />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Area 
                        type="monotone" 
                        dataKey="receita" 
                        stroke="#8884d8" 
                        fillOpacity={1} 
                        fill="url(#colorReceit)" 
                        name="Receita (R$)"
                      />
                    </AreaChart>
                  </ChartContainer>
                </div>
                <ScrollBar orientation="horizontal" className="md:hidden" />
              </ScrollArea>
              <p className="text-sm text-muted-foreground text-center">Receita mensal gerada por veículos alugados</p>
            </TabsContent>
            
            <TabsContent value="vehicles" className="space-y-4">
              <ScrollArea className="w-full">
                <div className="h-80 min-w-[600px] md:min-w-0">
                  <ChartContainer config={vehiclesConfig} className="h-full">
                    <BarChart
                      data={vehiclesData}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="total" fill="#8884d8" name="Total" />
                      <Bar dataKey="disponivel" fill="#82ca9d" name="Disponíveis" />
                      <Bar dataKey="alugado" fill="#ffc658" name="Alugados" />
                    </BarChart>
                  </ChartContainer>
                </div>
                <ScrollBar orientation="horizontal" className="md:hidden" />
              </ScrollArea>
              <p className="text-sm text-muted-foreground text-center">Situação dos veículos da frota por mês</p>
            </TabsContent>
            
            <TabsContent value="drivers" className="space-y-4">
              <ScrollArea className="w-full">
                <div className="h-80 min-w-[600px] md:min-w-0">
                  <ChartContainer config={driversConfig} className="h-full">
                    <LineChart
                      data={driversData}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line 
                        type="monotone" 
                        dataKey="novos" 
                        stroke="#82ca9d" 
                        activeDot={{ r: 8 }}
                        name="Novos Motoristas" 
                      />
                      <Line 
                        type="monotone" 
                        dataKey="ativos" 
                        stroke="#8884d8" 
                        name="Motoristas Ativos" 
                      />
                    </LineChart>
                  </ChartContainer>
                </div>
                <ScrollBar orientation="horizontal" className="md:hidden" />
              </ScrollArea>
              <p className="text-sm text-muted-foreground text-center">Novos motoristas e motoristas ativos por mês</p>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardCharts;
