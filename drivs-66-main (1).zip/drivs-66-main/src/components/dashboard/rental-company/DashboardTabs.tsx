
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import OverviewTabContent from './OverviewTabContent';
import VehicleHistoryTabContent from './VehicleHistoryTabContent';
import TabStatsCards from './TabStatsCards';

const DashboardTabs = () => {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="w-full px-2 md:px-0">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4 md:space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 h-auto">
          <TabsTrigger value="overview" className="text-xs md:text-sm p-2 md:p-3">
            Visão Geral
          </TabsTrigger>
          <TabsTrigger value="vehicles" className="text-xs md:text-sm p-2 md:p-3">
            Veículos
          </TabsTrigger>
          <TabsTrigger value="drivers" className="text-xs md:text-sm p-2 md:p-3 hidden md:flex">
            Motoristas
          </TabsTrigger>
          <TabsTrigger value="financial" className="text-xs md:text-sm p-2 md:p-3 hidden md:flex">
            Financeiro
          </TabsTrigger>
          <TabsTrigger value="history" className="text-xs md:text-sm p-2 md:p-3">
            Histórico
          </TabsTrigger>
        </TabsList>

        {/* Mobile dropdown for hidden tabs */}
        <div className="md:hidden">
          <select 
            value={activeTab} 
            onChange={(e) => setActiveTab(e.target.value)}
            className="w-full p-2 border rounded-lg bg-background"
          >
            <option value="overview">Visão Geral</option>
            <option value="vehicles">Veículos</option>
            <option value="drivers">Motoristas</option>
            <option value="financial">Financeiro</option>
            <option value="history">Histórico</option>
          </select>
        </div>

        <TabsContent value="overview" className="space-y-4 md:space-y-6">
          <OverviewTabContent />
        </TabsContent>

        <TabsContent value="vehicles" className="space-y-4 md:space-y-6">
          <TabStatsCards type="vehicles" />
        </TabsContent>

        <TabsContent value="drivers" className="space-y-4 md:space-y-6">
          <TabStatsCards type="drivers" />
        </TabsContent>

        <TabsContent value="financial" className="space-y-4 md:space-y-6">
          <TabStatsCards type="financial" />
        </TabsContent>

        <TabsContent value="history" className="space-y-4 md:space-y-6">
          <VehicleHistoryTabContent />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DashboardTabs;
