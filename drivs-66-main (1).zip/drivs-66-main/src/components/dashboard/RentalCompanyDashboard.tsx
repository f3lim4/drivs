
import { DashboardStats } from "./rental-company/DashboardStats";
import DashboardHeader from "./rental-company/DashboardHeader";
import DashboardTabs from "./rental-company/DashboardTabs";
import DashboardAlerts from "./rental-company/DashboardAlerts";
import QuickAccess from "./rental-company/QuickAccess";
import RecentActivities from "./rental-company/RecentActivities";

const RentalCompanyDashboard = () => {
  return (
    <div className="space-y-6">
      {/* Header com estatísticas principais e link de referência para motoristas */}
      <DashboardHeader />
      
      {/* Alertas importantes */}
      <DashboardAlerts alerts={[]} />
      
      {/* Cards de estatísticas detalhadas */}
      <DashboardStats />
      
      {/* Grid com Acesso Rápido e Atividades Recentes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <QuickAccess />
        <RecentActivities />
      </div>
      
      {/* Abas com conteúdo detalhado */}
      <DashboardTabs />
    </div>
  );
};

export default RentalCompanyDashboard;
