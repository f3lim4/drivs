
import React from "react";
import { UserRole, Driver, DriverStatus } from "@/types";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface DriverUserSectionProps {
  user: any;
  isCollapsed: boolean;
}

export const DriverUserSection: React.FC<DriverUserSectionProps> = ({ user, isCollapsed }) => {
  const getUserDisplayName = () => {
    if (user?.role === UserRole.DRIVER) {
      return (user as Driver).fullName;
    }
    return user?.email?.split("@")[0];
  };

  const getUserInitials = () => {
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      return driver.fullName?.split(" ").map((n: string) => n[0]).join("").toUpperCase() || "D";
    }
    const userName = user?.email?.split("@")[0] || "Admin";
    return userName.split(" ").map(n => n[0]).join("").toUpperCase() || "U";
  };

  const getUserImage = () => {
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      return driver.profile_photo;
    }
    return undefined;
  };

  const getUserRoleLabel = () => {
    switch (user?.role) {
      case UserRole.DRIVER:
        return "Motorista";
      default:
        return "Usuário";
    }
  };

  const getDriverStatusLabel = () => {
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      const statusLabels = {
        [DriverStatus.PENDING]: "Em Aberto",
        [DriverStatus.UNDER_REVIEW]: "Em Análise",
        [DriverStatus.APPROVED]: driver.activeContract ? "Ativo (Com Contrato)" : "Aprovado",
        [DriverStatus.REJECTED]: "Reprovado",
        [DriverStatus.DEACTIVATED]: "Desativado",
        [DriverStatus.BLACKLISTED]: "Negativado"
      };
      return statusLabels[driver.status] || "Status Desconhecido";
    }
    return null;
  };

  const getStatusColor = () => {
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      const statusColors = {
        [DriverStatus.PENDING]: "bg-blue-500",
        [DriverStatus.UNDER_REVIEW]: "bg-yellow-500",
        [DriverStatus.APPROVED]: "bg-green-500",
        [DriverStatus.REJECTED]: "bg-red-500",
        [DriverStatus.DEACTIVATED]: "bg-gray-500",
        [DriverStatus.BLACKLISTED]: "bg-red-600"
      };
      return statusColors[driver.status] || "bg-gray-500";
    }
    return "bg-green-500";
  };

  // Só mostrar para motoristas
  if (user?.role !== UserRole.DRIVER) {
    return null;
  }

  if (isCollapsed) {
    return (
      <div className="p-2 border-b border-blue-500 flex justify-center">
        <div className="relative">
          <Avatar className="w-8 h-8">
            <AvatarImage src={getUserImage()} alt="Usuário" />
            <AvatarFallback className="bg-blue-500 text-white text-xs">
              {getUserInitials()}
            </AvatarFallback>
          </Avatar>
          <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-blue-600 ${getStatusColor()}`}></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 border-b border-blue-500">
      <div className="flex items-center gap-3">
        <div className="relative">
          <Avatar className="w-12 h-12">
            <AvatarImage src={getUserImage()} alt="Usuário" />
            <AvatarFallback className="bg-blue-500 text-white text-sm font-medium">
              {getUserInitials()}
            </AvatarFallback>
          </Avatar>
          {/* Status indicator */}
          <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-blue-600 ${getStatusColor()}`}></div>
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-white text-sm truncate">{getUserDisplayName()}</h3>
          <p className="text-xs text-blue-200">{getUserRoleLabel()}</p>
          <p className="text-xs text-blue-100 mt-1">{getDriverStatusLabel()}</p>
        </div>
      </div>
    </div>
  );
};
