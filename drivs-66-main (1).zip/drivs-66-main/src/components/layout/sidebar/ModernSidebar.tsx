
import { useAuth } from "@/contexts/AuthContext";
import { Sidebar, SidebarContent, useSidebar } from "@/components/ui/sidebar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ModernSidebarMenu } from "./ModernSidebarMenu";
import { CompanyHeader } from "./CompanyHeader";
import { DriverUserSection } from "./DriverUserSection";

export const ModernSidebar = () => {
  const { user } = useAuth();
  const { state } = useSidebar();

  const isCollapsed = state === "collapsed";

  return (
    <Sidebar 
      className="border-r border-blue-400 bg-blue-600 min-h-screen" 
      collapsible="offcanvas" 
      side="left"
    >
      <SidebarContent className="bg-blue-600 flex flex-col h-full">
        {/* Company Header Section - espaçamento mínimo */}
        <div className="flex-shrink-0 px-1 pt-1">
          <CompanyHeader user={user} isCollapsed={isCollapsed} />
        </div>

        {/* Driver User Section - espaçamento mínimo */}
        <div className="flex-shrink-0 px-1">
          <DriverUserSection user={user} isCollapsed={isCollapsed} />
        </div>

        {/* Menu com ScrollArea responsivo - cola ao topo */}
        <div className="flex-1 min-h-0">
          <ScrollArea className="h-full">
            <div className="px-1">
              <ModernSidebarMenu />
            </div>
          </ScrollArea>
        </div>
      </SidebarContent>
    </Sidebar>
  );
};
