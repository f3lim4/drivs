
import React from "react";
import { UserRole, Driver, Manager, Inspector } from "@/types";
import { Building } from "lucide-react";
import { useCompanySettings } from "@/hooks/useCompanySettings";

interface CompanyHeaderProps {
  user: any;
  isCollapsed: boolean;
}

export const CompanyHeader: React.FC<CompanyHeaderProps> = ({ user, isCollapsed }) => {
  const { companyData } = useCompanySettings();

  const getUserDisplayName = () => {
    if (user?.role === UserRole.DRIVER) {
      return (user as Driver).fullName;
    }
    if (user?.role === UserRole.RENTAL_COMPANY) {
      // Usar dados do banco se disponível, senão usar dados do usuário
      return companyData?.company_name || (user as any).companyName;
    }
    if (user?.role === UserRole.MANAGER) {
      return (user as Manager).name;
    }
    if (user?.role === UserRole.INSPECTOR) {
      return (user as Inspector).name;
    }
    return user?.email?.split("@")[0];
  };

  const getUserRoleLabel = () => {
    switch (user?.role) {
      case UserRole.DRIVER:
        return "Motorista";
      case UserRole.RENTAL_COMPANY:
        return "Locadora";
      case UserRole.MANAGER:
        return "Gestor";
      case UserRole.INSPECTOR:
        return "Vistoriador";
      case UserRole.ANALYST:
        return "Analista DRIVS";
      case UserRole.ADMIN:
        return "Administrador";
      default:
        return "Usuário";
    }
  };

  const getStatusColor = () => {
    return "bg-green-500"; // Default para outros tipos de usuário
  };

  const getCompanyName = () => {
    // Para usuários admin demo, não mostrar informações de empresa
    if (user?.id === 'admin-demo-user') {
      return null;
    }
    
    // Para locadoras, usar dados atualizados das configurações se disponível
    if (user?.role === UserRole.RENTAL_COMPANY) {
      return companyData?.company_name || (user as any).companyName || "Sua Empresa";
    }
    // Para gestores e vistoriadores, mostrar nome da locadora
    if (user?.role === UserRole.MANAGER || user?.role === UserRole.INSPECTOR) {
      return companyData?.company_name || "Locadora XYZ";
    }
    return null;
  };

  const getCompanyLogo = () => {
    // Para usuários admin demo, não mostrar logo
    if (user?.id === 'admin-demo-user') {
      return null;
    }
    
    // Para locadoras, usar logo atualizada das configurações se disponível
    if (user?.role === UserRole.RENTAL_COMPANY && companyData?.logo_url) {
      return companyData.logo_url;
    }
    return null;
  };

  const getPlanLabel = () => {
    if (companyData?.plan) {
      const planLabels = {
        'basic': 'Plano Básico',
        'premium': 'Plano Premium',
        'enterprise': 'Plano Empresarial'
      };
      return planLabels[companyData.plan as keyof typeof planLabels] || companyData.plan;
    }
    return "Plano Básico";
  };

  // Não mostrar header de empresa para admin demo ou outros tipos que não precisam
  if (user?.id === 'admin-demo-user' || user?.role === UserRole.ADMIN || !(user?.role === UserRole.RENTAL_COMPANY || user?.role === UserRole.MANAGER || user?.role === UserRole.INSPECTOR)) {
    return null;
  }

  if (isCollapsed) {
    return (
      <div className="p-2 border-b border-blue-500 flex justify-center">
        <div className="relative">
          {getCompanyLogo() ? (
            <img
              src={getCompanyLogo()}
              alt="Logo da empresa"
              className="w-8 h-8 rounded object-contain bg-white/10 p-0.5"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          ) : (
            <div className="w-8 h-8 rounded bg-white/10 flex items-center justify-center">
              <Building className="w-4 h-4 text-white" />
            </div>
          )}
          <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-blue-600 ${getStatusColor()}`}></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 border-b border-blue-500">
      <div className="flex items-center gap-3">
        <div className="relative">
          {getCompanyLogo() ? (
            <img
              src={getCompanyLogo()}
              alt="Logo da empresa"
              className="w-12 h-12 rounded-lg object-contain bg-white/10 p-1"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          ) : (
            <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center">
              <Building className="w-6 h-6 text-white" />
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-white text-sm truncate">
            {getCompanyName()}
          </h3>
          <p className="text-xs text-blue-200">{getPlanLabel()}</p>
        </div>
        <div className={`w-3 h-3 rounded-full ${getStatusColor()}`}></div>
      </div>
    </div>
  );
};
