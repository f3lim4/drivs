
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver, DriverStatus } from "@/types";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarMenu, 
  SidebarMenuItem, 
  SidebarMenuButton,
  useSidebar
} from "@/components/ui/sidebar";
import { 
  Home, User, Users, Settings, Car, AlertTriangle, 
  FileText, FileMinus, BarChart3, Camera, Search,
  ChevronRight, Trophy, Building, UserCheck, DollarSign, Handshake, Layers3, Clock
} from "lucide-react";

export const ModernSidebarMenu = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { state, setOpenMobile } = useSidebar();
  const isMobile = useIsMobile();

  const getMenuItems = () => {
    // Se não houver usuário logado, não mostrar menu
    if (!user) {
      return [];
    }

    // Menu para admin - ACESSO COMPLETO A TODAS AS PÁGINAS ADMIN
    if (user?.role === UserRole.ADMIN) {
      return [
        { title: "Painel Administrativo", icon: Home, path: "/admin/painel" },
        { title: "Planos e Assinaturas", icon: Layers3, path: "/admin/planos" },
        { title: "Usuários Administradores", icon: Users, path: "/admin/usuarios" },
        { title: "Gestão de Motoristas", icon: User, path: "/admin/motoristas" },
        { title: "Gestão de Locadoras", icon: Building, path: "/admin/locadoras" },
        { title: "Gestão de Veículos", icon: Car, path: "/admin/veiculos" },
        { title: "Análise de Motoristas", icon: UserCheck, path: "/admin/analise-de-motoristas" },
        { title: "Gestão de Contratos", icon: FileText, path: "/admin/contratos" },
        { title: "Gestão de Vistorias", icon: Camera, path: "/admin/vistorias" },
        { title: "Gestão de Pagamentos", icon: FileMinus, path: "/admin/pagamentos" },
        { title: "Gestão de Manutenções", icon: Settings, path: "/admin/manutencoes" },
        { title: "Gestão de Infrações", icon: AlertTriangle, path: "/admin/infracoes" },
        { title: "Controle Financeiro", icon: DollarSign, path: "/admin/financeiro" },
        { title: "Motoristas Negativados", icon: AlertTriangle, path: "/admin/negativados" },
        { title: "Relatórios Gerenciais", icon: BarChart3, path: "/admin/relatorios" },
        { title: "Negociações", icon: Handshake, path: "/admin/negociacoes" }
      ];
    }

    // Menu para locadoras
    if (user?.role === UserRole.RENTAL_COMPANY) {
      return [
        { title: "Dashboard", icon: Home, path: "/locadora/dashboard" },
        { title: "Motoristas", icon: User, path: "/locadora/motorista" },
        { title: "Análise de Motoristas", icon: UserCheck, path: "/locadora/analise-de-motorista" },
        { title: "Veículos", icon: Car, path: "/locadora/veiculos" },
        { title: "Contratos", icon: FileText, path: "/locadora/contratos" },
        { title: "Vistorias", icon: Camera, path: "/locadora/vistorias" },
        { title: "Pagamentos", icon: FileMinus, path: "/locadora/pagamentos" },
        { title: "Manutenções", icon: Settings, path: "/locadora/manutencoes" },
        { title: "Infrações", icon: AlertTriangle, path: "/locadora/infracoes" },
        { title: "Ranking", icon: Trophy, path: "/locadora/ranking" },
        { title: "Financeiro", icon: DollarSign, path: "/locadora/financeiro" },
        { title: "Relatórios", icon: BarChart3, path: "/locadora/relatorios" },
        { title: "Negociações", icon: Handshake, path: "/locadora/negociacoes" }
      ];
    }

    // Menu para motoristas
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      
      // Para motoristas com status "pending" ou "under_review" - apenas Dashboard e Documentos
      if (driver.status === DriverStatus.PENDING || driver.status === DriverStatus.UNDER_REVIEW) {
        return [
          { title: "Dashboard", icon: Home, path: "/motorista/dashboard" },
          { title: "Documentos", icon: FileText, path: "/motorista/documentos" }
        ];
      }

      // Para outros status, menu completo
      return [
        { title: "Dashboard", icon: Home, path: "/motorista/dashboard" },
        { title: "Documentos", icon: FileText, path: "/motorista/documentos" },
        { title: "Meu Perfil", icon: User, path: "/motorista/perfil" },
        { title: "Meu Veículo", icon: Car, path: "/motorista/veiculo" },
        { title: "Contratos", icon: FileText, path: "/motorista/contratos" },
        { title: "Pagamentos", icon: FileMinus, path: "/motorista/pagamentos" },
        { title: "Infrações", icon: AlertTriangle, path: "/motorista/infracoes" },
        { title: "Configurações", icon: Settings, path: "/motorista/configuracoes" }
      ];
    }

    return [];
  };

  const menuItems = getMenuItems();
  const isCollapsed = state === "collapsed";

  const handleMenuClick = (path: string) => {
    console.log('Navegando para:', path);
    console.log('Path atual:', location.pathname);
    navigate(path);
    if (isMobile) {
      setOpenMobile(false);
    }
  };

  const isActive = (path: string) => location.pathname === path;

  // Se não há itens de menu, não renderizar nada
  if (menuItems.length === 0) {
    return null;
  }

  return (
    <SidebarGroup className="p-0">
      <SidebarGroupContent>
        <SidebarMenu className="space-y-0">
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.path}>
              <SidebarMenuButton 
                onClick={() => handleMenuClick(item.path)}
                isActive={isActive(item.path)}
                className={`w-full justify-between ${isMobile ? 'h-10 px-2' : 'h-8 px-2'} text-blue-100 hover:bg-blue-800 hover:text-white border-0 ${
                  isActive(item.path) 
                    ? 'bg-blue-700 text-white font-medium' 
                    : ''
                }`}
              >
                <div className="flex items-center gap-2">
                  <item.icon className="h-4 w-4" />
                  {!isCollapsed && (
                    <span className={`${isMobile ? 'text-base font-medium' : 'text-sm font-medium'}`}>
                      {item.title}
                    </span>
                  )}
                </div>
                {!isCollapsed && <ChevronRight className="h-3 w-3" />}
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  );
};

