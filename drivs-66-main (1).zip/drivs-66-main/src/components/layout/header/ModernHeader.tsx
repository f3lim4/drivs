
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { useSidebar } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { NotificationBell } from "../NotificationBell";
import { UserRole, Driver } from "@/types";
import { Menu, User, Settings, LogOut, Users, CreditCard } from "lucide-react";

interface ModernHeaderProps {
  pageTitle: string;
}

export const ModernHeader = ({ pageTitle }: ModernHeaderProps) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { open, setOpen, setOpenMobile } = useSidebar();
  const isMobile = useIsMobile();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const handleMenuToggle = () => {
    if (isMobile) {
      setOpenMobile(true);
    } else {
      setOpen(!open);
    }
  };

  // Apenas RENTAL_COMPANY (admin da locadora) tem acesso aos menus de Usuários e Planos
  const showUsersMenu = user?.role === UserRole.RENTAL_COMPANY;
  const showPlansMenu = user?.role === UserRole.RENTAL_COMPANY;

  const getUserImage = () => {
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      return driver.profile_photo;
    }
    if (user?.role === UserRole.RENTAL_COMPANY) {
      const company = user as any;
      return company.logo;
    }
    return undefined;
  };

  const getUserInitials = () => {
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      return driver.fullName?.split(" ").map((n: string) => n[0]).join("").toUpperCase() || "D";
    }
    if (user?.role === UserRole.RENTAL_COMPANY) {
      const company = user as any;
      return company.companyName?.split(" ").map((n: string) => n[0]).join("").toUpperCase() || "L";
    }
    const userName = user?.email?.split("@")[0] || "Admin";
    return userName.split(" ").map(n => n[0]).join("").toUpperCase() || "U";
  };

  return (
    <header className="h-14 sm:h-16 bg-white dark:bg-gray-900 flex items-center justify-between px-3 sm:px-4 md:px-6 shadow-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40">
      <div className="flex items-center gap-2 sm:gap-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleMenuToggle}
          className="h-8 w-8 sm:h-9 sm:w-9 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200 p-0"
        >
          <Menu className="h-4 w-4 sm:h-5 sm:w-5" />
        </Button>
        <h1 className="text-sm sm:text-base md:text-lg font-semibold text-gray-900 dark:text-gray-100 truncate">
          {pageTitle}
        </h1>
      </div>
      
      <div className="flex items-center gap-2 sm:gap-3">
        <NotificationBell />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 sm:h-9 sm:w-9 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 p-0"
            >
              <Avatar className="h-7 w-7 sm:h-8 sm:w-8">
                <AvatarImage src={getUserImage()} alt="Usuário" />
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-48 sm:w-56 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 mr-2 sm:mr-4" align="end" forceMount>
            <DropdownMenuItem
              onClick={() =>
                user?.role === UserRole.RENTAL_COMPANY || user?.role === UserRole.MANAGER
                  ? navigate("/locadora/perfil")
                  : navigate("/motorista/perfil")
              }
              className="hover:bg-gray-100 dark:hover:bg-gray-700 text-sm"
            >
              <User className="mr-2 h-4 w-4" />
              <span>Perfil</span>
            </DropdownMenuItem>
            {user?.role === UserRole.ADMIN && (
              <DropdownMenuItem onClick={() => navigate("/admin")} className="hover:bg-gray-100 dark:hover:bg-gray-700 text-sm">
                <Settings className="mr-2 h-4 w-4" />
                <span>Administração</span>
              </DropdownMenuItem>
            )}
            {showUsersMenu && (
              <DropdownMenuItem onClick={() => navigate("/locadora/usuarios")} className="hover:bg-gray-100 dark:hover:bg-gray-700 text-sm">
                <Users className="mr-2 h-4 w-4" />
                <span>Usuários</span>
              </DropdownMenuItem>
            )}
            {showPlansMenu && (
              <DropdownMenuItem onClick={() => navigate("/locadora/planos")} className="hover:bg-gray-100 dark:hover:bg-gray-700 text-sm">
                <CreditCard className="mr-2 h-4 w-4" />
                <span>Planos</span>
              </DropdownMenuItem>
            )}
            <DropdownMenuItem
              onClick={() =>
                (user?.role === UserRole.RENTAL_COMPANY || user?.role === UserRole.MANAGER)
                  ? navigate("/locadora/configuracoes")
                  : navigate("/motorista/configuracoes")
              }
              className="hover:bg-gray-100 dark:hover:bg-gray-700 text-sm"
            >
              <Settings className="mr-2 h-4 w-4" />
              <span>Configurações</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-gray-200 dark:bg-gray-600" />
            <DropdownMenuItem onClick={handleLogout} className="hover:bg-red-50 dark:hover:bg-red-950 text-red-600 dark:text-red-400 text-sm">
              <LogOut className="mr-2 h-4 w-4" />
              <span>Sair</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};
