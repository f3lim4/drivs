
import { useState, useEffect } from "react";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { DashboardAlert } from "../dashboard/rental-company/DashboardAlerts";
import { useNavigate } from "react-router-dom";

// Mock data for notifications
const mockNotifications: DashboardAlert[] = [
  {
    type: "warning",
    title: "Pagamentos Atrasados",
    description: "3 motoristas com pagamentos em atraso",
    action: "/pagamentos",
    date: "2 horas atrás"
  },
  {
    type: "info",
    title: "Nova Solicitação",
    description: "João Silva enviou documentos para análise",
    action: "/motoristas-admin",
    date: "4 horas atrás"
  },
  {
    type: "default",
    title: "Manutenção Concluída",
    description: "Veículo ABC-1234 está pronto para uso",
    action: "/manutencao",
    date: "1 dia atrás",
    read: true
  },
  {
    type: "warning",
    title: "Vistoria Pendente",
    description: "Veículo DEF-5678 precisa de vistoria hoje",
    action: "/inspecoes",
    date: "3 dias atrás",
    read: true
  }
];

export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<DashboardAlert[]>(mockNotifications);
  const [unreadCount, setUnreadCount] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    // Count unread notifications
    const count = notifications.filter(notif => !notif.read).length;
    setUnreadCount(count);
  }, [notifications]);

  const handleMarkAsRead = (index: number) => {
    const updatedNotifications = [...notifications];
    updatedNotifications[index] = { ...updatedNotifications[index], read: true };
    setNotifications(updatedNotifications);
    setOpen(false);
    
    // Navigate to the action page
    navigate(notifications[index].action);
  };

  const handleMarkAllAsRead = () => {
    const updatedNotifications = notifications.map(notif => ({ ...notif, read: true }));
    setNotifications(updatedNotifications);
  };

  const handleViewAll = () => {
    navigate("/atividades");
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative h-9 w-9 rounded-lg hover:bg-accent">
          <Bell className="h-6 w-6" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 px-1.5 min-w-[20px] h-5 flex items-center justify-center">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="border-b border-border px-3 py-2 flex justify-between items-center">
          <h5 className="font-medium">Notificações</h5>
          <Button variant="ghost" size="sm" onClick={handleMarkAllAsRead}>
            Marcar todas como lidas
          </Button>
        </div>
        
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="w-full">
            <TabsTrigger value="all" className="flex-1">Todas</TabsTrigger>
            <TabsTrigger value="unread" className="flex-1">Não lidas</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="max-h-[400px] overflow-y-auto p-2">
            {notifications.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground">
                Nenhuma notificação
              </div>
            ) : (
              <div className="space-y-2">
                {notifications.map((notif, index) => (
                  <div 
                    key={index} 
                    className={`p-2 rounded-md cursor-pointer hover:bg-muted ${!notif.read ? "border-l-2 border-primary" : ""}`}
                    onClick={() => handleMarkAsRead(index)}
                  >
                    <div className="flex justify-between items-start">
                      <h6 className="font-medium text-sm">{notif.title}</h6>
                      <span className="text-xs text-muted-foreground">{notif.date}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{notif.description}</p>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="unread" className="max-h-[400px] overflow-y-auto p-2">
            {notifications.filter(n => !n.read).length === 0 ? (
              <div className="text-center py-6 text-muted-foreground">
                Nenhuma notificação não lida
              </div>
            ) : (
              <div className="space-y-2">
                {notifications
                  .filter(notif => !notif.read)
                  .map((notif, index) => (
                    <div 
                      key={index} 
                      className="p-2 rounded-md border-l-2 border-primary cursor-pointer hover:bg-muted"
                      onClick={() => handleMarkAsRead(notifications.findIndex(n => n === notif))}
                    >
                      <div className="flex justify-between items-start">
                        <h6 className="font-medium text-sm">{notif.title}</h6>
                        <span className="text-xs text-muted-foreground">{notif.date}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{notif.description}</p>
                    </div>
                  ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        <div className="border-t border-border p-2">
          <Button variant="ghost" size="sm" className="w-full" onClick={handleViewAll}>
            Ver todas as notificações
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
