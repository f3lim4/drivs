
import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { DashboardRoutes } from "@/routes/DashboardRoutes";
import { AdminRoutes } from "@/routes/AdminRoutes";
import { DriverRoutes } from "@/routes/DriverRoutes";
import { RentalCompanyRoutes } from "@/routes/RentalCompanyRoutes";
import AuthRoutes from "@/routes/AuthRoutes";
import NotFound from "@/pages/NotFound";
import { UserRole } from "@/types";
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar";
import { ModernSidebar } from "@/components/layout/sidebar/ModernSidebar";
import { ModernHeader } from "@/components/layout/header/ModernHeader";

const AppLayout = () => {
  console.log('AppLayout: Component rendering');
  
  const { user, loading } = useAuth();

  console.log('AppLayout: Auth state:', { hasUser: !!user, loading, userRole: user?.role });

  if (loading) {
    console.log('AppLayout: Showing loading');
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <h2 className="text-base sm:text-lg md:text-xl">Carregando...</h2>
        </div>
      </div>
    );
  }

  if (!user) {
    console.log('AppLayout: No user, redirecting to login');
    return <Navigate to="/login" replace />;
  }

  console.log('AppLayout: User authenticated, showing routes for role:', user.role);

  return (
    <SidebarProvider>
      <div className="min-h-screen w-full flex bg-background">
        <ModernSidebar />
        <SidebarInset className="flex-1 w-full min-w-0 flex flex-col">
          <ModernHeader pageTitle="Dashboard" />
          <main className="flex-1 p-3 sm:p-4 md:p-6 w-full overflow-x-hidden">
            <div className="w-full max-w-full">
              <Routes>
                {/* Admin Routes */}
                {user.role === UserRole.ADMIN && (
                  <>
                    {AdminRoutes()}
                    {/* Redirect dashboard para admin */}
                    <Route path="dashboard" element={<Navigate to="/admin/painel" replace />} />
                  </>
                )}
                
                {/* Driver Routes */}
                {user.role === UserRole.DRIVER && (
                  <>
                    {DriverRoutes()}
                    {DashboardRoutes()}
                    {/* Redirect dashboard genérico para o dashboard específico do motorista */}
                    <Route path="dashboard" element={<Navigate to="/motorista/dashboard" replace />} />
                  </>
                )}
                
                {/* ✅ RENTAL COMPANY ROUTES - CORRIGIR ORDEM DE PRECEDÊNCIA */}
                {user.role === UserRole.RENTAL_COMPANY && (
                  <>
                    {RentalCompanyRoutes()}
                    {/* Redirect dashboard genérico para o dashboard específico da locadora */}
                    <Route path="dashboard" element={<Navigate to="/locadora/dashboard" replace />} />
                    {/* ✅ ADICIONAR REDIRECT DE MOTORISTA/DASHBOARD PARA LOCADORA */}
                    <Route path="motorista/dashboard" element={<Navigate to="/locadora/dashboard" replace />} />
                  </>
                )}
                
                {/* Auth routes */}
                <Route path="auth/*" element={<AuthRoutes />} />
                
                {/* ✅ REDIRECIONAMENTO BASEADO NO ROLE DO USUÁRIO */}
                <Route path="/" element={
                  <Navigate to={
                    user.role === UserRole.ADMIN ? "/admin/painel" : 
                    user.role === UserRole.RENTAL_COMPANY ? "/locadora/dashboard" : 
                    user.role === UserRole.DRIVER ? "/motorista/dashboard" :
                    "/dashboard"
                  } replace />
                } />
                
                {/* ✅ PROTEÇÃO CONTRA ACESSO INCORRETO */}
                {user.role !== UserRole.ADMIN && (
                  <Route path="admin/*" element={<Navigate to="/" replace />} />
                )}
                
                {user.role !== UserRole.DRIVER && (
                  <Route path="motorista/*" element={<Navigate to="/" replace />} />
                )}
                
                {user.role !== UserRole.RENTAL_COMPANY && (
                  <Route path="locadora/*" element={<Navigate to="/" replace />} />
                )}
                
                {/* Fallback */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </div>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default AppLayout;
