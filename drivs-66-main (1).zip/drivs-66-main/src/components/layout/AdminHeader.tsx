
import React from "react";

export const AdminHeader: React.FC = () => {
  return (
    <div className="flex items-center gap-3 mb-6">
      <img 
        src="/lovable-uploads/e10d36b5-ea43-4e95-bdf6-fdd7cae31c66.png" 
        alt="DRIVS Logo" 
        className="h-8 w-auto"
      />
      <div className="border-l border-gray-300 h-8"></div>
      <h1 className="text-2xl font-bold text-gray-800">Painel Administrativo</h1>
    </div>
  );
};
