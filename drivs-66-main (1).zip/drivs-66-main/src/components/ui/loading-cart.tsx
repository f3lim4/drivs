
import { Car, Bike, Truck, Circle } from "lucide-react";
import { useState, useEffect } from "react";

export const LoadingCart = () => {
  const [currentIconIndex, setCurrentIconIndex] = useState(0);
  
  const icons = [
    { Icon: Car, name: "carro" },
    { Icon: Bike, name: "moto" }, 
    { Icon: Truck, name: "caminhão" },
    { Icon: Circle, name: "roda" }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIconIndex((prev) => (prev + 1) % icons.length);
    }, 800);

    return () => clearInterval(interval);
  }, []);

  const CurrentIcon = icons[currentIconIndex].Icon;

  return (
    <div className="flex items-center justify-center h-64 w-full">
      <CurrentIcon className="h-12 w-12 text-blue-600 animate-bounce transition-all duration-300" />
    </div>
  );
};
