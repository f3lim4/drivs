
import { cn } from "@/lib/utils";
import { LoadingCart } from "./loading-cart";

interface FuturisticLoadingProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  message?: string;
}

export const FuturisticLoading = ({ className, size = "md", message }: FuturisticLoadingProps) => {
  return (
    <LoadingCart />
  );
};
