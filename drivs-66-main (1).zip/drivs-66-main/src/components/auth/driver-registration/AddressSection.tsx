
import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface AddressSectionProps {
  formData: {
    zipCode: string;
    city: string;
    state: string;
    address: string;
  };
  onInputChange: (field: string, value: string) => void;
  onCepChange: (value: string) => void;
  cepLoading: boolean;
}

const AddressSection = ({
  formData,
  onInputChange,
  onCepChange,
  cepLoading
}: AddressSectionProps) => {
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="zipCode">CEP *</Label>
          <Input
            id="zipCode"
            value={formData.zipCode}
            onChange={(e) => onCepChange(e.target.value)}
            placeholder="00000-000"
            disabled={cepLoading}
            required
          />
          {cepLoading && <p className="text-xs text-blue-600 mt-1">Buscando endereço...</p>}
        </div>
        <div>
          <Label htmlFor="city">Cidade *</Label>
          <Input
            id="city"
            value={formData.city}
            onChange={(e) => onInputChange('city', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="state">Estado *</Label>
          <Input
            id="state"
            value={formData.state}
            onChange={(e) => onInputChange('state', e.target.value)}
            required
          />
        </div>
      </div>
      
      <div>
        <Label htmlFor="address">Endereço Completo *</Label>
        <Textarea
          id="address"
          value={formData.address}
          onChange={(e) => onInputChange('address', e.target.value)}
          required
        />
      </div>
    </>
  );
};

export default AddressSection;
