
import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface PersonalInfoSectionProps {
  formData: {
    fullName: string;
    email: string;
    phone: string;
    dateOfBirth: string;
  };
  onInputChange: (field: string, value: string) => void;
  validationErrors: {
    dateOfBirth?: string;
  };
  onDateOfBirthChange: (value: string) => void;
}

const PersonalInfoSection = ({
  formData,
  onInputChange,
  validationErrors,
  onDateOfBirthChange
}: PersonalInfoSectionProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <Label htmlFor="fullName">Nome Completo *</Label>
        <Input
          id="fullName"
          value={formData.fullName}
          onChange={(e) => onInputChange('fullName', e.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="email">Email *</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => onInputChange('email', e.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="dateOfBirth">Data de Nascimento *</Label>
        <Input
          id="dateOfBirth"
          type="date"
          value={formData.dateOfBirth}
          onChange={(e) => onDateOfBirthChange(e.target.value)}
          className={validationErrors.dateOfBirth ? "border-red-500" : ""}
          required
        />
        {validationErrors.dateOfBirth && (
          <p className="text-xs text-red-600 mt-1">{validationErrors.dateOfBirth}</p>
        )}
      </div>
      <div>
        <Label htmlFor="phone">Telefone *</Label>
        <Input
          id="phone"
          value={formData.phone}
          onChange={(e) => onInputChange('phone', e.target.value)}
          required
        />
      </div>
    </div>
  );
};

export default PersonalInfoSection;
