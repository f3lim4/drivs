
import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface DocumentsSectionProps {
  formData: {
    cpf: string;
    cnh: string;
    cnhExpires: string;
  };
  validationErrors: {
    cpf?: string;
    cnh?: string;
    cnhExpires?: string;
  };
  onCPFChange: (value: string) => void;
  onCNHChange: (value: string) => void;
  onCnhExpiresChange: (value: string) => void;
}

const DocumentsSection = ({
  formData,
  validationErrors,
  onCPFChange,
  onCNHChange,
  onCnhExpiresChange
}: DocumentsSectionProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <Label htmlFor="cpf">CPF *</Label>
        <Input
          id="cpf"
          value={formData.cpf}
          onChange={(e) => onCPFChange(e.target.value)}
          placeholder="000.000.000-00"
          className={validationErrors.cpf ? "border-red-500" : ""}
          required
        />
        {validationErrors.cpf && (
          <p className="text-xs text-red-600 mt-1">{validationErrors.cpf}</p>
        )}
      </div>
      <div>
        <Label htmlFor="cnh">CNH *</Label>
        <Input
          id="cnh"
          value={formData.cnh}
          onChange={(e) => onCNHChange(e.target.value)}
          placeholder="00000000000"
          className={validationErrors.cnh ? "border-red-500" : ""}
          required
        />
        {validationErrors.cnh && (
          <p className="text-xs text-red-600 mt-1">{validationErrors.cnh}</p>
        )}
      </div>
      <div>
        <Label htmlFor="cnhExpires">Vencimento da CNH *</Label>
        <Input
          id="cnhExpires"
          type="date"
          value={formData.cnhExpires}
          onChange={(e) => onCnhExpiresChange(e.target.value)}
          className={validationErrors.cnhExpires ? "border-red-500" : ""}
          required
        />
        {validationErrors.cnhExpires && (
          <p className="text-xs text-red-600 mt-1">{validationErrors.cnhExpires}</p>
        )}
      </div>
    </div>
  );
};

export default DocumentsSection;
