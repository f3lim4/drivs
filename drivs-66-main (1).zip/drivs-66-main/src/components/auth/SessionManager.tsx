
import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export const SessionManager = () => {
  const { user, logout } = useAuth();

  useEffect(() => {
    if (!user) return;

    // Configurar verificação de atividade do usuário
    let lastActivity = Date.now();
    const SESSION_TIMEOUT = 2 * 60 * 60 * 1000; // 2 horas
    const WARNING_TIME = 15 * 60 * 1000; // 15 minutos antes de expirar
    
    // Atualizar última atividade em eventos do usuário
    const updateActivity = () => {
      lastActivity = Date.now();
    };

    // Eventos que indicam atividade do usuário
    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    events.forEach(event => {
      document.addEventListener(event, updateActivity, true);
    });

    // Verificar sessão periodicamente
    const checkSession = () => {
      const now = Date.now();
      const inactiveTime = now - lastActivity;
      
      // Avisar quando a sessão estiver próxima de expirar
      if (inactiveTime > SESSION_TIMEOUT - WARNING_TIME && inactiveTime < SESSION_TIMEOUT) {
        toast.warning('Sua sessão expirará em breve. Mova o mouse para manter-se logado.', {
          duration: 10000,
        });
      }
      
      // Logout automático após inatividade
      if (inactiveTime > SESSION_TIMEOUT) {
        toast.error('Sua sessão expirou devido à inatividade. Você será redirecionado para o login.');
        setTimeout(() => {
          logout();
        }, 3000);
      }
    };

    // Verificar a cada minuto
    const sessionInterval = setInterval(checkSession, 60 * 1000);

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, updateActivity, true);
      });
      clearInterval(sessionInterval);
    };
  }, [user, logout]);

  return null; // Component não renderiza nada
};
