
import React, { useRef } from "react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Upload, FileText, X } from "lucide-react";

interface DocumentUploadFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  accept?: string;
  required?: boolean;
}

const DocumentUploadField = ({ 
  label, 
  value, 
  onChange, 
  accept = "image/*,.pdf", 
  required = false 
}: DocumentUploadFieldProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64String = reader.result as string;
        onChange(base64String);
        // Salvar no cookie para persistência
        document.cookie = `doc_${label.toLowerCase().replace(/\s+/g, '_')}=${encodeURIComponent(base64String)}; path=/; max-age=86400`;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemove = () => {
    onChange("");
    // Remover do cookie
    document.cookie = `doc_${label.toLowerCase().replace(/\s+/g, '_')}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const getFileName = (base64: string) => {
    if (base64.includes("data:application/pdf")) {
      return "documento.pdf";
    }
    return "imagem.jpg";
  };

  return (
    <div className="w-full space-y-2">
      <Label className="text-sm font-medium">{label} {required && "*"}</Label>
      
      {!value ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center cursor-pointer hover:border-blue-400 transition-colors bg-gray-50 hover:bg-gray-100"
        >
          <Upload className="mx-auto h-4 w-4 text-gray-400 mb-1" />
          <p className="text-xs text-gray-600 font-medium">
            Clique para selecionar
          </p>
          <p className="text-xs text-gray-500">
            PDF ou imagem
          </p>
        </div>
      ) : (
        <div className="border border-gray-300 rounded-lg p-3 bg-green-50 border-green-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium text-green-700 truncate">
                {getFileName(value)}
              </span>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleRemove}
              className="text-red-600 hover:text-red-700 hover:bg-red-50 h-7 w-7 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      <Input
        ref={fileInputRef}
        type="file"
        accept={accept}
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
};

export default DocumentUploadField;
