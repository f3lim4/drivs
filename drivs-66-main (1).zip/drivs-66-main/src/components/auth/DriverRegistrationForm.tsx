import React from "react";
import { Button } from "@/components/ui/button";
import PersonalInfoSection from "./driver-registration/PersonalInfoSection";
import DocumentsSection from "./driver-registration/DocumentsSection";
import AddressSection from "./driver-registration/AddressSection";
import PasswordSection from "./driver-registration/PasswordSection";
import DocumentUploadSection from "./driver-registration/DocumentUploadSection";
import { useCepLookup } from "@/hooks/useCepLookup";
import { useFormValidation } from "@/hooks/useFormValidation";

interface DriverFormData {
  fullName: string;
  email: string;
  phone: string;
  cpf: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  cnh: string;
  cnhExpires: string;
  dateOfBirth: string;
  password: string;
  confirmPassword: string;
}

interface DriverRegistrationFormProps {
  formData: DriverFormData;
  documents: {
    cnhDocument: string;
    addressProof: string;
    selfieDocument: string;
    appProfileScreenshot: string;
  };
  onInputChange: (field: string, value: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  loading: boolean;
  isValidating: boolean;
  updateDocument: (field: string, value: string) => void;
}

const DriverRegistrationForm = ({
  formData,
  documents,
  onInputChange,
  onSubmit,
  loading,
  isValidating,
  updateDocument
}: DriverRegistrationFormProps) => {
  const { lookupCep, loading: cepLoading } = useCepLookup();
  const {
    validationErrors,
    handleCPFChange,
    handleCNHChange,
    handleDateOfBirthChange,
    handleCnhExpiresChange,
    validateFormSubmission
  } = useFormValidation();

  const handleCepChange = async (value: string) => {
    console.log('CEP alterado para:', value);
    onInputChange('zipCode', value);
    
    if (value.length === 9 || (value.length === 8 && !value.includes('-'))) {
      const cepData = await lookupCep(value);
      if (cepData) {
        onInputChange('address', cepData.logradouro);
        onInputChange('city', cepData.localidade);
        onInputChange('state', cepData.uf);
      }
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('Dados do formulário antes da validação:', formData);
    
    if (!validateFormSubmission(formData)) {
      return;
    }
    
    onSubmit(e);
  };

  return (
    <form onSubmit={handleFormSubmit} className="space-y-4">
      <PersonalInfoSection
        formData={{
          fullName: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          dateOfBirth: formData.dateOfBirth
        }}
        onInputChange={onInputChange}
        validationErrors={validationErrors}
        onDateOfBirthChange={(value) => handleDateOfBirthChange(value, onInputChange)}
      />

      <DocumentsSection
        formData={{
          cpf: formData.cpf,
          cnh: formData.cnh,
          cnhExpires: formData.cnhExpires
        }}
        validationErrors={validationErrors}
        onCPFChange={(value) => handleCPFChange(value, onInputChange)}
        onCNHChange={(value) => handleCNHChange(value, onInputChange)}
        onCnhExpiresChange={(value) => {
          console.log('CNH Expires alterado para:', value);
          handleCnhExpiresChange(value, onInputChange);
        }}
      />

      <AddressSection
        formData={{
          zipCode: formData.zipCode,
          city: formData.city,
          state: formData.state,
          address: formData.address
        }}
        onInputChange={onInputChange}
        onCepChange={handleCepChange}
        cepLoading={cepLoading}
      />

      <PasswordSection
        formData={{
          password: formData.password,
          confirmPassword: formData.confirmPassword
        }}
        onInputChange={onInputChange}
      />

      <DocumentUploadSection
        documents={documents}
        updateDocument={updateDocument}
      />

      <Button 
        type="submit" 
        className="w-full" 
        disabled={
          loading || 
          isValidating || 
          !!validationErrors.cpf || 
          !!validationErrors.cnh || 
          !!validationErrors.dateOfBirth || 
          !!validationErrors.cnhExpires
        }
      >
        {loading || isValidating ? "Validando..." : "Cadastrar"}
      </Button>
    </form>
  );
};

export default DriverRegistrationForm;;
