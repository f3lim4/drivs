
import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface AddressSectionProps {
  formData: {
    zipCode: string;
    city: string;
    state: string;
    address: string;
  };
  onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onCepChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  cepLoading: boolean;
}

const AddressSection = ({
  formData,
  onInputChange,
  onCepChange,
  cepLoading
}: AddressSectionProps) => {
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="zipCode">CEP</Label>
          <Input
            id="zipCode"
            name="zipCode"
            type="text"
            value={formData.zipCode}
            onChange={onCepChange}
            placeholder="00000-000"
            disabled={cepLoading}
            required
          />
          {cepLoading && <p className="text-xs text-blue-600">Buscando endereço...</p>}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="city">Cidade</Label>
          <Input
            id="city"
            name="city"
            type="text"
            value={formData.city}
            onChange={onInputChange}
            placeholder="Cidade"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="state">Estado</Label>
          <Input
            id="state"
            name="state"
            type="text"
            value={formData.state}
            onChange={onInputChange}
            placeholder="SP"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="address">Endereço</Label>
          <Input
            id="address"
            name="address"
            type="text"
            value={formData.address}
            onChange={onInputChange}
            placeholder="Rua, número, complemento"
            required
          />
        </div>
      </div>
    </>
  );
};

export default AddressSection;
