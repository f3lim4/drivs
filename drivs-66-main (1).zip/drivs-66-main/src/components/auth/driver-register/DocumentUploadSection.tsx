
import React from "react";
import DocumentUploadField from "../DocumentUploadField";

interface DocumentUploadSectionProps {
  documents: {
    cnhDocument: string;
    addressProof: string;
    selfieDocument: string;
    appProfileScreenshot: string;
  };
  updateDocument: (field: string, value: string) => void;
}

const DocumentUploadSection = ({
  documents,
  updateDocument
}: DocumentUploadSectionProps) => {
  return (
    <div className="mt-6 space-y-4">
      <div className="border-t pt-4">
        <h3 className="text-lg font-semibold mb-3">Documentos</h3>
        <p className="text-sm text-gray-600 mb-4">
          Envie seus documentos para acelerar o processo de aprovação (opcional).
        </p>
        
        <div className="space-y-4">
          <DocumentUploadField
            label="Foto de Perfil"
            value={documents.selfieDocument}
            onChange={(value) => updateDocument('selfieDocument', value)}
            accept="image/*"
            required={false}
          />
          
          <DocumentUploadField
            label="CNH (Carteira Nacional de Habilitação)"
            value={documents.cnhDocument}
            onChange={(value) => updateDocument('cnhDocument', value)}
            accept="image/*,.pdf"
            required={false}
          />
          
          <DocumentUploadField
            label="Comprovante de Residência"
            value={documents.addressProof}
            onChange={(value) => updateDocument('addressProof', value)}
            accept="image/*,.pdf"
            required={false}
          />
          
          <DocumentUploadField
            label="Print do Perfil do App 99/Uber"
            value={documents.appProfileScreenshot}
            onChange={(value) => updateDocument('appProfileScreenshot', value)}
            accept="image/*"
            required={false}
          />
        </div>
      </div>
    </div>
  );
};

export default DocumentUploadSection;
