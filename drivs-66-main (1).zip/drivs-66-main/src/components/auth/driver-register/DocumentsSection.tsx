
import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface DocumentsSectionProps {
  formData: {
    cpf: string;
    cnh: string;
  };
  validationErrors: {
    cpf?: string;
    cnh?: string;
  };
  onCPFChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onCNHChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const DocumentsSection = ({
  formData,
  validationErrors,
  onCPFChange,
  onCNHChange
}: DocumentsSectionProps) => {
  console.log('📄 [DOCUMENTS SECTION] Rendering with data:', {
    cpf: formData.cpf,
    cnh: formData.cnh,
    errors: validationErrors
  });

  const handleCPFInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    console.log('📝 [CPF INPUT] User typing:', e.target.value);
    onCPFChange(e);
  };

  const handleCNHInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    console.log('📝 [CNH INPUT] User typing:', e.target.value);
    onCNHChange(e);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <Label htmlFor="cpf">CPF</Label>
        <Input
          id="cpf"
          name="cpf"
          type="text"
          value={formData.cpf || ""}
          onChange={handleCPFInput}
          placeholder="000.000.000-00"
          className={validationErrors.cpf ? "border-red-500" : ""}
          autoComplete="off"
          maxLength={14}
          required
        />
        {validationErrors.cpf && (
          <p className="text-xs text-red-600">{validationErrors.cpf}</p>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="cnh">CNH</Label>
        <Input
          id="cnh"
          name="cnh"
          type="text"
          value={formData.cnh || ""}
          onChange={handleCNHInput}
          placeholder="00000000000"
          className={validationErrors.cnh ? "border-red-500" : ""}
          autoComplete="off"
          maxLength={11}
          required
        />
        {validationErrors.cnh && (
          <p className="text-xs text-red-600">{validationErrors.cnh}</p>
        )}
      </div>
    </div>
  );
};

export default DocumentsSection;
