
import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface PersonalInfoSectionProps {
  formData: {
    fullName: string;
    email: string;
    phone: string;
    dateOfBirth: string;
  };
  onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  validationErrors: {
    dateOfBirth?: string;
  };
  onDateOfBirthChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const PersonalInfoSection = ({
  formData,
  onInputChange,
  validationErrors,
  onDateOfBirthChange
}: PersonalInfoSectionProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <Label htmlFor="fullName">Nome Completo</Label>
        <Input
          id="fullName"
          name="fullName"
          type="text"
          value={formData.fullName}
          onChange={onInputChange}
          placeholder="Digite seu nome completo"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="email">E-mail</Label>
        <Input
          id="email"
          name="email"
          type="email"
          value={formData.email}
          onChange={onInputChange}
          placeholder="Digite seu e-mail"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="dateOfBirth">Data de Nascimento</Label>
        <Input
          id="dateOfBirth"
          name="dateOfBirth"
          type="date"
          value={formData.dateOfBirth}
          onChange={onDateOfBirthChange}
          className={validationErrors.dateOfBirth ? "border-red-500" : ""}
          required
        />
        {validationErrors.dateOfBirth && (
          <p className="text-xs text-red-600">{validationErrors.dateOfBirth}</p>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="phone">Telefone</Label>
        <Input
          id="phone"
          name="phone"
          type="tel"
          value={formData.phone}
          onChange={onInputChange}
          placeholder="(11) 99999-9999"
          required
        />
      </div>
    </div>
  );
};

export default PersonalInfoSection;
