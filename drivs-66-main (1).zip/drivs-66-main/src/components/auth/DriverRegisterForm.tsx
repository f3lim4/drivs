
import { Button } from "@/components/ui/button";
import { Car } from "lucide-react";
import PersonalInfoSection from "./driver-register/PersonalInfoSection";
import DocumentsSection from "./driver-register/DocumentsSection";
import AddressSection from "./driver-register/AddressSection";
import PasswordSection from "./driver-register/PasswordSection";
import DocumentUploadSection from "./driver-register/DocumentUploadSection";
import { useCepLookup } from "@/hooks/useCepLookup";
import { useDriverRegisterFormValidation } from "@/hooks/useDriverRegisterFormValidation";

interface DriverRegisterFormData {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
  phone: string;
  cpf: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  dateOfBirth: string;
  cnh: string;
  referralCompanyId: string | null;
}

interface DriverRegisterFormProps {
  formData: DriverRegisterFormData;
  documents: {
    cnhDocument: string;
    addressProof: string;
    selfieDocument: string;
    appProfileScreenshot: string;
  };
  loading: boolean;
  isValidating: boolean;
  referralId: string | null;
  onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSubmit: (e: React.FormEvent) => void;
  updateDocument: (field: string, value: string) => void;
}

export const DriverRegisterForm = ({
  formData,
  documents,
  loading,
  isValidating,
  referralId,
  onInputChange,
  onSubmit,
  updateDocument
}: DriverRegisterFormProps) => {
  console.log('🎨 [DRIVER REGISTER FORM] Renderizando formulário...', {
    hasFormData: !!formData,
    referralId,
    loading,
    isValidating
  });

  const { lookupCep, loading: cepLoading } = useCepLookup();
  const {
    validationErrors,
    handleCPFChange,
    handleCNHChange,
    handleDateOfBirthChange,
    validateFormSubmission
  } = useDriverRegisterFormValidation();

  const handleCepChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    onInputChange(e);
    
    if (value.length === 9 || (value.length === 8 && !value.includes('-'))) {
      console.log('🔍 [CEP LOOKUP] Buscando CEP:', value);
      const cepData = await lookupCep(value);
      if (cepData) {
        console.log('✅ [CEP LOOKUP] Dados encontrados:', cepData);
        // Simular eventos para atualizar os campos
        const addressEvent = { target: { name: 'address', value: cepData.logradouro } } as React.ChangeEvent<HTMLInputElement>;
        const cityEvent = { target: { name: 'city', value: cepData.localidade } } as React.ChangeEvent<HTMLInputElement>;
        const stateEvent = { target: { name: 'state', value: cepData.uf } } as React.ChangeEvent<HTMLInputElement>;
        
        onInputChange(addressEvent);
        onInputChange(cityEvent);
        onInputChange(stateEvent);
      }
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('📝 [FORM SUBMIT] Validando formulário antes do envio...');
    
    if (!validateFormSubmission(formData)) {
      console.log('❌ [FORM SUBMIT] Validação falhou');
      return;
    }
    
    console.log('✅ [FORM SUBMIT] Validação passou, enviando...');
    onSubmit(e);
  };

  // Se não há formData, mostra loading
  if (!formData) {
    console.log('⏳ [DRIVER REGISTER FORM] Aguardando dados do formulário...');
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <form onSubmit={handleFormSubmit} className="space-y-4">
      <PersonalInfoSection
        formData={{
          fullName: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          dateOfBirth: formData.dateOfBirth
        }}
        onInputChange={onInputChange}
        validationErrors={validationErrors}
        onDateOfBirthChange={(e) => handleDateOfBirthChange(e, onInputChange)}
      />

      <DocumentsSection
        formData={{
          cpf: formData.cpf,
          cnh: formData.cnh
        }}
        validationErrors={validationErrors}
        onCPFChange={(e) => handleCPFChange(e, onInputChange)}
        onCNHChange={(e) => handleCNHChange(e, onInputChange)}
      />

      <AddressSection
        formData={{
          zipCode: formData.zipCode,
          city: formData.city,
          state: formData.state,
          address: formData.address
        }}
        onInputChange={onInputChange}
        onCepChange={handleCepChange}
        cepLoading={cepLoading}
      />

      <PasswordSection
        formData={{
          password: formData.password,
          confirmPassword: formData.confirmPassword
        }}
        onInputChange={onInputChange}
      />

      <DocumentUploadSection
        documents={documents}
        updateDocument={updateDocument}
      />

      {referralId && (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800">
            <Car className="inline w-4 h-4 mr-1" />
            Cadastro via locadora específica - Seu perfil será direcionado automaticamente
          </p>
        </div>
      )}

      <Button 
        type="submit" 
        className="w-full" 
        disabled={
          loading || 
          isValidating || 
          !!validationErrors.cpf || 
          !!validationErrors.cnh || 
          !!validationErrors.dateOfBirth
        }
      >
        {loading || isValidating ? "Validando..." : "Criar Conta"}
      </Button>
    </form>
  );
};
