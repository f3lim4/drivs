
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import CompleteInspectionForm from "../inspection/CompleteInspectionForm";
import { InspectionData } from "@/types/inspection";

interface NativeCameraCaptureProps {
  inspectionId: number;
  vehiclePlate: string;
  vehicleModel: string;
  onComplete: () => void;
  customPhotoRequirements?: any;
  inspectionType?: 'inicial' | 'entrega' | 'manutencao' | 'eventual';
  title?: string;
  description?: string;
  deadline?: string;
  canUsePhotoFromFiles?: boolean;
}

const NativeCameraCapture = ({ 
  inspectionId, 
  vehiclePlate, 
  vehicleModel, 
  onComplete,
  inspectionType = 'eventual',
  title,
  description,
  deadline,
  canUsePhotoFromFiles = false
}: NativeCameraCaptureProps) => {
  const { user } = useAuth();
  
  // Determinar se pode usar arquivos (apenas vistoriadores podem)
  const canUseFiles = user?.role === UserRole.INSPECTOR;
  
  // Função para obter o nome do usuário de forma segura
  const getUserName = (user: any, fallback?: string): string => {
    if (!user) return fallback || "Usuário";
    
    if ('fullName' in user && user.fullName) {
      return user.fullName;
    }
    if ('name' in user && user.name) {
      return user.name;
    }
    return fallback || "Usuário";
  };
  
  // Nome do motorista (se for motorista logado) ou nome do vistoriador
  const driverName = user?.role === UserRole.DRIVER ? getUserName(user, "Motorista") : "Motorista";
  const inspectorName = user?.role === UserRole.INSPECTOR ? getUserName(user) : undefined;

  const handleInspectionComplete = (data: InspectionData) => {
    console.log('Vistoria finalizada:', data);
    // Aqui você pode salvar os dados da vistoria
    onComplete();
  };

  return (
    <div className="min-h-screen bg-background dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <CompleteInspectionForm
          inspectionType={inspectionType}
          vehiclePlate={vehiclePlate}
          vehicleModel={vehicleModel}
          driverName={driverName}
          inspectorName={inspectorName}
          onComplete={handleInspectionComplete}
          onCancel={onComplete}
          canUseFiles={canUseFiles}
          title={title}
          description={description}
          deadline={deadline}
        />
      </div>
    </div>
  );
};

export default NativeCameraCapture;
