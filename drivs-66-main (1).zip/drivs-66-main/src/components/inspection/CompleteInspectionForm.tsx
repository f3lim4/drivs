
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Save, Calendar, MapPin, Clock, User } from "lucide-react";
import { InspectionData, InspectionPhoto, ExtraPhoto, STANDARD_PHOTO_REQUIREMENTS } from "@/types/inspection";
import StandardPhotoCapture from "./StandardPhotoCapture";
import ExtraPhotosSection from "./ExtraPhotosSection";
import { toast } from "sonner";

interface CompleteInspectionFormProps {
  inspectionType: 'inicial' | 'entrega' | 'manutencao' | 'eventual';
  vehiclePlate: string;
  vehicleModel: string;
  driverName: string;
  inspectorName?: string;
  onComplete: (data: InspectionData) => void;
  onCancel: () => void;
  canUseFiles?: boolean;
  title?: string;
  description?: string;
  deadline?: string;
}

const CompleteInspectionForm = ({
  inspectionType,
  vehiclePlate,
  vehicleModel,
  driverName,
  inspectorName,
  onComplete,
  onCancel,
  canUseFiles = false,
  title,
  description,
  deadline
}: CompleteInspectionFormProps) => {
  const [standardPhotos, setStandardPhotos] = useState<Record<string, InspectionPhoto>>({});
  const [extraPhotos, setExtraPhotos] = useState<ExtraPhoto[]>([]);
  const [generalObservations, setGeneralObservations] = useState("");
  const [currentDateTime, setCurrentDateTime] = useState<string>("");
  const [currentLocation, setCurrentLocation] = useState<string>("");

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setCurrentDateTime(now.toLocaleString('pt-BR'));
    };

    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setCurrentLocation(`${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
        },
        () => setCurrentLocation("Localização não disponível")
      );
    } else {
      setCurrentLocation("Geolocalização não suportada");
    }
  }, []);

  const handleStandardPhoto = (requirementId: string, photo: InspectionPhoto) => {
    setStandardPhotos(prev => ({ ...prev, [requirementId]: photo }));
  };

  const getInspectionTypeLabel = (type: string) => {
    switch (type) {
      case 'inicial': return 'Vistoria Inicial';
      case 'entrega': return 'Vistoria de Entrega';
      case 'manutencao': return 'Vistoria de Manutenção';
      case 'eventual': return 'Vistoria Eventual';
      default: return 'Vistoria';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'inicial': return 'bg-blue-100 text-blue-800';
      case 'entrega': return 'bg-green-100 text-green-800';
      case 'manutencao': return 'bg-orange-100 text-orange-800';
      case 'eventual': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const requiredPhotos = STANDARD_PHOTO_REQUIREMENTS.filter(req => req.required);
  const completedRequiredPhotos = requiredPhotos.filter(req => standardPhotos[req.id]);
  const totalStandardPhotos = Object.keys(standardPhotos).length;
  const progressPercentage = (completedRequiredPhotos.length / requiredPhotos.length) * 100;

  const canComplete = completedRequiredPhotos.length === requiredPhotos.length;

  const handleComplete = () => {
    if (!canComplete) {
      toast.error("Complete todas as fotos obrigatórias antes de finalizar");
      return;
    }

    const inspectionData: InspectionData = {
      id: Date.now().toString(),
      type: inspectionType,
      vehiclePlate,
      vehicleModel,
      driverName,
      inspectorName,
      standardPhotos: Object.values(standardPhotos),
      extraPhotos,
      generalObservations,
      status: 'completed',
      createdAt: new Date().toISOString(),
      completedAt: new Date().toISOString(),
      deadline,
      title,
      description
    };

    onComplete(inspectionData);
    toast.success("Vistoria finalizada com sucesso!");
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho da Vistoria */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              {title || getInspectionTypeLabel(inspectionType)}
            </CardTitle>
            <Badge className={getTypeColor(inspectionType)}>
              {getInspectionTypeLabel(inspectionType)}
            </Badge>
          </div>
          {description && (
            <p className="text-sm text-muted-foreground mt-2">{description}</p>
          )}
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <span className="font-medium">Veículo:</span>
              <span>{vehicleModel} - {vehiclePlate}</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="h-4 w-4" />
              <span className="font-medium">Motorista:</span>
              <span>{driverName}</span>
            </div>
            {inspectorName && (
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span className="font-medium">Vistoriador:</span>
                <span>{inspectorName}</span>
              </div>
            )}
            {deadline && (
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span className="font-medium">Prazo:</span>
                <span>{deadline}</span>
              </div>
            )}
          </div>
          
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progresso das fotos obrigatórias</span>
              <span>{completedRequiredPhotos.length}/{requiredPhotos.length}</span>
            </div>
            <Progress value={progressPercentage} className="w-full" />
          </div>
        </CardContent>
      </Card>

      {/* Fotos Padrão */}
      <Card>
        <CardHeader>
          <CardTitle>Fotos Padrão da Vistoria</CardTitle>
          <p className="text-sm text-muted-foreground">
            Complete todas as fotos obrigatórias ({completedRequiredPhotos.length}/{requiredPhotos.length})
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {STANDARD_PHOTO_REQUIREMENTS.map((requirement) => (
              <StandardPhotoCapture
                key={requirement.id}
                requirement={requirement}
                currentDateTime={currentDateTime}
                currentLocation={currentLocation}
                onPhotoTaken={handleStandardPhoto}
                isCompleted={!!standardPhotos[requirement.id]}
                canUseFiles={canUseFiles}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Fotos Extras */}
      <ExtraPhotosSection
        extraPhotos={extraPhotos}
        onPhotosChange={setExtraPhotos}
        currentDateTime={currentDateTime}
        currentLocation={currentLocation}
        canUseFiles={canUseFiles}
      />

      {/* Observações Gerais */}
      <Card>
        <CardHeader>
          <CardTitle>Observações Gerais</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={generalObservations}
            onChange={(e) => setGeneralObservations(e.target.value)}
            placeholder="Adicione observações gerais sobre a vistoria..."
            rows={4}
          />
        </CardContent>
      </Card>

      {/* Botões de Ação */}
      <div className="flex gap-4">
        <Button onClick={onCancel} variant="outline" className="flex-1">
          Cancelar
        </Button>
        <Button 
          onClick={handleComplete} 
          className="flex-1"
          disabled={!canComplete}
        >
          <Save className="h-4 w-4 mr-2" />
          Finalizar Vistoria ({completedRequiredPhotos.length}/{requiredPhotos.length})
        </Button>
      </div>
    </div>
  );
};

export default CompleteInspectionForm;
