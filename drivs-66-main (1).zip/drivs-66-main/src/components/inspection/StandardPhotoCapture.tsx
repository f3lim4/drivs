
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Camera, CheckCircle, Clock, MapPin } from "lucide-react";
import { StandardPhotoRequirement, InspectionPhoto } from "@/types/inspection";
import { toast } from "sonner";
import { Camera as CapacitorCamera, CameraResultType, CameraSource } from '@capacitor/camera';

interface StandardPhotoCaptureProps {
  requirement: StandardPhotoRequirement;
  currentDateTime: string;
  currentLocation: string;
  onPhotoTaken: (requirementId: string, photo: InspectionPhoto) => void;
  isCompleted: boolean;
  canUseFiles?: boolean;
}

const StandardPhotoCapture = ({
  requirement,
  currentDateTime,
  currentLocation,
  onPhotoTaken,
  isCompleted,
  canUseFiles = false
}: StandardPhotoCaptureProps) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<InspectionPhoto | null>(
    isCompleted ? { id: '', url: '', timestamp: currentDateTime, location: currentLocation } : null
  );

  const handleCameraCapture = async () => {
    try {
      setIsCapturing(true);
      
      const photo = await CapacitorCamera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera,
        saveToGallery: true
      });

      if (photo.dataUrl) {
        const inspectionPhoto: InspectionPhoto = {
          id: Date.now().toString(),
          url: photo.dataUrl,
          timestamp: currentDateTime,
          location: currentLocation
        };
        
        setCapturedPhoto(inspectionPhoto);
        onPhotoTaken(requirement.id, inspectionPhoto);
        toast.success(`Foto capturada: ${requirement.title}`);
      }
    } catch (error) {
      console.error('Erro ao acessar câmera:', error);
      toast.error('Erro ao acessar a câmera');
    } finally {
      setIsCapturing(false);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      const photo: InspectionPhoto = {
        id: Date.now().toString(),
        url,
        timestamp: currentDateTime,
        location: currentLocation
      };
      
      setCapturedPhoto(photo);
      onPhotoTaken(requirement.id, photo);
      toast.success(`Foto selecionada: ${requirement.title}`);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'exterior': return 'bg-blue-100 text-blue-800';
      case 'interior': return 'bg-green-100 text-green-800';
      case 'mechanical': return 'bg-orange-100 text-orange-800';
      case 'accessories': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className={`relative ${isCompleted ? 'border-green-500 bg-green-50' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Camera className="h-4 w-4" />
            {requirement.title}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge className={getCategoryColor(requirement.category)}>
              {requirement.category}
            </Badge>
            {isCompleted && (
              <Badge className="bg-green-500 text-white">
                <CheckCircle className="h-3 w-3 mr-1" />
                Concluída
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          {requirement.description}
        </p>
        
        {capturedPhoto && (
          <div className="relative">
            <img
              src={capturedPhoto.url}
              alt={requirement.title}
              className="w-full h-32 object-cover rounded-lg border"
            />
            <div className="absolute top-2 right-2">
              <Badge className="bg-green-500 text-white">
                <CheckCircle className="h-3 w-3 mr-1" />
                Capturada
              </Badge>
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{currentDateTime}</span>
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="h-3 w-3" />
            <span className="truncate">{currentLocation}</span>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleCameraCapture}
            disabled={isCapturing}
            className="flex-1"
            variant={isCompleted ? "outline" : "default"}
          >
            <Camera className="h-4 w-4 mr-2" />
            {isCapturing ? "Capturando..." : isCompleted ? "Nova Foto" : "Câmera"}
          </Button>
          
          {canUseFiles && (
            <>
              <Button
                variant="outline"
                onClick={() => document.getElementById(`file-${requirement.id}`)?.click()}
                className="flex-1"
              >
                Arquivo
              </Button>
              <input
                id={`file-${requirement.id}`}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default StandardPhotoCapture;
