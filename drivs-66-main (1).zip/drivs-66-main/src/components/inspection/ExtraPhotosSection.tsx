
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Camera, Plus, Trash2, Clock, MapPin } from "lucide-react";
import { ExtraPhoto } from "@/types/inspection";
import { toast } from "sonner";
import { Camera as CapacitorCamera, CameraResultType, CameraSource } from '@capacitor/camera';

interface ExtraPhotosSectionProps {
  extraPhotos: ExtraPhoto[];
  onPhotosChange: (photos: ExtraPhoto[]) => void;
  currentDateTime: string;
  currentLocation: string;
  maxPhotos?: number;
  canUseFiles?: boolean;
}

const ExtraPhotosSection = ({
  extraPhotos,
  onPhotosChange,
  currentDateTime,
  currentLocation,
  maxPhotos = 10,
  canUseFiles = false
}: ExtraPhotosSectionProps) => {
  const [isCapturing, setIsCapturing] = useState(false);

  const addExtraPhoto = async (fromCamera: boolean = true) => {
    if (extraPhotos.length >= maxPhotos) {
      toast.error(`Limite máximo de ${maxPhotos} fotos extras atingido`);
      return;
    }

    try {
      setIsCapturing(true);
      
      if (fromCamera) {
        const photo = await CapacitorCamera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Camera,
          saveToGallery: true
        });

        if (photo.dataUrl) {
          const newPhoto: ExtraPhoto = {
            id: Date.now().toString(),
            url: photo.dataUrl,
            timestamp: currentDateTime,
            location: currentLocation,
            observations: ''
          };
          
          onPhotosChange([...extraPhotos, newPhoto]);
          toast.success('Foto extra capturada');
        }
      } else {
        // Para seleção de arquivo
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.onchange = (e) => {
          const file = (e.target as HTMLInputElement).files?.[0];
          if (file) {
            const url = URL.createObjectURL(file);
            const newPhoto: ExtraPhoto = {
              id: Date.now().toString(),
              url,
              timestamp: currentDateTime,
              location: currentLocation,
              observations: ''
            };
            
            onPhotosChange([...extraPhotos, newPhoto]);
            toast.success('Foto extra selecionada');
          }
        };
        input.click();
      }
    } catch (error) {
      console.error('Erro ao capturar foto:', error);
      toast.error('Erro ao capturar foto');
    } finally {
      setIsCapturing(false);
    }
  };

  const removePhoto = (photoId: string) => {
    const updatedPhotos = extraPhotos.filter(photo => photo.id !== photoId);
    onPhotosChange(updatedPhotos);
    toast.success('Foto removida');
  };

  const updateObservations = (photoId: string, observations: string) => {
    const updatedPhotos = extraPhotos.map(photo =>
      photo.id === photoId ? { ...photo, observations } : photo
    );
    onPhotosChange(updatedPhotos);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="h-5 w-5" />
          Fotos Extras com Observações ({extraPhotos.length}/{maxPhotos})
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Adicione fotos extras com observações específicas
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {extraPhotos.length < maxPhotos && (
          <div className="flex gap-2">
            <Button
              onClick={() => addExtraPhoto(true)}
              disabled={isCapturing}
              className="flex-1"
            >
              <Camera className="h-4 w-4 mr-2" />
              {isCapturing ? "Capturando..." : "Nova Foto"}
            </Button>
            
            {canUseFiles && (
              <Button
                onClick={() => addExtraPhoto(false)}
                variant="outline"
                className="flex-1"
              >
                <Plus className="h-4 w-4 mr-2" />
                Selecionar Arquivo
              </Button>
            )}
          </div>
        )}

        <div className="space-y-4">
          {extraPhotos.map((photo, index) => (
            <Card key={photo.id} className="p-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Badge variant="outline">Foto Extra {index + 1}</Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removePhoto(photo.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="relative">
                  <img
                    src={photo.url}
                    alt={`Foto extra ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    <span>{photo.timestamp}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    <span className="truncate">{photo.location}</span>
                  </div>
                </div>
                
                <Textarea
                  value={photo.observations}
                  onChange={(e) => updateObservations(photo.id, e.target.value)}
                  placeholder="Adicione observações sobre esta foto..."
                  rows={3}
                />
              </div>
            </Card>
          ))}
        </div>

        {extraPhotos.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <Camera className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Nenhuma foto extra adicionada</p>
            <p className="text-sm">Clique em "Nova Foto" para adicionar</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ExtraPhotosSection;
