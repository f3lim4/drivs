
import React, { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Users, 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  EyeOff,
  Search,
  UserCheck,
  Camera,
  Settings
} from "lucide-react";
import { useCompanyUsers } from "@/hooks/useCompanyUsers";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";

interface Permission {
  motoristas: boolean;
  veiculos: boolean;
  contratos: boolean;
  pagamentos: boolean;
  financeiro: boolean;
  infracoes: boolean;
  manutencao: boolean;
  vistorias: boolean;
  negativar: boolean;
  ranking: boolean;
  relatorios: boolean;
  configuracoes: boolean;
}

const CompanyUsers = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [permissions, setPermissions] = useState<Permission>({
    motoristas: true,
    veiculos: true,
    contratos: true,
    pagamentos: true,
    financeiro: true,
    infracoes: true,
    manutencao: true,
    vistorias: true,
    negativar: true,
    ranking: true,
    relatorios: true,
    configuracoes: true
  });
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    role: 'manager' as 'manager' | 'inspector',
    password: ""
  });

  // Usar o ID da locadora atual (assumindo que o user tem esse ID)
  const companyId = user?.role === UserRole.RENTAL_COMPANY ? user.id : undefined;
  const { users, loading, createUser, toggleUserStatus, deleteUser } = useCompanyUsers(companyId);

  if (!user || (user.role !== UserRole.RENTAL_COMPANY && user.role !== UserRole.MANAGER)) {
    return (
      <div className="page-content">
        <Card className="content-card content-card-red">
          <CardContent className="p-6">
            <p className="text-center text-muted-foreground">Acesso não autorizado</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return <FuturisticLoading />;
  }

  const getRoleLabel = (role: 'manager' | 'inspector') => {
    return role === 'manager' ? "Gestor" : "Vistoriador";
  };

  const getRoleIcon = (role: 'manager' | 'inspector') => {
    return role === 'manager' ? UserCheck : Camera;
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreateUser = async () => {
    if (!newUser.name || !newUser.email || !newUser.password) {
      return;
    }

    await createUser({
      ...newUser,
      permissions: newUser.role === 'manager' ? permissions : undefined
    });

    setNewUser({ name: "", email: "", role: 'manager', password: "" });
    setPermissions({
      motoristas: true,
      veiculos: true,
      contratos: true,
      pagamentos: true,
      financeiro: true,
      infracoes: true,
      manutencao: true,
      vistorias: true,
      negativar: true,
      ranking: true,
      relatorios: true,
      configuracoes: true
    });
    setIsCreateDialogOpen(false);
  };

  const handlePermissionChange = (permission: keyof Permission, checked: boolean) => {
    setPermissions(prev => ({ ...prev, [permission]: checked }));
  };

  const permissionLabels = {
    motoristas: "Motoristas",
    veiculos: "Veículos", 
    contratos: "Contratos",
    pagamentos: "Pagamentos",
    financeiro: "Financeiro",
    infracoes: "Infrações",
    manutencao: "Manutenção",
    vistorias: "Vistorias",
    negativar: "Negativar",
    ranking: "Ranking",
    relatorios: "Relatórios",
    configuracoes: "Configurações"
  };

  return (
    <div className="page-content">
      <div className="space-y-6">
        <div className="page-header">
          <div>
            <h1 className="page-title">Gerenciar Usuários</h1>
            <p className="page-subtitle">
              Gerencie gestores e vistoriadores da sua locadora
            </p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Novo Usuário
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Criar Novo Usuário</DialogTitle>
                <DialogDescription>
                  Adicione um gestor ou vistoriador à sua equipe
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome</Label>
                    <Input
                      id="name"
                      value={newUser.name}
                      onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newUser.email}
                      onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha</Label>
                    <Input
                      id="password"
                      type="password"
                      value={newUser.password}
                      onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">Tipo de Usuário</Label>
                    <Select value={newUser.role} onValueChange={(value) => setNewUser({ ...newUser, role: value as 'manager' | 'inspector' })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="manager">
                          <div className="flex items-center gap-2">
                            <UserCheck className="h-4 w-4" />
                            Gestor (Acesso configurável)
                          </div>
                        </SelectItem>
                        <SelectItem value="inspector">
                          <div className="flex items-center gap-2">
                            <Camera className="h-4 w-4" />
                            Vistoriador (Apenas vistorias)
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {newUser.role === 'manager' && (
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      Permissões do Gestor
                    </Label>
                    <div className="grid grid-cols-2 gap-3 p-4 border rounded-lg">
                      {Object.entries(permissionLabels).map(([key, label]) => (
                        <div key={key} className="flex items-center space-x-2">
                          <Checkbox
                            id={key}
                            checked={permissions[key as keyof Permission]}
                            onCheckedChange={(checked) => handlePermissionChange(key as keyof Permission, checked as boolean)}
                          />
                          <Label htmlFor={key} className="text-sm font-normal">
                            {label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleCreateUser}>
                  Criar Usuário
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Busca */}
        <Card className="content-card">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Cards informativos */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="content-card content-card-blue">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="h-5 w-5" />
                Gestores
              </CardTitle>
              <CardDescription>
                Gestores têm acesso configurável às funcionalidades
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {users.filter(u => u.role === 'manager' && u.active).length}
              </div>
              <p className="text-sm text-muted-foreground">ativos</p>
            </CardContent>
          </Card>

          <Card className="content-card content-card-green">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Vistoriadores
              </CardTitle>
              <CardDescription>
                Vistoriadores podem apenas realizar e gerenciar vistorias
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {users.filter(u => u.role === 'inspector' && u.active).length}
              </div>
              <p className="text-sm text-muted-foreground">ativos</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabela de usuários */}
        <Card className="content-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Usuários da Equipe ({filteredUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Permissões</TableHead>
                  <TableHead>Último Login</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => {
                  const RoleIcon = getRoleIcon(user.role);
                  return (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <RoleIcon className="h-4 w-4" />
                          <Badge variant={user.role === 'manager' ? "default" : "secondary"}>
                            {getRoleLabel(user.role)}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.active ? "default" : "secondary"}>
                          {user.active ? "Ativo" : "Inativo"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.role === 'manager' && user.permissions ? (
                          <div className="text-xs">
                            {Object.entries(user.permissions).filter(([, value]) => value).length} de {Object.keys(user.permissions).length} permissões
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">Apenas vistorias</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {user.last_login ? new Date(user.last_login).toLocaleDateString() : "Nunca"}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => toggleUserStatus(user.id)}
                          >
                            {user.active ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deleteUser(user.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Card informativo sobre permissões */}
        <Card className="content-card content-card-yellow">
          <CardHeader>
            <CardTitle>Sobre as Permissões</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <UserCheck className="h-4 w-4" />
                  Gestores
                </h4>
                <ul className="text-sm space-y-1">
                  <li>• Acesso configurável por permissão</li>
                  <li>• Pode gerenciar motoristas se permitido</li>
                  <li>• Acesso a relatórios conforme configuração</li>
                  <li>• Controle granular de funcionalidades</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Camera className="h-4 w-4" />
                  Vistoriadores
                </h4>
                <ul className="text-sm space-y-1">
                  <li>• Acesso apenas às vistorias</li>
                  <li>• Criar e atualizar laudos</li>
                  <li>• Fazer upload de fotos</li>
                  <li>• Visualizar histórico de vistorias</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CompanyUsers;
