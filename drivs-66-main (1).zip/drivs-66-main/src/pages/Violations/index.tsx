
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { SendViolationDialog } from "./components/SendViolationDialog";
import { ViolationDetailsDialog } from "./components/ViolationDetailsDialog";
import { ViolationsPageLayout } from "./components/ViolationsPageLayout";
import { DriverViolationsView } from "./components/DriverViolationsView";
import { RentalCompanyViolationsView } from "./components/RentalCompanyViolationsView";
import { AdminManagerViolationsView } from "./components/AdminManagerViolationsView";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

const mockViolations: Violation[] = [
  {
    id: "v1",
    contractId: "c1",
    vehicleId: "v1",
    vehicleInfo: "Chevrolet Onix 2023 - Placa ABC-1234",
    driverId: "d1",
    driverName: "João Motorista",
    companyId: "r1",
    companyName: "Best Rentals Inc.",
    date: "2025-05-10",
    location: "Av. Paulista, 1000, São Paulo",
    description: "Excesso de velocidade - 20km/h acima do limite",
    points: 4,
    value: 195.23,
    status: "pending",
    paymentDeadline: "2025-06-10"
  },
  {
    id: "v2",
    contractId: "c2",
    vehicleId: "v5",
    vehicleInfo: "Jeep Renegade 2023 - Placa MNO-7890",
    driverId: "d2",
    driverName: "Maria Aprovada",
    companyId: "r2",
    companyName: "City Drivers Cars",
    date: "2025-05-12",
    location: "Rod. Presidente Dutra, km 200, São José dos Campos",
    description: "Estacionamento em local proibido",
    points: 3,
    value: 130.16,
    status: "paid",
    paymentDeadline: "2025-06-12"
  },
  {
    id: "v3",
    contractId: "c3",
    vehicleId: "v3",
    vehicleInfo: "Renault Kwid 2023 - Placa GHI-9012",
    driverId: "d1",
    driverName: "João Motorista",
    companyId: "r1",
    companyName: "Best Rentals Inc.",
    date: "2025-04-20",
    location: "Rua Augusta, 500, São Paulo",
    description: "Avanço de sinal vermelho",
    points: 7,
    value: 293.47,
    status: "contested",
    paymentDeadline: "2025-05-20"
  },
  {
    id: "v4",
    contractId: "c1",
    vehicleId: "v1",
    vehicleInfo: "Chevrolet Onix 2023 - Placa ABC-1234",
    driverId: "d1",
    driverName: "João Motorista",
    companyId: "r1",
    companyName: "Best Rentals Inc.",
    date: "2025-05-15",
    location: "Av. Rebouças, 1200, São Paulo",
    description: "Uso de celular ao volante",
    points: 5,
    value: 243.47,
    status: "resolved",
    paymentDeadline: "2025-06-15"
  }
];

const ViolationsPage = () => {
  const { user } = useAuth();
  const [violations, setViolations] = useState(mockViolations);
  const [selectedViolation, setSelectedViolation] = useState<Violation | null>(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  
  const handleSendViolation = (violationData: Violation) => {
    setViolations([violationData, ...violations]);
  };

  const handleUpdateViolation = (violationId: string, newStatus: Violation["status"]) => {
    setViolations(violations.map(violation => 
      violation.id === violationId 
        ? { ...violation, status: newStatus }
        : violation
    ));
  };

  const handleViewDetails = (violation: Violation) => {
    setSelectedViolation(violation);
    setIsDetailsDialogOpen(true);
  };

  const getPageTitle = () => {
    if (user?.role === UserRole.RENTAL_COMPANY) return "Painel de Infrações";
    if (user && [UserRole.ADMIN, UserRole.MANAGER].includes(user.role as any)) return "Gestão de Infrações";
    return "Infrações de Trânsito";
  };

  const renderContent = () => {
    if (user?.role === UserRole.RENTAL_COMPANY) {
      return (
        <RentalCompanyViolationsView 
          violations={violations}
          onViewDetails={handleViewDetails}
        />
      );
    }

    if (user && [UserRole.ADMIN, UserRole.MANAGER].includes(user.role as any)) {
      return <AdminManagerViolationsView violations={violations} />;
    }

    return (
      <DriverViolationsView 
        violations={violations}
        userId={user?.id}
        onViewDetails={handleViewDetails}
      />
    );
  };

  const showSendViolationDialog = user?.role === UserRole.RENTAL_COMPANY || 
    (user && [UserRole.ADMIN, UserRole.MANAGER].includes(user.role as any));

  return (
    <ViolationsPageLayout 
      title={getPageTitle()}
      headerAction={showSendViolationDialog ? <SendViolationDialog onSendViolation={handleSendViolation} /> : undefined}
    >
      {renderContent()}
      
      <ViolationDetailsDialog
        violation={selectedViolation}
        isOpen={isDetailsDialogOpen}
        onClose={() => setIsDetailsDialogOpen(false)}
        onUpdateViolation={handleUpdateViolation}
      />
    </ViolationsPageLayout>
  );
};

export default ViolationsPage;
