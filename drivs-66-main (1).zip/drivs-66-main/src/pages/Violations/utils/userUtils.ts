
import { UserRole } from "@/types";

export const getUserName = (user: any) => {
  if (!user) return "Empresa Atual";
  
  switch (user.role) {
    case UserRole.RENTAL_COMPANY:
      return (user as any).companyName || (user as any).name || "Empresa Atual";
    case UserRole.DRIVER:
      return (user as any).fullName || "Motorista";
    case UserRole.MANAGER:
    case UserRole.INSPECTOR:
    case UserRole.ANALYST:
    case UserRole.ADMIN:
      return (user as any).name || "Usuário";
    default:
      return "Usuário";
  }
};
