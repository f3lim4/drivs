
export const validateViolationForm = (
  selectedDriver: string,
  selectedVehicle: string,
  location: string,
  description: string,
  points: string,
  value: string,
  date: string
) => {
  if (!selectedDriver || !selectedVehicle || !location || !description || !points || !value || !date) {
    return "Preencha todos os campos obrigatórios";
  }
  return null;
};
