
import { ViolationsSummaryCards } from "./ViolationsSummaryCards";
import { DriversViolationsTable } from "./DriversViolationsTable";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface AdminManagerViolationsViewProps {
  violations: Violation[];
}

export const AdminManagerViolationsView = ({ violations }: AdminManagerViolationsViewProps) => {
  return (
    <>
      <ViolationsSummaryCards violations={violations} />
      <DriversViolationsTable violations={violations} />
    </>
  );
};
