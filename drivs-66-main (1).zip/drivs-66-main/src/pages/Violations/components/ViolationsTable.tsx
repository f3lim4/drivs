
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { UserRole } from "@/types";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface ViolationsTableProps {
  violations: Violation[];
  userRole?: UserRole;
  onViewDetails: (violation: Violation) => void;
}

export const ViolationsTable = ({ violations, userRole, onViewDetails }: ViolationsTableProps) => {
  const getStatusBadge = (status: Violation["status"]) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pendente</Badge>;
      case "paid":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Pago</Badge>;
      case "contested":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Contestada</Badge>;
      case "resolved":
        return <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">Resolvida</Badge>;
    }
  };
  
  const getPointsBadge = (points: number) => {
    let colorClass = "";
    if (points <= 3) {
      colorClass = "bg-green-100 text-green-800 border-green-300";
    } else if (points <= 5) {
      colorClass = "bg-yellow-100 text-yellow-800 border-yellow-300";
    } else {
      colorClass = "bg-red-100 text-red-800 border-red-300";
    }
    
    return <Badge variant="outline" className={colorClass}>{points} pontos</Badge>;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  return (
    <div className="border rounded-md overflow-hidden">
      <Table>
        <TableCaption>Lista de infrações de trânsito</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Data</TableHead>
            <TableHead>Veículo</TableHead>
            {userRole !== UserRole.DRIVER && <TableHead>Motorista</TableHead>}
            <TableHead>Descrição</TableHead>
            <TableHead>Pontos</TableHead>
            <TableHead>Valor</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {violations.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-4 text-muted-foreground">
                Nenhuma infração encontrada
              </TableCell>
            </TableRow>
          ) : (
            violations.map((violation) => (
              <TableRow key={violation.id}>
                <TableCell>
                  {formatDate(violation.date)}
                </TableCell>
                <TableCell>
                  {violation.vehicleInfo.split(' - ')[0]}
                </TableCell>
                {userRole !== UserRole.DRIVER && (
                  <TableCell>{violation.driverName}</TableCell>
                )}
                <TableCell>
                  <div className="max-w-xs truncate">{violation.description}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {violation.location}
                  </div>
                </TableCell>
                <TableCell>{getPointsBadge(violation.points)}</TableCell>
                <TableCell>R$ {violation.value.toFixed(2)}</TableCell>
                <TableCell>{getStatusBadge(violation.status)}</TableCell>
                <TableCell className="text-right">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => onViewDetails(violation)}
                  >
                    Detalhes
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};
