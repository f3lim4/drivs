
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ViolationsSummaryStats } from "./ViolationsSummaryStats";
import { ViolationsTable } from "./ViolationsTable";
import { UserRole } from "@/types";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface DriverViolationsViewProps {
  violations: Violation[];
  userId?: string;
  onViewDetails: (violation: Violation) => void;
}

export const DriverViolationsView = ({ violations, userId, onViewDetails }: DriverViolationsViewProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredViolations = violations.filter(violation => {
    const matchesSearch = 
      violation.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      violation.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      violation.vehicleInfo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      violation.driverName.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesStatus = statusFilter === "all" || violation.status === statusFilter;
    const matchesUser = violation.driverId === userId;
      
    return matchesSearch && matchesStatus && matchesUser;
  });

  return (
    <>
      <ViolationsSummaryStats 
        violations={violations} 
        userRole={UserRole.DRIVER} 
        userId={userId} 
      />
      
      <Card>
        <CardHeader>
          <CardTitle>Minhas Infrações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Buscar infrações"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="w-full md:w-48">
              <Select
                value={statusFilter}
                onValueChange={setStatusFilter}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="pending">Pendentes</SelectItem>
                  <SelectItem value="paid">Pagas</SelectItem>
                  <SelectItem value="contested">Contestadas</SelectItem>
                  <SelectItem value="resolved">Resolvidas</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <ViolationsTable 
            violations={filteredViolations}
            userRole={UserRole.DRIVER}
            onViewDetails={onViewDetails}
          />
        </CardContent>
      </Card>
    </>
  );
};
