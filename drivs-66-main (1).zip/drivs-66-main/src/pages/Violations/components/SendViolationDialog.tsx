
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useRealContractsData } from "@/pages/Contracts/hooks/useRealContractsData";
import { ViolationDriverSelector } from "./ViolationDriverSelector";
import { ViolationFormFields } from "./ViolationFormFields";
import { ViolationFileUpload } from "./ViolationFileUpload";
import { getUserName } from "../utils/userUtils";
import { validateViolationForm } from "../utils/validationUtils";

interface SendViolationDialogProps {
  onSendViolation: (violationData: any) => void;
}

export const SendViolationDialog = ({ onSendViolation }: SendViolationDialogProps) => {
  const { user } = useAuth();
  const { contracts } = useRealContractsData();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState("");
  const [selectedVehicle, setSelectedVehicle] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [points, setPoints] = useState("");
  const [value, setValue] = useState("");
  const [date, setDate] = useState("");
  const [violationFile, setViolationFile] = useState<File | null>(null);

  // Obter contratos ativos da locadora
  const activeContracts = contracts.filter(contract => contract.status === "active");
  
  // Criar lista de motoristas com contratos ativos
  const driversWithContracts = activeContracts.map(contract => ({
    id: contract.driver_id,
    name: contract.driver_name,
    contractId: contract.id,
    vehicleId: contract.vehicle_id,
    vehicleInfo: contract.vehicle_info
  }));

  // Remover duplicatas de motoristas (um motorista pode ter múltiplos contratos)
  const uniqueDrivers = driversWithContracts.reduce((acc, current) => {
    const existingDriver = acc.find(driver => driver.id === current.id);
    if (!existingDriver) {
      acc.push(current);
    }
    return acc;
  }, [] as typeof driversWithContracts);

  // Obter veículos do motorista selecionado
  const getDriverVehicles = () => {
    if (!selectedDriver) return [];
    return driversWithContracts
      .filter(item => item.id === selectedDriver)
      .map(item => ({
        id: item.vehicleId,
        info: item.vehicleInfo
      }));
  };

  const handleDriverChange = (driverId: string) => {
    setSelectedDriver(driverId);
    setSelectedVehicle(""); // Limpar seleção de veículo ao trocar motorista
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationError = validateViolationForm(
      selectedDriver,
      selectedVehicle,
      location,
      description,
      points,
      value,
      date
    );

    if (validationError) {
      toast.error(validationError);
      return;
    }

    const selectedDriverData = uniqueDrivers.find(d => d.id === selectedDriver);
    const selectedVehicleData = getDriverVehicles().find(v => v.id === selectedVehicle);
    
    const violationData = {
      id: `v${Date.now()}`,
      contractId: selectedDriverData?.contractId || `c${Date.now()}`,
      vehicleId: selectedVehicle,
      vehicleInfo: selectedVehicleData?.info || "",
      driverId: selectedDriver,
      driverName: selectedDriverData?.name || "",
      companyId: user?.id || "current_company",
      companyName: getUserName(user),
      date,
      location,
      description,
      points: parseInt(points),
      value: parseFloat(value),
      status: "pending" as const,
      paymentDeadline: new Date(new Date(date).getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 dias após a data da infração
      violationFile: violationFile ? {
        name: violationFile.name,
        size: violationFile.size,
        type: violationFile.type
      } : null
    };

    onSendViolation(violationData);
    
    // Limpar formulário
    setSelectedDriver("");
    setSelectedVehicle("");
    setLocation("");
    setDescription("");
    setPoints("");
    setValue("");
    setDate("");
    setViolationFile(null);
    setIsOpen(false);
    
    toast.success("Infração enviada com sucesso!");
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Enviar Infração
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Enviar Infração para Motorista</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <ViolationDriverSelector
            uniqueDrivers={uniqueDrivers}
            selectedDriver={selectedDriver}
            selectedVehicle={selectedVehicle}
            onDriverChange={handleDriverChange}
            onVehicleChange={setSelectedVehicle}
            getDriverVehicles={getDriverVehicles}
          />

          <ViolationFormFields
            date={date}
            location={location}
            description={description}
            points={points}
            value={value}
            onDateChange={setDate}
            onLocationChange={setLocation}
            onDescriptionChange={setDescription}
            onPointsChange={setPoints}
            onValueChange={setValue}
          />

          <ViolationFileUpload
            violationFile={violationFile}
            onFileChange={setViolationFile}
          />

          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsOpen(false)}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={uniqueDrivers.length === 0}>
              Enviar Infração
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
