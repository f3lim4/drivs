
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Clock, CheckCircle, XCircle } from "lucide-react";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface RentalCompanyViolationsPanelProps {
  violations: Violation[];
}

export const RentalCompanyViolationsPanel = ({ violations }: RentalCompanyViolationsPanelProps) => {
  // Estatísticas gerais
  const totalViolations = violations.length;
  const pendingViolations = violations.filter(v => v.status === "pending");
  const paidViolations = violations.filter(v => v.status === "paid");
  
  // Infrações atrasadas (prazo de pagamento vencido)
  const overdueViolations = pendingViolations.filter(v => {
    const deadline = new Date(v.paymentDeadline);
    return deadline < new Date();
  });
  
  // Valores financeiros
  const totalValue = violations.reduce((sum, v) => sum + v.value, 0);
  const pendingValue = pendingViolations.reduce((sum, v) => sum + v.value, 0);
  const overdueValue = overdueViolations.reduce((sum, v) => sum + v.value, 0);
  const paidValue = paidViolations.reduce((sum, v) => sum + v.value, 0);
  
  // Pontos totais
  const totalPoints = violations.reduce((sum, v) => sum + v.points, 0);

  return (
    <div className="space-y-6">
      {/* Resumo Principal */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-red-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total de Infrações
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{totalViolations}</div>
            <p className="text-xs text-muted-foreground">
              R$ {totalValue.toFixed(2)} total
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Em Aberto
            </CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingViolations.length}</div>
            <p className="text-xs text-muted-foreground">
              R$ {pendingValue.toFixed(2)} pendentes
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-red-600">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Atrasadas
            </CardTitle>
            <XCircle className="h-4 w-4 text-red-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-700">{overdueViolations.length}</div>
            <p className="text-xs text-muted-foreground">
              R$ {overdueValue.toFixed(2)} em atraso
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pagas
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{paidViolations.length}</div>
            <p className="text-xs text-muted-foreground">
              R$ {paidValue.toFixed(2)} recebidos
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
