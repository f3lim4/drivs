
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface DriverContract {
  id: string;
  name: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
}

interface ViolationDriverSelectorProps {
  uniqueDrivers: DriverContract[];
  selectedDriver: string;
  selectedVehicle: string;
  onDriverChange: (driverId: string) => void;
  onVehicleChange: (vehicleId: string) => void;
  getDriverVehicles: () => { id: string; info: string }[];
}

export const ViolationDriverSelector = ({
  uniqueDrivers,
  selectedDriver,
  selectedVehicle,
  onDriverChange,
  onVehicleChange,
  getDriverVehicles
}: ViolationDriverSelectorProps) => {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div>
        <Label htmlFor="driver">Motorista com Contrato Ativo *</Label>
        <Select value={selectedDriver} onValueChange={onDriverChange}>
          <SelectTrigger>
            <SelectValue placeholder={
              uniqueDrivers.length === 0 
                ? "Nenhum motorista com contrato ativo" 
                : "Selecione o motorista"
            } />
          </SelectTrigger>
          <SelectContent>
            {uniqueDrivers.length > 0 ? (
              uniqueDrivers.map((driver) => (
                <SelectItem key={driver.id} value={driver.id}>
                  {driver.name}
                </SelectItem>
              ))
            ) : null}
          </SelectContent>
        </Select>
        {uniqueDrivers.length === 0 && (
          <p className="text-sm text-muted-foreground mt-1">
            Apenas motoristas com contratos ativos podem receber infrações.
          </p>
        )}
      </div>
      
      <div>
        <Label htmlFor="vehicle">Veículo *</Label>
        <Select 
          value={selectedVehicle} 
          onValueChange={onVehicleChange}
          disabled={!selectedDriver}
        >
          <SelectTrigger>
            <SelectValue placeholder={selectedDriver ? "Selecione o veículo" : "Selecione primeiro o motorista"} />
          </SelectTrigger>
          <SelectContent>
            {getDriverVehicles().map((vehicle) => (
              <SelectItem key={vehicle.id} value={vehicle.id}>
                {vehicle.info}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};
