
import { Label } from "@/components/ui/label";
import { Calendar, MapPin, User, Car, FileText } from "lucide-react";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface ViolationDetailsInfoProps {
  violation: Violation;
}

export const ViolationDetailsInfo = ({ violation }: ViolationDetailsInfoProps) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  return (
    <div className="space-y-4">
      {/* Informações do Veículo e Motorista */}
      <div className="space-y-4">
        <div>
          <Label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Car className="h-4 w-4" />
            Veículo
          </Label>
          <div className="mt-1 p-3 bg-gray-50 rounded-md">
            <div className="font-medium">{violation.vehicleInfo}</div>
          </div>
        </div>

        <div>
          <Label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <User className="h-4 w-4" />
            Motorista
          </Label>
          <div className="mt-1 p-3 bg-gray-50 rounded-md">
            <div className="font-medium">{violation.driverName}</div>
          </div>
        </div>
      </div>

      {/* Detalhes da Infração */}
      <div className="space-y-4">
        <div>
          <Label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Data da Infração
          </Label>
          <div className="mt-1">{formatDate(violation.date)}</div>
        </div>

        <div>
          <Label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Local
          </Label>
          <div className="mt-1 p-3 bg-gray-50 rounded-md">
            {violation.location}
          </div>
        </div>

        <div>
          <Label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Descrição
          </Label>
          <div className="mt-1 p-3 bg-gray-50 rounded-md">
            {violation.description}
          </div>
        </div>
      </div>
    </div>
  );
};
