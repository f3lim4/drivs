
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";
import { ViolationStatusInfo } from "./ViolationStatusInfo";
import { ViolationDetailsInfo } from "./ViolationDetailsInfo";
import { ViolationPaymentSection } from "./ViolationPaymentSection";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface ViolationDetailsDialogProps {
  violation: Violation | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateViolation: (violationId: string, status: Violation["status"]) => void;
}

export const ViolationDetailsDialog = ({
  violation,
  isOpen,
  onClose,
  onUpdateViolation,
}: ViolationDetailsDialogProps) => {
  if (!violation) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            Detalhes da Infração
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <ViolationStatusInfo violation={violation} />
          <ViolationDetailsInfo violation={violation} />
          <ViolationPaymentSection 
            violation={violation}
            onUpdateViolation={onUpdateViolation}
            onClose={onClose}
          />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
