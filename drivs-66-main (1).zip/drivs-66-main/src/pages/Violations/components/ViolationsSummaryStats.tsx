
import { Card, CardContent } from "@/components/ui/card";
import { UserRole } from "@/types";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface ViolationsSummaryStatsProps {
  violations: Violation[];
  userRole?: UserRole;
  userId?: string;
}

export const ViolationsSummaryStats = ({ violations, userRole, userId }: ViolationsSummaryStatsProps) => {
  const calculateTotals = () => {
    let userViolations = violations;
    
    // Filter by current user for drivers
    if (userRole === UserRole.DRIVER) {
      userViolations = userViolations.filter(v => v.driverId === userId);
    }
    
    // Calculate totals only for pending and contested violations
    const relevantViolations = userViolations.filter(v => 
      v.status === "pending" || v.status === "contested");
      
    const totalPoints = relevantViolations.reduce((sum, v) => sum + v.points, 0);
    const totalValue = relevantViolations.reduce((sum, v) => sum + v.value, 0);
    
    return { totalPoints, totalValue };
  };

  const totals = calculateTotals();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total em Pontos</p>
              <h3 className="text-2xl font-bold">
                {totals.totalPoints} pontos
              </h3>
            </div>
            <div className="bg-yellow-100 p-3 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-600">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total em Valores</p>
              <h3 className="text-2xl font-bold">R$ {totals.totalValue.toFixed(2)}</h3>
            </div>
            <div className="bg-red-100 p-3 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-600">
                <circle cx="12" cy="12" r="10" />
                <line x1="8" y1="12" x2="16" y2="12" />
              </svg>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
