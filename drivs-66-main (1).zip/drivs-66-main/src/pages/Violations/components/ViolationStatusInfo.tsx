
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Calendar } from "lucide-react";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface ViolationStatusInfoProps {
  violation: Violation;
}

export const ViolationStatusInfo = ({ violation }: ViolationStatusInfoProps) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  const getStatusBadge = (status: Violation["status"]) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pendente</Badge>;
      case "paid":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Pago</Badge>;
      case "contested":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Contestada</Badge>;
      case "resolved":
        return <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">Resolvida</Badge>;
    }
  };

  const getPointsBadge = (points: number) => {
    let colorClass = "";
    if (points <= 3) {
      colorClass = "bg-green-100 text-green-800 border-green-300";
    } else if (points <= 5) {
      colorClass = "bg-yellow-100 text-yellow-800 border-yellow-300";
    } else {
      colorClass = "bg-red-100 text-red-800 border-red-300";
    }
    
    return <Badge variant="outline" className={colorClass}>{points} pontos</Badge>;
  };

  const isOverdue = violation.status === "pending" && new Date(violation.paymentDeadline) < new Date();

  return (
    <div className="space-y-6">
      {/* Status e Informações Básicas */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Status</Label>
          <div className="mt-1">
            {getStatusBadge(violation.status)}
            {isOverdue && (
              <Badge variant="outline" className="ml-2 bg-red-100 text-red-800 border-red-300">
                Em Atraso
              </Badge>
            )}
          </div>
        </div>
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Pontos</Label>
          <div className="mt-1">{getPointsBadge(violation.points)}</div>
        </div>
      </div>

      {/* Valor e Prazo */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Valor da Multa</Label>
          <div className="mt-1 text-lg font-semibold text-red-600">
            R$ {violation.value.toFixed(2)}
          </div>
        </div>
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Prazo de Pagamento</Label>
          <div className="mt-1 flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className={isOverdue ? "text-red-600 font-medium" : ""}>
              {formatDate(violation.paymentDeadline)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
