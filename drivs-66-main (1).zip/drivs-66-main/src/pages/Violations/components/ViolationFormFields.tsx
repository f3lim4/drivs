
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface ViolationFormFieldsProps {
  date: string;
  location: string;
  description: string;
  points: string;
  value: string;
  onDateChange: (date: string) => void;
  onLocationChange: (location: string) => void;
  onDescriptionChange: (description: string) => void;
  onPointsChange: (points: string) => void;
  onValueChange: (value: string) => void;
}

export const ViolationFormFields = ({
  date,
  location,
  description,
  points,
  value,
  onDateChange,
  onLocationChange,
  onDescriptionChange,
  onPointsChange,
  onValueChange
}: ViolationFormFieldsProps) => {
  return (
    <>
      <div>
        <Label htmlFor="date">Data da Infração *</Label>
        <Input
          id="date"
          type="date"
          value={date}
          onChange={(e) => onDateChange(e.target.value)}
          required
        />
      </div>

      <div>
        <Label htmlFor="location">Local da Infração *</Label>
        <Input
          id="location"
          placeholder="Ex: Av. Paulista, 1000, São Paulo"
          value={location}
          onChange={(e) => onLocationChange(e.target.value)}
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Descrição da Infração *</Label>
        <Textarea
          id="description"
          placeholder="Descreva a infração cometida"
          value={description}
          onChange={(e) => onDescriptionChange(e.target.value)}
          required
          rows={3}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="points">Pontos na CNH *</Label>
          <Input
            id="points"
            type="number"
            min="1"
            max="20"
            placeholder="Ex: 4"
            value={points}
            onChange={(e) => onPointsChange(e.target.value)}
            required
          />
        </div>
        
        <div>
          <Label htmlFor="value">Valor da Multa (R$) *</Label>
          <Input
            id="value"
            type="number"
            step="0.01"
            min="0"
            placeholder="Ex: 195.23"
            value={value}
            onChange={(e) => onValueChange(e.target.value)}
            required
          />
        </div>
      </div>
    </>
  );
};
