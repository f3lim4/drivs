
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload } from "lucide-react";
import { toast } from "sonner";

interface ViolationFileUploadProps {
  violationFile: File | null;
  onFileChange: (file: File | null) => void;
}

export const ViolationFileUpload = ({ violationFile, onFileChange }: ViolationFileUploadProps) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Verificar tipo de arquivo (permitir apenas PDF, JPG, PNG)
      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedTypes.includes(file.type)) {
        toast.error("Apenas arquivos PDF, JPG ou PNG são permitidos");
        return;
      }
      
      // Verificar tamanho (máximo 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error("O arquivo deve ter no máximo 5MB");
        return;
      }
      
      onFileChange(file);
      toast.success("Arquivo selecionado com sucesso!");
    }
  };

  return (
    <div>
      <Label htmlFor="violationFile">Arquivo da Multa (PDF, JPG, PNG - máx. 5MB)</Label>
      <div className="flex items-center gap-2">
        <Input
          id="violationFile"
          type="file"
          onChange={handleFileChange}
          accept=".pdf,.jpg,.jpeg,.png"
          className="hidden"
        />
        <Button
          type="button"
          variant="outline"
          onClick={() => document.getElementById('violationFile')?.click()}
          className="flex items-center gap-2"
        >
          <Upload className="h-4 w-4" />
          {violationFile ? "Trocar arquivo" : "Selecionar arquivo"}
        </Button>
        {violationFile && (
          <span className="text-sm text-muted-foreground">
            {violationFile.name} ({(violationFile.size / 1024 / 1024).toFixed(2)} MB)
          </span>
        )}
      </div>
    </div>
  );
};
