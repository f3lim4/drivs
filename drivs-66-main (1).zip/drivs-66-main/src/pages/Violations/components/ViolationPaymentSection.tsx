
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface ViolationPaymentSectionProps {
  violation: Violation;
  onUpdateViolation: (violationId: string, status: Violation["status"]) => void;
  onClose: () => void;
}

export const ViolationPaymentSection = ({ 
  violation, 
  onUpdateViolation, 
  onClose 
}: ViolationPaymentSectionProps) => {
  const [isMarkingAsPaid, setIsMarkingAsPaid] = useState(false);
  const [paymentProof, setPaymentProof] = useState<File | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setPaymentProof(file);
    }
  };

  const handleMarkAsPaid = () => {
    if (!paymentProof) {
      toast({
        title: "Comprovante necessário",
        description: "Por favor, anexe o comprovante de pagamento.",
        variant: "destructive",
      });
      return;
    }

    onUpdateViolation(violation.id, "paid");
    setIsMarkingAsPaid(false);
    setPaymentProof(null);
    
    toast({
      title: "Pagamento registrado",
      description: "A infração foi marcada como paga com sucesso.",
    });
    
    onClose();
  };

  if (violation.status !== "pending") {
    return null;
  }

  return (
    <div className="border-t pt-6">
      <h4 className="font-medium mb-4">Registrar Pagamento</h4>
      
      {!isMarkingAsPaid ? (
        <Button 
          onClick={() => setIsMarkingAsPaid(true)}
          className="w-full"
        >
          Marcar como Pago
        </Button>
      ) : (
        <div className="space-y-4">
          <div>
            <Label htmlFor="payment-proof" className="text-sm font-medium">
              Comprovante de Pagamento *
            </Label>
            <div className="mt-1">
              <Input
                id="payment-proof"
                type="file"
                accept="image/*,.pdf"
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              {paymentProof && (
                <div className="mt-2 text-sm text-green-600 flex items-center gap-2">
                  <Upload className="h-4 w-4" />
                  Arquivo selecionado: {paymentProof.name}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={handleMarkAsPaid}
              disabled={!paymentProof}
              className="flex-1"
            >
              Confirmar Pagamento
            </Button>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsMarkingAsPaid(false);
                setPaymentProof(null);
              }}
              className="flex-1"
            >
              Cancelar
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
