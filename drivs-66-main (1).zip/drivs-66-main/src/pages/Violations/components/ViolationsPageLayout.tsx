
import { ReactNode } from "react";

interface ViolationsPageLayoutProps {
  title: string;
  children: ReactNode;
  headerAction?: ReactNode;
}

export const ViolationsPageLayout = ({ title, children, headerAction }: ViolationsPageLayoutProps) => {
  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{title}</h1>
        {headerAction}
      </div>
      {children}
    </div>
  );
};
