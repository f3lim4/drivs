
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Clock, CheckCircle, XCircle, DollarSign } from "lucide-react";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface ViolationsSummaryCardsProps {
  violations: Violation[];
}

export const ViolationsSummaryCards = ({ violations }: ViolationsSummaryCardsProps) => {
  const totalViolations = violations.length;
  const pendingViolations = violations.filter(v => v.status === "pending").length;
  const paidViolations = violations.filter(v => v.status === "paid").length;
  const contestedViolations = violations.filter(v => v.status === "contested").length;
  const resolvedViolations = violations.filter(v => v.status === "resolved").length;
  
  const totalValue = violations.reduce((sum, v) => sum + v.value, 0);
  const pendingValue = violations.filter(v => v.status === "pending").reduce((sum, v) => sum + v.value, 0);
  const totalPoints = violations.reduce((sum, v) => sum + v.points, 0);
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="border-l-4 border-l-red-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Total de Infrações
          </CardTitle>
          <AlertTriangle className="h-4 w-4 text-red-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-600">{totalViolations}</div>
          <p className="text-xs text-muted-foreground">
            {totalPoints} pontos acumulados
          </p>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-yellow-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Pendentes
          </CardTitle>
          <Clock className="h-4 w-4 text-yellow-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-yellow-600">{pendingViolations}</div>
          <p className="text-xs text-muted-foreground">
            R$ {pendingValue.toFixed(2)} em aberto
          </p>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-green-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Pagas
          </CardTitle>
          <CheckCircle className="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-600">{paidViolations}</div>
          <p className="text-xs text-muted-foreground">
            {resolvedViolations} resolvidas
          </p>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-blue-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Valor Total
          </CardTitle>
          <DollarSign className="h-4 w-4 text-blue-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-blue-600">R$ {totalValue.toFixed(2)}</div>
          <p className="text-xs text-muted-foreground">
            {contestedViolations} contestadas
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
