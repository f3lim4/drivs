
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { User, Eye } from "lucide-react";

interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

interface DriversViolationsTableProps {
  violations: Violation[];
}

interface DriverStats {
  driverId: string;
  driverName: string;
  totalViolations: number;
  totalPoints: number;
  totalValue: number;
  pendingViolations: number;
  paidViolations: number;
  contestedViolations: number;
  lastViolationDate: string;
  riskLevel: "low" | "medium" | "high";
}

export const DriversViolationsTable = ({ violations }: DriversViolationsTableProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [riskFilter, setRiskFilter] = useState<string>("all");

  // Agrupa infrações por motorista
  const driversStats: DriverStats[] = violations.reduce((acc: DriverStats[], violation) => {
    const existingDriver = acc.find(d => d.driverId === violation.driverId);
    
    if (existingDriver) {
      existingDriver.totalViolations += 1;
      existingDriver.totalPoints += violation.points;
      existingDriver.totalValue += violation.value;
      
      if (violation.status === "pending") existingDriver.pendingViolations += 1;
      if (violation.status === "paid") existingDriver.paidViolations += 1;
      if (violation.status === "contested") existingDriver.contestedViolations += 1;
      
      // Atualiza última infração se for mais recente
      if (new Date(violation.date) > new Date(existingDriver.lastViolationDate)) {
        existingDriver.lastViolationDate = violation.date;
      }
    } else {
      const newDriver: DriverStats = {
        driverId: violation.driverId,
        driverName: violation.driverName,
        totalViolations: 1,
        totalPoints: violation.points,
        totalValue: violation.value,
        pendingViolations: violation.status === "pending" ? 1 : 0,
        paidViolations: violation.status === "paid" ? 1 : 0,
        contestedViolations: violation.status === "contested" ? 1 : 0,
        lastViolationDate: violation.date,
        riskLevel: "low"
      };
      acc.push(newDriver);
    }
    
    return acc;
  }, []);

  // Calcula nível de risco
  driversStats.forEach(driver => {
    if (driver.totalPoints >= 15 || driver.pendingViolations >= 3) {
      driver.riskLevel = "high";
    } else if (driver.totalPoints >= 8 || driver.pendingViolations >= 2) {
      driver.riskLevel = "medium";
    } else {
      driver.riskLevel = "low";
    }
  });

  // Filtra motoristas
  const filteredDrivers = driversStats.filter(driver => {
    const matchesSearch = driver.driverName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRisk = riskFilter === "all" || driver.riskLevel === riskFilter;
    return matchesSearch && matchesRisk;
  });

  const getRiskBadge = (riskLevel: string) => {
    switch (riskLevel) {
      case "high":
        return <Badge className="bg-red-100 text-red-800 border-red-300">Alto Risco</Badge>;
      case "medium":
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">Médio Risco</Badge>;
      case "low":
        return <Badge className="bg-green-100 text-green-800 border-green-300">Baixo Risco</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 border-gray-300">N/A</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="h-5 w-5" />
          Análise por Motorista
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <Input
              placeholder="Buscar motorista..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="w-full md:w-48">
            <Select value={riskFilter} onValueChange={setRiskFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por risco" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="high">Alto Risco</SelectItem>
                <SelectItem value="medium">Médio Risco</SelectItem>
                <SelectItem value="low">Baixo Risco</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="border rounded-md overflow-hidden">
          <Table>
            <TableCaption>Resumo de infrações por motorista</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Motorista</TableHead>
                <TableHead className="text-center">Total</TableHead>
                <TableHead className="text-center">Pontos</TableHead>
                <TableHead className="text-center">Pendentes</TableHead>
                <TableHead className="text-right">Valor Total</TableHead>
                <TableHead>Última Infração</TableHead>
                <TableHead>Nível de Risco</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDrivers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-4 text-muted-foreground">
                    Nenhum motorista encontrado
                  </TableCell>
                </TableRow>
              ) : (
                filteredDrivers.map((driver) => (
                  <TableRow key={driver.driverId}>
                    <TableCell className="font-medium">{driver.driverName}</TableCell>
                    <TableCell className="text-center">{driver.totalViolations}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline" className={
                        driver.totalPoints <= 7 ? "bg-green-100 text-green-800 border-green-300" :
                        driver.totalPoints <= 14 ? "bg-yellow-100 text-yellow-800 border-yellow-300" :
                        "bg-red-100 text-red-800 border-red-300"
                      }>
                        {driver.totalPoints}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      {driver.pendingViolations > 0 ? (
                        <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">
                          {driver.pendingViolations}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">0</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      R$ {driver.totalValue.toFixed(2)}
                    </TableCell>
                    <TableCell>{formatDate(driver.lastViolationDate)}</TableCell>
                    <TableCell>{getRiskBadge(driver.riskLevel)}</TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
