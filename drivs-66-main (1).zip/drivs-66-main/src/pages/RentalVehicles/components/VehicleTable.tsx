
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Edit, Trash2, User, Eye, Building } from "lucide-react";
import { toast } from "sonner";

interface RentalVehicle {
  id: string;
  brand: string;
  model: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold";
  documentExpiry: string;
  vehicleValue: number;
  isFinanced: boolean;
  monthlyInstallment?: number;
  monthlyInsurance: number;
  monthlyTracker: number;
  images: string[];
  depositValue: number;
  weeklyValue: number;
  vehicleType: string;
  mileage?: number;
  fuelType?: string;
  transmissionType?: string;
  ipvaValue?: number;
  licensingStatus?: "up_to_date" | "overdue";
  kmLimit?: number;
  kmType?: "limited" | "unlimited";
  maintenanceResponsibility?: "rental_company" | "fifty_fifty" | "driver";
  description?: string;
  allowReservation?: boolean;
  company_name?: string;
  driverInfo?: {
    id: string;
    name: string;
    phone: string;
    contractStartDate: string;
  };
}

interface VehicleTableProps {
  vehicles: RentalVehicle[];
  onView?: (vehicle: RentalVehicle) => void;
  onEdit: (vehicle: RentalVehicle) => void;
  onDelete?: (vehicle: RentalVehicle) => void;
  showCompanyColumn?: boolean;
}

export const VehicleTable = ({ 
  vehicles, 
  onView, 
  onEdit, 
  onDelete,
  showCompanyColumn = false
}: VehicleTableProps) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Função para obter badge de status
  const getStatusBadge = (status: RentalVehicle["status"]) => {
    switch (status) {
      case "available":
        return <Badge className="bg-green-100 text-green-800 border-green-300">Disponível</Badge>;
      case "rented":
        return <Badge className="bg-blue-100 text-blue-800 border-blue-300">Alugado</Badge>;
      case "maintenance":
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">Manutenção</Badge>;
      case "stopped":
        return <Badge className="bg-red-100 text-red-800 border-red-300">Parado</Badge>;
      case "damaged":
        return <Badge className="bg-orange-100 text-orange-800 border-orange-300">Sinistrado</Badge>;
      case "sold":
        return <Badge className="bg-gray-100 text-gray-800 border-gray-300">Vendido</Badge>;
    }
  };

  // Função para obter badge de tipo de KM
  const getKmTypeBadge = (kmType?: "limited" | "unlimited", kmLimit?: number) => {
    if (!kmType) return <Badge variant="secondary">-</Badge>;
    
    switch (kmType) {
      case "limited":
        return (
          <div>
            <Badge className="bg-orange-100 text-orange-800 border-orange-300">Limitado</Badge>
            {kmLimit && <p className="text-xs text-muted-foreground mt-1">{kmLimit} km/mês</p>}
          </div>
        );
      case "unlimited":
        return <Badge className="bg-green-100 text-green-800 border-green-300">Livre</Badge>;
    }
  };

  const handleView = (vehicle: RentalVehicle) => {
    if (onView) {
      onView(vehicle);
    } else {
      toast.info(`Visualizar veículo: ${vehicle.brand} ${vehicle.model} (${vehicle.plate})`);
    }
  };

  const handleDelete = (vehicle: RentalVehicle) => {
    if (onDelete) {
      onDelete(vehicle);
    } else {
      toast.info(`Excluir veículo: ${vehicle.brand} ${vehicle.model} (${vehicle.plate})`);
    }
  };

  // Detectar automaticamente se deve mostrar a coluna da empresa
  const shouldShowCompanyColumn = showCompanyColumn || vehicles.some(v => v.company_name);

  return (
    <div className="border rounded-md">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Marca/Modelo</TableHead>
            <TableHead>Placa</TableHead>
            {shouldShowCompanyColumn && <TableHead>Locadora</TableHead>}
            <TableHead>Status/Motorista</TableHead>
            <TableHead>Transmissão</TableHead>
            <TableHead>Valor Semanal</TableHead>
            <TableHead>Tipo de KM</TableHead>
            <TableHead>Reserva</TableHead>
            <TableHead>Financiado</TableHead>
            <TableHead className="text-right">Ações</TableHead>
            <TableHead className="text-right">Visualizar</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {vehicles.length === 0 ? (
            <TableRow>
              <TableCell colSpan={shouldShowCompanyColumn ? 11 : 10} className="text-center py-8 text-muted-foreground">
                Nenhum veículo encontrado
              </TableCell>
            </TableRow>
          ) : (
            vehicles.map((vehicle) => (
              <TableRow key={vehicle.id}>
                <TableCell>
                  <div>
                    <p className="font-medium">{vehicle.brand}</p>
                    <p className="text-sm text-muted-foreground">{vehicle.model}</p>
                    <p className="text-xs text-muted-foreground">{vehicle.year} • {vehicle.color}</p>
                  </div>
                </TableCell>
                <TableCell className="font-mono">{vehicle.plate}</TableCell>
                {shouldShowCompanyColumn && (
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Building className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">
                        {vehicle.company_name || 'Sem Locadora'}
                      </span>
                    </div>
                  </TableCell>
                )}
                <TableCell>
                  <div className="space-y-1">
                    {getStatusBadge(vehicle.status)}
                    {vehicle.status === "rented" && vehicle.driverInfo && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <User className="h-3 w-3" />
                        <span>{vehicle.driverInfo.name}</span>
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{vehicle.transmissionType || "-"}</Badge>
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{formatCurrency(vehicle.weeklyValue)}</p>
                    <p className="text-xs text-muted-foreground">
                      Caução: {formatCurrency(vehicle.depositValue)}
                    </p>
                  </div>
                </TableCell>
                <TableCell>{getKmTypeBadge(vehicle.kmType, vehicle.kmLimit)}</TableCell>
                <TableCell>
                  <Badge variant={vehicle.allowReservation ? "default" : "secondary"}>
                    {vehicle.allowReservation ? "Permitida" : "Não permitida"}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div>
                    <Badge variant={vehicle.isFinanced ? "default" : "secondary"}>
                      {vehicle.isFinanced ? "Sim" : "Não"}
                    </Badge>
                    {vehicle.isFinanced && vehicle.monthlyInstallment && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatCurrency(vehicle.monthlyInstallment)}/mês
                      </p>
                    )}
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex gap-2 justify-end">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onEdit(vehicle)}
                      disabled={vehicle.status === "rented"}
                      className={vehicle.status === "rented" ? "opacity-50 cursor-not-allowed" : ""}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDelete(vehicle)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <Button 
                    variant="ghost"
                    size="icon"
                    title="Visualizar"
                    onClick={() => handleView(vehicle)}
                  >
                    <Eye className="h-5 w-5" />
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};
