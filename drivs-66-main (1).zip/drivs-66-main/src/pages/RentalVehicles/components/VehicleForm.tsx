import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { X, Plus, Image, Upload, Car, DollarSign, Camera } from "lucide-react";

interface RentalVehicle {
  id: string;
  brand: string;
  model: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold";
  documentExpiry: string;
  vehicleValue: number;
  isFinanced: boolean;
  monthlyInstallment?: number;
  monthlyInsurance: number;
  monthlyTracker: number;
  images: string[];
  depositValue: number;
  weeklyValue: number;
  vehicleType: string;
  mileage?: number;
  fuelType?: string;
  transmissionType?: string;
  ipvaValue?: number;
  licensingStatus?: "up_to_date" | "overdue";
  kmLimit?: number;
  kmType?: "limited" | "unlimited";
  maintenanceResponsibility?: "rental_company" | "fifty_fifty" | "driver";
  description?: string;
  allowReservation?: boolean;
}

interface VehicleFormProps {
  vehicle?: RentalVehicle | null;
  onSubmit: (vehicleData: Omit<RentalVehicle, 'id'>) => void;
  onCancel: () => void;
}

export const VehicleForm = ({ vehicle, onSubmit, onCancel }: VehicleFormProps) => {
  const [formData, setFormData] = useState({
    brand: "",
    model: "",
    plate: "",
    year: new Date().getFullYear(),
    color: "",
    status: "available" as "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold",
    documentExpiry: "",
    vehicleValue: 0,
    isFinanced: false,
    monthlyInstallment: 0,
    monthlyInsurance: 0,
    monthlyTracker: 0,
    images: [] as string[],
    depositValue: 0,
    weeklyValue: 0,
    vehicleType: "",
    mileage: undefined as number | undefined,
    fuelType: "",
    transmissionType: "",
    ipvaValue: 0,
    licensingStatus: "up_to_date" as "up_to_date" | "overdue",
    kmLimit: undefined as number | undefined,
    kmType: "limited" as "limited" | "unlimited",
    maintenanceResponsibility: "rental_company" as "rental_company" | "fifty_fifty" | "driver",
    description: "",
    allowReservation: true
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Tipos de veículo disponíveis
  const vehicleTypes = [
    "Sedan",
    "Hatch",
    "SUV",
    "Pickup",
    "Van",
    "Conversível",
    "Coupe",
    "Wagon"
  ];

  const fuelTypes = [
    "Gasolina",
    "Etanol",
    "Flex",
    "Diesel",
    "GNV",
    "Elétrico",
    "Híbrido"
  ];

  const transmissionTypes = [
    "Manual",
    "Automática",
    "CVT",
    "Semi-automática"
  ];

  // Função para calcular o mês de vencimento do licenciamento baseado na placa
  const getLicensingDueMonth = (plate: string) => {
    if (!plate) return "";
    
    const lastDigit = plate.slice(-1);
    const months = {
      '1': 'julho',
      '2': 'julho',
      '3': 'agosto',
      '4': 'agosto',
      '5': 'setembro',
      '6': 'setembro',
      '7': 'outubro',
      '8': 'outubro',
      '9': 'novembro',
      '0': 'dezembro'
    };
    
    return months[lastDigit as keyof typeof months] || "";
  };

  // Função para calcular IPVA (4% do valor do veículo)
  const calculateIPVA = (vehicleValue: number) => {
    return vehicleValue * 0.04;
  };

  // Preencher formulário se estiver editando
  useEffect(() => {
    if (vehicle) {
      setFormData({
        brand: vehicle.brand,
        model: vehicle.model,
        plate: vehicle.plate,
        year: vehicle.year,
        color: vehicle.color,
        status: vehicle.status,
        documentExpiry: vehicle.documentExpiry,
        vehicleValue: vehicle.vehicleValue,
        isFinanced: vehicle.isFinanced,
        monthlyInstallment: vehicle.monthlyInstallment || 0,
        monthlyInsurance: vehicle.monthlyInsurance,
        monthlyTracker: vehicle.monthlyTracker,
        images: vehicle.images || [],
        depositValue: vehicle.depositValue || 0,
        weeklyValue: vehicle.weeklyValue || 0,
        vehicleType: vehicle.vehicleType || "",
        mileage: vehicle.mileage,
        fuelType: vehicle.fuelType || "",
        transmissionType: vehicle.transmissionType || "",
        ipvaValue: vehicle.ipvaValue || calculateIPVA(vehicle.vehicleValue),
        licensingStatus: vehicle.licensingStatus || "up_to_date",
        kmLimit: vehicle.kmLimit,
        kmType: vehicle.kmType || "limited",
        maintenanceResponsibility: vehicle.maintenanceResponsibility || "rental_company",
        description: vehicle.description || "",
        allowReservation: vehicle.allowReservation ?? true
      });
    }
  }, [vehicle]);

  // Atualizar IPVA automaticamente quando o valor do veículo mudar
  useEffect(() => {
    if (formData.vehicleValue > 0) {
      const calculatedIPVA = calculateIPVA(formData.vehicleValue);
      setFormData(prev => ({ ...prev, ipvaValue: calculatedIPVA }));
    }
  }, [formData.vehicleValue]);

  // Validar formulário
  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.brand.trim()) newErrors.brand = "Marca é obrigatória";
    if (!formData.model.trim()) newErrors.model = "Modelo é obrigatório";
    if (!formData.plate.trim()) newErrors.plate = "Placa é obrigatória";
    if (formData.year < 1990 || formData.year > new Date().getFullYear() + 1) {
      newErrors.year = "Ano inválido";
    }
    if (!formData.color.trim()) newErrors.color = "Cor é obrigatória";
    if (formData.vehicleValue <= 0) newErrors.vehicleValue = "Valor do veículo deve ser maior que zero";
    if (formData.monthlyInsurance <= 0) newErrors.monthlyInsurance = "Valor do seguro deve ser maior que zero";
    if (formData.monthlyTracker <= 0) newErrors.monthlyTracker = "Valor do rastreador deve ser maior que zero";
    if (formData.depositValue <= 0) newErrors.depositValue = "Valor da caução deve ser maior que zero";
    if (formData.weeklyValue <= 0) newErrors.weeklyValue = "Valor semanal deve ser maior que zero";
    if (!formData.vehicleType.trim()) newErrors.vehicleType = "Tipo de veículo é obrigatório";
    if (!formData.fuelType.trim()) newErrors.fuelType = "Tipo de combustível é obrigatório";
    if (!formData.transmissionType.trim()) newErrors.transmissionType = "Tipo de transmissão é obrigatório";
    if (formData.ipvaValue <= 0) newErrors.ipvaValue = "Valor do IPVA deve ser maior que zero";
    
    if (formData.isFinanced && formData.monthlyInstallment <= 0) {
      newErrors.monthlyInstallment = "Valor da parcela deve ser maior que zero";
    }

    if (formData.mileage !== undefined && formData.mileage < 0) {
      newErrors.mileage = "Quilometragem não pode ser negativa";
    }

    if (formData.kmType === "limited" && (!formData.kmLimit || formData.kmLimit <= 0)) {
      newErrors.kmLimit = "Limite de quilometragem deve ser maior que zero";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      const submitData = { ...formData };
      if (!formData.isFinanced) {
        delete submitData.monthlyInstallment;
      }
      if (formData.kmType === "unlimited") {
        delete submitData.kmLimit;
      }
      onSubmit(submitData);
    }
  };

  // Handle input change
  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: "" }));
    }
  };

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && formData.images.length < 5) {
      Array.from(files).forEach((file) => {
        if (formData.images.length < 5) {
          const reader = new FileReader();
          reader.onload = (e) => {
            const result = e.target?.result as string;
            setFormData(prev => ({
              ...prev,
              images: [...prev.images, result]
            }));
          };
          reader.readAsDataURL(file);
        }
      });
    }
  };

  const handleRemoveImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Tabs defaultValue="vehicle" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="vehicle" className="flex items-center gap-2">
            <Car className="h-4 w-4" />
            Informações do Veículo
          </TabsTrigger>
          <TabsTrigger value="rental" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            Informações de Aluguel
          </TabsTrigger>
          <TabsTrigger value="photos" className="flex items-center gap-2">
            <Camera className="h-4 w-4" />
            Fotos
          </TabsTrigger>
        </TabsList>

        <TabsContent value="vehicle" className="space-y-6 mt-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Dados Básicos do Veículo</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Marca */}
                <div className="space-y-2">
                  <Label htmlFor="brand">Marca *</Label>
                  <Input
                    id="brand"
                    value={formData.brand}
                    onChange={(e) => handleInputChange("brand", e.target.value)}
                    placeholder="Ex: Toyota"
                    className={errors.brand ? "border-red-500" : ""}
                  />
                  {errors.brand && <p className="text-sm text-red-500">{errors.brand}</p>}
                </div>

                {/* Modelo */}
                <div className="space-y-2">
                  <Label htmlFor="model">Modelo *</Label>
                  <Input
                    id="model"
                    value={formData.model}
                    onChange={(e) => handleInputChange("model", e.target.value)}
                    placeholder="Ex: Corolla"
                    className={errors.model ? "border-red-500" : ""}
                  />
                  {errors.model && <p className="text-sm text-red-500">{errors.model}</p>}
                </div>

                {/* Placa */}
                <div className="space-y-2">
                  <Label htmlFor="plate">Placa *</Label>
                  <Input
                    id="plate"
                    value={formData.plate}
                    onChange={(e) => handleInputChange("plate", e.target.value.toUpperCase())}
                    placeholder="Ex: ABC-1234"
                    className={errors.plate ? "border-red-500" : ""}
                  />
                  {errors.plate && <p className="text-sm text-red-500">{errors.plate}</p>}
                  {formData.plate && (
                    <p className="text-xs text-muted-foreground">
                      Vencimento do licenciamento: {getLicensingDueMonth(formData.plate)}
                    </p>
                  )}
                </div>

                {/* Ano */}
                <div className="space-y-2">
                  <Label htmlFor="year">Ano *</Label>
                  <Input
                    id="year"
                    type="number"
                    value={formData.year}
                    onChange={(e) => handleInputChange("year", parseInt(e.target.value))}
                    min="1990"
                    max={new Date().getFullYear() + 1}
                    className={errors.year ? "border-red-500" : ""}
                  />
                  {errors.year && <p className="text-sm text-red-500">{errors.year}</p>}
                </div>

                {/* Cor */}
                <div className="space-y-2">
                  <Label htmlFor="color">Cor *</Label>
                  <Input
                    id="color"
                    value={formData.color}
                    onChange={(e) => handleInputChange("color", e.target.value)}
                    placeholder="Ex: Prata"
                    className={errors.color ? "border-red-500" : ""}
                  />
                  {errors.color && <p className="text-sm text-red-500">{errors.color}</p>}
                </div>

                {/* Tipo de Veículo */}
                <div className="space-y-2">
                  <Label htmlFor="vehicleType">Tipo de Veículo *</Label>
                  <Select value={formData.vehicleType} onValueChange={(value) => handleInputChange("vehicleType", value)}>
                    <SelectTrigger className={errors.vehicleType ? "border-red-500" : ""}>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {vehicleTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.vehicleType && <p className="text-sm text-red-500">{errors.vehicleType}</p>}
                </div>

                {/* Tipo de Combustível */}
                <div className="space-y-2">
                  <Label htmlFor="fuelType">Tipo de Combustível *</Label>
                  <Select value={formData.fuelType} onValueChange={(value) => handleInputChange("fuelType", value)}>
                    <SelectTrigger className={errors.fuelType ? "border-red-500" : ""}>
                      <SelectValue placeholder="Selecione o combustível" />
                    </SelectTrigger>
                    <SelectContent>
                      {fuelTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.fuelType && <p className="text-sm text-red-500">{errors.fuelType}</p>}
                </div>

                {/* Tipo de Transmissão */}
                <div className="space-y-2">
                  <Label htmlFor="transmissionType">Tipo de Transmissão *</Label>
                  <Select value={formData.transmissionType} onValueChange={(value) => handleInputChange("transmissionType", value)}>
                    <SelectTrigger className={errors.transmissionType ? "border-red-500" : ""}>
                      <SelectValue placeholder="Selecione a transmissão" />
                    </SelectTrigger>
                    <SelectContent>
                      {transmissionTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.transmissionType && <p className="text-sm text-red-500">{errors.transmissionType}</p>}
                </div>

                {/* Status */}
                <div className="space-y-2">
                  <Label htmlFor="status">Situação</Label>
                  <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Disponível</SelectItem>
                      <SelectItem value="rented">Alugado</SelectItem>
                      <SelectItem value="maintenance">Em Manutenção</SelectItem>
                      <SelectItem value="stopped">Parado</SelectItem>
                      <SelectItem value="damaged">Sinistrado</SelectItem>
                      <SelectItem value="sold">Vendido</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Quilometragem */}
                <div className="space-y-2">
                  <Label htmlFor="mileage">Quilometragem (opcional)</Label>
                  <Input
                    id="mileage"
                    type="number"
                    value={formData.mileage || ""}
                    onChange={(e) => handleInputChange("mileage", e.target.value ? parseInt(e.target.value) : undefined)}
                    placeholder="Ex: 15000"
                    min="0"
                    className={errors.mileage ? "border-red-500" : ""}
                  />
                  {errors.mileage && <p className="text-sm text-red-500">{errors.mileage}</p>}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Valores e Documentação</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Valor do Veículo */}
                <div className="space-y-2">
                  <Label htmlFor="vehicleValue">Valor do Veículo (R$) *</Label>
                  <Input
                    id="vehicleValue"
                    type="number"
                    value={formData.vehicleValue}
                    onChange={(e) => handleInputChange("vehicleValue", parseFloat(e.target.value) || 0)}
                    placeholder="0,00"
                    min="0"
                    step="0.01"
                    className={errors.vehicleValue ? "border-red-500" : ""}
                  />
                  {errors.vehicleValue && <p className="text-sm text-red-500">{errors.vehicleValue}</p>}
                </div>

                {/* IPVA Anual */}
                <div className="space-y-2">
                  <Label htmlFor="ipvaValue">IPVA Anual (R$) *</Label>
                  <Input
                    id="ipvaValue"
                    type="number"
                    value={formData.ipvaValue}
                    onChange={(e) => handleInputChange("ipvaValue", parseFloat(e.target.value) || 0)}
                    placeholder="0,00"
                    min="0"
                    step="0.01"
                    className={errors.ipvaValue ? "border-red-500" : ""}
                  />
                  {errors.ipvaValue && <p className="text-sm text-red-500">{errors.ipvaValue}</p>}
                  <p className="text-xs text-muted-foreground">
                    Valor automático: 4% do valor do veículo (R$ {(formData.vehicleValue * 0.04).toFixed(2)})
                  </p>
                </div>

                {/* Status do Licenciamento */}
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="licensingStatus">Situação do Licenciamento *</Label>
                  <Select value={formData.licensingStatus} onValueChange={(value) => handleInputChange("licensingStatus", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="up_to_date">Em dia</SelectItem>
                      <SelectItem value="overdue">Atrasado</SelectItem>
                    </SelectContent>
                  </Select>
                  {formData.plate && (
                    <p className="text-sm text-muted-foreground">
                      Vencimento baseado na placa ({formData.plate}): {getLicensingDueMonth(formData.plate)}
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Financiamento</h3>
              <div className="flex items-center space-x-2 mb-4">
                <Switch
                  id="isFinanced"
                  checked={formData.isFinanced}
                  onCheckedChange={(checked) => handleInputChange("isFinanced", checked)}
                />
                <Label htmlFor="isFinanced">Está financiado?</Label>
              </div>

              {formData.isFinanced && (
                <div className="space-y-2">
                  <Label htmlFor="monthlyInstallment">Valor da Parcela Mensal (R$) *</Label>
                  <Input
                    id="monthlyInstallment"
                    type="number"
                    value={formData.monthlyInstallment}
                    onChange={(e) => handleInputChange("monthlyInstallment", parseFloat(e.target.value) || 0)}
                    placeholder="0,00"
                    min="0"
                    step="0.01"
                    className={errors.monthlyInstallment ? "border-red-500" : ""}
                  />
                  {errors.monthlyInstallment && <p className="text-sm text-red-500">{errors.monthlyInstallment}</p>}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Custos Mensais</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Seguro Mensal */}
                <div className="space-y-2">
                  <Label htmlFor="monthlyInsurance">Valor do Seguro Mensal (R$) *</Label>
                  <Input
                    id="monthlyInsurance"
                    type="number"
                    value={formData.monthlyInsurance}
                    onChange={(e) => handleInputChange("monthlyInsurance", parseFloat(e.target.value) || 0)}
                    placeholder="0,00"
                    min="0"
                    step="0.01"
                    className={errors.monthlyInsurance ? "border-red-500" : ""}
                  />
                  {errors.monthlyInsurance && <p className="text-sm text-red-500">{errors.monthlyInsurance}</p>}
                </div>

                {/* Rastreador Mensal */}
                <div className="space-y-2">
                  <Label htmlFor="monthlyTracker">Valor do Rastreador Mensal (R$) *</Label>
                  <Input
                    id="monthlyTracker"
                    type="number"
                    value={formData.monthlyTracker}
                    onChange={(e) => handleInputChange("monthlyTracker", parseFloat(e.target.value) || 0)}
                    placeholder="0,00"
                    min="0"
                    step="0.01"
                    className={errors.monthlyTracker ? "border-red-500" : ""}
                  />
                  {errors.monthlyTracker && <p className="text-sm text-red-500">{errors.monthlyTracker}</p>}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rental" className="space-y-6 mt-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Valores de Aluguel</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Valor Semanal */}
                <div className="space-y-2">
                  <Label htmlFor="weeklyValue">Valor Semanal (R$) *</Label>
                  <Input
                    id="weeklyValue"
                    type="number"
                    value={formData.weeklyValue}
                    onChange={(e) => handleInputChange("weeklyValue", parseFloat(e.target.value) || 0)}
                    placeholder="0,00"
                    min="0"
                    step="0.01"
                    className={errors.weeklyValue ? "border-red-500" : ""}
                  />
                  {errors.weeklyValue && <p className="text-sm text-red-500">{errors.weeklyValue}</p>}
                </div>

                {/* Valor da Caução */}
                <div className="space-y-2">
                  <Label htmlFor="depositValue">Valor da Caução (R$) *</Label>
                  <Input
                    id="depositValue"
                    type="number"
                    value={formData.depositValue}
                    onChange={(e) => handleInputChange("depositValue", parseFloat(e.target.value) || 0)}
                    placeholder="0,00"
                    min="0"
                    step="0.01"
                    className={errors.depositValue ? "border-red-500" : ""}
                  />
                  {errors.depositValue && <p className="text-sm text-red-500">{errors.depositValue}</p>}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Descrição do Veículo</h3>
              <div className="space-y-2">
                <Label htmlFor="description">Descrição (opcional)</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="Descreva as características do veículo, equipamentos, condições especiais, etc."
                  rows={4}
                />
                <p className="text-xs text-muted-foreground">
                  Esta descrição será exibida para os motoristas interessados no veículo
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Disponibilidade para Reserva</h3>
              <div className="flex items-center space-x-2">
                <Switch
                  id="allowReservation"
                  checked={formData.allowReservation}
                  onCheckedChange={(checked) => handleInputChange("allowReservation", checked)}
                />
                <Label htmlFor="allowReservation">Permitir reserva online</Label>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Se habilitado, motoristas aprovados poderão reservar este veículo online
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Condições de Quilometragem</h3>
              <div className="space-y-4">
                {/* Tipo de Quilometragem */}
                <div className="space-y-2">
                  <Label htmlFor="kmType">Tipo de Quilometragem *</Label>
                  <Select value={formData.kmType} onValueChange={(value) => handleInputChange("kmType", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="limited">KM Limitado</SelectItem>
                      <SelectItem value="unlimited">KM Livre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Limite de KM (só aparece se for limitado) */}
                {formData.kmType === "limited" && (
                  <div className="space-y-2">
                    <Label htmlFor="kmLimit">Limite de KM por Mês *</Label>
                    <Input
                      id="kmLimit"
                      type="number"
                      value={formData.kmLimit || ""}
                      onChange={(e) => handleInputChange("kmLimit", parseInt(e.target.value) || undefined)}
                      placeholder="Ex: 5000"
                      min="1"
                      className={errors.kmLimit ? "border-red-500" : ""}
                    />
                    {errors.kmLimit && <p className="text-sm text-red-500">{errors.kmLimit}</p>}
                    <p className="text-xs text-muted-foreground">
                      Quilometragem máxima permitida por mês
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Responsabilidade pela Manutenção</h3>
              <div className="space-y-2">
                <Label htmlFor="maintenanceResponsibility">Quem arca com os custos de manutenção? *</Label>
                <Select value={formData.maintenanceResponsibility} onValueChange={(value) => handleInputChange("maintenanceResponsibility", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a responsabilidade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rental_company">Locadora</SelectItem>
                    <SelectItem value="fifty_fifty">Meio a Meio (50% cada)</SelectItem>
                    <SelectItem value="driver">Locatário</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Define quem será responsável pelos custos de manutenção do veículo
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="photos" className="space-y-6 mt-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-medium mb-4">Fotos do Veículo (máximo 5)</h3>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={formData.images.length >= 5}
                    className="flex-1"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Adicionar Fotos
                  </Button>
                </div>
                
                {formData.images.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {formData.images.map((image, index) => (
                      <div key={index} className="relative group">
                        <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                          <img 
                            src={image} 
                            alt={`Foto ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          className="absolute top-1 right-1 h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => handleRemoveImage(index)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
                
                {formData.images.length === 0 && (
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Image className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                    <p className="text-gray-500">Nenhuma foto adicionada</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Botões */}
      <div className="flex gap-3 pt-4">
        <Button type="submit" className="flex-1">
          {vehicle ? "Atualizar Veículo" : "Cadastrar Veículo"}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancelar
        </Button>
      </div>
    </form>
  );
};
