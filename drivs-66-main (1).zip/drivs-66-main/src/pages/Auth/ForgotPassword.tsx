
import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, Mail } from "lucide-react";
import { useSiteSettings } from "@/contexts/SiteSettingsContext";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const { settings } = useSiteSettings();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simular envio de email
    setTimeout(() => {
      setEmailSent(true);
      setIsSubmitting(false);
      toast.success("Email de recuperação enviado com sucesso!");
    }, 2000);
  };

  return (
    <div className="min-h-screen w-full flex flex-col bg-background">
      <div className="flex-1 flex items-center justify-center bg-cover bg-center relative p-4" 
           style={{ backgroundImage: "url('https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?q=80&w=1920')" }}>
        <div className="absolute inset-0 bg-black/70"></div>
        
        <div className="container flex flex-col md:flex-row items-center justify-center max-w-md relative z-10">
          <Card className="w-full shadow-lg bg-card dark:bg-black/90 backdrop-blur-sm border border-border">
            <CardHeader className="space-y-1 text-center">
              <Link to="/" className="mx-auto flex items-center gap-2 mb-4">
                <img 
                  src="/lovable-uploads/a26b7c22-c6a6-4f45-882b-c6ee66456c2d.png" 
                  alt="DRIVS Logo" 
                  className="h-8 w-8"
                />
                <span className="text-2xl font-bold text-primary">{settings?.site_title?.split('-')[0] || "DRIVS"}</span>
              </Link>
              <CardTitle className="text-2xl font-bold tracking-tight">
                {emailSent ? "Email enviado!" : "Esqueci minha senha"}
              </CardTitle>
              <CardDescription>
                {emailSent 
                  ? "Verifique sua caixa de entrada e siga as instruções para redefinir sua senha."
                  : "Digite seu email para receber instruções de recuperação"
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              {emailSent ? (
                <div className="text-center space-y-4">
                  <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                    <Mail className="w-8 h-8 text-green-600" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Enviamos um link de recuperação para <strong>{email}</strong>
                  </p>
                  <div className="space-y-2">
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setEmailSent(false);
                        setEmail("");
                      }}
                      className="w-full"
                    >
                      Enviar para outro email
                    </Button>
                    <Link to="/login">
                      <Button className="w-full">
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Voltar ao login
                      </Button>
                    </Link>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full bg-background border-border"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Enviando..." : "Enviar link de recuperação"}
                  </Button>
                  <Link to="/login">
                    <Button variant="outline" className="w-full">
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Voltar ao login
                    </Button>
                  </Link>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
