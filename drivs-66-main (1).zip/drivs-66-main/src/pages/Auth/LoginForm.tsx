
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

interface LoginFormProps {
  email: string;
  password: string;
  setEmail: (email: string) => void;
  setPassword: (password: string) => void;
  handleSubmit: (e: React.FormEvent) => void;
  showPassword: boolean;
  setShowPassword: (show: boolean) => void;
  isSubmitting: boolean;
}

export const LoginForm: React.FC<LoginFormProps> = ({
  email,
  password,
  setEmail,
  setPassword,
  handleSubmit,
  showPassword,
  setShowPassword,
  isSubmitting,
}) => (
  <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
    <div className="space-y-2">
      <Label htmlFor="email" className="text-xs sm:text-sm">Email</Label>
      <Input
        id="email"
        type="email"
        placeholder="seu@email.com"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
        className="w-full bg-background border-border text-xs sm:text-sm h-9 sm:h-10"
      />
    </div>
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label htmlFor="password" className="text-xs sm:text-sm">Senha</Label>
        <Link to="/esqueci-senha" className="text-xs sm:text-sm text-primary hover:underline">
          Esqueci minha senha
        </Link>
      </div>
      <div className="relative">
        <Input
          id="password"
          type={showPassword ? "text" : "password"}
          placeholder="Digite sua senha"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="w-full pr-10 bg-background border-border text-xs sm:text-sm h-9 sm:h-10"
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
        >
          {showPassword ? (
            <EyeOff className="h-3 w-3 sm:h-4 sm:w-4" />
          ) : (
            <Eye className="h-3 w-3 sm:h-4 sm:w-4" />
          )}
        </button>
      </div>
    </div>
    <Button
      type="submit"
      className="w-full h-9 sm:h-10 text-xs sm:text-sm"
      disabled={isSubmitting}
    >
      {isSubmitting ? "Entrando..." : "Entrar"}
    </Button>
  </form>
);
