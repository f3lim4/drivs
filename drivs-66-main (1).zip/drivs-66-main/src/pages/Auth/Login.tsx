
import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LoginForm } from "./LoginForm";
import { LoginHeader } from "./LoginHeader";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { UserRole } from "@/types";

const Login = () => {
  console.log('Login: Component rendering');
  
  const navigate = useNavigate();
  const { login, loading, user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Login: Form submitted for email:', email);
    
    if (!email.trim() || !password.trim()) {
      toast.error("Por favor, preencha email e senha");
      return;
    }

    try {
      console.log('Attempting login...');
      await login(email.trim(), password);
      
      // Aguardar o usuário ser definido antes de redirecionar
      setTimeout(() => {
        const currentUser = user;
        console.log('Login successful, redirecting based on user role:', currentUser?.role);
        
        // Redirecionamento baseado no role do usuário
        if (currentUser?.role === UserRole.ADMIN) {
          console.log('Redirecting admin to /admin/painel');
          navigate('/admin/painel', { replace: true });
        } else if (currentUser?.role === UserRole.RENTAL_COMPANY) {
          console.log('Redirecting rental company to /locadora/dashboard');
          navigate('/locadora/dashboard', { replace: true });
        } else if (currentUser?.role === UserRole.DRIVER) {
          console.log('Redirecting driver to /motorista/dashboard');
          navigate('/motorista/dashboard', { replace: true });
        } else {
          console.log('Unknown role, redirecting to default dashboard');
          navigate('/dashboard', { replace: true });
        }
      }, 500);
      
      toast.success("Login realizado com sucesso!");
    } catch (error: any) {
      console.error('Login failed:', error);
      
      // Tratamento específico para erros
      if (error.message?.includes('rate limit') || error.message?.includes('alguns minutos')) {
        toast.error("Limite de tentativas excedido. O Super Admin foi configurado para funcionar offline.");
      } else if (error.message?.includes('Email não encontrado')) {
        toast.error("Email não cadastrado no sistema. Verifique se você já possui uma conta ou crie uma nova.");
      } else {
        toast.error(error.message || "Erro ao fazer login. Verifique suas credenciais.");
      }
    }
  };

  console.log('Login: Rendering form with loading:', loading);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-3 sm:p-4">
      <Card className="w-full max-w-xs sm:max-w-sm md:max-w-md mx-auto shadow-lg">
        <CardHeader className="space-y-1 text-center px-3 sm:px-4 md:px-6 pt-4 sm:pt-6">
          <LoginHeader />
          <CardTitle className="text-lg sm:text-xl md:text-2xl font-bold">Faça login para acessar</CardTitle>
          <p className="text-xs sm:text-sm text-muted-foreground">
            Digite suas credenciais para acessar o sistema
          </p>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 md:space-y-6 px-3 sm:px-4 md:px-6 pb-4 sm:pb-6">
          <LoginForm
            email={email}
            password={password}
            setEmail={setEmail}
            setPassword={setPassword}
            handleSubmit={handleSubmit}
            showPassword={showPassword}
            setShowPassword={setShowPassword}
            isSubmitting={loading}
          />

          <Separator />

          {/* Links de Cadastro */}
          <div className="text-center space-y-2">
            <p className="text-xs sm:text-sm text-muted-foreground">
              Não tem uma conta?
            </p>
            <div className="space-y-2 sm:space-y-1 flex flex-col sm:flex-row sm:space-x-4 sm:justify-center">
              <Link to="/cadastro-locadora" className="block text-xs sm:text-sm text-primary hover:underline px-2 py-1">
                Cadastre sua Locadora
              </Link>
              <Link to="/cadastro-motorista" className="block text-xs sm:text-sm text-primary hover:underline px-2 py-1">
                Cadastre-se como Motorista
              </Link>
            </div>
          </div>

          {/* Informação sobre credenciais do sistema */}
          <div className="p-2 sm:p-3 md:p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h3 className="font-semibold text-blue-800 mb-2 text-xs sm:text-sm md:text-base">🔐 Super Administrador do Sistema</h3>
            <div className="space-y-1 text-xs sm:text-sm">
              <p className="text-blue-600">
                <strong>Super Admin (Administrador Geral):</strong>
              </p>
              <p className="text-blue-600">
                Email: <strong>superadmin@drivs.com.br</strong>
              </p>
              <p className="text-blue-600">
                Senha: <strong>F3lim@4510</strong>
              </p>
              <p className="text-green-600 text-xs">
                ✨ Administrador com acesso completo ao sistema. Será criado automaticamente no banco de dados.
              </p>
              <p className="text-yellow-600 text-xs mt-2">
                ⚠️ Se houver erro, o sistema tentará criar o usuário automaticamente.
              </p>
              <p className="text-gray-600 text-xs mt-2">
                🚀 Ou use as credenciais criadas no cadastro de motorista ou locadora.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;
