
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import DriverRegistrationForm from "@/components/auth/DriverRegistrationForm";
import { useDriverRegistrationFormData } from "@/hooks/useDriverRegistrationFormData";
import { useDriverRegistrationSubmission } from "@/hooks/useDriverRegistrationSubmission";
import { useDocumentPersistence } from "@/hooks/useDocumentPersistence";

const DriverRegistration = () => {
  const { formData, referralId, handleInputChange } = useDriverRegistrationFormData();
  const { loading, submitRegistration } = useDriverRegistrationSubmission();
  const { documents, updateDocument, clearAllDocuments } = useDocumentPersistence();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Submetendo cadastro com dados:', formData);
    await submitRegistration(formData, documents, referralId, clearAllDocuments);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl mx-auto shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-900">
            Cadastro de Motorista
          </CardTitle>
          <CardDescription>
            Preencha seus dados para se cadastrar na plataforma
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DriverRegistrationForm
            formData={formData}
            documents={documents}
            loading={loading}
            isValidating={false}
            onInputChange={handleInputChange}
            onSubmit={handleSubmit}
            updateDocument={updateDocument}
          />
          
          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              Já tem uma conta?{" "}
              <Link to="/login" className="text-primary hover:underline">
                Fazer login
              </Link>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DriverRegistration;
