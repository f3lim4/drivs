
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { UserRole } from "@/types";

const Register = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    fullName: "",
    role: "" as UserRole,
    // Campos específicos para motoristas
    cpf: "",
    rg: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    cnh: "",
    cnhExpires: "",
    // Campos específicos para locadoras
    companyName: "",
    cnpj: "",
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast.error("As senhas não coincidem");
      return;
    }

    if (!formData.role) {
      toast.error("Selecione um tipo de usuário");
      return;
    }

    setLoading(true);

    try {
      // Verificar CNPJ duplicado para locadoras
      if (formData.role === 'rental_company' && formData.cnpj) {
        const { data: existingCompany, error: checkError } = await supabase
          .from('rental_companies')
          .select('id')
          .eq('cnpj', formData.cnpj)
          .maybeSingle();

        if (checkError) {
          console.error('Error checking existing CNPJ:', checkError);
          throw new Error('Erro ao verificar CNPJ');
        }

        if (existingCompany) {
          toast.error("Já existe uma empresa cadastrada com este CNPJ");
          return;
        }
      }

      // Verificar CPF duplicado para motoristas
      if (formData.role === 'driver' && formData.cpf) {
        // Verificar na tabela drivers
        const { data: existingDriver, error: checkDriverError } = await supabase
          .from('drivers')
          .select('id')
          .eq('cpf', formData.cpf)
          .maybeSingle();

        if (checkDriverError) {
          console.error('Error checking existing CPF in drivers:', checkDriverError);
          throw new Error('Erro ao verificar CPF');
        }

        if (existingDriver) {
          toast.error("Já existe um motorista cadastrado com este CPF");
          return;
        }

        // Verificar também na tabela driver_registrations
        const { data: existingRegistration, error: checkRegistrationError } = await supabase
          .from('driver_registrations')
          .select('id')
          .eq('cpf', formData.cpf)
          .maybeSingle();

        if (checkRegistrationError) {
          console.error('Error checking existing CPF in registrations:', checkRegistrationError);
          throw new Error('Erro ao verificar CPF');
        }

        if (existingRegistration) {
          toast.error("Já existe um cadastro pendente com este CPF");
          return;
        }
      }

      // Criar usuário no Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            full_name: formData.fullName,
            role: formData.role,
            // Dados específicos baseado no role
            ...(formData.role === 'driver' && {
              cpf: formData.cpf,
              rg: formData.rg,
              phone: formData.phone,
              address: formData.address,
              city: formData.city,
              state: formData.state,
              cnh: formData.cnh,
              cnh_expires: formData.cnhExpires,
            }),
            ...(formData.role === 'rental_company' && {
              company_name: formData.companyName,
              cnpj: formData.cnpj,
              phone: formData.phone,
              address: formData.address,
            }),
          }
        }
      });

      if (authError) {
        // Verificar se é erro de CPF/CNPJ duplicado
        if (authError.message?.includes('duplicate key value violates unique constraint')) {
          if (authError.message?.includes('cnpj')) {
            toast.error("Este CNPJ já está cadastrado no sistema");
          } else if (authError.message?.includes('cpf')) {
            toast.error("Este CPF já está cadastrado no sistema");
          } else {
            toast.error("Dados já cadastrados no sistema");
          }
          return;
        }
        throw authError;
      }

      toast.success("Cadastro realizado com sucesso! Verifique seu email para confirmar a conta.");
      navigate("/login");
      
    } catch (error: any) {
      console.error("Erro no cadastro:", error);
      
      let errorMessage = "Erro no cadastro";
      if (error.message?.includes('duplicate key value violates unique constraint')) {
        if (error.message?.includes('cnpj')) {
          errorMessage = "Este CNPJ já está cadastrado no sistema";
        } else if (error.message?.includes('cpf')) {
          errorMessage = "Este CPF já está cadastrado no sistema";
        } else {
          errorMessage = "Dados já cadastrados no sistema";
        }
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <CardTitle>Cadastro</CardTitle>
          <CardDescription>
            Crie sua conta para acessar o sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="role">Tipo de Usuário</Label>
              <Select 
                value={formData.role} 
                onValueChange={(value: UserRole) => handleInputChange("role", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo de usuário" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="driver">Motorista</SelectItem>
                  <SelectItem value="rental_company">Locadora</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => handleInputChange("password", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar Senha</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fullName">
                {formData.role === 'rental_company' ? 'Nome do Responsável' : 'Nome Completo'}
              </Label>
              <Input
                id="fullName"
                value={formData.fullName}
                onChange={(e) => handleInputChange("fullName", e.target.value)}
                required
              />
            </div>

            {formData.role === 'rental_company' && (
              <div className="space-y-2">
                <Label htmlFor="companyName">Nome da Empresa</Label>
                <Input
                  id="companyName"
                  value={formData.companyName}
                  onChange={(e) => handleInputChange("companyName", e.target.value)}
                  required
                />
              </div>
            )}

            {formData.role === 'rental_company' && (
              <div className="space-y-2">
                <Label htmlFor="cnpj">CNPJ</Label>
                <Input
                  id="cnpj"
                  value={formData.cnpj}
                  onChange={(e) => handleInputChange("cnpj", e.target.value)}
                  required
                />
              </div>
            )}

            {formData.role === 'driver' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="cpf">CPF</Label>
                  <Input
                    id="cpf"
                    value={formData.cpf}
                    onChange={(e) => handleInputChange("cpf", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="rg">RG</Label>
                  <Input
                    id="rg"
                    value={formData.rg}
                    onChange={(e) => handleInputChange("rg", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cnh">CNH</Label>
                  <Input
                    id="cnh"
                    value={formData.cnh}
                    onChange={(e) => handleInputChange("cnh", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cnhExpires">Data de Vencimento da CNH</Label>
                  <Input
                    id="cnhExpires"
                    type="date"
                    value={formData.cnhExpires}
                    onChange={(e) => handleInputChange("cnhExpires", e.target.value)}
                    required
                  />
                </div>
              </>
            )}

            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => handleInputChange("address", e.target.value)}
                required
              />
            </div>

            {formData.role === 'driver' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="city">Cidade</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => handleInputChange("city", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">Estado</Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => handleInputChange("state", e.target.value)}
                    required
                  />
                </div>
              </>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Cadastrando..." : "Cadastrar"}
            </Button>

            <div className="text-center">
              <Button
                type="button"
                variant="link"
                onClick={() => navigate("/login")}
              >
                Já tem uma conta? Faça login
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Register;
