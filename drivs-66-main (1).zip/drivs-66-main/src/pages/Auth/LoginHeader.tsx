
import { Link } from "react-router-dom";
import { useSiteSettings } from "@/contexts/SiteSettingsContext";

export const LoginHeader: React.FC = () => {
  const { settings } = useSiteSettings();
  return (
    <Link to="/" className="mx-auto flex items-center gap-2 mb-4">
      <img 
        src="/lovable-uploads/e10d36b5-ea43-4e95-bdf6-fdd7cae31c66.png" 
        alt="DRIVS Logo" 
        className="h-10 w-auto"
      />
    </Link>
  );
};
