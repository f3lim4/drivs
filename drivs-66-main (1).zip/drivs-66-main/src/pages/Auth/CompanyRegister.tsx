
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { toast } from 'sonner';
import { Building, ArrowLeft } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const companyFormSchema = z.object({
  companyName: z.string().min(3, { message: "Nome da empresa deve ter no mínimo 3 caracteres" }),
  tradingName: z.string().optional(),
  cnpj: z.string().min(14, { message: "CNPJ deve ter 14 números" }).max(18),
  email: z.string().email({ message: "Email inválido" }),
  phone: z.string().min(10, { message: "Telefone inválido" }),
  password: z.string().min(6, { message: "Senha deve ter no mínimo 6 caracteres" }),
  confirmPassword: z.string(),
  address: z.string().min(5, { message: "Endereço obrigatório" }),
  city: z.string().min(2, { message: "Cidade obrigatória" }),
  state: z.string().min(2, { message: "Estado obrigatório" }),
  zipCode: z.string().min(5, { message: "CEP obrigatório" }),
  contactName: z.string().min(3, { message: "Nome do contato obrigatório" }),
  contactPosition: z.string().optional(),
  contactPhone: z.string().min(10, { message: "Telefone do contato inválido" }),
  description: z.string().optional(),
  websiteUrl: z.string().url({ message: "URL inválida" }).optional().or(z.literal('')),
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "Você deve aceitar os termos e condições",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"],
});

type CompanyFormValues = z.infer<typeof companyFormSchema>;

const CompanyRegister = () => {
  const navigate = useNavigate();
  const form = useForm<CompanyFormValues>({
    resolver: zodResolver(companyFormSchema),
    defaultValues: {
      companyName: "",
      tradingName: "",
      cnpj: "",
      email: "",
      phone: "",
      password: "",
      confirmPassword: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      contactName: "",
      contactPosition: "",
      contactPhone: "",
      description: "",
      websiteUrl: "",
      termsAccepted: false,
    },
  });

  async function onSubmit(data: CompanyFormValues) {
    try {
      console.log('=== INÍCIO DO CADASTRO DE LOCADORA ===');
      console.log('Dados recebidos:', data);

      // Normalizar email
      const normalizedEmail = data.email.toLowerCase().trim();
      console.log('Email normalizado:', normalizedEmail);

      // Verificar se já existe uma empresa com este email ou CNPJ
      console.log('🔍 Verificando duplicatas...');
      const { data: existingCompany, error: checkError } = await supabase
        .from('rental_company_registrations')
        .select('email, cnpj')
        .or(`email.eq.${normalizedEmail},cnpj.eq.${data.cnpj}`)
        .maybeSingle();

      if (checkError && checkError.code !== 'PGRST116') {
        console.error('❌ Erro ao verificar dados existentes:', checkError);
        throw new Error('Erro ao verificar dados existentes');
      }

      if (existingCompany) {
        console.log('❌ Empresa já existe:', existingCompany);
        if (existingCompany.email === normalizedEmail) {
          toast.error("Este email já está cadastrado no sistema.");
          return;
        }
        if (existingCompany.cnpj === data.cnpj) {
          toast.error("Este CNPJ já está cadastrado no sistema.");
          return;
        }
      }

      console.log('✅ Dados únicos, prosseguindo com cadastro...');

      // Cadastrar diretamente na tabela rental_company_registrations
      console.log('💾 Salvando na tabela rental_company_registrations...');
      const { data: insertData, error: insertError } = await supabase
        .from('rental_company_registrations')
        .insert({
          company_name: data.companyName,
          trading_name: data.tradingName || null,
          cnpj: data.cnpj,
          email: normalizedEmail,
          phone: data.phone,
          website_url: data.websiteUrl || null,
          description: data.description || null,
          address: data.address,
          city: data.city,
          state: data.state,
          zip_code: data.zipCode,
          contact_name: data.contactName,
          contact_position: data.contactPosition || null,
          contact_phone: data.contactPhone,
          password_hash: data.password, // Em produção, deve ser hash
          status: 'approved' // Aprovação automática para teste
        })
        .select()
        .single();

      if (insertError) {
        console.error('❌ Erro ao inserir na tabela:', insertError);
        if (insertError.message?.includes('duplicate key value violates unique constraint')) {
          if (insertError.message.includes('email')) {
            toast.error("Este email já está cadastrado no sistema.");
          } else if (insertError.message.includes('cnpj')) {
            toast.error("Este CNPJ já está cadastrado no sistema.");
          } else {
            toast.error("Dados já cadastrados no sistema.");
          }
          return;
        }
        throw new Error('Erro ao realizar cadastro: ' + insertError.message);
      }

      console.log('✅ Locadora cadastrada com sucesso:', insertData);
      
      // Aguardar um pouco para o trigger processar (se existir)
      console.log('⏳ Aguardando processamento...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      toast.success("Cadastro realizado com sucesso! Você pode fazer login agora!");
      
      console.log('🔄 Redirecionando para login...');
      setTimeout(() => {
        navigate('/login');
      }, 2000);

      console.log('=== FIM DO CADASTRO DE LOCADORA ===');

    } catch (error: any) {
      console.error('❌ Erro no cadastro:', error);
      toast.error("Erro ao realizar cadastro: " + (error.message || 'Erro desconhecido'));
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4">
      <div className="container mx-auto">
        <Link to="/login" className="flex items-center text-primary hover:underline mb-8">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar para Login
        </Link>

        <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-primary/10 p-3 rounded-full">
              <Building className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Cadastro de Locadora</h1>
              <p className="text-gray-600">Registre sua empresa e tenha acesso imediato</p>
            </div>
          </div>

          {/* Benefícios do cadastro */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-green-800 mb-2">🎉 Benefícios do Cadastro</h3>
            <ul className="text-sm text-green-700 space-y-1">
              <li>✅ Cadastro instantâneo - sem confirmação de email</li>
              <li>✅ Acesso imediato ao sistema</li>
              <li>✅ Gestão completa de motoristas e veículos</li>
              <li>✅ Relatórios e dashboard em tempo real</li>
            </ul>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Dados da Empresa */}
                <div className="col-span-2">
                  <h2 className="text-lg font-medium border-b pb-2 mb-4">Dados da Empresa</h2>
                </div>

                <FormField
                  control={form.control}
                  name="companyName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Razão Social*</FormLabel>
                      <FormControl>
                        <Input placeholder="Razão Social da empresa" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="tradingName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome Fantasia</FormLabel>
                      <FormControl>
                        <Input placeholder="Nome fantasia (opcional)" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="cnpj"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CNPJ*</FormLabel>
                      <FormControl>
                        <Input placeholder="00.000.000/0001-00" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefone da Empresa*</FormLabel>
                      <FormControl>
                        <Input placeholder="(00) 00000-0000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="websiteUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Website</FormLabel>
                      <FormControl>
                        <Input placeholder="https://www.suaempresa.com.br" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="col-span-2">
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Descrição da Empresa</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Conte um pouco sobre sua empresa..." 
                            className="min-h-[100px]" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Endereço */}
                <div className="col-span-2">
                  <h2 className="text-lg font-medium border-b pb-2 mb-4">Endereço</h2>
                </div>

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Endereço Completo*</FormLabel>
                      <FormControl>
                        <Input placeholder="Rua, número, complemento" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cidade*</FormLabel>
                      <FormControl>
                        <Input placeholder="Cidade" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Estado*</FormLabel>
                      <FormControl>
                        <Input placeholder="Estado" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="zipCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CEP*</FormLabel>
                      <FormControl>
                        <Input placeholder="00000-000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Dados do Contato */}
                <div className="col-span-2">
                  <h2 className="text-lg font-medium border-b pb-2 mb-4">Dados do Contato</h2>
                </div>

                <FormField
                  control={form.control}
                  name="contactName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome do Responsável*</FormLabel>
                      <FormControl>
                        <Input placeholder="Nome completo" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contactPosition"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cargo</FormLabel>
                      <FormControl>
                        <Input placeholder="Cargo na empresa" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contactPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefone do Responsável*</FormLabel>
                      <FormControl>
                        <Input placeholder="(00) 00000-0000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Informações de Acesso */}
                <div className="col-span-2">
                  <h2 className="text-lg font-medium border-b pb-2 mb-4">Informações de Acesso</h2>
                </div>

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email*</FormLabel>
                      <FormControl>
                        <Input placeholder="email@sualocadora.com.br" type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="col-span-1">
                  <div className="flex items-center h-full">
                    <div className="p-4 bg-blue-50 text-blue-800 rounded-lg w-full">
                      <p className="text-sm">Este será o email para acesso à plataforma</p>
                    </div>
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha*</FormLabel>
                      <FormControl>
                        <Input placeholder="Senha" type="password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirmar Senha*</FormLabel>
                      <FormControl>
                        <Input placeholder="Confirmar senha" type="password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Termos e Condições */}
                <div className="col-span-2 mt-2">
                  <FormField
                    control={form.control}
                    name="termsAccepted"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            Eu concordo com os{" "}
                            <Link to="/termos" className="text-primary hover:underline" target="_blank">
                              Termos de Serviço
                            </Link>{" "}
                            e{" "}
                            <Link to="/privacidade" className="text-primary hover:underline" target="_blank">
                              Política de Privacidade
                            </Link>
                          </FormLabel>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button type="submit" className="w-full" size="lg">
                  Cadastrar Locadora
                </Button>
                <Link to="/login" className="w-full sm:w-auto">
                  <Button variant="outline" className="w-full" size="lg">
                    Já tenho uma conta
                  </Button>
                </Link>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default CompanyRegister;
