
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { DriverRegisterForm } from "@/components/auth/DriverRegisterForm";
import { useDriverRegisterForm } from "@/hooks/useDriverRegisterForm";

const DriverRegister = () => {
  console.log('🔍 [DRIVER REGISTER] Componente carregando...');
  
  const {
    formData,
    documents,
    loading,
    isValidating,
    referralId,
    handleInputChange,
    handleSubmit,
    updateDocument
  } = useDriverRegisterForm();

  console.log('📋 [DRIVER REGISTER] Estado do componente:', {
    hasFormData: !!formData,
    hasDocuments: !!documents,
    loading,
    isValidating,
    referralId
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl mx-auto shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-900">
            Cadastro de Motorista
          </CardTitle>
          <CardDescription>
            Preencha seus dados para se cadastrar na plataforma
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DriverRegisterForm
            formData={formData}
            documents={documents}
            loading={loading}
            isValidating={isValidating}
            referralId={referralId}
            onInputChange={handleInputChange}
            onSubmit={handleSubmit}
            updateDocument={updateDocument}
          />
          
          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              Já tem uma conta?{" "}
              <Link to="/login" className="text-primary hover:underline">
                Fazer login
              </Link>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DriverRegister;
