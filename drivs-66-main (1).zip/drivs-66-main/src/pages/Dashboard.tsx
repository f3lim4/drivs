
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import AdminDashboard from "./Dashboard/components/AdminDashboard";
import DriverDashboard from "./Dashboard/components/DriverDashboard";
import RentalCompanyDashboard from "@/components/dashboard/RentalCompanyDashboard";

const Dashboard = () => {
  const { user } = useAuth();

  console.log('Dashboard: Rendering for user role:', user?.role);
  console.log('Dashboard: User data:', user);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-xl font-semibold">Carregando...</h2>
        </div>
      </div>
    );
  }

  // Renderizar dashboard específico baseado no tipo de usuário
  switch (user.role) {
    case UserRole.ADMIN:
      return <AdminDashboard />;
    
    case UserRole.RENTAL_COMPANY:
      return <RentalCompanyDashboard />;
    
    case UserRole.DRIVER:
    default:
      return <DriverDashboard />;
  }
};

export default Dashboard;
