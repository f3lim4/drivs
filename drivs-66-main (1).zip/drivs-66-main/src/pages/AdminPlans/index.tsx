
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Pencil, Trash2, PlusCircle } from "lucide-react";

const PERMISSION_LIST = [
  { key: "motoristas", label: "Motoristas" },
  { key: "veiculos", label: "Veículos" },
  { key: "contratos", label: "Contratos" },
  { key: "pagamentos", label: "Pagamentos" },
  { key: "financeiro", label: "Financeiro" },
  { key: "infracoes", label: "Infrações" },
  { key: "manutencao", label: "Manutenção" },
  { key: "vistorias", label: "Vistorias" },
  { key: "negativar", label: "Negativar" },
  { key: "ranking", label: "Ranking" },
  { key: "relatorios", label: "Relatórios" },
  { key: "configuracoes", label: "Configurações" },
];

const defaultPermissions = PERMISSION_LIST.reduce((acc, cur) => ({ ...acc, [cur.key]: true }), {});

type Permissions = { [key: string]: boolean };

type PlanData = {
  id: string;
  name: string;
  price: number;
  maxCars: number;
  permissions: Permissions;
};

type PlanHistory = {
  id: string;
  companyName: string;
  planName: string;
  paymentDate: string;
  price: number;
};

export default function AdminPlansPage() {
  const [plans, setPlans] = useState<PlanData[]>([
    {
      id: "1",
      name: "Basic",
      price: 199,
      maxCars: 5,
      permissions: { ...defaultPermissions, veiculos: true, financeiro: false, manutencao: false },
    },
    {
      id: "2",
      name: "Premium",
      price: 399,
      maxCars: 20,
      permissions: { ...defaultPermissions, financeiro: true, manutencao: true },
    }
  ]);
  const [history] = useState<PlanHistory[]>([
    {
      id: "h1",
      companyName: "AutoLoc Rental",
      planName: "Premium",
      paymentDate: "2024-06-05",
      price: 399,
    },
    {
      id: "h2",
      companyName: "CarShare Plus",
      planName: "Basic",
      paymentDate: "2024-06-01",
      price: 199,
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<PlanData | null>(null);

  const handleOpenModal = (plan?: PlanData) => {
    setEditingPlan(plan ? { ...plan } : {
      id: crypto.randomUUID(),
      name: "",
      price: 0,
      maxCars: 0,
      permissions: { ...defaultPermissions },
    });
    setIsModalOpen(true);
  };

  const handleChangePlanField = (field: keyof PlanData, value: any) => {
    setEditingPlan(prev =>
      prev ? { ...prev, [field]: value } : prev
    );
  };

  const handlePermissionChange = (key: string, checked: boolean) => {
    setEditingPlan((prev) =>
      prev
        ? {
            ...prev,
            permissions: {
              ...prev.permissions,
              [key]: checked,
            },
          }
        : prev
    );
  };

  const handleSavePlan = () => {
    if (!editingPlan) return;
    if (!editingPlan.name || editingPlan.price < 0 || editingPlan.maxCars <= 0) {
      toast.error("Preencha todos os campos obrigatórios corretamente.");
      return;
    }
    setPlans(prev => {
      const exists = prev.find(p => p.id === editingPlan.id);
      if (exists) {
        return prev.map(p => p.id === editingPlan.id ? editingPlan : p);
      }
      return [...prev, editingPlan];
    });
    setIsModalOpen(false);
    toast.success("Plano salvo com sucesso!");
  };

  const handleDeletePlan = (id: string) => {
    setPlans(prev => prev.filter(p => p.id !== id));
    toast.success("Plano excluído.");
  };

  return (
    <div className="container py-8 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Gerenciar Planos das Locadoras</h1>
        <Button onClick={() => handleOpenModal()} className="gap-2">
          <PlusCircle className="w-4 h-4" />
          Novo Plano
        </Button>
      </div>
      {/* Cadastro/edição de plano */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingPlan && editingPlan.name ? "Editar Plano" : "Novo Plano"}</DialogTitle>
          </DialogHeader>
          <form className="space-y-4" onSubmit={e => {e.preventDefault(); handleSavePlan();}}>
            <div>
              <label className="font-medium text-sm">Nome do Plano *</label>
              <Input value={editingPlan?.name || ""} onChange={e => handleChangePlanField("name", e.target.value)} required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="font-medium text-sm">Preço mensal *</label>
                <Input type="number" min={0} value={editingPlan?.price || ""} onChange={e => handleChangePlanField("price", Number(e.target.value))} required />
              </div>
              <div>
                <label className="font-medium text-sm">Máx de veículos *</label>
                <Input type="number" min={1} value={editingPlan?.maxCars || ""} onChange={e => handleChangePlanField("maxCars", Number(e.target.value))} required />
              </div>
            </div>
            <div>
              <label className="font-medium text-sm mb-2 block">Permissões de acesso</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {PERMISSION_LIST.map(({ key, label }) => (
                  <label key={key} className="flex items-center gap-2">
                    <Checkbox
                      checked={!!editingPlan?.permissions[key]}
                      onCheckedChange={checked => handlePermissionChange(key, !!checked)}
                    />
                    <span>{label}</span>
                  </label>
                ))}
              </div>
            </div>
            <DialogFooter className="gap-2 flex flex-row justify-end">
              <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" variant="default">
                Salvar Plano
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Lista de planos cadastrados */}
      <Card>
        <CardHeader>
          <CardTitle>Planos Cadastrados</CardTitle>
          <CardDescription>Veja, edite ou remova os planos disponíveis no sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Preço (R$)</TableHead>
                <TableHead>Veículos Máx.</TableHead>
                <TableHead>Permissões Liberadas</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {plans.map(plan => (
                <TableRow key={plan.id}>
                  <TableCell className="font-semibold">{plan.name}</TableCell>
                  <TableCell>R$ {plan.price}</TableCell>
                  <TableCell>{plan.maxCars}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(plan.permissions)
                        .filter(([_, v]) => v)
                        .map(([perm]) => (
                          <Badge key={perm} variant="outline" className="text-xs">{PERMISSION_LIST.find(p => p.key === perm)?.label}</Badge>
                        ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button variant="secondary" size="sm" onClick={() => handleOpenModal(plan)}>
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button variant="destructive" size="sm" onClick={() => handleDeletePlan(plan.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Histórico de assinaturas/pagamentos */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Assinaturas/ Pagamentos</CardTitle>
          <CardDescription>Lista de todas as locadoras pagantes e plano contratado</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Locadora</TableHead>
                <TableHead>Plano</TableHead>
                <TableHead>Pagamento</TableHead>
                <TableHead>Valor (R$)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.map(h => (
                <TableRow key={h.id}>
                  <TableCell>{h.companyName}</TableCell>
                  <TableCell>{h.planName}</TableCell>
                  <TableCell>{h.paymentDate}</TableCell>
                  <TableCell>R$ {h.price}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
