
import ReportsPage from "@/pages/Reports";

const AdminRelatoriosPage = () => <ReportsPage />;

export default AdminRelatoriosPage;
