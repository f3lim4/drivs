import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { NegotiationCard } from "../../pages/Negotiations/components/NegotiationCard";
import { NegotiationDetailsDialog } from "../../pages/Negotiations/components/NegotiationDetailsDialog";
import { CreateNegotiationFlow } from "../../pages/Negotiations/components/CreateNegotiationFlow";
import { NegotiationFilters } from "../../pages/Negotiations/components/NegotiationFilters";
import { NegotiationStats } from "../../pages/Negotiations/components/NegotiationStats";
import { NegotiationStatusManager } from "../../pages/Negotiations/components/NegotiationStatusManager";
import { Negotiation, CreateNegotiationData } from "../../pages/Negotiations/types";
import { mockNegotiations } from "../../pages/Negotiations/data/mockData";
import { toast } from "@/hooks/use-toast";
import { AlertTriangle, DollarSign, Clock } from "lucide-react";

const AdminNegotiationsPage = () => {
  const { user } = useAuth();
  const [negotiations, setNegotiations] = useState<Negotiation[]>([]);
  const [selectedNegotiation, setSelectedNegotiation] = useState<Negotiation | null>(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const displayNegotiations: Negotiation[] = [];

  const getFilteredNegotiations = () => {
    let filtered = displayNegotiations;

    if (searchTerm) {
      filtered = filtered.filter(n =>
        n.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        n.driverCpf.includes(searchTerm) ||
        n.companyName.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    if (statusFilter !== "all") {
      filtered = filtered.filter(n => n.status === statusFilter);
    }
    if (typeFilter !== "all") {
      filtered = filtered.filter(n => n.type === typeFilter);
    }
    return filtered;
  };

  const filteredNegotiations = getFilteredNegotiations();

  const handleViewDetails = (negotiation: Negotiation) => {
    setSelectedNegotiation(negotiation);
    setIsDetailsDialogOpen(true);
  };

  const handleSendMessage = (negotiation: Negotiation) => {
    toast({
      title: "Mensagens",
      description: "Funcionalidade de mensagens será implementada em breve."
    });
  };

  const handleCreateNegotiation = (data: CreateNegotiationData) => {
    const paymentDeadline = data.paymentDeadline;

    const newNegotiation: Negotiation = {
      id: Date.now().toString(),
      driverId: data.driverId,
      driverName: data.driverName,
      driverCpf: data.driverCpf,
      companyId: user?.id || "",
      companyName: "Empresa Exemplo",
      type: "debt",
      status: "pending",
      description: `Negociação de ${data.selectedDebts.length} débito(s): ${data.selectedDebts.map(d => d.description).join(', ')}`,
      originalAmount: data.totalAmount,
      negotiatedAmount: data.proposedAmount,
      installments: data.installments,
      installmentValue: data.proposedAmount ? data.proposedAmount / (data.installments || 1) : undefined,
      paymentDeadline,
      createdAt: new Date(),
      updatedAt: new Date(),
      messages: [],
      debts: data.selectedDebts,
      payments: []
    };

    setNegotiations([newNegotiation, ...negotiations]);
    toast({
      title: "Negociação criada",
      description: `Nova negociação foi enviada para ${data.driverName}.`
    });
  };

  const handleBlacklistDriver = (data: { driverId: string; driverName: string; driverCpf: string; observations?: string }) => {
    console.log("Enviando para DRIVS:", data);
    toast({
      title: "Enviado para DRIVS",
      description: `${data.driverName} foi enviado para análise da DRIVS.`,
      variant: "default"
    });
  };

  const handleClearFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setTypeFilter("all");
  };

  return (
    <div className="container py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Negociações (Admin)</h1>
          <p className="text-muted-foreground">
            Gerencie acordos com motoristas desativados e inadimplentes (Admin)
          </p>
        </div>
        <CreateNegotiationFlow onCreateNegotiation={handleCreateNegotiation} />
      </div>

      <NegotiationStats negotiations={filteredNegotiations} />

      <NegotiationFilters
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        statusFilter={statusFilter}
        onStatusFilterChange={setStatusFilter}
        typeFilter={typeFilter}
        onTypeFilterChange={setTypeFilter}
        onClearFilters={handleClearFilters}
      />

      {filteredNegotiations.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <h3 className="text-lg font-medium mb-2">Nenhuma negociação encontrada</h3>
            <p className="text-muted-foreground text-center">
              {searchTerm || statusFilter !== "all" || typeFilter !== "all"
                ? "Tente ajustar os filtros para encontrar negociações."
                : "Crie sua primeira negociação selecionando um motorista desativado."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNegotiations.map((negotiation) => (
            <div key={negotiation.id} className="space-y-4">
              <NegotiationCard
                negotiation={negotiation}
                onViewDetails={handleViewDetails}
                onSendMessage={handleSendMessage}
              />
              <NegotiationStatusManager
                negotiation={negotiation}
                onBlacklistDriver={handleBlacklistDriver}
              />
            </div>
          ))}
        </div>
      )}

      <NegotiationDetailsDialog
        negotiation={selectedNegotiation}
        isOpen={isDetailsDialogOpen}
        onOpenChange={setIsDetailsDialogOpen}
      />
    </div>
  );
};

export default AdminNegotiationsPage;
