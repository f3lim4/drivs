
import AdminRentalCompanies from "@/pages/RentalCompanies/AdminRentalCompanies";

// Wrapper: Garante que continue funcionando como a tela de admin de locadoras.
// Você pode personalizar aqui qualquer título/outro comportamento específico do admin.
const AdminLocadorasPage = () => <AdminRentalCompanies />;

export default AdminLocadorasPage;
