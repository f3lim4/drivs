
import MaintenancePage from "@/pages/Maintenance";

const AdminManutencoesPage = () => <MaintenancePage />;

export default AdminManutencoesPage;
