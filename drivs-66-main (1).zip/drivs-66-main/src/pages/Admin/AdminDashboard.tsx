
import AdminDashboard from "@/pages/Dashboard/components/AdminDashboard";

const AdminPainel = () => {
  return (
    <div className="container mx-auto py-6">
      <AdminDashboard />
    </div>
  );
};

export default AdminPainel;
