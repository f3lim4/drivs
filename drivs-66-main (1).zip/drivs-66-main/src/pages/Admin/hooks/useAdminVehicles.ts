
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface RentalVehicle {
  id: string;
  brand: string;
  model: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold";
  documentExpiry: string;
  vehicleValue: number;
  isFinanced: boolean;
  monthlyInstallment?: number;
  monthlyInsurance: number;
  monthlyTracker: number;
  images: string[];
  depositValue: number;
  weeklyValue: number;
  vehicleType: string;
  mileage?: number;
  fuelType?: string;
  transmissionType: string;
  ipvaValue?: number;
  licensingStatus?: "up_to_date" | "overdue";
  kmLimit?: number;
  kmType: "limited" | "unlimited";
  maintenanceResponsibility?: "rental_company" | "fifty_fifty" | "driver";
  description?: string;
  allowReservation: boolean;
  company_name: string;
  company_id: string;
}

export const useAdminVehicles = () => {
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState<RentalVehicle[]>([]);
  const [loading, setLoading] = useState(true);

  const loadVehicles = async () => {
    try {
      setLoading(true);
      console.log('Admin carregando veículos de todas as locadoras...');

      // Verificar se é admin
      if (user?.role !== UserRole.ADMIN) {
        console.log('Usuário não é admin, não pode ver todos os veículos');
        toast.error('Acesso negado');
        setVehicles([]);
        return;
      }

      // Primeiro, vamos verificar se há dados na tabela
      console.log('Verificando dados na tabela rental_company_vehicles...');
      const { data: allVehicles, error: countError } = await supabase
        .from('rental_company_vehicles')
        .select('id, brand, model, company_id');

      console.log('Todos os veículos (apenas id, brand, model, company_id):', allVehicles);
      console.log('Total de registros na tabela:', allVehicles?.length || 0);

      if (countError) {
        console.error('Erro ao contar veículos:', countError);
      }

      // Verificar se há locadoras
      console.log('Verificando locadoras disponíveis...');
      const { data: companies, error: companiesError } = await supabase
        .from('rental_companies')
        .select('id, company_name');

      console.log('Locadoras disponíveis:', companies);

      if (companiesError) {
        console.error('Erro ao buscar locadoras:', companiesError);
      }

      // Buscar todos os veículos com join para locadoras
      console.log('Fazendo query principal com join...');
      const { data: vehiclesData, error } = await supabase
        .from('rental_company_vehicles')
        .select(`
          *,
          rental_companies!rental_company_vehicles_company_id_fkey (
            id,
            company_name
          )
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Erro ao carregar veículos para admin:', error);
        toast.error('Erro ao carregar veículos: ' + error.message);
        setVehicles([]);
        return;
      }

      console.log('Dados brutos do Supabase para admin:', vehiclesData);
      console.log('Quantidade de veículos retornados:', vehiclesData?.length || 0);

      // Se não há dados, vamos verificar se a foreign key está correta
      if (!vehiclesData || vehiclesData.length === 0) {
        console.log('Nenhum veículo encontrado. Verificando foreign keys...');
        
        // Verificar veículos sem locadora associada
        const { data: orphanVehicles } = await supabase
          .from('rental_company_vehicles')
          .select('*')
          .is('company_id', null);
        
        console.log('Veículos sem locadora:', orphanVehicles);

        // Verificar veículos com company_id inválido
        const { data: invalidCompanyVehicles } = await supabase
          .from('rental_company_vehicles')
          .select(`
            *,
            rental_companies!left (
              id,
              company_name
            )
          `)
          .is('rental_companies.id', null);

        console.log('Veículos com company_id inválido:', invalidCompanyVehicles);
      }

      // Mapear os dados para o formato esperado pela tabela
      const mappedVehicles: RentalVehicle[] = vehiclesData?.map(vehicle => ({
        id: vehicle.id,
        brand: vehicle.brand,
        model: vehicle.model,
        plate: vehicle.plate,
        year: vehicle.year,
        color: vehicle.color,
        status: vehicle.status as "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold",
        documentExpiry: vehicle.document_expiry || '',
        vehicleValue: vehicle.vehicle_value || 0,
        isFinanced: vehicle.is_financed || false,
        monthlyInstallment: vehicle.monthly_installment,
        monthlyInsurance: vehicle.monthly_insurance || 0,
        monthlyTracker: vehicle.monthly_tracker || 0,
        images: vehicle.images || [],
        depositValue: vehicle.deposit_value,
        weeklyValue: vehicle.weekly_value,
        vehicleType: vehicle.vehicle_type,
        mileage: vehicle.mileage,
        fuelType: vehicle.fuel_type,
        transmissionType: vehicle.transmission_type,
        ipvaValue: vehicle.ipva_value,
        licensingStatus: vehicle.licensing_status as "up_to_date" | "overdue" | undefined,
        kmLimit: vehicle.km_limit,
        kmType: vehicle.km_type as "limited" | "unlimited",
        maintenanceResponsibility: vehicle.maintenance_responsibility as "rental_company" | "fifty_fifty" | "driver" | undefined,
        description: vehicle.description,
        allowReservation: vehicle.allow_reservation || false,
        company_name: vehicle.rental_companies?.company_name || 'Sem Locadora',
        company_id: vehicle.company_id
      })) || [];

      console.log("Veículos mapeados para admin:", mappedVehicles);
      console.log("Total de veículos encontrados:", mappedVehicles.length);
      setVehicles(mappedVehicles);

    } catch (error: any) {
      console.error('Erro geral ao carregar veículos para admin:', error);
      toast.error('Erro inesperado ao carregar veículos');
      setVehicles([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    console.log('AdminVehiclesPage useEffect - user:', user);
    if (user?.role === UserRole.ADMIN) {
      console.log('Usuário é admin, carregando veículos...');
      loadVehicles();
    } else {
      console.log('Usuário não é admin, role:', user?.role);
      setLoading(false);
    }
  }, [user]);

  return { vehicles, loading, loadVehicles };
};
