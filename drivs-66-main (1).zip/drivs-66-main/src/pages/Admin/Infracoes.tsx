
import ViolationsPage from "@/pages/Violations";

const AdminInfracoesPage = () => <ViolationsPage />;

export default AdminInfracoesPage;
