
import FinancialPage from "@/pages/Financial";

const AdminFinanceiroPage = () => <FinancialPage />;

export default AdminFinanceiroPage;
