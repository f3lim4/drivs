
import PaymentsPage from "@/pages/Payments";

const AdminPagamentosPage = () => <PaymentsPage />;

export default AdminPagamentosPage;
