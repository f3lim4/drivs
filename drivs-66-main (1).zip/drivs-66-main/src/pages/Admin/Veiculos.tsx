
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AdminVehiclesHeader } from "./components/AdminVehiclesHeader";
import { AdminVehiclesFilters } from "./components/AdminVehiclesFilters";
import { AdminVehiclesTable } from "./components/AdminVehiclesTable";
import { useAdminVehicles } from "./hooks/useAdminVehicles";
import { filterAdminVehicles } from "./utils/adminVehicleFilters";

const AdminVehiclesPage = () => {
  const { user } = useAuth();
  const { vehicles, loading } = useAdminVehicles();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Filtrar veículos
  const filteredVehicles = filterAdminVehicles(vehicles, searchTerm, statusFilter);

  // Verificar se usuário não é admin
  if (user?.role !== UserRole.ADMIN) {
    return (
      <div className="container py-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600">Acesso Negado</h1>
          <p className="text-muted-foreground mt-2">
            Apenas administradores podem acessar esta página.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6 space-y-6">
      <AdminVehiclesHeader vehicleCount={filteredVehicles.length} />

      <Card>
        <CardHeader>
          <CardTitle>Veículos de Todas as Locadoras ({filteredVehicles.length})</CardTitle>
          <AdminVehiclesFilters
            searchTerm={searchTerm}
            statusFilter={statusFilter}
            onSearchChange={setSearchTerm}
            onStatusFilterChange={setStatusFilter}
            vehicleCount={filteredVehicles.length}
          />
        </CardHeader>
        <CardContent>
          <AdminVehiclesTable
            vehicles={filteredVehicles}
            loading={loading}
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminVehiclesPage;
