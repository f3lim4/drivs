
import React, { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { 
  Users as UsersIcon, 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  EyeOff,
  Search,
  Filter,
  UserPlus
} from "lucide-react";
import { useAllUsers } from "@/hooks/useAllUsers";
import { useCreateSystemUsers } from "@/hooks/useCreateSystemUsers";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";

const AdminUsersPage = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [userToDelete, setUserToDelete] = useState<any>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deletePassword, setDeletePassword] = useState("");
  
  // Estados para criação de usuários
  const [isCreateAdminOpen, setIsCreateAdminOpen] = useState(false);
  const [isCreateAnalystOpen, setIsCreateAnalystOpen] = useState(false);
  const [adminForm, setAdminForm] = useState({
    name: "",
    email: "",
    password: ""
  });
  const [analystForm, setAnalystForm] = useState({
    name: "",
    email: "",
    password: ""
  });

  const { users, loading, deleteUser, toggleUserStatus, refetch } = useAllUsers();
  const { createAdministrator, createAnalyst, loading: createLoading } = useCreateSystemUsers();

  if (!user || user.role !== UserRole.ADMIN) {
    return (
      <div className="page-content">
        <Card className="content-card content-card-red">
          <CardContent className="p-6">
            <p className="text-center text-muted-foreground">Acesso não autorizado</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return <FuturisticLoading />;
  }

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "active" && user.active) ||
      (statusFilter === "inactive" && !user.active);
    
    return matchesSearch && matchesStatus;
  });

  const handleDeleteUser = async () => {
    if (!deletePassword) {
      toast.error("Digite sua senha para confirmar");
      return;
    }

    // Verificar se a senha está correta (simulação)
    if (deletePassword !== "admin123") {
      toast.error("Senha incorreta");
      return;
    }

    if (userToDelete) {
      await deleteUser(userToDelete.id, userToDelete.role);
      setUserToDelete(null);
      setDeletePassword("");
      setIsDeleteDialogOpen(false);
    }
  };

  const openDeleteDialog = (user: any) => {
    setUserToDelete(user);
    setIsDeleteDialogOpen(true);
  };

  const closeDeleteDialog = () => {
    setUserToDelete(null);
    setDeletePassword("");
    setIsDeleteDialogOpen(false);
  };

  const handleCreateAdmin = async () => {
    if (!adminForm.name || !adminForm.email || !adminForm.password) {
      toast.error("Preencha todos os campos");
      return;
    }

    const success = await createAdministrator(adminForm);
    if (success) {
      setAdminForm({ name: "", email: "", password: "" });
      setIsCreateAdminOpen(false);
      refetch(); // Atualizar a lista de usuários
    }
  };

  const handleCreateAnalyst = async () => {
    if (!analystForm.name || !analystForm.email || !analystForm.password) {
      toast.error("Preencha todos os campos");
      return;
    }

    const success = await createAnalyst(analystForm);
    if (success) {
      setAnalystForm({ name: "", email: "", password: "" });
      setIsCreateAnalystOpen(false);
      refetch(); // Atualizar a lista de usuários
    }
  };

  const totalUsers = users.length;
  const activeUsers = users.filter(u => u.active).length;
  const inactiveUsers = users.filter(u => !u.active).length;
  const adminUsers = users.filter(u => u.role === "Administrador").length;

  return (
    <div className="page-content">
      <div className="space-y-6">
        <div className="page-header">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="page-title">Gerenciar Usuários Administrativos</h1>
              <p className="page-subtitle">
                Gerencie administradores e analistas do sistema
              </p>
            </div>
            <div className="flex gap-2">
              <Dialog open={isCreateAdminOpen} onOpenChange={setIsCreateAdminOpen}>
                <DialogTrigger asChild>
                  <Button className="flex items-center gap-2" disabled={createLoading}>
                    <UserPlus className="h-4 w-4" />
                    Criar Administrador
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Criar Novo Administrador</DialogTitle>
                    <DialogDescription>
                      Preencha os dados para criar um novo administrador do sistema.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="admin-name">Nome Completo</Label>
                      <Input
                        id="admin-name"
                        value={adminForm.name}
                        onChange={(e) => setAdminForm({ ...adminForm, name: e.target.value })}
                        placeholder="Digite o nome completo"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="admin-email">Email</Label>
                      <Input
                        id="admin-email"
                        type="email"
                        value={adminForm.email}
                        onChange={(e) => setAdminForm({ ...adminForm, email: e.target.value })}
                        placeholder="Digite o email"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="admin-password">Senha</Label>
                      <Input
                        id="admin-password"
                        type="password"
                        value={adminForm.password}
                        onChange={(e) => setAdminForm({ ...adminForm, password: e.target.value })}
                        placeholder="Digite a senha"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsCreateAdminOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleCreateAdmin} disabled={createLoading}>
                      {createLoading ? "Criando..." : "Criar Administrador"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog open={isCreateAnalystOpen} onOpenChange={setIsCreateAnalystOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2" disabled={createLoading}>
                    <UserPlus className="h-4 w-4" />
                    Criar Analista
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Criar Novo Analista</DialogTitle>
                    <DialogDescription>
                      Preencha os dados para criar um novo analista do sistema.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="analyst-name">Nome Completo</Label>
                      <Input
                        id="analyst-name"
                        value={analystForm.name}
                        onChange={(e) => setAnalystForm({ ...analystForm, name: e.target.value })}
                        placeholder="Digite o nome completo"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="analyst-email">Email</Label>
                      <Input
                        id="analyst-email"
                        type="email"
                        value={analystForm.email}
                        onChange={(e) => setAnalystForm({ ...analystForm, email: e.target.value })}
                        placeholder="Digite o email"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="analyst-password">Senha</Label>
                      <Input
                        id="analyst-password"
                        type="password"
                        value={analystForm.password}
                        onChange={(e) => setAnalystForm({ ...analystForm, password: e.target.value })}
                        placeholder="Digite a senha"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsCreateAnalystOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleCreateAnalyst} disabled={createLoading}>
                      {createLoading ? "Criando..." : "Criar Analista"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {/* Cards de Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
              <UsersIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalUsers}</div>
              <p className="text-xs text-muted-foreground">
                Usuários administrativos
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Usuários Ativos</CardTitle>
              <UsersIcon className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{activeUsers}</div>
              <p className="text-xs text-muted-foreground">
                Com acesso ativo
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Usuários Inativos</CardTitle>
              <UsersIcon className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{inactiveUsers}</div>
              <p className="text-xs text-muted-foreground">
                Com acesso bloqueado
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <Card className="content-card">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por nome ou email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="flex gap-2">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-md text-sm"
                >
                  <option value="all">Todos os status</option>
                  <option value="active">Ativos</option>
                  <option value="inactive">Inativos</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabela de usuários */}
        <Card className="content-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UsersIcon className="h-5 w-5" />
              Usuários Administrativos ({filteredUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {filteredUsers.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Criado em</TableHead>
                    <TableHead>Último Login</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant="destructive" className="flex items-center gap-1">
                          <UsersIcon className="h-3 w-3" />
                          {user.role}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.active ? "default" : "secondary"}>
                          {user.active ? "Ativo" : "Inativo"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(user.created_at).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell>
                        {user.last_login ? new Date(user.last_login).toLocaleDateString('pt-BR') : "Nunca"}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => toggleUserStatus(user.id, user.role)}
                          >
                            {user.active ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openDeleteDialog(user)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-10">
                <p className="text-muted-foreground">
                  Nenhum usuário encontrado com os filtros aplicados.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Dialog de confirmação de exclusão */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={closeDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir o usuário <strong>{userToDelete?.name}</strong> ({userToDelete?.role})?
                Esta ação não pode ser desfeita.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="deletePassword">Digite sua senha para confirmar:</Label>
                <Input
                  id="deletePassword"
                  type="password"
                  value={deletePassword}
                  onChange={(e) => setDeletePassword(e.target.value)}
                  placeholder="Sua senha de administrador"
                />
              </div>
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={closeDeleteDialog}>
                Cancelar
              </AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteUser} className="bg-red-600 hover:bg-red-700">
                Confirmar Exclusão
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
};

export default AdminUsersPage;
