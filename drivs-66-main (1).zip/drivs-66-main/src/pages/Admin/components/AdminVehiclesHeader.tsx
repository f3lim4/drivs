
interface AdminVehiclesHeaderProps {
  vehicleCount: number;
}

export const AdminVehiclesHeader = ({ vehicleCount }: AdminVehiclesHeaderProps) => {
  return (
    <div className="flex justify-between items-center">
      <h1 className="text-3xl font-bold text-card-foreground">TODOS OS VEÍCULOS</h1>
    </div>
  );
};
