
import { VehicleTable } from "@/pages/RentalVehicles/components/VehicleTable";
import { toast } from "sonner";

interface RentalVehicle {
  id: string;
  brand: string;
  model: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold";
  documentExpiry: string;
  vehicleValue: number;
  isFinanced: boolean;
  monthlyInstallment?: number;
  monthlyInsurance: number;
  monthlyTracker: number;
  images: string[];
  depositValue: number;
  weeklyValue: number;
  vehicleType: string;
  mileage?: number;
  fuelType?: string;
  transmissionType: string;
  ipvaValue?: number;
  licensingStatus?: "up_to_date" | "overdue";
  kmLimit?: number;
  kmType: "limited" | "unlimited";
  maintenanceResponsibility?: "rental_company" | "fifty_fifty" | "driver";
  description?: string;
  allowReservation: boolean;
  company_name: string;
  company_id: string;
}

interface AdminVehiclesTableProps {
  vehicles: RentalVehicle[];
  loading: boolean;
}

export const AdminVehiclesTable = ({ vehicles, loading }: AdminVehiclesTableProps) => {
  const handleEdit = () => {
    toast.info("Admin não pode editar veículos aqui.");
  };

  const handleDelete = () => {
    toast.info("Admin não pode excluir veículos aqui.");
  };

  if (loading) {
    return (
      <div className="text-center py-10">
        <p className="text-muted-foreground">Carregando veículos...</p>
      </div>
    );
  }

  return (
    <VehicleTable
      vehicles={vehicles}
      onEdit={handleEdit}
      onDelete={handleDelete}
      showCompanyColumn={true}
    />
  );
};
