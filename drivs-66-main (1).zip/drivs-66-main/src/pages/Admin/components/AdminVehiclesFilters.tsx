
import { VehicleFilters } from "@/pages/RentalVehicles/components/VehicleFilters";

interface AdminVehiclesFiltersProps {
  searchTerm: string;
  statusFilter: string;
  onSearchChange: (value: string) => void;
  onStatusFilterChange: (value: string) => void;
  vehicleCount: number;
}

export const AdminVehiclesFilters = ({
  searchTerm,
  statusFilter,
  onSearchChange,
  onStatusFilterChange,
  vehicleCount
}: AdminVehiclesFiltersProps) => {
  return (
    <VehicleFilters
      searchTerm={searchTerm}
      statusFilter={statusFilter}
      onSearchChange={onSearchChange}
      onStatusFilterChange={onStatusFilterChange}
    />
  );
};
