
import Inspections from "@/pages/Inspections";

const AdminVistoriasPage = () => <Inspections />;

export default AdminVistoriasPage;
