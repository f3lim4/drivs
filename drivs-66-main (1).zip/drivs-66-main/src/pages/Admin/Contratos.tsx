
import Contracts from "@/pages/Contracts";

const AdminContratosPage = () => <Contracts />;

export default AdminContratosPage;
