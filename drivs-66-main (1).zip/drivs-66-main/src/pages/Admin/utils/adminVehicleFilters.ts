
interface RentalVehicle {
  id: string;
  brand: string;
  model: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold";
  documentExpiry: string;
  vehicleValue: number;
  isFinanced: boolean;
  monthlyInstallment?: number;
  monthlyInsurance: number;
  monthlyTracker: number;
  images: string[];
  depositValue: number;
  weeklyValue: number;
  vehicleType: string;
  mileage?: number;
  fuelType?: string;
  transmissionType: string;
  ipvaValue?: number;
  licensingStatus?: "up_to_date" | "overdue";
  kmLimit?: number;
  kmType: "limited" | "unlimited";
  maintenanceResponsibility?: "rental_company" | "fifty_fifty" | "driver";
  description?: string;
  allowReservation: boolean;
  company_name: string;
  company_id: string;
}

export const filterAdminVehicles = (
  vehicles: RentalVehicle[],
  searchTerm: string,
  statusFilter: string
): RentalVehicle[] => {
  return vehicles.filter(vehicle => {
    const matchesSearch = 
      vehicle.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.company_name.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesStatus = 
      statusFilter === "all" || 
      vehicle.status === statusFilter;
      
    return matchesSearch && matchesStatus;
  });
};
