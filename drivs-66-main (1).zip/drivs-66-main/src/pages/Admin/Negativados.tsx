
import BlacklistDriversPage from "@/pages/BlacklistDrivers";

const AdminNegativadosPage = () => <BlacklistDriversPage />;

export default AdminNegativadosPage;
