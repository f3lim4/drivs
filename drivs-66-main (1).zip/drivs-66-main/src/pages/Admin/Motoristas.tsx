
import Drivers from "@/pages/Drivers";

const AdminMotoristasPage = () => <Drivers />;

export default AdminMotoristasPage;
