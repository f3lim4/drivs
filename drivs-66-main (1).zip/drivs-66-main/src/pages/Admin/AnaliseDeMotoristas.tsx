
import React from "react";
import DriversAnalysis from "@/pages/DriversAnalysis";
import { useAuth } from "@/contexts/AuthContext";

const AdminAnaliseDeMotoristasPage = () => {
  const { user } = useAuth();

  console.log("[ADMIN ANALISE DE MOTORISTAS] - user", user);

  // Renderiza exatamente o mesmo conteúdo da página comum de análise de motoristas
  return <DriversAnalysis />;
};

export default AdminAnaliseDeMotoristasPage;
