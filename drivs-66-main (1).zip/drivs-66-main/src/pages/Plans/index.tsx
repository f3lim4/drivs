
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  CheckCircle,
  Star,
  CreditCard,
  QrCode,
  Zap,
  Building,
  Users,
  BarChart3,
  Shield,
  Edit,
  Plus,
  Calendar,
  TrendingUp
} from "lucide-react";

const plans = [
  {
    id: "basic",
    name: "Básico",
    price: 199,
    period: "/mês",
    description: "Para locadoras iniciantes com até 5 veículos",
    maxVehicles: 5,
    maxUsers: 2,
    features: [
      "Gerenciamento de motoristas",
      "Gerenciamento de veículos (até 5)",
      "Registro de pagamentos",
      "Contratos básicos",
      "Suporte por email"
    ],
    color: "from-blue-500 to-cyan-500",
    popular: false
  },
  {
    id: "professional",
    name: "Profissional",
    price: 399,
    period: "/mês",
    description: "Para locadoras em crescimento com até 20 veículos",
    maxVehicles: 20,
    maxUsers: 5,
    features: [
      "Tudo do plano Básico",
      "Sistema de vistorias completo",
      "Gestão de manutenções",
      "Infrações de trânsito",
      "Negativação de motoristas",
      "Relatórios básicos",
      "Suporte prioritário"
    ],
    color: "from-purple-500 to-pink-500",
    popular: true
  },
  {
    id: "enterprise",
    name: "Empresarial",
    price: 799,
    period: "/mês",
    description: "Para locadoras estabelecidas com frota ilimitada",
    maxVehicles: "Ilimitado",
    maxUsers: "Ilimitado",
    features: [
      "Tudo do plano Profissional",
      "Usuários ilimitados",
      "Veículos ilimitados",
      "Relatórios avançados",
      "API de integração",
      "Dashboard personalizado",
      "Suporte 24/7 dedicado",
      "Personalização da plataforma"
    ],
    color: "from-emerald-500 to-green-500",
    popular: false
  }
];

const PlansPage = () => {
  const { user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("pix");
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [showPaymentMethods, setShowPaymentMethods] = useState(false);
  const [cardData, setCardData] = useState({
    number: "**** **** **** 1234",
    name: "João Silva",
    expiry: "12/25",
    brand: "Visa"
  });
  
  // Simular dados do plano atual da locadora
  const currentPlan = "basic";
  const currentPlanData = plans.find(plan => plan.id === currentPlan);
  const subscriptionStartDate = new Date("2024-01-15"); // Simular data de início
  const subscriptionEndDate = new Date("2025-01-15"); // Simular data de expiração
  const daysUntilExpiry = Math.ceil((subscriptionEndDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));

  const handlePlanUpgrade = async (planId: string) => {
    setIsUpgrading(true);
    try {
      // Simular processo de upgrade
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      if (paymentMethod === "pix") {
        toast.success("Código PIX gerado! Verifique seu email para finalizar o pagamento.");
      } else {
        toast.success("Pagamento processado com sucesso! Seu plano será atualizado em instantes.");
      }
      
      // Simular atualização do plano
      console.log(`Upgrading to plan: ${planId}`);
    } catch (error) {
      toast.error("Erro ao processar upgrade. Tente novamente.");
    } finally {
      setIsUpgrading(false);
    }
  };

  const handleSavePaymentMethod = () => {
    toast.success("Forma de pagamento atualizada com sucesso!");
    setShowPaymentMethods(false);
  };

  const handleCancelSubscription = () => {
    toast.success("Solicitação de cancelamento enviada. Entraremos em contato em breve.");
  };

  const handleAddPaymentMethod = () => {
    toast.success("Redirecionando para adicionar novo cartão...");
    // Aqui seria redirecionado para o sistema de pagamento
  };

  const handleEditPaymentMethod = () => {
    toast.success("Redirecionando para editar cartão...");
    // Aqui seria redirecionado para editar o cartão
  };

  const PaymentMethodsDialog = () => (
    <Dialog open={showPaymentMethods} onOpenChange={setShowPaymentMethods}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Gerenciar Formas de Pagamento</DialogTitle>
          <DialogDescription>
            Configure suas formas de pagamento preferidas
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-3">
                <CreditCard className="h-8 w-8 text-blue-600" />
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-medium">{cardData.brand}</span>
                    <span className="text-sm text-muted-foreground">{cardData.number}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {cardData.name} • Expira {cardData.expiry}
                  </div>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={handleEditPaymentMethod}>
                <Edit className="h-4 w-4 mr-1" />
                Editar
              </Button>
            </div>
            
            <Button variant="outline" className="w-full" onClick={handleAddPaymentMethod}>
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Novo Cartão
            </Button>
          </div>
          
          <div className="space-y-4">
            <Label className="text-base font-medium">Forma de Pagamento Padrão</Label>
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="card" id="default-card" />
                <Label htmlFor="default-card" className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4" />
                  Cartão de Crédito ({cardData.brand} {cardData.number.slice(-4)})
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="pix" id="default-pix" />
                <Label htmlFor="default-pix" className="flex items-center gap-2">
                  <QrCode className="h-4 w-4" />
                  PIX (5% de desconto)
                </Label>
              </div>
            </RadioGroup>
          </div>
          
          <Button onClick={handleSavePaymentMethod} className="w-full">
            Salvar Configurações
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );

  const UpgradeDialog = ({ plan }: { plan: typeof plans[0] }) => (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          className="w-full" 
          onClick={() => setSelectedPlan(plan.id)}
          disabled={plan.id === currentPlan}
        >
          {plan.id === currentPlan ? "Plano Atual" : "Fazer Upgrade"}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {plan.id === currentPlan ? "Gerenciar Plano" : `Upgrade para ${plan.name}`}
          </DialogTitle>
          <DialogDescription>
            {plan.id === currentPlan 
              ? "Gerencie seu plano atual" 
              : "Confirme os detalhes do seu upgrade"
            }
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="text-center">
            <div className="text-2xl font-bold">R$ {plan.price}</div>
            <div className="text-muted-foreground">{plan.period}</div>
          </div>
          
          <Separator />
          
          {plan.id !== currentPlan && (
            <>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-base font-medium">Forma de Pagamento</Label>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setShowPaymentMethods(true)}
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Alterar
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg bg-muted/50">
                  {paymentMethod === "pix" ? (
                    <div className="flex items-center gap-3">
                      <QrCode className="h-8 w-8 text-green-600" />
                      <div>
                        <div className="font-medium">PIX</div>
                        <div className="text-sm text-muted-foreground">
                          5% de desconto • R$ {Math.round(plan.price * 0.95)}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3">
                      <CreditCard className="h-8 w-8 text-blue-600" />
                      <div>
                        <div className="font-medium">{cardData.brand} {cardData.number.slice(-4)}</div>
                        <div className="text-sm text-muted-foreground">
                          {cardData.name} • R$ {plan.price}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="space-y-2 text-xs text-muted-foreground">
                <p>• Cobrança mensal recorrente</p>
                <p>• Cancele a qualquer momento</p>
                <p>• Upgrade imediato após confirmação</p>
              </div>
              
              <Button 
                onClick={() => handlePlanUpgrade(plan.id)}
                disabled={isUpgrading}
                className="w-full"
              >
                {isUpgrading ? "Processando..." : `Confirmar Upgrade - R$ ${paymentMethod === 'pix' ? Math.round(plan.price * 0.95) : plan.price}`}
              </Button>
            </>
          )}
          
          {plan.id === currentPlan && (
            <div className="space-y-4">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setShowPaymentMethods(true)}
              >
                <CreditCard className="h-4 w-4 mr-2" />
                Gerenciar Formas de Pagamento
              </Button>
              
              <Button 
                variant="destructive" 
                className="w-full"
                onClick={handleCancelSubscription}
              >
                Cancelar Assinatura
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );

  if (user?.role !== UserRole.RENTAL_COMPANY && user?.role !== UserRole.MANAGER) {
    return (
      <div className="container py-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Acesso Negado</h1>
          <p className="text-muted-foreground">Esta página é exclusiva para locadoras.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="text-center flex-1">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Planos e Assinaturas
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Gerencie seu plano atual e faça upgrade para desbloquear mais funcionalidades
          </p>
        </div>
        <Button 
          variant="outline" 
          onClick={() => setShowPaymentMethods(true)}
          className="ml-4"
        >
          <CreditCard className="h-4 w-4 mr-2" />
          Pagamentos
        </Button>
      </div>

      {/* Plano Atual */}
      <Card className="border-2 border-primary">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                Seu Plano Atual
              </CardTitle>
              <CardDescription>Plano ativo da sua locadora</CardDescription>
            </div>
            <Badge variant="default" className="bg-green-100 text-green-800">
              Ativo
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">{currentPlanData?.name}</h3>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-2xl font-bold">R$ {currentPlanData?.price}</span>
                <span className="text-muted-foreground">{currentPlanData?.period}</span>
              </div>
              <p className="text-muted-foreground mb-4">{currentPlanData?.description}</p>
              
              {/* Datas da Assinatura */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-blue-500" />
                  <span>Iniciado em: {subscriptionStartDate.toLocaleDateString('pt-BR')}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-orange-500" />
                  <span>Expira em: {subscriptionEndDate.toLocaleDateString('pt-BR')}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <TrendingUp className="h-4 w-4 text-green-500" />
                  <span className={daysUntilExpiry <= 30 ? "text-orange-600 font-medium" : "text-green-600"}>
                    {daysUntilExpiry > 0 ? `${daysUntilExpiry} dias restantes` : "Expirado"}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Building className="h-4 w-4 text-blue-500" />
                  <span>Até {currentPlanData?.maxVehicles} veículos</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-green-500" />
                  <span>Até {currentPlanData?.maxUsers} usuários</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium mb-3">Recursos Inclusos:</h4>
              <ul className="space-y-2">
                {currentPlanData?.features.slice(0, 4).map((feature, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>{feature}</span>
                  </li>
                ))}
                {currentPlanData && currentPlanData.features.length > 4 && (
                  <li className="text-sm text-muted-foreground">
                    +{currentPlanData.features.length - 4} recursos adicionais
                  </li>
                )}
              </ul>
              
              <div className="mt-4">
                <UpgradeDialog plan={currentPlanData!} />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Todos os Planos */}
      <div>
        <h2 className="text-2xl font-semibold mb-6 text-center">Todos os Planos Disponíveis</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <Card 
              key={plan.id}
              className={`relative overflow-hidden transition-all duration-300 hover:shadow-lg ${
                plan.id === currentPlan ? 'ring-2 ring-primary' : ''
              } ${plan.popular ? 'border-purple-200 shadow-md' : ''}`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-center py-1 text-sm font-medium">
                  Mais Popular
                </div>
              )}
              
              <CardHeader className={plan.popular ? 'pt-8' : ''}>
                <div className="text-center">
                  <CardTitle className="text-xl mb-2">{plan.name}</CardTitle>
                  <div className="flex items-baseline justify-center gap-1 mb-2">
                    <span className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                      R$ {plan.price}
                    </span>
                    <span className="text-muted-foreground">{plan.period}</span>
                  </div>
                  <CardDescription className="text-center">
                    {plan.description}
                  </CardDescription>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4 text-blue-500" />
                    <span>{plan.maxVehicles} veículos</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-green-500" />
                    <span>{plan.maxUsers} usuários</span>
                  </div>
                </div>
                
                <ul className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="pt-4">
                  {plan.id === currentPlan ? (
                    <Button className="w-full" disabled>
                      <Star className="h-4 w-4 mr-2" />
                      Plano Atual
                    </Button>
                  ) : (
                    <UpgradeDialog plan={plan} />
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Benefícios do Upgrade */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            Por que fazer upgrade?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <BarChart3 className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <h3 className="font-medium mb-2">Relatórios Avançados</h3>
              <p className="text-sm text-muted-foreground">
                Acesse insights detalhados sobre sua frota e operação
              </p>
            </div>
            <div className="text-center">
              <Shield className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <h3 className="font-medium mb-2">Suporte Prioritário</h3>
              <p className="text-sm text-muted-foreground">
                Atendimento especializado e resolução mais rápida
              </p>
            </div>
            <div className="text-center">
              <Building className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <h3 className="font-medium mb-2">Mais Capacidade</h3>
              <p className="text-sm text-muted-foreground">
                Gerencie mais veículos e usuários em sua conta
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <PaymentMethodsDialog />
    </div>
  );
};

export default PlansPage;
