import React, { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { UserRole, Driver, DriverStatus } from "@/types";
import { toast } from "sonner";
import { User, Mail, Phone, MapPin, Calendar, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const Profile = () => {
  const { user, loading } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [profileLoading, setProfileLoading] = useState(true);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    cpf: "",
    rg: "",
    cnh: "",
    cnhExpires: "",
    dateOfBirth: "",
  });

  useEffect(() => {
    const fetchDriverData = async () => {
      if (user && user.role === UserRole.DRIVER) {
        setProfileLoading(true);
        console.log('=== BUSCANDO DADOS DO MOTORISTA NO PERFIL ===');
        console.log('Email do usuário:', user.email);
        
        try {
          // Primeiro tentar buscar na tabela driver_registrations
          console.log('1. Buscando em driver_registrations...');
          const { data: driverRegistration, error: regError } = await supabase
            .from('driver_registrations')
            .select('*')
            .eq('email', user.email)
            .maybeSingle();

          if (regError) {
            console.error('Erro ao buscar em driver_registrations:', regError);
          }

          if (driverRegistration) {
            console.log('✅ Dados encontrados em driver_registrations:');
            console.log('CNH:', driverRegistration.cnh);
            console.log('CNH Expires:', driverRegistration.cnh_expires);
            console.log('ZIP Code:', driverRegistration.zip_code);
            console.log('Full data:', driverRegistration);
            
            setFormData({
              fullName: driverRegistration.full_name || "",
              email: driverRegistration.email || "",
              phone: driverRegistration.phone || "",
              address: driverRegistration.address || "",
              city: driverRegistration.city || "",
              state: driverRegistration.state || "",
              zipCode: driverRegistration.zip_code || "",
              cpf: driverRegistration.cpf || "",
              rg: "", // RG não está em driver_registrations
              cnh: driverRegistration.cnh || "",
              cnhExpires: driverRegistration.cnh_expires || "",
              dateOfBirth: driverRegistration.date_of_birth || "",
            });
          } else {
            // Se não encontrou em driver_registrations, buscar na tabela drivers
            console.log('2. Não encontrado em driver_registrations, buscando em drivers...');
            const { data: driver, error: driverError } = await supabase
              .from('drivers')
              .select('*')
              .eq('email', user.email)
              .maybeSingle();

            if (driverError) {
              console.error('Erro ao buscar em drivers:', driverError);
            }

            if (driver) {
              console.log('✅ Dados encontrados em drivers:');
              console.log('CNH:', driver.cnh);
              console.log('CNH Expires:', driver.cnh_expires);
              console.log('ZIP Code:', driver.zip_code);
              console.log('Full data:', driver);
              
              setFormData({
                fullName: driver.full_name || "",
                email: driver.email || "",
                phone: driver.phone || "",
                address: driver.address || "",
                city: driver.city || "",
                state: driver.state || "",
                zipCode: driver.zip_code || "",
                cpf: driver.cpf || "",
                rg: driver.rg || "",
                cnh: driver.cnh || "",
                cnhExpires: driver.cnh_expires || "",
                dateOfBirth: driver.date_of_birth || "",
              });
            } else {
              console.log('3. Não encontrado em drivers, usando dados do contexto...');
              // Fallback para dados do contexto de auth
              setFormData({
                fullName: user.fullName || user.name || "",
                email: user.email,
                phone: user.phone || "",
                address: user.address || "",
                city: user.city || "",
                state: user.state || "",
                zipCode: user.zipCode || "",
                cpf: user.cpf || "",
                rg: user.rg || "",
                cnh: user.cnh || "",
                cnhExpires: user.cnh_expires || "",
                dateOfBirth: user.date_of_birth || "",
              });
            }
          }

          console.log('=== DADOS FINAIS CARREGADOS NO PERFIL ===');
          console.log('CNH final:', formData.cnh);
          console.log('CNH Expires final:', formData.cnhExpires);
          console.log('ZIP Code final:', formData.zipCode);
          console.log('========================================');

        } catch (error) {
          console.error('Erro ao buscar dados do motorista:', error);
          toast.error('Erro ao carregar dados do perfil');
        } finally {
          setProfileLoading(false);
        }
      } else if (user) {
        // Para outros tipos de usuário, usar dados básicos
        setFormData({
          fullName: user.fullName || user.name || "",
          email: user.email,
          phone: user.phone || "",
          address: user.address || "",
          city: user.city || "",
          state: user.state || "",
          zipCode: "",
          cpf: user.cpf || "",
          rg: user.rg || "",
          cnh: user.cnh || "",
          cnhExpires: user.cnh_expires || "",
          dateOfBirth: user.date_of_birth || "",
        });
        setProfileLoading(false);
      }
    };

    fetchDriverData();
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    
    try {
      console.log('=== SALVANDO DADOS DO PERFIL ===');
      console.log('CNH a salvar:', formData.cnh);
      console.log('CNH Expires a salvar:', formData.cnhExpires);
      console.log('ZIP Code a salvar:', formData.zipCode);
      
      // Primeiro tentar atualizar na tabela drivers (se existir)
      const { error: driverError } = await supabase
        .from('drivers')
        .update({
          full_name: formData.fullName,
          phone: formData.phone,
          address: formData.address,
          city: formData.city,
          state: formData.state,
          zip_code: formData.zipCode,
          cnh: formData.cnh,
          cnh_expires: formData.cnhExpires || null,
          date_of_birth: formData.dateOfBirth || null,
          rg: formData.rg
        })
        .eq('email', user.email);

      if (driverError) {
        console.log('Erro ao atualizar drivers, tentando driver_registrations...');
        
        // Se falhou na tabela drivers, tentar na driver_registrations
        const { error: regError } = await supabase
          .from('driver_registrations')
          .update({
            full_name: formData.fullName,
            phone: formData.phone,
            address: formData.address,
            city: formData.city,
            state: formData.state,
            zip_code: formData.zipCode,
            cnh: formData.cnh,
            cnh_expires: formData.cnhExpires || null,
            date_of_birth: formData.dateOfBirth || null
          })
          .eq('email', user.email);

        if (regError) {
          console.error('Erro ao atualizar perfil:', regError);
          throw regError;
        }
      }

      console.log('✅ Perfil atualizado com sucesso');
      toast.success("Perfil atualizado com sucesso!");
      setIsEditing(false);
    } catch (error) {
      console.error('Erro ao salvar perfil:', error);
      toast.error("Erro ao atualizar perfil");
    }
  };

  const getUserRoleLabel = () => {
    switch (user?.role) {
      case UserRole.DRIVER:
        return "Motorista";
      case UserRole.RENTAL_COMPANY:
        return "Locadora";
      case UserRole.MANAGER:
        return "Gestor";
      case UserRole.INSPECTOR:
        return "Vistoriador";
      case UserRole.ANALYST:
        return "Analista";
      case UserRole.ADMIN:
        return "Administrador";
      default:
        return "Usuário";
    }
  };

  const getStatusLabel = () => {
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      const statusLabels = {
        pending: "Em Aberto",
        under_review: "Em Análise",
        approved: "Aprovado",
        rejected: "Rejeitado",
        deactivated: "Desativado",
        blacklisted: "Negativado"
      };
      return statusLabels[driver.status as keyof typeof statusLabels] || "Desconhecido";
    }
    return "Ativo";
  };

  const getStatusColor = () => {
    if (user?.role === UserRole.DRIVER) {
      const driver = user as Driver;
      const statusColors = {
        pending: "bg-blue-500",
        under_review: "bg-yellow-500",
        approved: "bg-green-500",
        rejected: "bg-red-500",
        deactivated: "bg-gray-500",
        blacklisted: "bg-red-600"
      };
      return statusColors[driver.status as keyof typeof statusColors] || "bg-gray-500";
    }
    return "bg-green-500";
  };

  const getUserInitials = () => {
    const name = user?.fullName || user?.name || user?.email || "U";
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  // Verificar se o motorista pode editar (status em aberto)
  const canEdit = user?.role === UserRole.DRIVER && (user as Driver).status === DriverStatus.PENDING;

  if (loading || profileLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Carregando perfil...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-lg text-muted-foreground">Usuário não encontrado</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Meu Perfil</h1>
          <p className="text-muted-foreground mt-1">
            Gerencie suas informações pessoais e dados de cadastro
          </p>
        </div>
        {canEdit && (
          <Button
            onClick={() => setIsEditing(!isEditing)}
            variant={isEditing ? "outline" : "default"}
            size="lg"
          >
            {isEditing ? "Cancelar" : "Editar Perfil"}
          </Button>
        )}
      </div>

      {/* Profile Header Card */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex items-center space-x-6">
            <Avatar className="w-24 h-24">
              <AvatarImage 
                src={user.role === UserRole.DRIVER ? (user as Driver).profile_photo : undefined} 
                alt="Foto do perfil" 
              />
              <AvatarFallback className="text-2xl font-semibold">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-900">
                {formData.fullName || user.name}
              </h2>
              <p className="text-muted-foreground mb-2">{formData.email}</p>
              <div className="flex items-center gap-4">
                <Badge className={`${getStatusColor()} text-white`}>
                  {getStatusLabel()}
                </Badge>
                <Badge variant="outline">
                  {getUserRoleLabel()}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Informações Pessoais */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Informações Pessoais
            </CardTitle>
            <CardDescription>
              Dados básicos e informações de identificação
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div>
                <Label htmlFor="fullName">Nome Completo</Label>
                <Input
                  id="fullName"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  disabled={!isEditing}
                />
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  disabled={!isEditing}
                />
              </div>

              <div>
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  disabled={!isEditing}
                  placeholder="(00) 00000-0000"
                />
              </div>

              <div>
                <Label htmlFor="dateOfBirth">Data de Nascimento</Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  disabled={!isEditing}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Documentos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Documentos
            </CardTitle>
            <CardDescription>
              Documentação pessoal e habilitação
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div>
                <Label htmlFor="cpf">CPF</Label>
                <Input
                  id="cpf"
                  value={formData.cpf}
                  onChange={(e) => setFormData({ ...formData, cpf: e.target.value })}
                  disabled={!isEditing}
                  placeholder="000.000.000-00"
                />
              </div>

              <div>
                <Label htmlFor="rg">RG</Label>
                <Input
                  id="rg"
                  value={formData.rg}
                  onChange={(e) => setFormData({ ...formData, rg: e.target.value })}
                  disabled={!isEditing}
                  placeholder="00.000.000-0"
                />
              </div>

              <div>
                <Label htmlFor="cnh">CNH</Label>
                <Input
                  id="cnh"
                  value={formData.cnh}
                  onChange={(e) => setFormData({ ...formData, cnh: e.target.value })}
                  disabled={!isEditing}
                  placeholder="00000000000"
                />
                {!formData.cnh && (
                  <p className="text-sm text-red-500 mt-1">
                    ⚠️ CNH não encontrada no perfil - Valor atual: "{formData.cnh}"
                  </p>
                )}
                {formData.cnh && (
                  <p className="text-sm text-green-600 mt-1">
                    ✅ CNH: {formData.cnh}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="cnhExpires">Validade da CNH</Label>
                <Input
                  id="cnhExpires"
                  type="date"
                  value={formData.cnhExpires}
                  onChange={(e) => setFormData({ ...formData, cnhExpires: e.target.value })}
                  disabled={!isEditing}
                />
                {!formData.cnhExpires && (
                  <p className="text-sm text-red-500 mt-1">
                    ⚠️ Data de validade da CNH não encontrada - Valor atual: "{formData.cnhExpires}"
                  </p>
                )}
                {formData.cnhExpires && (
                  <p className="text-sm text-green-600 mt-1">
                    ✅ Validade CNH: {new Date(formData.cnhExpires).toLocaleDateString('pt-BR')}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Endereço */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Endereço
            </CardTitle>
            <CardDescription>
              Informações de localização e residência
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="lg:col-span-2">
                <Label htmlFor="address">Endereço Completo</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  disabled={!isEditing}
                  placeholder="Rua, número, bairro"
                />
              </div>

              <div>
                <Label htmlFor="city">Cidade</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  disabled={!isEditing}
                />
              </div>

              <div>
                <Label htmlFor="state">Estado</Label>
                <Input
                  id="state"
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  disabled={!isEditing}
                />
              </div>

              <div>
                <Label htmlFor="zipCode">CEP</Label>
                <Input
                  id="zipCode"
                  value={formData.zipCode}
                  onChange={(e) => setFormData({ ...formData, zipCode: e.target.value })}
                  disabled={!isEditing}
                  placeholder="00000-000"
                />
                {!formData.zipCode && (
                  <p className="text-sm text-red-500 mt-1">
                    ⚠️ CEP não encontrado no perfil - Valor atual: "{formData.zipCode}"
                  </p>
                )}
                {formData.zipCode && (
                  <p className="text-sm text-green-600 mt-1">
                    ✅ CEP: {formData.zipCode}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Botão de Salvar */}
      {isEditing && (
        <Card className="mt-6">
          <CardContent className="pt-6">
            <div className="flex justify-end space-x-4">
              <Button 
                variant="outline" 
                onClick={() => setIsEditing(false)}
              >
                Cancelar
              </Button>
              <Button onClick={handleSave} size="lg">
                Salvar Alterações
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Profile;
