
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogTrigger, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Building, Search, Eye, Calendar, DollarSign, X } from "lucide-react";
import { RentalCompanyDetailsModal } from "./components/RentalCompanyDetailsModal";
import { EditRentalCompanyModal } from "./components/EditRentalCompanyModal";
import { useRentalCompanies, RentalCompanyData } from "@/hooks/useRentalCompanies";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";

const AdminRentalCompanies = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCompany, setSelectedCompany] = useState<RentalCompanyData | null>(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [companyToDelete, setCompanyToDelete] = useState<RentalCompanyData | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editCompany, setEditCompany] = useState<RentalCompanyData | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const { companies, loading, updateCompanyStatus, updateCompany, deleteCompany } = useRentalCompanies();

  const handleViewDetails = (company: RentalCompanyData) => {
    setSelectedCompany(company);
    setIsDetailsModalOpen(true);
  };

  const handleStatusChange = (companyId: string, newStatus: boolean) => {
    updateCompanyStatus(companyId, newStatus);
  };

  const handleDeleteCompany = (companyId: string) => {
    deleteCompany(companyId);
    setIsDeleteDialogOpen(false);
    setCompanyToDelete(null);
  };

  const handleEditCompany = (company: RentalCompanyData) => {
    setEditCompany(company);
    setIsEditModalOpen(true);
  };

  const handleSaveCompany = (updated: RentalCompanyData) => {
    updateCompany(updated.id, updated);
    setEditCompany(null);
    setIsEditModalOpen(false);
  };

  const getPaymentStatusBadge = (status: string) => {
    const statusConfig = {
      paid: { label: "Pago", className: "bg-green-100 text-green-800" },
      pending: { label: "Pendente", className: "bg-yellow-100 text-yellow-800" },
      overdue: { label: "Vencido", className: "bg-red-100 text-red-800" },
      trial: { label: "Trial", className: "bg-blue-100 text-blue-800" }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || { 
      label: status || "Desconhecido", 
      className: "bg-gray-100 text-gray-800" 
    };
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const getPlanBadge = (plan: string) => {
    const planConfig = {
      basic: { className: "bg-gray-100 text-gray-800" },
      premium: { className: "bg-blue-100 text-blue-800" },
      enterprise: { className: "bg-purple-100 text-purple-800" }
    };
    
    const config = planConfig[plan as keyof typeof planConfig] || { 
      className: "bg-gray-100 text-gray-800" 
    };
    return <Badge className={config.className}>{plan || "Básico"}</Badge>;
  };

  const getStatusBadge = (isActive: boolean) => {
    return (
      <Badge className={isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
        {isActive ? 'Ativa' : 'Desativada'}
      </Badge>
    );
  };

  if (loading) {
    return <FuturisticLoading />;
  }

  const filteredCompanies = companies.filter(company =>
    company.company_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    company.cnpj.includes(searchTerm)
  );

  const totalCompanies = companies.length;
  const activeCompanies = companies.filter(c => c.is_active && c.payment_status === "paid").length;
  const pendingPayments = companies.filter(c => c.payment_status === "pending" || c.payment_status === "overdue").length;
  const inactiveCompanies = companies.filter(c => !c.is_active).length;

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Locadoras Cadastradas</h1>
        <p className="text-muted-foreground">
          Gerencie todas as locadoras registradas na plataforma
        </p>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Locadoras</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCompanies}</div>
            <p className="text-xs text-muted-foreground">
              Cadastradas na plataforma
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Locadoras Ativas</CardTitle>
            <Building className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{activeCompanies}</div>
            <p className="text-xs text-muted-foreground">
              Com pagamentos em dia
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagamentos Pendentes</CardTitle>
            <DollarSign className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingPayments}</div>
            <p className="text-xs text-muted-foreground">
              Requerem atenção
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Locadoras Desativadas</CardTitle>
            <Building className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{inactiveCompanies}</div>
            <p className="text-xs text-muted-foreground">
              Necessitam atenção
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou CNPJ..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Locadoras */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Locadoras</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>CNPJ</TableHead>
                <TableHead>Plano</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Status Pagamento</TableHead>
                <TableHead>Vencimento</TableHead>
                <TableHead>Veículos</TableHead>
                <TableHead>Motoristas</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCompanies.map((company) => (
                <TableRow key={company.id}>
                  <TableCell className="font-medium">{company.company_name}</TableCell>
                  <TableCell>{company.cnpj}</TableCell>
                  <TableCell>{getPlanBadge(company.plan)}</TableCell>
                  <TableCell>{getStatusBadge(company.is_active)}</TableCell>
                  <TableCell>{getPaymentStatusBadge(company.payment_status)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      {company.due_date ? new Date(company.due_date).toLocaleDateString('pt-BR') : 'N/A'}
                    </div>
                  </TableCell>
                  <TableCell>{company.vehicle_count}</TableCell>
                  <TableCell>{company.drivers_count}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleViewDetails(company)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Ver Detalhes
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => handleEditCompany(company)}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path d="M16.474 5.842L18.158 7.526a2.121 2.121 0 010 3.001l-8.486 8.485a2.5 2.5 0 01-1.06.637l-3.53 1.056a.5.5 0 01-.632-.632l1.055-3.53c.14-.468.358-.897.636-1.06l8.487-8.485a2.121 2.121 0 013.001 0z" />
                        </svg>
                        Editar
                      </Button>
                      <AlertDialog open={isDeleteDialogOpen && companyToDelete?.id === company.id} onOpenChange={(open) => {
                        if (!open) {
                          setIsDeleteDialogOpen(false);
                          setCompanyToDelete(null);
                        }
                      }}>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setCompanyToDelete(company);
                              setIsDeleteDialogOpen(true);
                            }}
                          >
                            <X className="h-4 w-4 mr-1" />
                            Excluir
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Tem certeza que deseja excluir esta locadora?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Esta ação não poderá ser desfeita. Todos os dados relacionados à locadora <span className="font-semibold">{company.company_name}</span> serão removidos da plataforma.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDeleteCompany(company.id)}>
                              Confirmar Exclusão
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Modal de Detalhes */}
      <RentalCompanyDetailsModal
        company={selectedCompany}
        isOpen={isDetailsModalOpen}
        onClose={() => setIsDetailsModalOpen(false)}
        onStatusChange={handleStatusChange}
      />
      {/* Modal de Edição */}
      <EditRentalCompanyModal
        company={editCompany}
        isOpen={isEditModalOpen}
        onClose={() => { setIsEditModalOpen(false); setEditCompany(null); }}
        onSave={handleSaveCompany}
      />
    </div>
  );
};

export default AdminRentalCompanies;
