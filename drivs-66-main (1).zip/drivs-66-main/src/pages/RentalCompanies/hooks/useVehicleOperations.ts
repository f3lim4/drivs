
import { useState } from "react";
import { Vehicle, VehicleWithEditData } from "../types/vehicle";
import { useRentalCompanyVehicles, RentalCompanyVehicle } from "@/hooks/useRentalCompanyVehicles";

export const useVehicleOperations = () => {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [openVehicleForm, setOpenVehicleForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | VehicleWithEditData | null>(null);

  const { vehicles, loading, createVehicle, updateVehicle, deleteVehicle } = useRentalCompanyVehicles();

  const handleAddVehicle = () => {
    console.log('Adding vehicle...');
    setSelectedVehicle(null);
    setOpenVehicleForm(true);
  };

  const handleVehicleSubmit = async (vehicleData: any) => {
    try {
      console.log('Submitting vehicle data:', vehicleData);
      
      if (selectedVehicle && 'id' in selectedVehicle) {
        // Editar veículo existente
        console.log('Editing existing vehicle:', selectedVehicle.id);
        
        const updateData: Partial<RentalCompanyVehicle> = {
          brand: vehicleData.brand,
          model: vehicleData.model,
          plate: vehicleData.plate,
          year: vehicleData.year,
          color: vehicleData.color,
          status: vehicleData.status as RentalCompanyVehicle['status'],
          vehicle_type: vehicleData.type || vehicleData.vehicle_type || vehicleData.vehicleType,
          fuel_type: vehicleData.fuelType,
          transmission_type: vehicleData.transmissionType,
          mileage: vehicleData.mileage,
          weekly_value: vehicleData.weeklyValue,
          deposit_value: vehicleData.depositValue,
          vehicle_value: vehicleData.vehicleValue,
          is_financed: vehicleData.isFinanced,
          monthly_installment: vehicleData.monthlyInstallment,
          monthly_insurance: vehicleData.insuranceValue || vehicleData.monthlyInsurance,
          monthly_tracker: vehicleData.trackerValue || vehicleData.monthlyTracker,
          ipva_value: vehicleData.ipvaValue,
          km_type: vehicleData.kmType as RentalCompanyVehicle['km_type'],
          km_limit: vehicleData.kmLimit,
          licensing_status: vehicleData.licensingStatus === "Em dia" ? "up_to_date" : "overdue",
          document_expiry: vehicleData.documentExpiry,
          maintenance_responsibility: vehicleData.maintenanceResponsibility as RentalCompanyVehicle['maintenance_responsibility'],
          allow_reservation: vehicleData.allowReservation,
          description: vehicleData.observations || vehicleData.description,
          renavam: vehicleData.renavam,
          chassi: vehicleData.chassi,
          licensing_expiry: vehicleData.licensingExpiry,
          last_revision_km: vehicleData.lastRevisionKm,
          observations: vehicleData.observations
        };

        await updateVehicle(selectedVehicle.id, updateData);
      } else {
        // Criar novo veículo
        console.log('Creating new vehicle');
        
        const createData: Omit<RentalCompanyVehicle, 'id' | 'created_at' | 'updated_at'> = {
          company_id: "", // Será preenchido automaticamente no hook
          brand: vehicleData.brand,
          model: vehicleData.model,
          plate: vehicleData.plate,
          year: vehicleData.year,
          color: vehicleData.color,
          status: (vehicleData.status || "available") as RentalCompanyVehicle['status'],
          vehicle_type: vehicleData.type || vehicleData.vehicle_type || vehicleData.vehicleType || "Sedan",
          fuel_type: vehicleData.fuelType,
          transmission_type: vehicleData.transmissionType || "Manual",
          mileage: vehicleData.mileage || 0,
          weekly_value: vehicleData.weeklyValue,
          deposit_value: vehicleData.depositValue,
          vehicle_value: vehicleData.vehicleValue,
          is_financed: vehicleData.isFinanced || false,
          monthly_installment: vehicleData.monthlyInstallment,
          monthly_insurance: vehicleData.insuranceValue || vehicleData.monthlyInsurance,
          monthly_tracker: vehicleData.trackerValue || vehicleData.monthlyTracker || 45,
          ipva_value: vehicleData.ipvaValue,
          km_type: (vehicleData.kmType || "unlimited") as RentalCompanyVehicle['km_type'],
          km_limit: vehicleData.kmLimit,
          licensing_status: vehicleData.licensingStatus === "Em dia" ? "up_to_date" : "overdue",
          document_expiry: vehicleData.documentExpiry,
          maintenance_responsibility: (vehicleData.maintenanceResponsibility || "rental_company") as RentalCompanyVehicle['maintenance_responsibility'],
          allow_reservation: vehicleData.allowReservation ?? true,
          description: vehicleData.observations || vehicleData.description,
          images: vehicleData.images || [],
          renavam: vehicleData.renavam,
          chassi: vehicleData.chassi,
          licensing_expiry: vehicleData.licensingExpiry,
          last_revision_km: vehicleData.lastRevisionKm,
          observations: vehicleData.observations
        };

        await createVehicle(createData);
      }
      
      // Fechar modais
      setOpenVehicleForm(false);
      setShowEditDialog(false);
      setSelectedVehicle(null);
      
    } catch (error) {
      console.error("Error saving vehicle:", error);
      // O toast de erro já é mostrado no hook useRentalCompanyVehicles
    }
  };

  const handleViewVehicle = (vehicle: RentalCompanyVehicle) => {
    console.log('Viewing vehicle:', vehicle);
    setSelectedVehicle(vehicle as any);
    setShowViewModal(true);
  };

  const handleEditVehicle = (vehicle: RentalCompanyVehicle) => {
    console.log('Editing vehicle:', vehicle);
    
    const vehicleWithEditData: VehicleWithEditData = {
      ...vehicle,
      brand: vehicle.brand,
      model: vehicle.model,
      type: vehicle.vehicle_type,
      plate: vehicle.plate,
      year: vehicle.year,
      color: vehicle.color,
      status: vehicle.status,
      images: vehicle.images || [],
      weeklyValue: vehicle.weekly_value,
      depositValue: vehicle.deposit_value,
      kmType: vehicle.km_type,
      transmissionType: vehicle.transmission_type,
      allowReservation: vehicle.allow_reservation,
      renavam: vehicle.renavam || "123456789",
      chassi: vehicle.chassi || "9BWZZZ377VT004251",
      fuelType: vehicle.fuel_type || "flex",
      vehicleValue: vehicle.vehicle_value || 85000,
      ipvaValue: vehicle.ipva_value || 2550,
      insuranceValue: vehicle.monthly_insurance || 350,
      trackerValue: vehicle.monthly_tracker || 45,
      isFinanced: vehicle.is_financed ?? false,
      observations: vehicle.observations || vehicle.description || "",
      licensingExpiry: vehicle.licensing_expiry || "2025-03-15",
      licensingStatus: vehicle.licensing_status === "up_to_date" ? "Em dia" : "Vencido",
      lastRevisionKm: vehicle.last_revision_km || 45230,
      driverInfo: undefined
    };
    
    setSelectedVehicle(vehicleWithEditData);
    setShowEditDialog(true);
  };

  const handleDeleteVehicle = async (vehicleId: string) => {
    try {
      console.log('Deleting vehicle:', vehicleId);
      await deleteVehicle(vehicleId);
    } catch (error) {
      console.error("Error deleting vehicle:", error);
    }
  };

  return {
    search,
    setSearch,
    status,
    setStatus,
    openVehicleForm,
    setOpenVehicleForm,
    showViewModal,
    setShowViewModal,
    showEditDialog,
    setShowEditDialog,
    selectedVehicle,
    setSelectedVehicle,
    handleAddVehicle,
    handleVehicleSubmit,
    handleViewVehicle,
    handleEditVehicle,
    handleDeleteVehicle,
    vehicles,
    loading
  };
};
