
import { Vehicle } from "../types/vehicle";

const mockVehicles: Vehicle[] = [];

export const getVehiclesByCompany = (companyId: string): Vehicle[] => {
  return [];
};

const sortVehiclesByStatus = (vehicles: Vehicle[]): Vehicle[] => {
  const statusOrder = { "available": 1, "rented": 2, "maintenance": 3, "stopped": 4 };
  return vehicles.sort((a, b) => {
    const orderA = statusOrder[a.status] || 5;
    const orderB = statusOrder[b.status] || 5;
    return orderA - orderB;
  });
};
