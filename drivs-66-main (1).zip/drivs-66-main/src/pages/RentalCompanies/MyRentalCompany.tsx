
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Building2, Users, Car, Phone, Mail, MapPin, Star, Calendar, FileText, Clock, AlertTriangle, Ban } from "lucide-react";
import { toast } from "sonner";

const MyRentalCompany = () => {
  const { user } = useAuth();
  const [companyData, setCompanyData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  if (!user || user.role !== UserRole.DRIVER) {
    return <div>Acesso não autorizado</div>;
  }

  const driver = user as Driver;
  const isActiveDriver = !!driver.activeContract && driver.status !== "deactivated";
  const isDeactivatedDriver = driver.status === "deactivated";

  useEffect(() => {
    // Simulando dados da locadora baseado no contrato ativo ou informações de desativação
    if (driver.activeContract || isDeactivatedDriver) {
      const contractStart = new Date(driver.activeContract?.contractStart || '');
      const contractEnd = new Date(driver.activeContract?.contractEnd || '');
      const contractOpened = new Date('2024-01-10'); // Data quando o contrato foi aberto/assinado
      
      const mockCompanyData = {
        id: driver.activeContract?.companyId || 1,
        name: driver.activeContract?.companyName || (driver as any).deactivationInfo?.rentalCompany || "Auto Rental Plus",
        cnpj: "12.345.678/0001-90",
        phone: "(11) 3456-7890",
        email: "contato@autorentalplus.com.br",
        address: "Av. Paulista, 1000 - Bela Vista, São Paulo - SP, 01310-100",
        rating: 4.8,
        contractStartDate: driver.activeContract?.contractStart,
        contractEndDate: driver.activeContract?.contractEnd,
        contractOpenedDate: contractOpened.toISOString(),
        logo: "/placeholder.svg",
        description: "Locadora especializada em veículos para motoristas de aplicativo com mais de 10 anos de experiência no mercado.",
        ...(isDeactivatedDriver && {
          deactivationInfo: (driver as any).deactivationInfo
        })
      };
      setCompanyData(mockCompanyData);
    }
    setLoading(false);
  }, [driver, isActiveDriver, isDeactivatedDriver]);

  const handleContact = () => {
    toast.success("Entrando em contato com a locadora...");
  };

  const handleOpenRequest = () => {
    toast.success("Abrindo solicitação...");
  };

  if (!driver.activeContract && !isDeactivatedDriver) {
    return (
      <div className="min-h-screen bg-background dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Card className="bg-card dark:bg-gray-800">
            <CardContent className="p-6 text-center">
              <p className="text-muted-foreground">Você precisa ter um contrato ativo para visualizar sua locadora.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-64"></div>
            <div className="h-64 bg-gray-300 dark:bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-foreground dark:text-white">Minha Locadora</h1>
            <p className="text-lg text-muted-foreground dark:text-gray-300 mt-1">
              {isDeactivatedDriver ? "Informações da locadora que desativou seu contrato" : "Informações da sua locadora atual"}
            </p>
          </div>

          {/* Alerta para motorista desativado */}
          {isDeactivatedDriver && companyData.deactivationInfo && (
            <Alert className="border-red-500 bg-red-50 dark:bg-red-900/20">
              <Ban className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800 dark:text-red-200">
                <div className="space-y-2">
                  <p className="font-semibold">Contrato Desativado</p>
                  <div className="text-sm space-y-1">
                    <p><strong>Motivo:</strong> {companyData.deactivationInfo.reason}</p>
                    <p><strong>Data da desativação:</strong> {new Date(companyData.deactivationInfo.deactivatedAt).toLocaleDateString('pt-BR', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}</p>
                  </div>
                  <p className="text-xs mt-2">
                    Entre em contato com a locadora para esclarecimentos ou resolução de pendências.
                  </p>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Informações Principais da Locadora */}
          <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
                    <Building2 className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <CardTitle className="text-xl text-foreground dark:text-white">{companyData.name}</CardTitle>
                    <p className="text-sm text-muted-foreground dark:text-gray-400">CNPJ: {companyData.cnpj}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="h-4 w-4 text-yellow-500 fill-current" />
                      <span className="text-sm font-medium text-foreground dark:text-white">{companyData.rating}</span>
                      <span className="text-sm text-muted-foreground dark:text-gray-400">(4.8/5.0)</span>
                    </div>
                  </div>
                </div>
                <Badge className={isDeactivatedDriver ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300" : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"}>
                  {isDeactivatedDriver ? "Desativado" : "Ativo"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground dark:text-gray-300">
                {companyData.description}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground dark:text-gray-300">
                  <Phone className="h-4 w-4" />
                  <span>{companyData.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground dark:text-gray-300">
                  <Mail className="h-4 w-4" />
                  <span>{companyData.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground dark:text-gray-300 md:col-span-2">
                  <MapPin className="h-4 w-4" />
                  <span>{companyData.address}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Informações do Contrato */}
          <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
            <CardHeader>
              <CardTitle className="text-foreground dark:text-white">
                {isDeactivatedDriver ? "Informações do Contrato Desativado" : "Informações do Contrato"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-foreground dark:text-white">Veículo</p>
                  <p className="text-sm text-muted-foreground dark:text-gray-400">{driver.activeContract?.vehicleModel || "Honda Civic"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground dark:text-white">Status do Contrato</p>
                  <Badge className={isDeactivatedDriver ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300" : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"}>
                    {isDeactivatedDriver ? "Desativado" : "Ativo"}
                  </Badge>
                </div>
                {!isDeactivatedDriver && (
                  <>
                    <div>
                      <p className="text-sm font-medium text-foreground dark:text-white">Contrato Aberto em</p>
                      <p className="text-sm text-muted-foreground dark:text-gray-400">
                        {new Date(companyData.contractOpenedDate).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground dark:text-white">Data de Início</p>
                      <p className="text-sm text-muted-foreground dark:text-gray-400">
                        {new Date(driver.activeContract?.contractStart || '').toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground dark:text-white">Data de Término</p>
                      <p className="text-sm text-muted-foreground dark:text-gray-400">
                        {new Date(driver.activeContract?.contractEnd || '').toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground dark:text-white">Renovação/Encerramento</p>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-orange-500" />
                        <p className="text-sm text-orange-600 dark:text-orange-400">
                          Renovar ou encerrar até {new Date(driver.activeContract?.contractEnd || '').toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Ações Rápidas */}
          <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
            <CardHeader>
              <CardTitle className="text-foreground dark:text-white">
                {isDeactivatedDriver ? "Suporte e Contato" : "Ações Rápidas"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                <Button 
                  onClick={handleContact}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Entrar em Contato
                </Button>
                {!isDeactivatedDriver && (
                  <Button 
                    onClick={handleOpenRequest}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Abrir Solicitação
                  </Button>
                )}
                <Button variant="outline" className="border-border dark:border-gray-600 text-foreground dark:text-white hover:bg-accent dark:hover:bg-gray-700">
                  <Mail className="h-4 w-4 mr-2" />
                  Enviar E-mail
                </Button>
                <Button variant="outline" className="border-border dark:border-gray-600 text-foreground dark:text-white hover:bg-accent dark:hover:bg-gray-700">
                  <MapPin className="h-4 w-4 mr-2" />
                  Ver Localização
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default MyRentalCompany;
