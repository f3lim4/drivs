
import RentalCompanyVehiclesPage from "./RentalCompanyVehiclesPage";
export default RentalCompanyVehiclesPage;
