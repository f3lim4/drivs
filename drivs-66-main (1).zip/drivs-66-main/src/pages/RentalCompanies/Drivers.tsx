
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { UserRole, DriverStatus } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { 
  Search, 
  Eye, 
  UserCheck, 
  UserX, 
  Clock,
  Users,
  CheckCircle,
  XCircle,
  AlertCircle
} from "lucide-react";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";

interface Driver {
  id: string;
  full_name: string;
  cpf: string;
  rg?: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  cnh?: string;
  cnh_expires?: string;
  email?: string;
  date_of_birth?: string;
  status: DriverStatus;
  available: boolean;
  rating: number;
  violations: number;
  created_at: string;
  updated_at: string;
  rejection_reason?: string;
  rejection_date?: string;
  company_id?: string;
  source?: 'drivers' | 'registrations';
}

const RentalCompanyDriversPage = () => {
  const { user } = useAuth();
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const loadDrivers = async () => {
    if (!user || user.role !== UserRole.RENTAL_COMPANY) {
      setLoading(false);
      return;
    }

    try {
      console.log('🏢 Carregando motoristas para locadora:', user.id);
      setLoading(true);

      // Buscar motoristas da tabela drivers
      const { data: driversData, error: driversError } = await supabase
        .from('drivers')
        .select(`
          *,
          rental_companies!drivers_company_id_fkey (
            id,
            company_name
          )
        `)
        .eq('company_id', user.id)
        .order('created_at', { ascending: false });

      if (driversError && driversError.code !== 'PGRST116') {
        console.error('Erro ao carregar motoristas da tabela drivers:', driversError);
      }

      // Buscar motoristas da tabela driver_registrations
      const { data: registrationsData, error: registrationsError } = await supabase
        .from('driver_registrations')
        .select('*')
        .eq('referral_company_id', user.id)
        .order('created_at', { ascending: false });

      if (registrationsError && registrationsError.code !== 'PGRST116') {
        console.error('Erro ao carregar registros de motoristas:', registrationsError);
      }

      let allDrivers: Driver[] = [];

      // Adicionar motoristas da tabela drivers
      if (driversData) {
        allDrivers = driversData.map((driver) => ({
          ...driver,
          status: driver.status as DriverStatus, // Cast to enum
          available: driver.available ?? false,
          rating: driver.rating ?? 0,
          violations: driver.violations ?? 0,
          source: 'drivers' as const
        }));
      }

      // Adicionar motoristas da tabela driver_registrations que não estão em drivers
      if (registrationsData) {
        const existingDriverEmails = new Set(allDrivers.map(d => d.email?.toLowerCase()));
        const existingDriverCpfs = new Set(allDrivers.map(d => d.cpf));

        const registrationDrivers = registrationsData
          .filter(reg => {
            const emailExists = reg.email && existingDriverEmails.has(reg.email.toLowerCase());
            const cpfExists = reg.cpf && existingDriverCpfs.has(reg.cpf);
            return !emailExists && !cpfExists;
          })
          .map((reg) => ({
            id: reg.id,
            full_name: reg.full_name,
            cpf: reg.cpf,
            rg: '',
            phone: reg.phone,
            address: reg.address,
            city: reg.city,
            state: reg.state,
            cnh: reg.cnh || '',
            cnh_expires: reg.cnh_expires || undefined,
            email: reg.email || '',
            date_of_birth: reg.date_of_birth || undefined,
            status: reg.status as DriverStatus, // Cast to enum
            available: false,
            rating: 0,
            violations: 0,
            created_at: reg.created_at,
            updated_at: reg.updated_at,
            company_id: reg.referral_company_id,
            source: 'registrations' as const
          }));

        allDrivers = [...allDrivers, ...registrationDrivers];
      }

      console.log(`✅ Total de motoristas carregados: ${allDrivers.length}`);
      setDrivers(allDrivers);

    } catch (error: any) {
      console.error('Erro ao carregar motoristas:', error);
      toast.error('Erro ao carregar lista de motoristas');
      setDrivers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDrivers();
  }, [user]);

  const filteredDrivers = drivers.filter((driver) => {
    const matchesSearch = driver.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         driver.cpf?.includes(searchTerm) ||
                         driver.email?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const getStatusBadge = (status: DriverStatus) => {
    const statusConfig = {
      [DriverStatus.PENDING]: { 
        label: "Pendente", 
        variant: "outline" as const, 
        icon: Clock,
        className: "border-yellow-500 text-yellow-600" 
      },
      [DriverStatus.UNDER_REVIEW]: { 
        label: "Em Análise", 
        variant: "outline" as const,
        icon: AlertCircle,
        className: "border-blue-500 text-blue-600" 
      },
      [DriverStatus.APPROVED]: { 
        label: "Aprovado", 
        variant: "default" as const,
        icon: CheckCircle,
        className: "bg-green-500 text-white" 
      },
      [DriverStatus.ACTIVE]: { 
        label: "Ativo", 
        variant: "default" as const,
        icon: UserCheck,
        className: "bg-green-600 text-white" 
      },
      [DriverStatus.REJECTED]: { 
        label: "Rejeitado", 
        variant: "destructive" as const,
        icon: XCircle,
        className: "bg-red-500 text-white" 
      },
      [DriverStatus.DEACTIVATED]: { 
        label: "Desativado", 
        variant: "secondary" as const,
        icon: UserX,
        className: "bg-gray-500 text-white" 
      },
      [DriverStatus.BLACKLISTED]: { 
        label: "Bloqueado", 
        variant: "destructive" as const,
        icon: XCircle,
        className: "bg-red-700 text-white" 
      }
    };

    const config = statusConfig[status] || statusConfig[DriverStatus.PENDING];
    const Icon = config.icon;
    
    return (
      <Badge variant={config.variant} className={config.className}>
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  const getStatsCards = () => {
    const stats = {
      total: filteredDrivers.length,
      pending: filteredDrivers.filter(d => d.status === DriverStatus.PENDING).length,
      approved: filteredDrivers.filter(d => d.status === DriverStatus.APPROVED || d.status === DriverStatus.ACTIVE).length,
      rejected: filteredDrivers.filter(d => d.status === DriverStatus.REJECTED).length
    };

    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-sm text-muted-foreground">Pendentes</p>
                <p className="text-2xl font-bold">{stats.pending}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Aprovados</p>
                <p className="text-2xl font-bold">{stats.approved}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <XCircle className="h-5 w-5 text-red-500" />
              <div>
                <p className="text-sm text-muted-foreground">Rejeitados</p>
                <p className="text-2xl font-bold">{stats.rejected}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  if (!user || user.role !== UserRole.RENTAL_COMPANY) {
    return (
      <div className="container py-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">Acesso não autorizado</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return <FuturisticLoading />;
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Motoristas</h1>
          <p className="text-muted-foreground">
            Gerencie os motoristas cadastrados na sua locadora
          </p>
        </div>
      </div>

      {getStatsCards()}

      {/* Filtros de busca */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome, CPF ou email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Tabela de motoristas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Motoristas ({filteredDrivers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredDrivers.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Motorista</TableHead>
                    <TableHead>Contato</TableHead>
                    <TableHead>Localização</TableHead>
                    <TableHead>CNH</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Cadastro</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDrivers.map((driver) => (
                    <TableRow key={driver.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{driver.full_name}</p>
                          <p className="text-sm text-muted-foreground">CPF: {driver.cpf}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm">{driver.phone}</p>
                          {driver.email && (
                            <p className="text-sm text-muted-foreground">{driver.email}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <p className="text-sm">{driver.city}/{driver.state}</p>
                      </TableCell>
                      <TableCell>
                        <div>
                          {driver.cnh ? (
                            <>
                              <p className="text-sm font-medium">{driver.cnh}</p>
                              {driver.cnh_expires && (
                                <p className="text-sm text-muted-foreground">
                                  Vence: {new Date(driver.cnh_expires).toLocaleDateString('pt-BR')}
                                </p>
                              )}
                            </>
                          ) : (
                            <p className="text-sm text-muted-foreground">Não informado</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(driver.status)}
                      </TableCell>
                      <TableCell>
                        <p className="text-sm">
                          {new Date(driver.created_at).toLocaleDateString('pt-BR')}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {driver.source === 'registrations' ? 'Registro' : 'Sistema'}
                        </p>
                      </TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          Ver
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-10">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum motorista encontrado</h3>
              <p className="text-muted-foreground">
                {searchTerm 
                  ? 'Tente ajustar os filtros de busca.'
                  : 'Nenhum motorista foi cadastrado na sua locadora ainda.'
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default RentalCompanyDriversPage;
