
import { VehicleFilters } from "./VehicleFilters";
import { useVehicleOperationsContext } from "./VehicleOperationsProvider";

export const VehicleFiltersSection = () => {
  const { search, setSearch, status, setStatus } = useVehicleOperationsContext();

  return (
    <div className="flex flex-col md:flex-row gap-4 justify-between md:items-end">
      <VehicleFilters
        search={search}
        onSearch={setSearch}
        status={status}
        onStatusChange={setStatus}
      />
    </div>
  );
};
