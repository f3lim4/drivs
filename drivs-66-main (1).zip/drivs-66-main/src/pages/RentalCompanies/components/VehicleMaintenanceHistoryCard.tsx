
import { Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function VehicleMaintenanceHistoryCard() {
  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-lg flex items-center gap-2">
        <Calendar className="h-5 w-5" />
        Histórico e Manutenção
      </h4>
      <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
        <div>
          <label className="text-sm font-medium text-muted-foreground">Quilometragem Atual</label>
          <p className="text-lg font-semibold">45.230 km</p>
        </div>
        <div>
          <label className="text-sm font-medium text-muted-foreground">Última Revisão</label>
          <p className="font-semibold">15/01/2024</p>
        </div>
        <div>
          <label className="text-sm font-medium text-muted-foreground">Próxima Revisão</label>
          <p className="font-semibold">15/07/2024</p>
        </div>
        <div>
          <label className="text-sm font-medium text-muted-foreground">Infrações</label>
          <Badge className="bg-green-100 text-green-800">0 pendentes</Badge>
        </div>
      </div>
    </div>
  );
}
