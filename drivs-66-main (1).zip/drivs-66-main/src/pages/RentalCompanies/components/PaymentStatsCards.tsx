
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, Calendar, AlertTriangle, CheckCircle, Clock } from "lucide-react";

interface Payment {
  id: string;
  driver_name: string;
  vehicle_info: string;
  due_date: string;
  amount: number;
  status: "paid" | "pending" | "overdue" | "partial";
  paid_amount?: number;
}

interface PaymentStatsCardsProps {
  payments: Payment[];
}

export const PaymentStatsCards = ({ payments }: PaymentStatsCardsProps) => {
  const stats = [
    {
      title: "Total Recebido",
      value: `R$ ${payments.filter(p => p.status === "paid").reduce((sum, p) => sum + (p.paid_amount || 0), 0).toLocaleString('pt-BR')}`,
      icon: CheckCircle,
      color: "text-green-600"
    },
    {
      title: "Pendente",
      value: `R$ ${payments.filter(p => p.status === "pending").reduce((sum, p) => sum + p.amount, 0).toLocaleString('pt-BR')}`,
      icon: Clock,
      color: "text-yellow-600"
    },
    {
      title: "Em Atraso",
      value: `R$ ${payments.filter(p => p.status === "overdue").reduce((sum, p) => sum + p.amount, 0).toLocaleString('pt-BR')}`,
      icon: AlertTriangle,
      color: "text-red-600"
    },
    {
      title: "Taxa de Adimplência",
      value: `${payments.length > 0 ? ((payments.filter(p => p.status === "paid").length / payments.length) * 100).toFixed(1) : 0}%`,
      icon: DollarSign,
      color: "text-blue-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              {stat.title}
            </CardTitle>
            <stat.icon className={`h-5 w-5 ${stat.color}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${stat.color}`}>
              {stat.value}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
