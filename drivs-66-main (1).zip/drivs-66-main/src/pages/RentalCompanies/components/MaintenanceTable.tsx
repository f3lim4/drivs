
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Wrench, CheckCircle, AlertTriangle } from "lucide-react";
import { Maintenance } from "@/hooks/useMaintenances";

interface MaintenanceTableProps {
  maintenances: Maintenance[];
}

export const MaintenanceTable = ({ maintenances }: MaintenanceTableProps) => {
  const getStatusBadge = (status: string) => {
    const statusConfig = {
      scheduled: { label: "Agendada", className: "bg-blue-100 text-blue-800 border-blue-300", icon: Calendar },
      in_progress: { label: "Em Andamento", className: "bg-yellow-100 text-yellow-800 border-yellow-300", icon: Wrench },
      completed: { label: "Concluída", className: "bg-green-100 text-green-800 border-green-300", icon: CheckCircle },
      cancelled: { label: "Cancelada", className: "bg-red-100 text-red-800 border-red-300", icon: AlertTriangle }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.scheduled;
    return (
      <Badge variant="outline" className={config.className}>
        <config.icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  const getTypeLabel = (type: string) => {
    const types = {
      preventiva: "Preventiva",
      corretiva: "Corretiva", 
      revisao: "Revisão",
      pneus: "Pneus",
      oleo: "Óleo"
    };
    return types[type as keyof typeof types] || type;
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleDateString('pt-BR');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Histórico de Manutenções</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left p-4">ID</th>
                <th className="text-left p-4">Veículo</th>
                <th className="text-left p-4">Motorista</th>
                <th className="text-left p-4">Tipo</th>
                <th className="text-left p-4">Descrição</th>
                <th className="text-left p-4">Data</th>
                <th className="text-left p-4">Custo</th>
                <th className="text-left p-4">Status</th>
                <th className="text-left p-4">Ações</th>
              </tr>
            </thead>
            <tbody>
              {maintenances.map((maintenance) => (
                <tr key={maintenance.id} className="border-b hover:bg-gray-50">
                  <td className="p-4 font-medium">{maintenance.id.slice(-8)}</td>
                  <td className="p-4">
                    <div className="font-medium">{maintenance.vehicle_info || "Veículo não encontrado"}</div>
                    <div className="text-xs text-gray-500">{maintenance.odometer.toLocaleString()} km</div>
                  </td>
                  <td className="p-4">
                    {maintenance.driver_name ? (
                      <div className="text-sm">
                        <div className="font-medium">{maintenance.driver_name}</div>
                        <div className="text-xs text-gray-500">Motorista Ativo</div>
                      </div>
                    ) : (
                      <div className="text-xs text-gray-500">Sem motorista</div>
                    )}
                  </td>
                  <td className="p-4">{getTypeLabel(maintenance.maintenance_type)}</td>
                  <td className="p-4 max-w-xs">
                    <div className="truncate" title={maintenance.description}>
                      {maintenance.description}
                    </div>
                  </td>
                  <td className="p-4">
                    <div>{formatDate(maintenance.scheduled_date || maintenance.completed_date)}</div>
                    {maintenance.completed_date && maintenance.scheduled_date && (
                      <div className="text-xs text-gray-500">
                        Agendada: {formatDate(maintenance.scheduled_date)}
                      </div>
                    )}
                  </td>
                  <td className="p-4 font-medium">
                    R$ {(maintenance.actual_cost || maintenance.estimated_cost).toLocaleString('pt-BR', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </td>
                  <td className="p-4">{getStatusBadge(maintenance.status)}</td>
                  <td className="p-4">
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">Ver</Button>
                      <Button size="sm">Editar</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {maintenances.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Nenhuma manutenção encontrada com os filtros aplicados
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
