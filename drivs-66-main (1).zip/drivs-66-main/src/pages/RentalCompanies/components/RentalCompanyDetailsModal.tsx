
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Building, Calendar, DollarSign, Users, Car, Phone, Mail, MapPin, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { RentalCompanyData } from "@/hooks/useRentalCompanies";

interface RentalCompanyDetailsModalProps {
  company: RentalCompanyData | null;
  isOpen: boolean;
  onClose: () => void;
  onStatusChange: (companyId: string, newStatus: boolean) => void;
}

export const RentalCompanyDetailsModal = ({
  company,
  isOpen,
  onClose,
  onStatusChange
}: RentalCompanyDetailsModalProps) => {
  const [isLoading, setIsLoading] = useState(false);

  if (!company) return null;

  const handleStatusToggle = async () => {
    setIsLoading(true);
    try {
      const newStatus = !company.is_active;
      onStatusChange(company.id, newStatus);
      toast.success(`Locadora ${newStatus ? 'ativada' : 'desativada'} com sucesso!`);
      onClose();
    } catch (error) {
      toast.error("Erro ao alterar status da locadora");
    } finally {
      setIsLoading(false);
    }
  };

  const getPlanBadge = (plan: string) => {
    const planConfig = {
      basic: { className: "bg-gray-100 text-gray-800" },
      premium: { className: "bg-blue-100 text-blue-800" },
      enterprise: { className: "bg-purple-100 text-purple-800" }
    };
    
    const config = planConfig[plan as keyof typeof planConfig] || planConfig.basic;
    return <Badge className={config.className}>{plan}</Badge>;
  };

  const getPaymentStatusBadge = (status: string) => {
    const statusConfig = {
      paid: { label: "Pago", className: "bg-green-100 text-green-800" },
      pending: { label: "Pendente", className: "bg-yellow-100 text-yellow-800" },
      overdue: { label: "Vencido", className: "bg-red-100 text-red-800" }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <Building className="h-6 w-6" />
            Detalhes da Locadora
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status da Locadora */}
          <Card className={`border-l-4 ${company.is_active ? 'border-l-green-500' : 'border-l-red-500'}`}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  {company.is_active ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-600" />
                  )}
                  Status da Locadora
                </span>
                <Badge className={company.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                  {company.is_active ? 'Ativa' : 'Desativada'}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-3">
                <Button
                  onClick={handleStatusToggle}
                  disabled={isLoading}
                  variant={company.is_active ? "destructive" : "default"}
                  className={company.is_active ? "" : "bg-green-600 hover:bg-green-700"}
                >
                  {isLoading ? "Processando..." : company.is_active ? "Desativar Locadora" : "Ativar Locadora"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Informações Básicas */}
          <Card>
            <CardHeader>
              <CardTitle>Informações Básicas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Nome da Empresa</label>
                  <p className="text-lg font-semibold">{company.company_name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">CNPJ</label>
                  <p className="text-lg">{company.cnpj}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Email</label>
                  <p className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    {company.email || "contato@" + (company.company_name || "empresa").toLowerCase().replace(/\s+/g, '') + ".com"}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Telefone</label>
                  <p className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    {company.phone || "(11) 9999-8888"}
                  </p>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Endereço</label>
                <p className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  {company.address || "Rua Exemplo, 123 - São Paulo, SP"}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Plano e Pagamento */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Plano e Pagamento</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Plano Atual</label>
                  <div className="mt-1">{getPlanBadge(company.plan)}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Status do Pagamento</label>
                  <div className="mt-1">{getPaymentStatusBadge(company.payment_status)}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Próximo Vencimento</label>
                  <p className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {company.due_date ? new Date(company.due_date).toLocaleDateString('pt-BR') : 'N/A'}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Estatísticas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Car className="h-4 w-4" />
                    <span>Veículos Cadastrados</span>
                  </div>
                  <span className="font-semibold">{company.vehicle_count}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span>Motoristas Ativos</span>
                  </div>
                  <span className="font-semibold">{company.drivers_count}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span>Data de Cadastro</span>
                  </div>
                  <span className="font-semibold">
                    {company.registration_date ? new Date(company.registration_date).toLocaleDateString('pt-BR') : 'N/A'}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Ações Administrativas */}
          <Card>
            <CardHeader>
              <CardTitle>Ações Administrativas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                <Button variant="outline">
                  <DollarSign className="h-4 w-4 mr-2" />
                  Ver Histórico Financeiro
                </Button>
                <Button variant="outline">
                  <Users className="h-4 w-4 mr-2" />
                  Gerenciar Motoristas
                </Button>
                <Button variant="outline">
                  <Car className="h-4 w-4 mr-2" />
                  Ver Veículos
                </Button>
                <Button variant="outline">
                  <Mail className="h-4 w-4 mr-2" />
                  Enviar Notificação
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};
