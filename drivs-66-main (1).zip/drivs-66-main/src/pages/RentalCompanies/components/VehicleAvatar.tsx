
import { Car } from "lucide-react";

interface VehicleAvatarProps {
  vehicleBrand: string;
  vehicleModel: string;
  vehicleImages?: string[];
  className?: string;
}

export const VehicleAvatar = ({ vehicleBrand, vehicleModel, vehicleImages, className = "w-12 h-12" }: VehicleAvatarProps) => {
  // Usar a primeira imagem do array se disponível, senão usar fallback baseado na marca/modelo
  const getVehicleImage = () => {
    if (vehicleImages && vehicleImages.length > 0) {
      return vehicleImages[0];
    }

    // Fallback baseado na marca/modelo para compatibilidade
    const key = `${vehicleBrand.toLowerCase()}-${vehicleModel.toLowerCase()}`;
    
    const vehicleImagesFallback: Record<string, string> = {
      "honda-civic": "https://images.unsplash.com/photo-1549924231-f129b911e442?w=400&h=300&fit=crop",
      "toyota-corolla": "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=400&h=300&fit=crop",
      "volkswagen-jetta": "https://images.unsplash.com/photo-1919151184838-ab4d4906e9d5?w=400&h=300&fit=crop",
      "chevrolet-onix": "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=400&h=300&fit=crop",
      "hyundai-hb20": "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=400&h=300&fit=crop",
      "nissan-versa": "https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400&h=300&fit=crop",
      "ford-ka sedan": "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop",
      "fiat-argo": "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=300&fit=crop",
      "renault-logan": "https://images.unsplash.com/photo-1483058712412-4245e9b90334?w=400&h=300&fit=crop",
      "peugeot-208": "https://images.unsplash.com/photo-1487887235947-a955ef187fcc?w=400&h=300&fit=crop"
    };

    return vehicleImagesFallback[key] || "https://images.unsplash.com/photo-1549924231-f129b911e442?w=400&h=300&fit=crop";
  };

  const imageUrl = getVehicleImage();

  return (
    <div className={`${className} rounded-lg overflow-hidden shadow-sm bg-gray-100 flex items-center justify-center`}>
      <img 
        src={imageUrl} 
        alt={`${vehicleBrand} ${vehicleModel}`}
        className="w-full h-full object-cover"
        onError={(e) => {
          // Fallback para ícone se a imagem não carregar
          const target = e.target as HTMLImageElement;
          target.style.display = 'none';
          const parent = target.parentElement;
          if (parent) {
            parent.innerHTML = '<div class="w-full h-full flex items-center justify-center bg-gray-200"><svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25m18 0A2.25 2.25 0 0018.75 3H5.25A2.25 2.25 0 003 5.25m18 0V12a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 12V5.25"></path></svg></div>';
          }
        }}
      />
    </div>
  );
};
