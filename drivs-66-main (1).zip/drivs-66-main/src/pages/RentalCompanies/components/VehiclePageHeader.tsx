
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";

interface VehiclePageHeaderProps {
  onAddVehicle: () => void;
}

export const VehiclePageHeader = ({ onAddVehicle }: VehiclePageHeaderProps) => {
  return (
    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
      <div>
        <h1 className="text-2xl font-bold tracking-tight uppercase">VEÍCULOS</h1>
      </div>
      <div className="flex gap-2">
        <Button variant="default" className="flex items-center gap-2" onClick={onAddVehicle}>
          <PlusCircle className="h-4 w-4" />
          Cadastrar Veículo
        </Button>
      </div>
    </div>
  );
};
