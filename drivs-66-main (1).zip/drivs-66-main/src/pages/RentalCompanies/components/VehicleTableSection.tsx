
import { VehicleTable } from "./VehicleTable";
import { useVehicleOperationsContext } from "./VehicleOperationsProvider";

export const VehicleTableSection = () => {
  const { 
    search, 
    status, 
    handleViewVehicle, 
    handleEditVehicle, 
    handleDeleteVehicle,
    vehicles,
    loading 
  } = useVehicleOperationsContext();

  // Filtros aplicados
  const filteredVehicles = vehicles.filter((vehicle) => {
    const statusOk = status === "all" || vehicle.status === status;
    const searchValue = `${vehicle.brand} ${vehicle.model} ${vehicle.plate}`.toLowerCase();
    const searchOk = searchValue.includes(search.toLowerCase());
    return statusOk && searchOk;
  });

  // Ordenar: disponíveis primeiro, depois alugados
  const sortedVehicles = [...filteredVehicles].sort((a, b) => {
    if (a.status === "available" && b.status !== "available") return -1;
    if (a.status !== "available" && b.status === "available") return 1;
    return 0;
  });

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <VehicleTable
      vehicles={sortedVehicles}
      onView={handleViewVehicle}
      onEdit={handleEditVehicle}
      onDelete={handleDeleteVehicle}
    />
  );
};
