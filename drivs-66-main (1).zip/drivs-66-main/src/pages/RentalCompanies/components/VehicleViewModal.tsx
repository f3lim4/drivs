
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Car, FileText, Clock, Users } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { VehicleStatusBadge } from "./VehicleStatusBadge";
import { VehicleAvatar } from "./VehicleAvatar";
import { VehicleCommercialValuesCard } from "./VehicleCommercialValuesCard";
import { VehicleMaintenanceHistoryCard } from "./VehicleMaintenanceHistoryCard";
import { VehicleDriverInfoCard } from "./VehicleDriverInfoCard";
import { VehicleDocumentationCard } from "./VehicleDocumentationCard";

interface Vehicle {
  id: string;
  brand: string;
  model: string;
  type: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped";
  weeklyValue: number;
  depositValue: number;
  kmType: "limited" | "unlimited";
  transmissionType: string;
  allowReservation: boolean;
  images: string[];
  driverInfo?: {
    id: string;
    name: string;
    phone: string;
    contractStartDate: string;
  };
}

interface VehicleViewModalProps {
  vehicle: Vehicle | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function VehicleViewModal({
  vehicle,
  open,
  onOpenChange,
}: VehicleViewModalProps) {
  if (!vehicle) return null;

  // Histórico geral do veículo em ordem cronológica
  const vehicleGeneralHistory = [
    {
      date: "2024-02-20",
      type: "CONTRATO",
      description: vehicle.status === "rented" && vehicle.driverInfo 
        ? `Contrato iniciado com ${vehicle.driverInfo.name}` 
        : "Contrato anterior finalizado",
      status: vehicle.status === "rented" ? "active" : "completed"
    },
    {
      date: "2024-02-15",
      type: "MANUTENÇÃO",
      description: "Revisão geral concluída - AutoCenter Premium",
      status: "completed"
    },
    {
      date: "2024-02-10",
      type: "INSPEÇÃO",
      description: "Vistoria semanal aprovada",
      status: "completed"
    },
    {
      date: "2024-02-05",
      type: "CONTRATO",
      description: "Contrato anterior finalizado - João Silva",
      status: "completed"
    },
    {
      date: "2024-01-30",
      type: "MANUTENÇÃO",
      description: "Troca de óleo e filtros",
      status: "completed"
    },
    {
      date: "2024-01-25",
      type: "INFRAÇÃO",
      description: "Multa por estacionamento irregular - Resolvida",
      status: "completed"
    },
    {
      date: "2024-01-15",
      type: "CONTRATO",
      description: "Contrato iniciado com João Silva",
      status: "completed"
    }
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[85vh] overflow-hidden flex flex-col bg-white">
        <DialogHeader className="pb-2 border-b border-gray-200 -m-6 px-6 pt-6 mb-1 bg-white">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-bold text-black">
              {vehicle.brand} {vehicle.model} - {vehicle.plate}
            </DialogTitle>
            <div className="flex items-center gap-3">
              <VehicleStatusBadge status={vehicle.status} />
              {vehicle.status === "rented" && vehicle.driverInfo && (
                <span className="text-sm font-medium text-black">
                  {vehicle.driverInfo.name}
                </span>
              )}
            </div>
          </div>
        </DialogHeader>

        {/* Sistema de Abas */}
        <Tabs defaultValue="vehicle-info" className="flex-1 overflow-hidden mt-1">
          <TabsList className="grid w-full grid-cols-3 h-12 bg-gray-100 p-1 rounded-lg mb-3">
            <TabsTrigger value="vehicle-info" className="flex items-center gap-2 text-base font-medium">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Informações do Veículo</span>
              <span className="sm:hidden">Veículo</span>
            </TabsTrigger>
            <TabsTrigger value="rental-info" className="flex items-center gap-2 text-base font-medium">
              <Car className="h-4 w-4" />
              <span className="hidden sm:inline">Informações de Aluguel</span>
              <span className="sm:hidden">Aluguel</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2 text-base font-medium">
              <Clock className="h-4 w-4" />
              <span>Histórico</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Aba 1: Informações do Veículo */}
          <TabsContent value="vehicle-info" className="overflow-y-auto max-h-[58vh] space-y-4">
            <div className="bg-white p-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <div>
                  <span className="text-sm text-black block">Marca:</span>
                  <span className="font-semibold text-black">{vehicle.brand}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Modelo:</span>
                  <span className="font-semibold text-black">{vehicle.model}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Placa:</span>
                  <span className="font-mono font-semibold text-black">{vehicle.plate}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Vencimento do licenciamento</span>
                  <span className="font-semibold text-black">15/03/2025</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Ano:</span>
                  <span className="font-semibold text-black">{vehicle.year}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Cor:</span>
                  <span className="font-semibold text-black">{vehicle.color}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Tipo de Veículo:</span>
                  <span className="font-semibold text-black">{vehicle.type}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Tipo de Combustível:</span>
                  <span className="font-semibold text-black">Flex</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Tipo de Transmissão:</span>
                  <span className="font-semibold text-black">{vehicle.transmissionType}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Quilometragem da ultima revisão</span>
                  <span className="font-semibold text-black">45.230 km</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Valor do Veículo (R$):</span>
                  <span className="font-semibold text-black">R$ 85.000,00</span>
                </div>
                <div>
                  <span className="text-sm text-black block">IPVA Anual (R$):</span>
                  <span className="font-semibold text-black">R$ 2.550,00</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Situação do Licenciamento:</span>
                  <span className="text-sm text-green-600 font-medium">Em dia</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Vencimento (baseado na placa)</span>
                  <span className="font-semibold text-black">Março</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Está financiado?</span>
                  <span className="font-semibold text-black">Não</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Valor do Seguro Mensal (R$):</span>
                  <span className="font-semibold text-black">R$ 350,00</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Valor do Rastreador Mensal (R$):</span>
                  <span className="font-semibold text-black">R$ 45,00</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Status</span>
                  <VehicleStatusBadge status={vehicle.status} />
                </div>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-black">RENAVAM</label>
                    <p className="text-lg font-semibold text-black">123456789</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-black">Chassi</label>
                    <p className="text-sm font-semibold text-black">9BWZZZ377VT004251</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Seção de Fotos */}
            <div className="bg-white p-4">
              <h4 className="text-lg font-bold text-black mb-4">Fotos</h4>
              <div className="space-y-4">
                {/* Grid de 5 fotos em linha */}
                <div className="grid grid-cols-5 gap-4">
                  {vehicle.images.map((img, idx) => (
                    <div key={idx} className="group cursor-pointer relative overflow-hidden rounded-lg">
                      <img
                        src={img}
                        alt={`${vehicle.brand} ${vehicle.model} - Foto ${idx + 1}`}
                        className="w-full aspect-square object-cover group-hover:shadow-md transition-all duration-300 group-hover:scale-105"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Aba 2: Informações de Aluguel */}
          <TabsContent value="rental-info" className="overflow-y-auto max-h-[58vh] space-y-4">
            <div className="bg-white p-4">
              <VehicleCommercialValuesCard vehicle={vehicle} />
            </div>

            <div className="bg-white p-4">
              <h4 className="text-lg font-bold text-black mb-4">Configurações de Aluguel</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <span className="text-sm text-black block">Tipo de KM</span>
                  <span className="font-semibold text-black">{vehicle.kmType === "limited" ? "Limitada" : "Livre"}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Aceita Reservas</span>
                  <span className="font-semibold text-black">{vehicle.allowReservation ? "Sim" : "Não"}</span>
                </div>
                <div>
                  <span className="text-sm text-black block">Status Atual</span>
                  <VehicleStatusBadge status={vehicle.status} />
                </div>
              </div>
            </div>

            {/* Dados do Motorista na aba de Aluguel */}
            {vehicle.status === "rented" && vehicle.driverInfo && (
              <div className="bg-white p-4">
                <VehicleDriverInfoCard 
                  driverInfo={vehicle.driverInfo!}
                  vehicle={vehicle}
                />
              </div>
            )}

            <div className="bg-white p-4">
              <VehicleMaintenanceHistoryCard />
            </div>
          </TabsContent>

          {/* Aba Histórico */}
          <TabsContent value="history" className="overflow-y-auto max-h-[58vh]">
            <div className="space-y-4">
              {/* Histórico Geral do Veículo */}
              <div className="bg-white p-4">
                <h4 className="text-lg font-bold text-black mb-4 flex items-center gap-2">
                  <Clock className="h-5 w-5 text-black" />
                  Histórico Geral do Veículo
                </h4>
                <div className="space-y-3">
                  {vehicleGeneralHistory.map((event, index) => (
                    <div key={index} className={`border-l-4 pl-4 py-2 ${
                      event.status === "active" 
                        ? "border-blue-500 bg-blue-50" 
                        : "border-gray-300 bg-gray-50"
                    }`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`inline-block px-2 py-1 text-xs font-bold rounded ${
                          event.type === "CONTRATO" ? "bg-green-100 text-green-800" :
                          event.type === "MANUTENÇÃO" ? "bg-orange-100 text-orange-800" :
                          event.type === "INSPEÇÃO" ? "bg-blue-100 text-blue-800" :
                          event.type === "INFRAÇÃO" ? "bg-red-100 text-red-800" :
                          "bg-gray-100 text-gray-800"
                        }`}>
                          {event.type}
                        </span>
                        <span className="text-sm text-black font-medium">
                          {new Date(event.date).toLocaleDateString("pt-BR")}
                        </span>
                      </div>
                      <p className="text-sm text-black">{event.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
