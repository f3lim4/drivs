
import { User, CreditCard, Phone, Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface DriverInfo {
  id: string;
  name: string;
  phone: string;
  contractStartDate: string;
}

interface Vehicle {
  weeklyValue: number;
}

interface VehicleDriverInfoCardProps {
  driverInfo: DriverInfo;
  vehicle: Vehicle;
}

export function VehicleDriverInfoCard({ driverInfo, vehicle }: VehicleDriverInfoCardProps) {
  return (
    <div className="p-6 bg-blue-50 rounded-lg border border-blue-200">
      <h4 className="text-lg font-bold text-blue-800 mb-4 flex items-center gap-2">
        <User className="h-5 w-5" />
        Motorista Atual - Informações Completas
      </h4>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="space-y-3">
          <h5 className="font-semibold text-blue-700 flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            Dados Pessoais
          </h5>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Nome Completo</label>
            <p className="text-lg font-semibold text-blue-900">{driverInfo.name}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">CPF</label>
            <p className="text-blue-900">123.456.789-10</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">CNH</label>
            <p className="text-blue-900">12345678901</p>
          </div>
        </div>

        <div className="space-y-3">
          <h5 className="font-semibold text-blue-700 flex items-center gap-2">
            <Phone className="h-4 w-4" />
            Contato
          </h5>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Telefone</label>
            <p className="text-lg font-semibold text-blue-900">{driverInfo.phone}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">E-mail</label>
            <p className="text-blue-900">motorista@email.com</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Endereço</label>
            <p className="text-blue-900">Rua das Flores, 123</p>
          </div>
        </div>

        <div className="space-y-3">
          <h5 className="font-semibold text-blue-700 flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Contrato
          </h5>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Início do Contrato</label>
            <p className="text-lg font-semibold text-blue-900">
              {new Date(driverInfo.contractStartDate).toLocaleDateString("pt-BR")}
            </p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Tempo de Contrato</label>
            <p className="text-blue-900">
              {Math.floor((new Date().getTime() - new Date(driverInfo.contractStartDate).getTime()) / (1000 * 3600 * 24))} dias
            </p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">Status</label>
            <Badge className="bg-green-100 text-green-800">Ativo</Badge>
          </div>
        </div>
      </div>

      {/* Dados Financeiros do Motorista */}
      <div className="mt-6 pt-4 border-t border-blue-200">
        <h5 className="font-semibold text-blue-700 mb-3">Informações Financeiras</h5>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-3 rounded">
            <label className="text-xs font-medium text-muted-foreground">Valor Semanal</label>
            <p className="text-lg font-bold text-green-600">R$ {vehicle.weeklyValue.toLocaleString("pt-BR")}</p>
          </div>
          <div className="bg-white p-3 rounded">
            <label className="text-xs font-medium text-muted-foreground">Pagamentos em Dia</label>
            <p className="text-lg font-bold text-green-600">4/4</p>
          </div>
          <div className="bg-white p-3 rounded">
            <label className="text-xs font-medium text-muted-foreground">Total Arrecadado</label>
            <p className="text-lg font-bold text-blue-600">R$ {(vehicle.weeklyValue * 4).toLocaleString("pt-BR")}</p>
          </div>
          <div className="bg-white p-3 rounded">
            <label className="text-xs font-medium text-muted-foreground">Infrações</label>
            <p className="text-lg font-bold text-green-600">0</p>
          </div>
        </div>
      </div>
    </div>
  );
}
