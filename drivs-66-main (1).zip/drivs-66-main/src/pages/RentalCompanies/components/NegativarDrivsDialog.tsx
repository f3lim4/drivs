
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface NegativarDrivsDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm?: (motivo: string) => void;
}

export default function NegativarDrivsDialog({ open, onClose, onConfirm }: NegativarDrivsDialogProps) {
  const [motivo, setMotivo] = useState("");
  const [touched, setTouched] = useState(false);

  useEffect(() => {
    if (open) {
      setMotivo("");
      setTouched(false);
    }
  }, [open]);

  const isDisabled = motivo.trim().length === 0;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Negativar na DRIVS</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <p>
            Informe o motivo da negativação. Este motivo será enviado para a equipe DRIVS analisar.
          </p>
          <Textarea
            value={motivo}
            onChange={e => setMotivo(e.target.value)}
            onBlur={() => setTouched(true)}
            placeholder="Descreva o motivo da negativação..."
            rows={4}
          />
          {touched && isDisabled && (
            <div className="text-sm text-red-600">O motivo é obrigatório.</div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            variant="destructive"
            disabled={isDisabled}
            onClick={() => {
              if (!isDisabled) {
                onConfirm?.(motivo.trim());
                onClose();
              }
            }}
          >
            Confirmar Negativação
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
