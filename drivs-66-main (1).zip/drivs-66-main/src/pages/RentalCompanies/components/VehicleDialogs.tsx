
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { VehicleViewModal } from "./VehicleViewModal";
import { VehicleForm } from "@/pages/RentalVehicles/components/VehicleForm";

interface VehicleDialogsProps {
  openVehicleForm: boolean;
  setOpenVehicleForm: (open: boolean) => void;
  showViewModal: boolean;
  setShowViewModal: (open: boolean) => void;
  showEditDialog: boolean;
  setShowEditDialog: (open: boolean) => void;
  selectedVehicle: any;
  setSelectedVehicle: (vehicle: any) => void;
  onVehicleSubmit: (vehicle: any) => void;
}

export const VehicleDialogs = ({
  openVehicleForm,
  setOpenVehicleForm,
  showViewModal,
  setShowViewModal,
  showEditDialog,
  setShowEditDialog,
  selectedVehicle,
  setSelectedVehicle,
  onVehicleSubmit
}: VehicleDialogsProps) => {
  
  const handleEditSubmit = async (vehicleData: any) => {
    try {
      console.log('Submitting edit for vehicle:', selectedVehicle?.id, vehicleData);
      await onVehicleSubmit(vehicleData);
      setShowEditDialog(false);
      setSelectedVehicle(null);
    } catch (error) {
      console.error('Error in handleEditSubmit:', error);
    }
  };

  const handleEditCancel = () => {
    setShowEditDialog(false);
    setSelectedVehicle(null);
  };

  const handleAddVehicleSubmit = async (vehicleData: any) => {
    try {
      console.log('Submitting new vehicle:', vehicleData);
      await onVehicleSubmit(vehicleData);
      setOpenVehicleForm(false);
      setSelectedVehicle(null);
    } catch (error) {
      console.error('Error in handleAddVehicleSubmit:', error);
    }
  };

  return (
    <>
      {/* Dialog popup normal para o cadastro de novo veículo */}
      <Dialog open={openVehicleForm} onOpenChange={setOpenVehicleForm}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">Cadastrar Novo Veículo</DialogTitle>
          </DialogHeader>
          <VehicleForm
            onSubmit={handleAddVehicleSubmit}
            onCancel={() => setOpenVehicleForm(false)}
            vehicle={null}
          />
        </DialogContent>
      </Dialog>

      {/* Modal para VISUALIZAR veículo */}
      <VehicleViewModal
        vehicle={selectedVehicle}
        open={showViewModal}
        onOpenChange={(open) => {
          setShowViewModal(open);
          if (!open) setSelectedVehicle(null);
        }}
      />

      {/* Dialog popup normal para EDITAR */}
      <Dialog open={showEditDialog} onOpenChange={(open) => {
        if (!open) {
          setShowEditDialog(false);
          setSelectedVehicle(null);
        }
      }}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Editar Veículo - {selectedVehicle?.brand} {selectedVehicle?.model}</DialogTitle>
          </DialogHeader>
          <VehicleForm
            vehicle={selectedVehicle}
            onSubmit={handleEditSubmit}
            onCancel={handleEditCancel}
          />
        </DialogContent>
      </Dialog>
    </>
  );
};
