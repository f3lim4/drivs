
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Maintenance } from "@/hooks/useMaintenances";

interface MaintenanceStatsCardsProps {
  maintenances: Maintenance[];
}

export const MaintenanceStatsCards = ({ maintenances }: MaintenanceStatsCardsProps) => {
  const calculateStats = () => {
    const scheduled = maintenances.filter(m => m.status === "scheduled").length;
    const inProgress = maintenances.filter(m => m.status === "in_progress").length;
    const completed = maintenances.filter(m => m.status === "completed").length;
    const totalCost = maintenances.reduce((sum, m) => sum + (m.actual_cost || m.estimated_cost), 0);

    return { scheduled, inProgress, completed, totalCost };
  };

  const stats = calculateStats();

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Card className="border-l-4 border-l-blue-500">
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Agendadas</p>
            <h3 className="text-3xl font-bold text-blue-600">{stats.scheduled}</h3>
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-l-4 border-l-yellow-500">
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Em Andamento</p>
            <h3 className="text-3xl font-bold text-yellow-600">{stats.inProgress}</h3>
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-l-4 border-l-green-500">
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Concluídas</p>
            <h3 className="text-3xl font-bold text-green-600">{stats.completed}</h3>
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-l-4 border-l-purple-500">
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Custo Total</p>
            <h3 className="text-2xl font-bold text-purple-600">
              R$ {stats.totalCost.toLocaleString('pt-BR', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
              })}
            </h3>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
