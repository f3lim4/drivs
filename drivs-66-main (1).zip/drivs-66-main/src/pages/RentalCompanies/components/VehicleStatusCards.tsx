
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Car, DollarSign, Wrench, AlertTriangle } from "lucide-react";
import { useVehicleOperationsContext } from "./VehicleOperationsProvider";

export const VehicleStatusCards = () => {
  const { vehicles } = useVehicleOperationsContext();

  const stats = {
    total: vehicles.length,
    available: vehicles.filter(v => v.status === "available").length,
    rented: vehicles.filter(v => v.status === "rented").length,
    maintenance: vehicles.filter(v => v.status === "maintenance").length,
    stopped: vehicles.filter(v => v.status === "stopped").length
  };

  const totalRevenue = vehicles
    .filter(v => v.status === "rented")
    .reduce((sum, v) => sum + (v.weekly_value * 4), 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total de Veículos</CardTitle>
          <Car className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.total}</div>
          <p className="text-xs text-muted-foreground">
            {stats.available} disponíveis • {stats.rented} alugados
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Receita Mensal</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {totalRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
          </div>
          <p className="text-xs text-muted-foreground">
            {stats.rented} veículos gerando receita
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Em Manutenção</CardTitle>
          <Wrench className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.maintenance}</div>
          <p className="text-xs text-muted-foreground">
            Veículos em reparo
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Atenção Requerida</CardTitle>
          <AlertTriangle className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.stopped}</div>
          <p className="text-xs text-muted-foreground">
            Veículos parados
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
