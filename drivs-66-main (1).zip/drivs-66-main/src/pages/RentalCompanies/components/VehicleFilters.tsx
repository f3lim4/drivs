
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Filter } from "lucide-react";

interface VehicleFiltersProps {
  search: string;
  onSearch: (value: string) => void;
  status: string;
  onStatusChange: (value: string) => void;
}

export function VehicleFilters({
  search,
  onSearch,
  status,
  onStatusChange,
}: VehicleFiltersProps) {
  return (
    <div className="flex flex-col md:flex-row gap-4 w-full">
      <div className="flex-1 relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          placeholder="Buscar por marca, modelo ou placa..."
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          className="pl-10"
        />
      </div>
      <div className="w-full md:w-60">
        <Select value={status} onValueChange={onStatusChange}>
          <SelectTrigger>
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Todos os Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="available">Disponível</SelectItem>
            <SelectItem value="rented">Alugado</SelectItem>
            <SelectItem value="maintenance">Manutenção</SelectItem>
            <SelectItem value="stopped">Parado</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
