
import { Badge } from "@/components/ui/badge";

type VehicleStatus = "available" | "rented" | "maintenance" | "stopped";

interface VehicleStatusBadgeProps {
  status: VehicleStatus;
}

export const VehicleStatusBadge = ({ status }: VehicleStatusBadgeProps) => {
  const statusConfig = {
    available: { label: "Disponível", variant: "default" as const, className: "bg-green-500 text-white" },
    rented: { label: "Alugado", variant: "default" as const, className: "bg-blue-500 text-white" },
    maintenance: { label: "Manutenção", variant: "outline" as const, className: "border-yellow-500 text-yellow-500" },
    stopped: { label: "Parado", variant: "outline" as const, className: "border-gray-500 text-gray-500" }
  };

  const config = statusConfig[status] || statusConfig.available;
  
  return (
    <Badge variant={config.variant} className={config.className}>
      {config.label}
    </Badge>
  );
};
