
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { PaymentActions } from "./PaymentActions";

interface Payment {
  id: string;
  driver_name: string;
  vehicle_info: string;
  due_date: string;
  amount: number;
  status: "paid" | "pending" | "overdue" | "partial";
  paid_amount?: number;
}

interface PaymentTableProps {
  payments: Payment[];
  updatePaymentStatus: (id: string, status: Payment['status'], amount?: number) => void;
}

export const PaymentTable = ({ payments, updatePaymentStatus }: PaymentTableProps) => {
  const getStatusBadge = (status: string) => {
    const statusConfig = {
      paid: { label: "Pago", className: "bg-green-100 text-green-800 border-green-300", icon: CheckCircle },
      pending: { label: "Pendente", className: "bg-yellow-100 text-yellow-800 border-yellow-300", icon: Clock },
      overdue: { label: "Em Atraso", className: "bg-red-100 text-red-800 border-red-300", icon: AlertTriangle },
      partial: { label: "Parcial", className: "bg-blue-100 text-blue-800 border-blue-300", icon: DollarSign }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    return (
      <Badge variant="outline" className={config.className}>
        <config.icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Histórico de Pagamentos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left p-4">Motorista</th>
                <th className="text-left p-4">Veículo</th>
                <th className="text-left p-4">Vencimento</th>
                <th className="text-left p-4">Valor</th>
                <th className="text-left p-4">Pago</th>
                <th className="text-left p-4">Status</th>
                <th className="text-left p-4">Ações</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((payment) => (
                <tr key={payment.id} className="border-b hover:bg-gray-50">
                  <td className="p-4 font-medium">{payment.driver_name}</td>
                  <td className="p-4">{payment.vehicle_info}</td>
                  <td className="p-4">{new Date(payment.due_date).toLocaleDateString('pt-BR')}</td>
                  <td className="p-4">R$ {payment.amount.toLocaleString('pt-BR')}</td>
                  <td className="p-4">
                    {payment.paid_amount ? `R$ ${payment.paid_amount.toLocaleString('pt-BR')}` : "-"}
                  </td>
                  <td className="p-4">{getStatusBadge(payment.status)}</td>
                  <td className="p-4">
                    <PaymentActions 
                      payment={payment} 
                      updatePaymentStatus={updatePaymentStatus} 
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {payments.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Nenhum pagamento encontrado
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
