
import React, { createContext, useContext } from "react";
import { useVehicleOperations } from "../hooks/useVehicleOperations";
import { RentalCompanyVehicle } from "@/hooks/useRentalCompanyVehicles";

interface VehicleOperationsContextType {
  search: string;
  setSearch: (search: string) => void;
  status: string;
  setStatus: (status: string) => void;
  openVehicleForm: boolean;
  setOpenVehicleForm: (open: boolean) => void;
  showViewModal: boolean;
  setShowViewModal: (open: boolean) => void;
  showEditDialog: boolean;
  setShowEditDialog: (open: boolean) => void;
  selectedVehicle: any;
  setSelectedVehicle: (vehicle: any) => void;
  handleAddVehicle: () => void;
  handleVehicleSubmit: (vehicle: any) => void;
  handleViewVehicle: (vehicle: any) => void;
  handleEditVehicle: (vehicle: any) => void;
  handleDeleteVehicle: (vehicleId: string) => void;
  vehicles: RentalCompanyVehicle[];
  loading: boolean;
}

const VehicleOperationsContext = createContext<VehicleOperationsContextType | undefined>(undefined);

export const useVehicleOperationsContext = () => {
  const context = useContext(VehicleOperationsContext);
  if (!context) {
    throw new Error("useVehicleOperationsContext must be used within VehicleOperationsProvider");
  }
  return context;
};

interface VehicleOperationsProviderProps {
  children: React.ReactNode;
}

export const VehicleOperationsProvider = ({ children }: VehicleOperationsProviderProps) => {
  const operations = useVehicleOperations();

  return (
    <VehicleOperationsContext.Provider value={operations}>
      {children}
    </VehicleOperationsContext.Provider>
  );
};
