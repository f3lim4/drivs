
export type NegotiationStatus = "pending" | "in_progress" | "agreed" | "rejected" | "completed" | "overdue";
export type NegotiationType = "debt" | "violation" | "contract" | "payment";

export interface MockNegotiation {
  id: string;
  driverName: string;
  driverCpf: string;
  type: NegotiationType;
  status: NegotiationStatus;
  description: string;
  originalAmount: number;
  negotiatedAmount?: number;
  createdAt: string;
}
