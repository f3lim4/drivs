
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { RentalCompanyData } from "@/hooks/useRentalCompanies";

interface Permissions {
  motoristas: boolean;
  veiculos: boolean;
  contratos: boolean;
  pagamentos: boolean;
  financeiro: boolean;
  infracoes: boolean;
  manutencao: boolean;
  vistorias: boolean;
  negativar: boolean;
  ranking: boolean;
  relatorios: boolean;
  configuracoes: boolean;
}

interface EditRentalCompanyModalProps {
  company: RentalCompanyData | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updated: RentalCompanyData) => void;
}

const PERMISSION_LIST: { key: keyof Permissions; label: string }[] = [
  { key: "motoristas", label: "Motoristas" },
  { key: "veiculos", label: "Veículos" },
  { key: "contratos", label: "Contratos" },
  { key: "pagamentos", label: "Pagamentos" },
  { key: "financeiro", label: "Financeiro" },
  { key: "infracoes", label: "Infrações" },
  { key: "manutencao", label: "Manutenção" },
  { key: "vistorias", label: "Vistorias" },
  { key: "negativar", label: "Negativar" },
  { key: "ranking", label: "Ranking" },
  { key: "relatorios", label: "Relatórios" },
  { key: "configuracoes", label: "Configurações" },
];

export const EditRentalCompanyModal = ({
  company,
  isOpen,
  onClose,
  onSave
}: EditRentalCompanyModalProps) => {
  const [form, setForm] = useState<RentalCompanyData | null>(company);

  // Atualizar formulário se empresa mudar
  if (company && (!form || company.id !== form.id)) setForm(company);

  if (!company || !form) return null;

  const handleChange = (field: keyof RentalCompanyData, value: any) => {
    setForm(prev => prev ? { ...prev, [field]: value } : prev);
  };

  const handlePermissionChange = (perm: keyof Permissions, checked: boolean) => {
    setForm(prev =>
      prev
        ? {
            ...prev,
            permissions: {
              ...defaultPermissions,
              ...prev.permissions,
              [perm]: checked,
            },
          }
        : prev
    );
  };

  const handleSave = () => {
    onSave(form as RentalCompanyData);
    toast.success("Dados atualizados com sucesso!");
    onClose();
  };

  // Default: tudo liberado 
  const defaultPermissions: Permissions = {
    motoristas: true,
    veiculos: true,
    contratos: true,
    pagamentos: true,
    financeiro: true,
    infracoes: true,
    manutencao: true,
    vistorias: true,
    negativar: true,
    ranking: true,
    relatorios: true,
    configuracoes: true,
  };

  const perms = { ...defaultPermissions, ...form.permissions };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Locadora</DialogTitle>
        </DialogHeader>
        <form className="space-y-5" onSubmit={e => {e.preventDefault(); handleSave();}}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground">Nome da Empresa</label>
              <Input 
                value={form.company_name} 
                onChange={e => handleChange('company_name', e.target.value)}
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">CNPJ</label>
              <Input 
                value={form.cnpj}
                onChange={e => handleChange('cnpj', e.target.value)}
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Plano</label>
              <select
                className="w-full rounded border border-gray-300 p-2 text-sm bg-white"
                value={form.plan}
                onChange={e => handleChange('plan', e.target.value)}
              >
                <option value="basic">Basic</option>
                <option value="premium">Premium</option>
                <option value="enterprise">Enterprise</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Status Pagamento</label>
              <select
                className="w-full rounded border border-gray-300 p-2 text-sm bg-white"
                value={form.payment_status}
                onChange={e => handleChange('payment_status', e.target.value)}
              >
                <option value="paid">Pago</option>
                <option value="pending">Pendente</option>
                <option value="overdue">Vencido</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Próximo Vencimento</label>
              <Input
                type="date"
                value={form.due_date || ""}
                onChange={e => handleChange('due_date', e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Email</label>
              <Input
                value={form.email || ""}
                onChange={e => handleChange('email', e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Telefone</label>
              <Input
                value={form.phone || ""}
                onChange={e => handleChange('phone', e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Endereço</label>
              <Input
                value={form.address || ""}
                onChange={e => handleChange('address', e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center gap-4 mt-2">
            <span>Status:</span>
            <select
              className="rounded border border-gray-300 p-2 text-sm bg-white"
              value={form.is_active ? "active" : "inactive"}
              onChange={e => handleChange("is_active", e.target.value === "active")}
            >
              <option value="active">Ativa</option>
              <option value="inactive">Desativada</option>
            </select>
            {form.is_active ? (
              <Badge className="bg-green-100 text-green-800 flex items-center gap-1"><CheckCircle className="w-4 h-4" /> Ativa</Badge>
            ) : (
              <Badge className="bg-red-100 text-red-800 flex items-center gap-1"><XCircle className="w-4 h-4" /> Desativada</Badge>
            )}
          </div>
          {/* Permissões */}
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-2">
              Permissões/Módulos Liberados
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {PERMISSION_LIST.map(({ key, label }) => (
                <label className="flex items-center gap-2" key={key}>
                  <Checkbox
                    checked={perms[key]}
                    onCheckedChange={checked => handlePermissionChange(key, !!checked)}
                    id={`perm-${key}`}
                  />
                  <span>{label}</span>
                </label>
              ))}
            </div>
          </div>
          <DialogFooter className="flex flex-row gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" variant="default">
              Salvar Alterações
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
