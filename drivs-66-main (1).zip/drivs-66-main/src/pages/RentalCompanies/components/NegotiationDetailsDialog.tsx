import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

type NegotiationStatus = "pending" | "in_progress" | "agreed" | "rejected" | "completed" | "overdue";
type NegotiationType = "debt" | "violation" | "contract" | "payment";

interface MockNegotiation {
  id: string;
  driverName: string;
  driverCpf: string;
  type: NegotiationType;
  status: NegotiationStatus;
  description: string;
  originalAmount: number;
  negotiatedAmount?: number;
  createdAt: string;
}

interface NegotiationDetailsDialogProps {
  negotiation: MockNegotiation | null;
  open: boolean;
  onClose: () => void;
  onSave: (negotiation: MockNegotiation) => void;
}

const statusLabel = {
  pending: "Pendente",
  in_progress: "Em Andamento",
  agreed: "Aceito",
  rejected: "Rejeitado",
  completed: "Concluído",
  overdue: "Em Atraso"
};

const typeLabel = {
  debt: "Débito",
  violation: "Infração",
  contract: "Contrato",
  payment: "Pagamento"
};

export default function NegotiationDetailsDialog({
  negotiation,
  open,
  onClose,
  onSave
}: NegotiationDetailsDialogProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedNegotiation, setEditedNegotiation] = useState<MockNegotiation | null>(negotiation);

  // Reset editedNegotiation if negotiation changes
  React.useEffect(() => {
    setEditedNegotiation(negotiation);
    setIsEditing(false);
  }, [negotiation, open]);

  if (!negotiation) return null;

  const canEdit =
    negotiation.status !== "agreed" && negotiation.status !== "completed";

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!editedNegotiation) return;
    const { name, value } = e.target;
    setEditedNegotiation({
      ...editedNegotiation,
      [name]: name === "negotiatedAmount" || name === "originalAmount"
        ? Number(value)
        : value,
    });
  };

  const handleSave = () => {
    if (editedNegotiation) {
      onSave(editedNegotiation);
      setIsEditing(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            Detalhes da Negociação
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-2">
          <div className="flex flex-col gap-1">
            <span><b>Motorista:</b> {negotiation.driverName}</span>
            <span className="text-xs text-muted-foreground">CPF: {negotiation.driverCpf}</span>
          </div>
          <div className="flex gap-2">
            <Badge variant="outline">{typeLabel[negotiation.type]}</Badge>
            <Badge variant="outline">{statusLabel[negotiation.status]}</Badge>
          </div>
          <div>
            <b>Descrição:</b>{" "}
            {isEditing ? (
              <Input
                name="description"
                value={editedNegotiation?.description}
                onChange={handleInput}
              />
            ) : (
              negotiation.description
            )}
          </div>
          <div>
            <b>Valor Original:</b>{" "}
            {isEditing ? (
              <Input
                name="originalAmount"
                type="number"
                min={0}
                value={editedNegotiation?.originalAmount}
                onChange={handleInput}
              />
            ) : (
              `R$ ${negotiation.originalAmount.toFixed(2)}`
            )}
          </div>
          <div>
            <b>Valor Negociado:</b>{" "}
            {isEditing ? (
              <Input
                name="negotiatedAmount"
                type="number"
                min={0}
                value={editedNegotiation?.negotiatedAmount ?? ""}
                onChange={handleInput}
                placeholder="Opcional"
              />
            ) : (
              negotiation.negotiatedAmount
                ? `R$ ${negotiation.negotiatedAmount.toFixed(2)}`
                : "-"
            )}
          </div>
          <div>
            <b>Criado em:</b>{" "}
            {new Date(negotiation.createdAt).toLocaleDateString("pt-BR")}
          </div>
        </div>
        <DialogFooter className="flex justify-between mt-4">
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
          {canEdit &&
            (isEditing ? (
              <>
                <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                  Cancelar
                </Button>
                <Button size="sm" onClick={handleSave}>
                  Salvar
                </Button>
              </>
            ) : (
              <Button size="sm" onClick={() => setIsEditing(true)}>
                Editar
              </Button>
            ))}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
