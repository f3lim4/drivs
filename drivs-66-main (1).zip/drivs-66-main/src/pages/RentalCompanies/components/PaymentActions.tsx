
import { Button } from "@/components/ui/button";

interface Payment {
  id: string;
  status: "paid" | "pending" | "overdue" | "partial";
  amount: number;
}

interface PaymentActionsProps {
  payment: Payment;
  updatePaymentStatus: (id: string, status: Payment['status'], amount?: number) => void;
}

export const PaymentActions = ({ payment, updatePaymentStatus }: PaymentActionsProps) => {
  return (
    <div className="flex gap-2">
      <Button size="sm" variant="outline">Ver</Button>
      {payment.status !== "paid" && (
        <Button 
          size="sm"
          onClick={() => updatePaymentStatus(payment.id, "paid", payment.amount)}
        >
          Registrar Pagamento
        </Button>
      )}
    </div>
  );
};
