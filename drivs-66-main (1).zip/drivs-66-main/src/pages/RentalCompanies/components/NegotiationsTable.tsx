
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MockNegotiation, NegotiationStatus, NegotiationType } from "./types";

interface NegotiationsTableProps {
  negotiations: MockNegotiation[];
  onOpenDetails: (negotiation: MockNegotiation) => void;
  onNegativar: (negotiation: MockNegotiation) => void;
}

export const NegotiationsTable = ({ negotiations, onOpenDetails, onNegativar }: NegotiationsTableProps) => {
  function getStatusBadge(status: NegotiationStatus) {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pendente</Badge>;
      case "in_progress":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Em Andamento</Badge>;
      case "agreed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Aceito</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Rejeitado</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Concluído</Badge>;
      case "overdue":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Em Atraso</Badge>;
      default:
        return <Badge variant="outline">Status</Badge>;
    }
  }

  function getTypeLabel(type: NegotiationType) {
    switch (type) {
      case "debt": return "Débito";
      case "violation": return "Infração";
      case "contract": return "Contrato";
      case "payment": return "Pagamento";
      default: return type;
    }
  }

  return (
    <div className="overflow-x-auto rounded-lg border">
      <table className="min-w-full bg-white text-sm">
        <thead>
          <tr>
            <th className="p-4 text-left border-b">Motorista</th>
            <th className="p-4 text-left border-b">CPF</th>
            <th className="p-4 text-left border-b">Tipo</th>
            <th className="p-4 text-left border-b">Status</th>
            <th className="p-4 text-left border-b">Valor Original</th>
            <th className="p-4 text-left border-b">Valor Negociado</th>
            <th className="p-4 text-left border-b">Criado em</th>
            <th className="p-4 text-left border-b">Ações</th>
          </tr>
        </thead>
        <tbody>
          {negotiations.map((n) => (
            <tr key={n.id} className="hover:bg-muted/30 transition-colors">
              <td className="p-4">{n.driverName}</td>
              <td className="p-4">{n.driverCpf}</td>
              <td className="p-4">{getTypeLabel(n.type)}</td>
              <td className="p-4">{getStatusBadge(n.status)}</td>
              <td className="p-4">R$ {n.originalAmount.toFixed(2)}</td>
              <td className="p-4">
                {n.negotiatedAmount && n.negotiatedAmount !== n.originalAmount
                  ? `R$ ${n.negotiatedAmount.toFixed(2)}`
                  : "-"}
              </td>
              <td className="p-4">{new Date(n.createdAt).toLocaleDateString("pt-BR")}</td>
              <td className="p-4 flex gap-2 flex-wrap">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onOpenDetails(n)}
                >
                  Ver
                </Button>
                {n.status !== "agreed" && n.status !== "completed" && (
                  <Button
                    size="sm"
                    onClick={() => onOpenDetails(n)}
                  >
                    Editar
                  </Button>
                )}
                {(n.status === "rejected" || n.status === "overdue") && (
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => onNegativar(n)}
                  >
                    Negativar
                  </Button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {negotiations.length === 0 && (
        <div className="p-8 text-center text-muted-foreground text-sm">
          Nenhuma negociação encontrada.
        </div>
      )}
    </div>
  );
};
