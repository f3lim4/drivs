
import { Shield } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function VehicleDocumentationCard() {
  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-lg flex items-center gap-2">
        <Shield className="h-5 w-5" />
        Documentação
      </h4>
      <div className="space-y-3">
        <div>
          <label className="text-sm font-medium text-muted-foreground">RENAVAM</label>
          <p className="text-lg font-semibold">123456789</p>
        </div>
        <div>
          <label className="text-sm font-medium text-muted-foreground">Chassi</label>
          <p className="text-sm font-semibold">9BWZZZ377VT004251</p>
        </div>
        <div>
          <label className="text-sm font-medium text-muted-foreground">Licenciamento</label>
          <Badge className="bg-green-100 text-green-800">Em dia</Badge>
        </div>
        <div>
          <label className="text-sm font-medium text-muted-foreground">Seguro</label>
          <Badge className="bg-green-100 text-green-800">Ativo</Badge>
        </div>
        <div>
          <label className="text-sm font-medium text-muted-foreground">IPVA</label>
          <Badge className="bg-green-100 text-green-800">Pago</Badge>
        </div>
      </div>
    </div>
  );
}
