
interface Vehicle {
  weeklyValue: number;
  depositValue: number;
}

interface VehicleCommercialValuesCardProps {
  vehicle: Vehicle;
}

export function VehicleCommercialValuesCard({ vehicle }: VehicleCommercialValuesCardProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6 bg-green-50 rounded-lg border border-green-200">
      <div className="text-center">
        <label className="text-sm font-medium text-muted-foreground block">Valor Semanal</label>
        <p className="text-2xl font-bold text-green-600">R$ {vehicle.weeklyValue.toLocaleString("pt-BR")}</p>
      </div>
      <div className="text-center">
        <label className="text-sm font-medium text-muted-foreground block">Caução</label>
        <p className="text-2xl font-bold text-gray-700">R$ {vehicle.depositValue.toLocaleString("pt-BR")}</p>
      </div>
      <div className="text-center">
        <label className="text-sm font-medium text-muted-foreground block">Valor Diário</label>
        <p className="text-2xl font-bold text-blue-600">R$ {Math.round(vehicle.weeklyValue / 7).toLocaleString("pt-BR")}</p>
      </div>
    </div>
  );
}
