
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Edit, Trash2, Eye, User } from "lucide-react";
import { useState } from "react";
import { RentalCompanyVehicle } from "@/hooks/useRentalCompanyVehicles";

interface VehicleTableProps {
  vehicles: RentalCompanyVehicle[];
  onView: (vehicle: any) => void;
  onEdit: (vehicle: any) => void;
  onDelete: (vehicleId: string) => void;
}

export const VehicleTable = ({ vehicles, onView, onEdit, onDelete }: VehicleTableProps) => {
  const [vehicleToDelete, setVehicleToDelete] = useState<RentalCompanyVehicle | null>(null);

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      available: { label: "Disponível", className: "bg-green-100 text-green-800" },
      rented: { label: "Alugado", className: "bg-blue-100 text-blue-800" },
      maintenance: { label: "Manutenção", className: "bg-yellow-100 text-yellow-800" },
      stopped: { label: "Parado", className: "bg-red-100 text-red-800" },
      damaged: { label: "Sinistrado", className: "bg-orange-100 text-orange-800" },
      sold: { label: "Vendido", className: "bg-gray-100 text-gray-800" }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig];
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleDeleteClick = (vehicle: RentalCompanyVehicle) => {
    setVehicleToDelete(vehicle);
  };

  const confirmDelete = () => {
    if (vehicleToDelete) {
      onDelete(vehicleToDelete.id);
      setVehicleToDelete(null);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Veículos Cadastrados</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Veículo</TableHead>
                <TableHead>Placa</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Valor Semanal</TableHead>
                <TableHead>Transmissão</TableHead>
                <TableHead>KM</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vehicles.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    Nenhum veículo cadastrado
                  </TableCell>
                </TableRow>
              ) : (
                vehicles.map((vehicle) => (
                  <TableRow key={vehicle.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{vehicle.brand} {vehicle.model}</p>
                        <p className="text-sm text-muted-foreground">{vehicle.year} • {vehicle.color}</p>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono">{vehicle.plate}</TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {getStatusBadge(vehicle.status)}
                        {vehicle.status === "rented" && vehicle.driver_id && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <User className="h-3 w-3" />
                            <span>Alugado</span>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{formatCurrency(vehicle.weekly_value)}</p>
                        <p className="text-xs text-muted-foreground">
                          Caução: {formatCurrency(vehicle.deposit_value)}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{vehicle.transmission_type}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={vehicle.km_type === "unlimited" ? "default" : "secondary"}>
                        {vehicle.km_type === "unlimited" ? "Livre" : `${vehicle.km_limit || 0} km/mês`}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button 
                          variant="ghost"
                          size="icon"
                          onClick={() => onView(vehicle)}
                          title="Visualizar"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost"
                          size="icon"
                          onClick={() => onEdit(vehicle)}
                          disabled={vehicle.status === "rented"}
                          title="Editar"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteClick(vehicle)}
                              title="Excluir"
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
                              <AlertDialogDescription>
                                Tem certeza que deseja excluir o veículo <strong>{vehicle.brand} {vehicle.model} - {vehicle.plate}</strong>?
                                Esta ação não pode ser desfeita.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
                                Confirmar Exclusão
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
