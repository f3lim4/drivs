
import { VehicleDialogs } from "./VehicleDialogs";
import { useVehicleOperationsContext } from "./VehicleOperationsProvider";

export const VehicleDialogsSection = () => {
  const {
    openVehicleForm,
    setOpenVehicleForm,
    showViewModal,
    setShowViewModal,
    showEditDialog,
    setShowEditDialog,
    selectedVehicle,
    setSelectedVehicle,
    handleVehicleSubmit
  } = useVehicleOperationsContext();

  return (
    <VehicleDialogs
      openVehicleForm={openVehicleForm}
      setOpenVehicleForm={setOpenVehicleForm}
      showViewModal={showViewModal}
      setShowViewModal={setShowViewModal}
      showEditDialog={showEditDialog}
      setShowEditDialog={setShowEditDialog}
      selectedVehicle={selectedVehicle}
      setSelectedVehicle={setSelectedVehicle}
      onVehicleSubmit={handleVehicleSubmit}
    />
  );
};
