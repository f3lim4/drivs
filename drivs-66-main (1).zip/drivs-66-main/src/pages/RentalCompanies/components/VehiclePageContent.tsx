
import { VehicleStatusCards } from "./VehicleStatusCards";
import { VehiclePageHeader } from "./VehiclePageHeader";
import { VehicleFiltersSection } from "./VehicleFiltersSection";
import { VehicleTableSection } from "./VehicleTableSection";
import { VehicleDialogsSection } from "./VehicleDialogsSection";
import { useVehicleOperationsContext } from "./VehicleOperationsProvider";

export const VehiclePageContent = () => {
  const { handleAddVehicle } = useVehicleOperationsContext();

  return (
    <div className="container py-6 space-y-6">
      <VehiclePageHeader onAddVehicle={handleAddVehicle} />
      
      <VehicleStatusCards />
      
      <VehicleFiltersSection />
      
      <VehicleTableSection />
      
      <VehicleDialogsSection />
    </div>
  );
};
