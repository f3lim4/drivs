
import { VehicleOperationsProvider } from "./components/VehicleOperationsProvider";
import { VehiclePageContent } from "./components/VehiclePageContent";

const RentalCompanyVehiclesPage = () => {
  return (
    <VehicleOperationsProvider>
      <VehiclePageContent />
    </VehicleOperationsProvider>
  );
};

export default RentalCompanyVehiclesPage;
