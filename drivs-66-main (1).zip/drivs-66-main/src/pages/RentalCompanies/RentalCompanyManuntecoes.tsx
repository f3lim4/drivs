
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Wrench, MapPin } from "lucide-react";
import { ScheduleMaintenanceDialog } from "@/pages/Maintenance/components/ScheduleMaintenanceDialog";
import { NewMaintenanceDialog } from "@/pages/Maintenance/components/NewMaintenanceDialog";
import { MaintenanceLocationsDialog } from "@/pages/Maintenance/components/MaintenanceLocationsDialog";
import { toast } from "sonner";
import { MaintenanceStatsCards } from "./components/MaintenanceStatsCards";
import { MaintenanceFilters } from "./components/MaintenanceFilters";
import { MaintenanceTable } from "./components/MaintenanceTable";
import { useMaintenances } from "@/hooks/useMaintenances";

const RentalCompanyMaintenance = () => {
  const { user } = useAuth();
  const { maintenances, loading, createMaintenance } = useMaintenances();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [showNewMaintenanceDialog, setShowNewMaintenanceDialog] = useState(false);
  const [showLocationsDialog, setShowLocationsDialog] = useState(false);

  const handleScheduleMaintenance = async (data: any) => {
    try {
      await createMaintenance(data);
      toast.success("Manutenção agendada com sucesso!");
      setShowScheduleDialog(false);
    } catch (error) {
      toast.error("Erro ao agendar manutenção");
    }
  };

  const handleNewMaintenance = async (data: any) => {
    try {
      await createMaintenance(data);
      toast.success("Manutenção registrada com sucesso!");
      setShowNewMaintenanceDialog(false);
    } catch (error) {
      toast.error("Erro ao registrar manutenção");
    }
  };

  const filteredMaintenances = maintenances.filter(maintenance => {
    const matchesSearch = searchTerm === "" || 
      maintenance.vehicle_info?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      maintenance.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      maintenance.location_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (maintenance.driver_name && maintenance.driver_name.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === "all" || maintenance.status === statusFilter;
    const matchesType = typeFilter === "all" || maintenance.maintenance_type === typeFilter;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  // Se não é uma locadora, não permitir acesso
  if (user?.role !== "rental_company") {
    return (
      <div className="container py-6 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Apenas locadoras podem acessar esta página.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="container py-6 space-y-6">
        <div className="h-10 w-full max-w-xs bg-gradient-to-r from-blue-200 to-purple-200 animate-pulse rounded"></div>
        <div className="h-12 w-full bg-gradient-to-r from-blue-100 to-purple-100 animate-pulse rounded mt-4"></div>
        <div className="h-96 w-full bg-gradient-to-r from-blue-50 to-purple-50 animate-pulse rounded mt-4"></div>
      </div>
    );
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Manutenções</h1>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowLocationsDialog(true)}
          >
            <MapPin className="w-4 h-4 mr-2" />
            Locais
          </Button>
          <Button onClick={() => setShowScheduleDialog(true)}>
            <Calendar className="w-4 h-4 mr-2" />
            Agendar Manutenção
          </Button>
          <Button onClick={() => setShowNewMaintenanceDialog(true)}>
            <Wrench className="w-4 h-4 mr-2" />
            Nova Manutenção
          </Button>
        </div>
      </div>

      <MaintenanceStatsCards maintenances={maintenances} />

      <MaintenanceFilters
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        statusFilter={statusFilter}
        setStatusFilter={setStatusFilter}
        typeFilter={typeFilter}
        setTypeFilter={setTypeFilter}
      />

      <MaintenanceTable maintenances={filteredMaintenances} />

      {/* Dialogs */}
      <ScheduleMaintenanceDialog
        open={showScheduleDialog}
        onOpenChange={setShowScheduleDialog}
        onSchedule={handleScheduleMaintenance}
      />

      <NewMaintenanceDialog
        open={showNewMaintenanceDialog}
        onOpenChange={setShowNewMaintenanceDialog}
        onSave={handleNewMaintenance}
      />

      <MaintenanceLocationsDialog
        open={showLocationsDialog}
        onOpenChange={setShowLocationsDialog}
      />
    </div>
  );
};

export default RentalCompanyMaintenance;
