
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { SendViolationDialog } from "@/pages/Violations/components/SendViolationDialog";
import { ViolationDetailsDialog } from "@/pages/Violations/components/ViolationDetailsDialog";
import { ViolationsPageLayout } from "@/pages/Violations/components/ViolationsPageLayout";
import { RentalCompanyViolationsView } from "@/pages/Violations/components/RentalCompanyViolationsView";
import { useViolationsData, type ViolationData } from "@/hooks/useViolationsData";

// Adaptar o tipo para compatibilidade com os componentes existentes
interface Violation {
  id: string;
  contractId: string;
  vehicleId: string;
  vehicleInfo: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  date: string;
  location: string;
  description: string;
  points: number;
  value: number;
  status: "pending" | "paid" | "contested" | "resolved";
  paymentDeadline: string;
}

const RentalCompanyViolationsPage = () => {
  const { user } = useAuth();
  const { violations: dbViolations, loading, createViolation, updateViolationStatus } = useViolationsData();
  const [selectedViolation, setSelectedViolation] = useState<Violation | null>(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  
  // Converter dados do banco para o formato esperado pelos componentes
  const violations: Violation[] = dbViolations.map(violation => ({
    id: violation.id,
    contractId: violation.contract_id || '',
    vehicleId: violation.vehicle_id || '',
    vehicleInfo: violation.violation_type, // Usando violation_type como info do veículo por enquanto
    driverId: violation.driver_id || '',
    driverName: 'Motorista', // Placeholder - poderia buscar do banco
    companyId: violation.company_id,
    companyName: user?.companyName || 'Locadora',
    date: violation.date,
    location: violation.location,
    description: violation.description,
    points: violation.points,
    value: violation.amount,
    status: violation.status,
    paymentDeadline: violation.payment_deadline || ''
  }));

  const handleSendViolation = async (violationData: Violation) => {
    if (!user?.id) return;

    const newViolation: Omit<ViolationData, 'id' | 'created_at' | 'updated_at'> = {
      contract_id: violationData.contractId || null,
      vehicle_id: violationData.vehicleId || null,
      driver_id: violationData.driverId || null,
      company_id: user.id,
      violation_type: violationData.description.split(' - ')[0] || 'Infração de trânsito',
      location: violationData.location,
      date: violationData.date,
      description: violationData.description,
      points: violationData.points,
      amount: violationData.value,
      status: violationData.status,
      payment_deadline: violationData.paymentDeadline || null,
      evidence_files: [],
      notes: null
    };

    await createViolation(newViolation);
  };

  const handleUpdateViolation = async (violationId: string, newStatus: Violation["status"]) => {
    await updateViolationStatus(violationId, newStatus);
  };

  const handleViewDetails = (violation: Violation) => {
    setSelectedViolation(violation);
    setIsDetailsDialogOpen(true);
  };

  if (loading) {
    return (
      <ViolationsPageLayout title="Painel de Infrações">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando infrações...</p>
          </div>
        </div>
      </ViolationsPageLayout>
    );
  }

  return (
    <ViolationsPageLayout 
      title="Painel de Infrações"
      headerAction={<SendViolationDialog onSendViolation={handleSendViolation} />}
    >
      <RentalCompanyViolationsView 
        violations={violations}
        onViewDetails={handleViewDetails}
      />
      
      <ViolationDetailsDialog
        violation={selectedViolation}
        isOpen={isDetailsDialogOpen}
        onClose={() => setIsDetailsDialogOpen(false)}
        onUpdateViolation={handleUpdateViolation}
      />
    </ViolationsPageLayout>
  );
};

export default RentalCompanyViolationsPage;
