import { useState } from "react";
import { Handshake } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { CreateNegotiationFlow } from "@/pages/Negotiations/components/CreateNegotiationFlow";
import { CreateNegotiationData } from "@/pages/Negotiations/types";
import { StatsCard } from "@/components/shared/StatsCard";
import { SearchFilters } from "@/components/shared/SearchFilters";
import NegotiationDetailsDialog from "./components/NegotiationDetailsDialog";
import NegativarDrivsDialog from "./components/NegativarDrivsDialog";
import { NegotiationsTable } from "./components/NegotiationsTable";
import { MockNegotiation } from "./components/types";
import { FileText, CheckCircle, AlertTriangle, TrendingUp } from "lucide-react";

export default function RentalCompanyNegotiations() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [selectedNegotiation, setSelectedNegotiation] = useState<MockNegotiation | null>(null);
  const [openDetails, setOpenDetails] = useState(false);
  const [negotiations, setNegotiations] = useState<MockNegotiation[]>([]);
  const [openNegativarDialog, setOpenNegativarDialog] = useState(false);
  const [negativarNegotiationId, setNegativarNegotiationId] = useState<string | null>(null);

  const filteredNegotiations = negotiations.filter((n) => {
    const matchesSearch =
      searchTerm === "" ||
      n.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.driverCpf.replace(/\D/g, "").includes(searchTerm.replace(/\D/g, ""));

    const matchesStatus = statusFilter === "all" || n.status === statusFilter;
    const matchesType = typeFilter === "all" || n.type === typeFilter;

    return matchesSearch && matchesStatus && matchesType;
  });

  const statsData = [
    {
      title: "Total de Negociações",
      value: negotiations.length,
      description: `${negotiations.filter(n => n.status === "pending").length} pendentes`,
      icon: FileText,
      borderColor: "border-l-blue-500",
      iconColor: "text-blue-600",
      valueColor: "text-blue-600"
    },
    {
      title: "Concluídas",
      value: negotiations.filter(n => n.status === "completed" || n.status === "agreed").length,
      description: `R$ ${negotiations.filter(n => n.status === "completed" || n.status === "agreed")
        .reduce((acc, cur) => acc + (cur.negotiatedAmount || cur.originalAmount), 0).toFixed(2)} recuperados`,
      icon: CheckCircle,
      borderColor: "border-l-green-500",
      iconColor: "text-green-600",
      valueColor: "text-green-600"
    },
    {
      title: "Problemas",
      value: negotiations.filter(n => n.status === "overdue" || n.status === "rejected").length,
      description: `${negotiations.filter(n => n.status === "overdue").length} em atraso, ${negotiations.filter(n => n.status === "rejected").length} rejeitadas`,
      icon: AlertTriangle,
      borderColor: "border-l-red-500",
      iconColor: "text-red-600",
      valueColor: "text-red-600"
    },
    {
      title: "Taxa de Sucesso",
      value: `${negotiations.length > 0
        ? (((negotiations.filter(n => n.status === "completed" || n.status === "agreed").length / negotiations.length) * 100)).toFixed(1)
        : "0.0"}%`,
      description: `R$ ${negotiations.reduce((a, c) => a + (c.negotiatedAmount || c.originalAmount), 0).toFixed(2)} total`,
      icon: TrendingUp,
      borderColor: "border-l-yellow-500",
      iconColor: "text-yellow-600",
      valueColor: "text-yellow-600"
    }
  ];

  const filterOptions = [
    {
      value: statusFilter,
      onChange: setStatusFilter,
      placeholder: "Status",
      options: [
        { value: "all", label: "Todos os Status" },
        { value: "pending", label: "Pendente" },
        { value: "in_progress", label: "Em Andamento" },
        { value: "agreed", label: "Aceito" },
        { value: "rejected", label: "Rejeitado" },
        { value: "completed", label: "Concluído" },
        { value: "overdue", label: "Em Atraso" }
      ]
    },
    {
      value: typeFilter,
      onChange: setTypeFilter,
      placeholder: "Tipo",
      options: [
        { value: "all", label: "Todos os Tipos" },
        { value: "debt", label: "Débito" },
        { value: "violation", label: "Infração" },
        { value: "contract", label: "Contrato" },
        { value: "payment", label: "Pagamento" }
      ]
    }
  ];

  function handleOpenDetails(negotiation: MockNegotiation) {
    setSelectedNegotiation(negotiation);
    setOpenDetails(true);
  }

  function handleEditNegotiation(updated: MockNegotiation) {
    setNegotiations((prev) =>
      prev.map((n) => (n.id === updated.id ? updated : n))
    );
    setOpenDetails(false);
  }

  function handleNegativar(negotiation: MockNegotiation) {
    setNegativarNegotiationId(negotiation.id);
    setOpenNegativarDialog(true);
  }

  function handleConfirmNegativar(motivo: string) {
    const negotiation = negotiations.find(n => n.id === negativarNegotiationId);
    if (negotiation) {
      console.log("Negativar na DRIVS:", { id: negotiation.id, driver: negotiation.driverName, motivo });
    }
    setOpenNegativarDialog(false);
    setNegativarNegotiationId(null);
  }

  function handleCreateNegotiation(data: CreateNegotiationData) {
    const newNegotiation: MockNegotiation = {
      id: Date.now().toString(),
      driverName: data.driverName,
      driverCpf: data.driverCpf,
      type: "debt",
      status: "pending",
      description: `Negociação de ${data.selectedDebts.length} débito(s): ${data.selectedDebts.map(d => d.description).join(', ')}`,
      originalAmount: data.totalAmount,
      negotiatedAmount: data.proposedAmount,
      createdAt: new Date().toISOString().split('T')[0]
    };

    setNegotiations([newNegotiation, ...negotiations]);
    toast({
      title: "Negociação criada",
      description: `Nova negociação foi enviada para ${data.driverName}.`
    });
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6 py-6 px-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Handshake className="h-8 w-8 text-blue-600" />
            Acordos de Motoristas
          </h1>
          <p className="text-muted-foreground text-lg mt-2">
            Gerencie acordos com motoristas desativados e inadimplentes
          </p>
        </div>
        
        <div className="flex-shrink-0">
          <CreateNegotiationFlow onCreateNegotiation={handleCreateNegotiation} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsData.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      <SearchFilters
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        searchPlaceholder="Buscar por nome, CPF ou empresa..."
        filters={filterOptions}
      />

      <NegotiationsTable
        negotiations={filteredNegotiations}
        onOpenDetails={handleOpenDetails}
        onNegativar={handleNegativar}
      />

      <NegotiationDetailsDialog
        negotiation={selectedNegotiation}
        open={openDetails}
        onClose={() => setOpenDetails(false)}
        onSave={handleEditNegotiation}
      />

      <NegativarDrivsDialog
        open={openNegativarDialog}
        onClose={() => setOpenNegativarDialog(false)}
        onConfirm={handleConfirmNegativar}
      />
    </div>
  );
}
