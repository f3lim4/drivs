
export interface Vehicle {
  id: string;
  brand: string;
  model: string;
  type: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold";
  images: string[];
  
  // Dados comerciais
  weeklyValue: number;
  depositValue: number;
  kmType: "limited" | "unlimited";
  kmLimit?: number;
  transmissionType: string;
  allowReservation?: boolean;
  
  // Dados adicionais
  renavam?: string;
  chassi?: string;
  fuelType?: string;
  vehicleValue?: number;
  ipvaValue?: number;
  insuranceValue?: number;
  trackerValue?: number;
  isFinanced?: boolean;
  monthlyInstallment?: number;
  observations?: string;
  
  // Dados de licenciamento
  licensingExpiry?: string;
  licensingStatus?: "Em dia" | "Vencido";
  lastRevisionKm?: number;
  
  // Informações do motorista (se alugado)
  driverInfo?: {
    id: string;
    name: string;
    phone: string;
    contractStartDate: string;
  };
}

export interface VehicleWithEditData extends Vehicle {
  // Inclui todos os campos de Vehicle mais campos específicos para edição
  maintenanceResponsibility?: "rental_company" | "fifty_fifty" | "driver";
  documentExpiry?: string;
  mileage?: number;
}
