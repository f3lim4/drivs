
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { CreatePaymentDialog } from "@/pages/Payments/components/CreatePaymentDialog";
import { VehicleExpenseDialog } from "@/pages/Payments/components/VehicleExpenseDialog";
import { useRentalCompanyPayments } from "@/hooks/useRentalCompanyPayments";
import { useRentalCompanyVehicles } from "@/hooks/useRentalCompanyVehicles";
import { useAuth } from "@/contexts/AuthContext";
import { PaymentStatsCards } from "./components/PaymentStatsCards";
import { PaymentFilters } from "./components/PaymentFilters";
import { PaymentTable } from "./components/PaymentTable";

// Mock drivers data - in a real app this would come from a hook or API
const mockDrivers = [
  { id: "1", name: "João Silva", phone: "(11) 99999-1111" },
  { id: "2", name: "Maria Santos", phone: "(11) 99999-2222" },
  { id: "3", name: "Carlos Oliveira", phone: "(11) 99999-3333" },
  { id: "4", name: "Ana Costa", phone: "(11) 99999-4444" }
];

const RentalCompanyPayments = () => {
  const { user } = useAuth();
  const { payments, loading, updatePaymentStatus } = useRentalCompanyPayments();
  const { vehicles } = useRentalCompanyVehicles();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = searchTerm === "" || 
      payment.driver_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.vehicle_info.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || payment.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Convert company vehicles to the format expected by VehicleExpenseDialog
  const companyVehicles = vehicles.map(vehicle => {
    // Simulate random driver assignment for demo
    const randomDriver = Math.random() > 0.3 ? mockDrivers[Math.floor(Math.random() * mockDrivers.length)] : null;
    
    return {
      id: vehicle.id,
      plate: vehicle.plate,
      model: vehicle.model,
      brand: vehicle.brand,
      driverName: randomDriver?.name,
      driverPhone: randomDriver?.phone
    };
  });

  if (loading) {
    return (
      <div className="container py-6 space-y-6">
        <div className="text-center">
          <p>Carregando pagamentos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Pagamentos</h1>
          <p className="text-gray-600">Controle financeiro dos aluguéis</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowExpenseDialog(true)}
            className="flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            Cadastrar Despesa
          </Button>
          <CreatePaymentDialog onPaymentCreated={() => {}} />
        </div>
      </div>

      {/* Statistics Cards */}
      <PaymentStatsCards payments={payments} />

      {/* Filters */}
      <PaymentFilters 
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        statusFilter={statusFilter}
        setStatusFilter={setStatusFilter}
      />

      {/* Payments Table */}
      <PaymentTable 
        payments={filteredPayments}
        updatePaymentStatus={updatePaymentStatus}
      />

      {/* Vehicle Expense Dialog */}
      <VehicleExpenseDialog
        open={showExpenseDialog}
        onOpenChange={setShowExpenseDialog}
        vehicles={companyVehicles}
      />
    </div>
  );
};

export default RentalCompanyPayments;
