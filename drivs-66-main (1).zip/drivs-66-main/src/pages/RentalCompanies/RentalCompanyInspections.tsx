
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Filter, Eye, CheckCircle, Clock, AlertTriangle, Calendar, Users, Car } from "lucide-react";
import CreateInspectionDialog from "@/pages/Inspections/components/CreateInspectionDialog";
import { InspectionViewModal } from "@/pages/Inspections/components/InspectionViewModal";
import { useRentalCompanyInspections } from "@/pages/Inspections/hooks/useRentalCompanyInspections";
import { LocalInspection } from "@/pages/Inspections/types/inspection";

const RentalCompanyInspections = () => {
  const { 
    inspections,
    loading,
    createInspection,
    updateInspectionStatus,
    rejectPhoto,
    rejectAllPhotos,
    pendingInspectionsCount,
    awaitingApprovalInspectionsCount,
    completedInspectionsCount
  } = useRentalCompanyInspections();

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [selectedInspection, setSelectedInspection] = useState<LocalInspection | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Filter inspections
  const filteredInspections = inspections.filter(inspection => {
    const matchesSearch = searchTerm === "" || 
      inspection.vehiclePlate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inspection.driverName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || inspection.status === statusFilter;
    const matchesType = typeFilter === "all" || inspection.type === typeFilter;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const handleViewInspection = (inspection: LocalInspection) => {
    setSelectedInspection(inspection);
    setIsModalOpen(true);
  };

  const handleCreateInspection = async (inspectionData: Omit<LocalInspection, 'id'>) => {
    await createInspection(inspectionData);
  };

  const handleUpdateStatus = (inspectionId: string, status: LocalInspection["status"], observations?: string) => {
    updateInspectionStatus(inspectionId, status, observations);
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      "Pendente": { label: "Pendente", className: "bg-yellow-100 text-yellow-800", icon: Clock },
      "Aguardando Aprovação": { label: "Aguardando", className: "bg-blue-100 text-blue-800", icon: AlertTriangle },
      "Concluída": { label: "Concluída", className: "bg-green-100 text-green-800", icon: CheckCircle },
      "Rejeitada": { label: "Rejeitada", className: "bg-red-100 text-red-800", icon: AlertTriangle },
      "Em Andamento": { label: "Em Andamento", className: "bg-orange-100 text-orange-800", icon: Clock }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig["Pendente"];
    return (
      <Badge variant="outline" className={config.className}>
        <config.icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  const getTypeBadge = (type: string) => {
    const typeColors = {
      "Inicial": "bg-blue-100 text-blue-800",
      "Entrega": "bg-green-100 text-green-800",
      "Retorno": "bg-orange-100 text-orange-800",
      "Sinistro": "bg-red-100 text-red-800"
    };
    
    const className = typeColors[type as keyof typeof typeColors] || "bg-gray-100 text-gray-800";
    return (
      <Badge variant="outline" className={className}>
        {type}
      </Badge>
    );
  };

  const stats = [
    {
      title: "Pendentes",
      value: pendingInspectionsCount,
      icon: Clock,
      color: "text-yellow-600"
    },
    {
      title: "Aguardando Aprovação",
      value: awaitingApprovalInspectionsCount,
      icon: AlertTriangle,
      color: "text-blue-600"
    },
    {
      title: "Concluídas",
      value: completedInspectionsCount,
      icon: CheckCircle,
      color: "text-green-600"
    },
    {
      title: "Total de Vistorias",
      value: inspections.length,
      icon: Calendar,
      color: "text-gray-600"
    }
  ];

  if (loading) {
    return (
      <div className="container py-6 space-y-6">
        <div className="text-center">
          <p>Carregando vistorias...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Vistorias da Locadora</h1>
          <p className="text-gray-600">Gerencie as vistorias dos seus veículos</p>
        </div>
        <CreateInspectionDialog onCreateInspection={handleCreateInspection} />
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="border-l-4 border-l-blue-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${stat.color}`}>
                {stat.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Input
                placeholder="Buscar por placa ou motorista..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="Pendente">Pendente</SelectItem>
                <SelectItem value="Aguardando Aprovação">Aguardando Aprovação</SelectItem>
                <SelectItem value="Concluída">Concluída</SelectItem>
                <SelectItem value="Rejeitada">Rejeitada</SelectItem>
                <SelectItem value="Em Andamento">Em Andamento</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Tipos</SelectItem>
                <SelectItem value="Inicial">Inicial</SelectItem>
                <SelectItem value="Entrega">Entrega</SelectItem>
                <SelectItem value="Retorno">Retorno</SelectItem>
                <SelectItem value="Sinistro">Sinistro</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Inspections Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Vistorias</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-4">ID</th>
                  <th className="text-left p-4">Veículo</th>
                  <th className="text-left p-4">Motorista</th>
                  <th className="text-left p-4">Tipo</th>
                  <th className="text-left p-4">Status</th>
                  <th className="text-left p-4">Vistoriador</th>
                  <th className="text-left p-4">Data</th>
                  <th className="text-left p-4">Fotos</th>
                  <th className="text-left p-4">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredInspections.map((inspection) => (
                  <tr key={inspection.id} className="border-b hover:bg-gray-50">
                    <td className="p-4 font-mono text-xs">{inspection.id}</td>
                    <td className="p-4">
                      <div>
                        <div className="font-medium">{inspection.vehicleModel}</div>
                        <div className="text-gray-500">{inspection.vehiclePlate}</div>
                      </div>
                    </td>
                    <td className="p-4">{inspection.driverName}</td>
                    <td className="p-4">{getTypeBadge(inspection.type)}</td>
                    <td className="p-4">{getStatusBadge(inspection.status)}</td>
                    <td className="p-4">{inspection.vistoriador}</td>
                    <td className="p-4">{new Date(inspection.inspectionDate).toLocaleDateString('pt-BR')}</td>
                    <td className="p-4">{inspection.photos}</td>
                    <td className="p-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleViewInspection(inspection)}
                        className="flex items-center gap-1"
                      >
                        <Eye className="h-3 w-3" />
                        Ver
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredInspections.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                Nenhuma vistoria encontrada
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Inspection View Modal */}
      <InspectionViewModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        inspection={selectedInspection}
        onUpdateStatus={handleUpdateStatus}
        onRejectPhoto={rejectPhoto}
        onRejectAllPhotos={rejectAllPhotos}
      />
    </div>
  );
};

export default RentalCompanyInspections;
