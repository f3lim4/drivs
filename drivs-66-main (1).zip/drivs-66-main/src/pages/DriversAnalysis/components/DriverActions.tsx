
import type { Driver } from "../types/Driver";
import { useDriverStatusActions } from "../hooks/useDriverStatusActions";
import { useDriverViewActions } from "../hooks/useDriverViewActions";

interface DriverActionsProps {
  drivers: Driver[];
  onDriverStatusUpdate: (driverId: string, newStatus: string) => void;
  onAnalyzeDriver: (driver: Driver) => void;
  onViewDriver: (driver: Driver) => void;
}

export const useDriverActions = ({
  drivers,
  onDriverStatusUpdate,
  onAnalyzeDriver,
  onViewDriver
}: DriverActionsProps) => {
  const statusActions = useDriverStatusActions({ 
    drivers, 
    onDriverStatusUpdate 
  });

  const viewActions = useDriverViewActions({ 
    drivers, 
    onAnalyzeDriver, 
    onViewDriver 
  });

  return {
    ...statusActions,
    ...viewActions
  };
};
