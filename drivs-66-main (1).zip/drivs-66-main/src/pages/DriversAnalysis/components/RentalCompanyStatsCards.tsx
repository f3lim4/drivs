
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Send, CheckCircle } from "lucide-react";

interface RentalCompanyStatsCardsProps {
  stats: {
    awaitingAnalysis: number;
    sentToDrivs: number;
    approved: number;
  };
}

export const RentalCompanyStatsCards = ({ stats }: RentalCompanyStatsCardsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Em Aberto</CardTitle>
          <AlertTriangle className="h-4 w-4 text-blue-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-blue-700">{stats.awaitingAnalysis}</div>
          <p className="text-xs text-muted-foreground">
            Aguardando análise
          </p>
        </CardContent>
      </Card>
      
      <Card className="border-l-4 border-l-purple-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Enviados para DRIVS</CardTitle>
          <Send className="h-4 w-4 text-purple-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-purple-700">{stats.sentToDrivs}</div>
          <p className="text-xs text-muted-foreground">
            Em análise profissional
          </p>
        </CardContent>
      </Card>
      
      <Card className="border-l-4 border-l-green-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Aprovados</CardTitle>
          <CheckCircle className="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-700">{stats.approved}</div>
          <p className="text-xs text-muted-foreground">
            Ativos no sistema
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
