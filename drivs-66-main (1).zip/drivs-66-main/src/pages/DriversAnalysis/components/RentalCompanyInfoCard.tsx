
import { Card, CardContent } from "@/components/ui/card";
import { Users } from "lucide-react";

interface RentalCompanyInfoCardProps {
  driversCount: number;
}

export const RentalCompanyInfoCard = ({ driversCount }: RentalCompanyInfoCardProps) => {
  return (
    <Card className="border-l-4 border-l-green-500">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-sm text-green-800">
          <Users className="h-4 w-4" />
          <span className="font-medium">
            Exibindo apenas motoristas que se cadastraram através do seu link de referência ({driversCount} motoristas)
          </span>
        </div>
      </CardContent>
    </Card>
  );
};
