
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  FileText, 
  Eye, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  CreditCard,
  Calendar,
  Camera
} from "lucide-react";
import { toast } from "sonner";

interface Driver {
  id: string;
  fullName: string;
  cpf: string;
  email: string;
  phone: string;
  status: string;
  documents: {
    cnh: { status: string; url: string; number?: string; category?: string; issueDate?: string; expiryDate?: string };
    rg: { status: string; url: string; reason?: string };
    cpf: { status: string; url: string };
    comprovante_residencia: { status: string; url: string; reason?: string };
  };
  address: {
    street: string;
    neighborhood: string;
    city: string;
    state: string;
    zipCode: string;
  };
  created_at: string;
  violations: number;
  rating: number;
}

interface DriverAnalysisModalProps {
  driver: Driver | null;
  isOpen: boolean;
  onClose: () => void;
  onApprove: (driverId: string, driverName: string) => void;
  onReject: (driverId: string, driverName: string) => void;
  onRequestResubmission: (driverId: string, driverName: string, document: string) => void;
  isViewOnly?: boolean;
}

export const DriverAnalysisModal = ({
  driver,
  isOpen,
  onClose,
  onApprove,
  onReject,
  onRequestResubmission,
  isViewOnly = false
}: DriverAnalysisModalProps) => {
  const [documentStatuses, setDocumentStatuses] = useState<{[key: string]: string}>({});

  if (!driver) return null;

  const getDocumentStatusBadge = (status: string) => {
    const statusConfig: any = {
      pending: { label: "Pendente", variant: "outline", className: "border-yellow-500 text-yellow-500 bg-yellow-50" },
      approved: { label: "Aprovado", variant: "default", className: "bg-green-500 text-white" },
      rejected: { label: "Reprovado", variant: "destructive", className: "bg-red-500 text-white" },
      resubmission: { label: "Reenvio Solicitado", variant: "outline", className: "border-orange-500 text-orange-500 bg-orange-50" }
    };

    const config = statusConfig[status] || statusConfig.pending;
    
    return (
      <Badge variant={config.variant} className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const handleDocumentAction = (action: string, docType: string) => {
    const newStatuses = { ...documentStatuses };
    
    switch (action) {
      case "approve":
        newStatuses[docType] = "approved";
        toast.success(`Documento ${docType.toUpperCase()} marcado como aprovado!`);
        break;
      case "reject":
        newStatuses[docType] = "rejected";
        toast.info(`Documento ${docType.toUpperCase()} marcado como reprovado!`);
        break;
      case "request":
        newStatuses[docType] = "resubmission";
        toast.info(`Documento ${docType.toUpperCase()} marcado para reenvio!`);
        break;
    }
    
    setDocumentStatuses(newStatuses);
  };

  const documents = [
    {
      name: "Foto do Perfil",
      type: "foto_perfil",
      status: documentStatuses["foto_perfil"] || "pending",
      icon: User
    },
    {
      name: "Foto Segurando CNH",
      type: "foto_cnh",
      status: documentStatuses["foto_cnh"] || "pending",
      icon: Camera
    },
    {
      name: "CNH (PDF ou Foto)",
      type: "cnh",
      status: documentStatuses["cnh"] || driver.documents.cnh.status,
      icon: CreditCard
    },
    {
      name: "Comprovante de Residência",
      type: "comprovante_residencia",
      status: documentStatuses["comprovante_residencia"] || driver.documents.comprovante_residencia.status,
      icon: MapPin
    },
    {
      name: "Print Perfil App (99/Uber)",
      type: "print_app",
      status: documentStatuses["print_app"] || "pending",
      icon: Phone
    }
  ];

  // Verificar se todos os documentos estão aprovados
  const allApproved = documents.every(doc => doc.status === "approved");
  
  // Verificar se algum documento precisa de reenvio
  const hasResubmission = documents.some(doc => doc.status === "resubmission");
  
  // Verificar se algum documento foi reprovado
  const hasRejected = documents.some(doc => doc.status === "rejected");

  const handleFinalApprove = () => {
    console.log("✅ Executando aprovação final do motorista");
    onApprove(driver.id, driver.fullName);
  };

  const handleFinalReject = () => {
    console.log("❌ Executando rejeição final do motorista");
    onReject(driver.id, driver.fullName);
  };

  const handleRequestResubmissionFinal = () => {
    const documentsToResubmit = documents
      .filter(doc => doc.status === "resubmission")
      .map(doc => doc.name)
      .join(", ");
    
    console.log("📄 Executando solicitação de reenvio de documentos:", documentsToResubmit);
    onRequestResubmission(driver.id, driver.fullName, documentsToResubmit);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {isViewOnly ? "VISUALIZAÇÃO DO MOTORISTA" : "ANÁLISE DETALHADA DO MOTORISTA"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Informações do Motorista - Seção Superior */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Dados Pessoais */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <User className="h-5 w-5" />
                  DADOS PESSOAIS
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                    <User className="w-8 h-8 text-gray-500" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{driver.fullName.toUpperCase()}</h3>
                    <p className="text-gray-600">{driver.email}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <span className="font-medium">CPF:</span>
                    <p>{driver.cpf}</p>
                  </div>
                  <div>
                    <span className="font-medium">Telefone:</span>
                    <p>{driver.phone}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Carteira de Motorista */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  CARTEIRA DE MOTORISTA
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <span className="font-medium">Número:</span>
                    <p>12345678901</p>
                  </div>
                  <div>
                    <span className="font-medium">Categoria:</span>
                    <p>AB</p>
                  </div>
                  <div>
                    <span className="font-medium">Data de Emissão:</span>
                    <p>14/06/2020</p>
                  </div>
                  <div>
                    <span className="font-medium">Validade:</span>
                    <div className="flex items-center gap-2">
                      <p>14/06/2025</p>
                      <Badge className="bg-red-500 text-white text-xs">Vence em breve</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Endereço */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  ENDEREÇO
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <span className="font-medium">Logradouro:</span>
                    <p>Rua das Flores, 123</p>
                  </div>
                  <div>
                    <span className="font-medium">Bairro:</span>
                    <p>Centro</p>
                  </div>
                  <div>
                    <span className="font-medium">Cidade:</span>
                    <p>São Paulo - SP</p>
                  </div>
                  <div>
                    <span className="font-medium">CEP:</span>
                    <p>01234-567</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Análise de Documentos - Seção Inferior */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                {isViewOnly ? "DOCUMENTOS" : "ANÁLISE DE DOCUMENTOS"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {documents.map((doc) => (
                <div key={doc.type} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <doc.icon className="h-5 w-5 text-gray-500" />
                      <div>
                        <p className="font-medium">{doc.name}</p>
                        {getDocumentStatusBadge(doc.status)}
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-1" />
                      Visualizar
                    </Button>
                  </div>
                  
                  {/* Ações para cada documento - só mostrar se não for modo visualização */}
                  {!isViewOnly && (
                    <div className="flex flex-wrap gap-2">
                      <Button 
                        variant="default" 
                        size="sm"
                        className="bg-green-600 hover:bg-green-700 text-white"
                        onClick={() => handleDocumentAction("approve", doc.type)}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        {doc.status === "approved" ? "✓ Aprovado" : "Aprovar"}
                      </Button>
                      <Button 
                        variant="destructive" 
                        size="sm"
                        onClick={() => handleDocumentAction("reject", doc.type)}
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        {doc.status === "rejected" ? "✓ Reprovado" : "Reprovar"}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="border-orange-500 text-orange-500 hover:bg-orange-50"
                        onClick={() => handleDocumentAction("request", doc.type)}
                      >
                        <AlertCircle className="h-4 w-4 mr-1" />
                        {doc.status === "resubmission" ? "✓ Marcado para Reenvio" : "Solicitar Reenvio"}
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Ações Finais - só mostrar se não for modo visualização */}
        <div className="flex justify-end gap-3 pt-6 border-t">
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
          
          {!isViewOnly && (
            <>
              {hasResubmission && (
                <Button 
                  variant="outline"
                  className="border-orange-500 text-orange-500 hover:bg-orange-50"
                  onClick={handleRequestResubmissionFinal}
                >
                  <AlertCircle className="h-4 w-4 mr-2" />
                  Confirmar Solicitação de Reenvios
                </Button>
              )}
              
              {hasRejected && (
                <Button 
                  variant="destructive"
                  onClick={handleFinalReject}
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Reprovar Motorista
                </Button>
              )}
              
              {allApproved && (
                <Button 
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={handleFinalApprove}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Aprovar Motorista
                </Button>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
