
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Eye, Users, Clock, Send } from "lucide-react";
import type { Driver } from "../types/Driver";

interface RentalCompanyDriversTableProps {
  drivers: Driver[];
  onViewDriver: (driver: Driver) => void;
  onAnalyzeDriver: (driver: Driver) => void;
  onSendToDrivs: (driverId: string, driverName: string) => void;
}

export const RentalCompanyDriversTable = ({ 
  drivers, 
  onViewDriver, 
  onAnalyzeDriver, 
  onSendToDrivs 
}: RentalCompanyDriversTableProps) => {
  const getStatusBadge = (status: string) => {
    const statusConfig: any = {
      pending: { label: "Em Aberto", variant: "outline", className: "border-blue-500 text-blue-500 bg-blue-50" },
      pending_documents: { label: "Aguardando Reenvio", variant: "outline", className: "border-orange-500 text-orange-500 bg-orange-50" },
      under_review: { label: "Em Análise da DRIVS", variant: "outline", className: "border-purple-500 text-purple-500 bg-purple-50" },
      in_analysis: { label: "Em Análise", variant: "outline", className: "border-yellow-500 text-yellow-500 bg-yellow-50" },
      active: { label: "Ativo", variant: "default", className: "bg-green-500 text-white" },
      approved: { label: "Aprovado", variant: "default", className: "bg-green-500 text-white" },
      rejected: { label: "Reprovado", variant: "destructive", className: "bg-red-500 text-white" }
    };

    const config = statusConfig[status] || statusConfig.pending;
    
    return (
      <Badge variant={config.variant} className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const getDocumentStatus = (documents: any) => {
    return { icon: Clock, color: "text-yellow-500", text: `Pendente`, badge: "Pendente" };
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          MOTORISTAS ({drivers.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {drivers.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Motorista</TableHead>
                  <TableHead>Status Documentos</TableHead>
                  <TableHead className="hidden lg:table-cell">Data Cadastro</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {drivers.map((driver) => {
                  const docStatus = getDocumentStatus(driver.documents);
                  
                  return (
                    <TableRow key={driver.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                            <Users className="w-5 h-5 text-gray-500" />
                          </div>
                          <div>
                            <p className="font-medium">{driver.fullName}</p>
                            <p className="text-sm text-muted-foreground">{driver.cpf}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{docStatus.badge}</span>
                        </div>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        {new Date(driver.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{getStatusBadge(driver.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onViewDriver(driver)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Ver
                          </Button>
                          {(driver.status === "pending" || driver.status === "pending_documents") && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => onAnalyzeDriver(driver)}
                              >
                                {driver.status === "pending_documents" ? "Revisar" : "Analisar"}
                              </Button>
                              <Button
                                variant="default"
                                size="sm"
                                className="bg-blue-600 hover:bg-blue-700 text-white"
                                onClick={() => onSendToDrivs(driver.id, driver.fullName)}
                              >
                                <Send className="h-4 w-4 mr-1" />
                                Enviar para DRIVS
                              </Button>
                            </>
                          )}
                          {driver.status === "in_analysis" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => onAnalyzeDriver(driver)}
                            >
                              Continuar Análise
                            </Button>
                          )}
                          {driver.status === "under_review" && (
                            <div className="flex flex-col items-center gap-1">
                              <span className="text-sm text-purple-600 font-medium">
                                Em análise pela DRIVS
                              </span>
                              <span className="text-xs text-gray-500">
                                Aguarde o resultado
                              </span>
                            </div>
                          )}
                          {driver.status === "pending_documents" && (
                            <span className="text-sm text-orange-600 font-medium">
                              Aguardando reenvio
                            </span>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-muted-foreground">
              Nenhum motorista encontrado.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
