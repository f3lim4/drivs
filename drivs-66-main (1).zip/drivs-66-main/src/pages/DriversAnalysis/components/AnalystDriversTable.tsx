
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Eye, Users, Clock } from "lucide-react";

interface Driver {
  id: string;
  fullName: string;
  cpf: string;
  email: string;
  phone: string;
  status: string;
  documents: {
    cnh: { status: string; url: string; number?: string; category?: string; issueDate?: string; expiryDate?: string };
    rg: { status: string; url: string; reason?: string };
    cpf: { status: string; url: string };
    comprovante_residencia: { status: string; url: string; reason?: string };
  };
  address: {
    street: string;
    neighborhood: string;
    city: string;
    state: string;
    zipCode: string;
  };
  created_at: string;
  violations: number;
  rating: number;
  rentalCompany?: string;
}

interface DriversTableProps {
  drivers: Driver[];
  onAnalyzeDriver: (driver: Driver) => void;
  onViewDriver: (driver: Driver) => void;
}

export const AnalystDriversTable = ({ drivers, onAnalyzeDriver, onViewDriver }: DriversTableProps) => {
  const getStatusBadge = (status: string) => {
    const statusConfig: any = {
      pending: { label: "Em Aberto", variant: "outline", className: "border-blue-500 text-blue-500 bg-blue-50" },
      sent_to_drivs: { label: "Aguardando Análise", variant: "outline", className: "border-blue-500 text-blue-500 bg-blue-50" },
      in_analysis: { label: "Em Análise", variant: "outline", className: "border-yellow-500 text-yellow-500 bg-yellow-50" },
      approved: { label: "Aprovado", variant: "default", className: "bg-green-500 text-white" },
      rejected: { label: "Reprovado", variant: "destructive", className: "bg-red-500 text-white" }
    };

    const config = statusConfig[status] || statusConfig.pending;
    
    return (
      <Badge variant={config.variant} className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const getDocumentStatus = (documents: any) => {
    return { icon: Clock, color: "text-yellow-500", text: `Pendente`, badge: "Pendente" };
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          MOTORISTAS PARA ANÁLISE ({drivers.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {drivers.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Motorista</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Locadora</TableHead>
                  <TableHead>Status Documentos</TableHead>
                  <TableHead className="hidden lg:table-cell">Data Envio</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {drivers.map((driver) => {
                  const docStatus = getDocumentStatus(driver.documents);
                  
                  return (
                    <TableRow key={driver.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                            <Users className="w-5 h-5 text-gray-500" />
                          </div>
                          <div>
                            <p className="font-medium">{driver.fullName}</p>
                            <p className="text-sm text-muted-foreground">{driver.cpf}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <p className="text-sm">{driver.email || 'Email não informado'}</p>
                      </TableCell>
                      <TableCell>
                        <p className="font-medium text-sm">{driver.rentalCompany || 'Sem Locadora'}</p>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{docStatus.badge}</span>
                        </div>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        {new Date(driver.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{getStatusBadge(driver.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onViewDriver(driver)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Ver
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onAnalyzeDriver(driver)}
                          >
                            Analisar
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-muted-foreground">
              Nenhum motorista encontrado com os filtros aplicados.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
