
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter } from "lucide-react";

interface RentalCompanyFiltersProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  statusFilter?: string;
  onStatusFilterChange?: (value: string) => void;
}

export const RentalCompanyFilters = ({
  searchQuery,
  onSearchChange,
  statusFilter = "all",
  onStatusFilterChange
}: RentalCompanyFiltersProps) => {
  const statusOptions = [
    { value: "all", label: "Todos os motoristas" },
    { value: "pending", label: "Aguardando análise" },
    { value: "under_review", label: "Em análise da DRIVS" },
    { value: "approved", label: "Aprovados" },
    { value: "active", label: "Ativos" },
    { value: "pending_documents", label: "Aguardando reenvio" },
    { value: "in_analysis", label: "Em análise interna" },
    { value: "rejected", label: "Rejeitados" }
  ];

  return (
    <Card className="content-card">
      <CardContent className="p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome, CPF ou email..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          {onStatusFilterChange && (
            <div className="w-full sm:w-64">
              <Select value={statusFilter} onValueChange={onStatusFilterChange}>
                <SelectTrigger>
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
