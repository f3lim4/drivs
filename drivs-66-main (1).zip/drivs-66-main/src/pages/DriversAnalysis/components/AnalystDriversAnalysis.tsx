import { useState, useEffect } from "react";
import { toast } from "sonner";
import { DriverAnalysisModal } from "./DriverAnalysisModal";
import { AnalystStatsCards } from "./AnalystStatsCards";
import { AnalystFilters } from "./AnalystFilters";
import { AnalystDriversTable } from "./AnalystDriversTable";

interface Driver {
  id: string;
  fullName: string;
  cpf: string;
  email: string;
  phone: string;
  status: string;
  documents: {
    cnh: { status: string; url: string; number?: string; category?: string; issueDate?: string; expiryDate?: string };
    rg: { status: string; url: string; reason?: string };
    cpf: { status: string; url: string };
    comprovante_residencia: { status: string; url: string; reason?: string };
  };
  address: {
    street: string;
    neighborhood: string;
    city: string;
    state: string;
    zipCode: string;
  };
  created_at: string;
  violations: number;
  rating: number;
  rentalCompany?: string;
}

export const AnalystDriversAnalysis = () => {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState(false);
  const [isViewOnly, setIsViewOnly] = useState(false);

  useEffect(() => {
    const fetchDrivers = async () => {
      setLoading(true);
      try {
        // Dados limpos - preparado para integração com banco de dados
        setDrivers([]);
      } catch (error) {
        console.error("Error fetching drivers:", error);
        toast.error("Erro ao carregar lista de motoristas");
      } finally {
        setLoading(false);
      }
    };

    fetchDrivers();
  }, []);

  const filteredDrivers = drivers.filter((driver) => {
    const matchesSearch = driver.fullName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         driver.cpf?.includes(searchQuery) ||
                         driver.rentalCompany?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || driver.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleAnalyzeDriver = (driver: Driver) => {
    setDrivers(prev => prev.map(d => 
      d.id === driver.id 
        ? { ...d, status: "in_analysis" }
        : d
    ));
    
    setSelectedDriver({...driver, status: "in_analysis"});
    setIsViewOnly(false);
    setIsAnalysisModalOpen(true);
    toast.info(`Iniciando análise do motorista ${driver.fullName}`);
  };

  const handleViewDriver = (driver: Driver) => {
    setSelectedDriver(driver);
    setIsViewOnly(true);
    setIsAnalysisModalOpen(true);
  };

  const handleApproveDriver = (driverId: string, driverName: string) => {
    setDrivers(prev => prev.map(driver => 
      driver.id === driverId 
        ? { ...driver, status: "approved" }
        : driver
    ));
    toast.success(`Motorista ${driverName} aprovado pela DRIVS!`);
    setIsAnalysisModalOpen(false);
  };

  const handleRejectDriver = (driverId: string, driverName: string) => {
    setDrivers(prev => prev.map(driver => 
      driver.id === driverId 
        ? { ...driver, status: "rejected" }
        : driver
    ));
    toast.error(`Motorista ${driverName} reprovado pela DRIVS!`);
    setIsAnalysisModalOpen(false);
  };

  const handleRequestResubmission = (driverId: string, driverName: string, document: string) => {
    setDrivers(prev => prev.map(driver => 
      driver.id === driverId 
        ? { ...driver, status: "sent_to_drivs" }
        : driver
    ));
    toast.info(`Solicitação de reenvio enviada para ${driverName} - Documentos: ${document}`);
    setIsAnalysisModalOpen(false);
  };

  const stats = {
    awaitingAnalysis: filteredDrivers.filter(d => d.status === "sent_to_drivs").length,
    inAnalysis: filteredDrivers.filter(d => d.status === "in_analysis").length,
    approved: filteredDrivers.filter(d => d.status === "approved").length
  };

  if (loading) {
    return (
      <div className="page-content">
        <div className="h-10 w-full max-w-xs bg-gradient-to-r from-blue-200 to-purple-200 animate-pulse rounded"></div>
        <div className="h-12 w-full bg-gradient-to-r from-blue-100 to-purple-100 animate-pulse rounded mt-4"></div>
        <div className="h-96 w-full bg-gradient-to-r from-blue-50 to-purple-50 animate-pulse rounded mt-4"></div>
      </div>
    );
  }

  return (
    <div className="page-content">
      <div className="space-y-6">
        <div className="page-header">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              ANÁLISE DE MOTORISTAS - DRIVS
            </h1>
            <p className="page-subtitle">
              Análise profissional de motoristas enviados pelas locadoras
            </p>
          </div>
        </div>

        <AnalystStatsCards stats={stats} />
        
        <AnalystFilters 
          searchQuery={searchQuery}
          statusFilter={statusFilter}
          onSearchChange={setSearchQuery}
          onStatusFilterChange={setStatusFilter}
        />

        <AnalystDriversTable 
          drivers={filteredDrivers}
          onAnalyzeDriver={handleAnalyzeDriver}
          onViewDriver={handleViewDriver}
        />

        <DriverAnalysisModal
          driver={selectedDriver}
          isOpen={isAnalysisModalOpen}
          onClose={() => setIsAnalysisModalOpen(false)}
          onApprove={handleApproveDriver}
          onReject={handleRejectDriver}
          onRequestResubmission={handleRequestResubmission}
          isViewOnly={isViewOnly}
        />
      </div>
    </div>
  );
};
