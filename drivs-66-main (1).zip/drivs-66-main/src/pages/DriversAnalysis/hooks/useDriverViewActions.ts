
import type { Driver } from "../types/Driver";
import { useAuthenticationChecks } from "./useAuthenticationChecks";

interface UseDriverViewActionsProps {
  drivers: Driver[];
  onAnalyzeDriver: (driver: Driver) => void;
  onViewDriver: (driver: Driver) => void;
}

export const useDriverViewActions = ({ 
  drivers, 
  onAnalyzeDriver, 
  onViewDriver 
}: UseDriverViewActionsProps) => {
  const { ensureAuthenticated } = useAuthenticationChecks(drivers);

  const handleAnalyzeDriver = (driver: Driver) => {
    console.log('📄 Executando análise de motorista:', driver.fullName);
    console.log('📄 [ACTION] Iniciando análise:', driver.fullName, `(${driver.id})`);
    
    if (!ensureAuthenticated('Análise de motorista')) return;
    
    onAnalyzeDriver(driver);
  };

  const handleViewDriver = (driver: Driver) => {
    console.log('👁️ Visualizando motorista:', driver.fullName);
    
    if (!ensureAuthenticated('Visualização de motorista')) return;
    
    onViewDriver(driver);
  };

  return {
    handleAnalyzeDriver,
    handleViewDriver
  };
};
