
import { useEffect } from "react";
import { toast } from "sonner";
import { debugDriverAssociations } from "../utils/driverAccessUtils";
import { useDriverDataFetcher } from "./useDriverDataFetcher";
import { useDriverStateManager } from "./useDriverStateManager";
import { processDriversTableData, processRegistrationsData, logDriverStatistics } from "../utils/driverDataProcessor";

export const useDriversData = (userId: string | undefined) => {
  const { drivers, setDrivers, loading, setLoading, updateLocalDriverStatus } = useDriverStateManager();
  const { fetchDriversFromTable, fetchDriverRegistrations, debugAllDriverData } = useDriverDataFetcher();

  const fetchDrivers = async (showLoadingToast = false) => {
    if (!userId) {
      console.log('⚠️ [FETCH] Nenhum userId fornecido, abortando busca');
      setLoading(false);
      return;
    }

    setLoading(true);
    
    if (showLoadingToast) {
      toast.info('Atualizando lista de motoristas...');
    }

    try {
      console.log('🔍 [FETCH] === INICIANDO BUSCA DE MOTORISTAS ===');
      console.log('🏢 [FETCH] Locadora ID:', userId);

      // Executar diagnóstico completo
      await debugAllDriverData(userId);

      // Debug: Listar todas as associações para debugging
      const debugInfo = await debugDriverAssociations(userId);
      console.log('🐛 [DEBUG] Informações de associação:', debugInfo);

      // Buscar dados de ambas as tabelas
      const [driversTableData, registrationsData] = await Promise.all([
        fetchDriversFromTable(userId),
        fetchDriverRegistrations(userId)
      ]);

      console.log('📋 [RESULT] Motoristas da tabela drivers:', driversTableData.length);
      console.log('📋 [RESULT] Registros da tabela driver_registrations:', registrationsData.length);

      // Processar dados das duas tabelas
      let allDrivers = processDriversTableData(driversTableData);
      const registrationDrivers = processRegistrationsData(registrationsData, allDrivers);
      allDrivers = [...allDrivers, ...registrationDrivers];

      console.log(`✅ [RESULT] Total de motoristas carregados para análise: ${allDrivers.length}`);
      
      // Log estatísticas detalhadas
      logDriverStatistics(allDrivers);

      setDrivers(allDrivers);

      if (showLoadingToast) {
        toast.success(`Lista atualizada! ${allDrivers.length} motoristas carregados.`);
      }

    } catch (error: any) {
      console.error('❌ Erro crítico ao carregar motoristas para análise:', error);
      toast.error('Erro ao carregar lista de motoristas para análise');
      setDrivers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDrivers();
  }, [userId]);

  const refreshFromDatabase = () => {
    console.log('🔄 [REFRESH] Recarregando dados do banco de dados...');
    fetchDrivers(true);
  };

  return {
    drivers,
    loading,
    refetchDrivers: fetchDrivers,
    updateLocalDriverStatus,
    refreshFromDatabase
  };
};
