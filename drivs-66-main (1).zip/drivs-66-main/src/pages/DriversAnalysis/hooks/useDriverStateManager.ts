
import { useState } from "react";
import type { Driver } from "../types/Driver";

export const useDriverStateManager = () => {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);

  const updateLocalDriverStatus = (driverId: string, newStatus: string) => {
    console.log(`🔄 [LOCAL UPDATE] Atualizando status local do motorista ${driverId} para ${newStatus}`);
    
    setDrivers(prev => {
      const updated = prev.map(d => 
        d.id === driverId 
          ? { ...d, status: newStatus }
          : d
      );
      
      const updatedDriver = updated.find(d => d.id === driverId);
      console.log(`✅ [LOCAL UPDATE] Status local atualizado:`, {
        driverId,
        oldStatus: prev.find(d => d.id === driverId)?.status,
        newStatus: updatedDriver?.status
      });
      
      return updated;
    });
  };

  return {
    drivers,
    setDrivers,
    loading,
    setLoading,
    updateLocalDriverStatus
  };
};
