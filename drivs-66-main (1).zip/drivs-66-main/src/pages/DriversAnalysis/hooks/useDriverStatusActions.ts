
import { useState } from "react";
import { toast } from "sonner";
import type { Driver } from "../types/Driver";
import { useDriverOperations } from "./useDriverOperations";
import { useAuthenticationChecks } from "./useAuthenticationChecks";

interface UseDriverStatusActionsProps {
  drivers: Driver[];
  onDriverStatusUpdate: (driverId: string, newStatus: string) => void;
}

export const useDriverStatusActions = ({ 
  drivers, 
  onDriverStatusUpdate 
}: UseDriverStatusActionsProps) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const { updateDriverStatus } = useDriverOperations({
    drivers,
    onDriverStatusUpdate,
    onAnalyzeDriver: () => {},
    onViewDriver: () => {}
  });
  const { ensureAuthenticated, ensureDriverAccess, user } = useAuthenticationChecks(drivers);

  const handleSendToDrivs = async (driverId: string, driverName: string) => {
    if (!ensureAuthenticated('Envio para DRIVS')) return;
    if (isProcessing) return;

    console.log('📤 [ACTION] Iniciando envio para DRIVS:', driverName, `(${driverId})`);
    
    const driver = drivers.find(d => d.id === driverId);
    if (!driver) {
      toast.error('Motorista não encontrado');
      return;
    }

    if (!(await ensureDriverAccess(driver, 'Envio para DRIVS'))) return;

    setIsProcessing(true);
    console.log('🔄 [SEND TO DRIVS] Alterando status para under_review');
    
    try {
      const success = await updateDriverStatus(driverId, 'under_review', user);
      if (success) {
        toast.success(`${driverName} foi enviado para análise da DRIVS com sucesso!`);
        console.log('✅ [SEND TO DRIVS] Motorista enviado com sucesso');
      }
    } catch (error) {
      console.error('❌ [SEND TO DRIVS] Erro:', error);
      toast.error('Erro ao enviar motorista para DRIVS');
    } finally {
      setIsProcessing(false);
      console.log('🔚 [OPERATION] Operação Envio para DRIVS finalizada');
    }
  };

  const handleApproveDriver = async (driverId: string, driverName: string) => {
    if (!ensureAuthenticated('Aprovação de motorista')) return;
    if (isProcessing) return;

    const driver = drivers.find(d => d.id === driverId);
    if (!driver) {
      toast.error('Motorista não encontrado');
      return;
    }

    if (!(await ensureDriverAccess(driver, 'Aprovação de motorista'))) return;

    console.log('✅ [APPROVE] Aprovando motorista:', driverName, `(${driverId})`);
    
    setIsProcessing(true);
    
    try {
      const success = await updateDriverStatus(driverId, 'approved', user);
      if (success) {
        toast.success(`${driverName} foi aprovado com sucesso!`);
        console.log('✅ [APPROVE] Motorista aprovado com sucesso');
      }
    } catch (error) {
      console.error('❌ [APPROVE] Erro:', error);
      toast.error('Erro ao aprovar motorista');
    } finally {
      setIsProcessing(false);
      console.log('🔚 [OPERATION] Operação Aprovação finalizada');
    }
  };

  const handleRejectDriver = async (driverId: string, driverName: string, reason?: string) => {
    if (!ensureAuthenticated('Rejeição de motorista')) return;
    if (isProcessing) return;

    const driver = drivers.find(d => d.id === driverId);
    if (!driver) {
      toast.error('Motorista não encontrado');
      return;
    }

    if (!(await ensureDriverAccess(driver, 'Rejeição de motorista'))) return;

    console.log('❌ [REJECT] Rejeitando motorista:', driverName, 'Motivo:', reason);
    
    setIsProcessing(true);
    
    try {
      const success = await updateDriverStatus(driverId, 'rejected', user);
      if (success) {
        toast.success(`${driverName} foi rejeitado.`);
        console.log('✅ [REJECT] Motorista rejeitado com sucesso');
      }
    } catch (error) {
      console.error('❌ [REJECT] Erro:', error);
      toast.error('Erro ao rejeitar motorista');
    } finally {
      setIsProcessing(false);
      console.log('🔚 [OPERATION] Operação Rejeição finalizada');
    }
  };

  const handleRequestResubmission = async (driverId: string, driverName: string, documents?: string) => {
    if (!ensureAuthenticated('Solicitação de reenvio de documentos')) return;
    if (isProcessing) return;

    const driver = drivers.find(d => d.id === driverId);
    if (!driver) {
      toast.error('Motorista não encontrado');
      return;
    }

    if (!(await ensureDriverAccess(driver, 'Solicitação de reenvio de documentos'))) return;

    console.log('📄 [RESUBMIT] Solicitando reenvio de documentos para', driverName, '- Documentos:', documents);
    
    setIsProcessing(true);
    
    try {
      const success = await updateDriverStatus(driverId, 'pending_documents', user);
      if (success) {
        toast.success(`Solicitação de reenvio enviada para ${driverName}`);
        console.log('✅ [RESUBMIT] Solicitação de reenvio enviada com sucesso');
      }
    } catch (error) {
      console.error('❌ [RESUBMIT] Erro:', error);
      toast.error('Erro ao solicitar reenvio de documentos');
    } finally {
      setIsProcessing(false);
      console.log('🔚 [OPERATION] Operação Solicitação de reenvio de documentos finalizada');
    }
  };

  return {
    handleSendToDrivs,
    handleApproveDriver,
    handleRejectDriver,
    handleRequestResubmission,
    isProcessing
  };
};
