
import { useState } from "react";
import type { Driver } from "../types/Driver";
import { verifyDriverAccess } from "../utils/driverAccessUtils";
import { useDriverStatusUpdater } from "./useDriverStatusUpdater";

interface DriverOperationsProps {
  drivers: Driver[];
  onDriverStatusUpdate: (driverId: string, newStatus: string) => void;
  onAnalyzeDriver: (driver: Driver) => void;
  onViewDriver: (driver: Driver) => void;
}

export const useDriverOperations = ({
  drivers,
  onDriverStatusUpdate,
  onAnalyzeDriver,
  onViewDriver
}: DriverOperationsProps) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const { updateDriverStatus } = useDriverStatusUpdater();

  // ✅ FUNÇÃO PARA ATUALIZAR STATUS COM CALLBACK LOCAL
  const updateDriverStatusWithCallback = async (
    driverId: string,
    newStatus: string,
    user: any
  ): Promise<boolean> => {
    const success = await updateDriverStatus(driverId, newStatus, user, drivers);
    
    if (success) {
      // Atualizar estado local
      onDriverStatusUpdate(driverId, newStatus);
    }
    
    return success;
  };

  return {
    isProcessing,
    setIsProcessing,
    updateDriverStatus: updateDriverStatusWithCallback,
    verifyDriverAccess
  };
};
