
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Driver } from "../types/Driver";

export const useDriverDataFetcher = () => {
  const fetchDriversFromTable = async (userId: string) => {
    console.log('📋 [FETCH DRIVERS] Buscando motoristas da tabela drivers para locadora:', userId);
    
    const { data: driversData, error: driversError } = await supabase
      .from('drivers')
      .select('*')
      .eq('company_id', userId)
      .order('created_at', { ascending: false });

    if (driversError && driversError.code !== 'PGRST116') {
      console.error('❌ Erro ao carregar motoristas da tabela drivers:', driversError);
      throw driversError;
    }

    console.log(`📊 [FETCH DRIVERS] Encontrados ${driversData?.length || 0} motoristas na tabela drivers`);
    if (driversData && driversData.length > 0) {
      console.log('📋 [DRIVERS] Primeiros registros:', driversData.slice(0, 3));
    }

    return driversData || [];
  };

  const fetchDriverRegistrations = async (userId: string) => {
    console.log('📋 [FETCH REGISTRATIONS] Buscando registros da tabela driver_registrations para locadora:', userId);
    
    const { data: registrationsData, error: registrationsError } = await supabase
      .from('driver_registrations')
      .select('*')
      .eq('referral_company_id', userId)
      .order('created_at', { ascending: false });

    if (registrationsError && registrationsError.code !== 'PGRST116') {
      console.error('❌ Erro ao carregar registros de motoristas:', registrationsError);
      throw registrationsError;
    }

    console.log(`📊 [FETCH REGISTRATIONS] Encontrados ${registrationsData?.length || 0} registros na tabela driver_registrations`);
    if (registrationsData && registrationsData.length > 0) {
      console.log('📋 [REGISTRATIONS] Primeiros registros:', registrationsData.slice(0, 3));
    }

    return registrationsData || [];
  };

  const debugAllDriverData = async (userId: string) => {
    console.log('🐛 [DEBUG] === DIAGNÓSTICO COMPLETO DE MOTORISTAS ===');
    console.log('🏢 [DEBUG] Locadora ID:', userId);
    
    try {
      // Buscar TODOS os registros para debug
      console.log('🔍 [DEBUG] Buscando TODOS os registros de driver_registrations...');
      const { data: allRegistrations, error: allRegError } = await supabase
        .from('driver_registrations')
        .select('id, full_name, email, referral_company_id, status, created_at')
        .order('created_at', { ascending: false });
      
      if (allRegError) {
        console.error('❌ [DEBUG] Erro ao buscar todos os registros:', allRegError);
      } else {
        console.log(`📊 [DEBUG] Total de registros no sistema: ${allRegistrations?.length || 0}`);
        
        // Filtrar por locadora
        const companyRegistrations = allRegistrations?.filter(reg => reg.referral_company_id === userId) || [];
        console.log(`🏢 [DEBUG] Registros para esta locadora: ${companyRegistrations.length}`);
        
        if (companyRegistrations.length > 0) {
          console.log('📋 [DEBUG] Registros da locadora:', companyRegistrations);
        }
        
        // Mostrar outros registros para comparação
        const otherRegistrations = allRegistrations?.filter(reg => reg.referral_company_id !== userId) || [];
        console.log(`👥 [DEBUG] Registros de outras locadoras: ${otherRegistrations.length}`);
      }

      // Buscar TODOS os motoristas da tabela drivers
      console.log('🔍 [DEBUG] Buscando TODOS os motoristas da tabela drivers...');
      const { data: allDrivers, error: allDriversError } = await supabase
        .from('drivers')
        .select('id, full_name, email, company_id, status, created_at')
        .order('created_at', { ascending: false });
      
      if (allDriversError) {
        console.error('❌ [DEBUG] Erro ao buscar todos os motoristas:', allDriversError);
      } else {
        console.log(`📊 [DEBUG] Total de motoristas no sistema: ${allDrivers?.length || 0}`);
        
        // Filtrar por locadora
        const companyDrivers = allDrivers?.filter(driver => driver.company_id === userId) || [];
        console.log(`🏢 [DEBUG] Motoristas para esta locadora: ${companyDrivers.length}`);
        
        if (companyDrivers.length > 0) {
          console.log('📋 [DEBUG] Motoristas da locadora:', companyDrivers);
        }
      }
      
    } catch (error) {
      console.error('❌ [DEBUG] Erro no diagnóstico:', error);
    }
    
    console.log('🐛 [DEBUG] === FIM DO DIAGNÓSTICO ===');
  };

  return {
    fetchDriversFromTable,
    fetchDriverRegistrations,
    debugAllDriverData
  };
};
