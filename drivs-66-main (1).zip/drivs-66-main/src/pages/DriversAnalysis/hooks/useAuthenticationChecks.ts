
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import type { Driver } from "../types/Driver";
import { useDriverOperations } from "./useDriverOperations";

export const useAuthenticationChecks = (drivers: Driver[]) => {
  const { user } = useAuth();
  const { verifyDriverAccess } = useDriverOperations({
    drivers,
    onDriverStatusUpdate: () => {},
    onAnalyzeDriver: () => {},
    onViewDriver: () => {}
  });

  const ensureAuthenticated = (actionName: string): boolean => {
    console.log('🔐 [AUTH CHECK] Verificando autenticação antes de:', actionName);
    
    if (!user) {
      console.error('❌ [AUTH] Usuário não autenticado');
      toast.error('Você precisa estar logado para realizar esta ação');
      return false;
    }

    console.log('👤 [USER INFO] Usuário verificado:', {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name
    });

    if (!['rental_company', 'admin', 'analyst'].includes(user.role)) {
      console.error('❌ [AUTH] Role não autorizado:', user.role);
      toast.error('Você não tem permissão para realizar esta ação');
      return false;
    }

    console.log('✅ [AUTH] Usuário autenticado e autorizado:', user.email, user.role);
    return true;
  };

  const ensureDriverAccess = async (driver: Driver, actionName: string): Promise<boolean> => {
    console.log('🔍 [DRIVER ACCESS] Verificando acesso para:', actionName, driver.fullName);
    
    const hasAccess = await verifyDriverAccess(driver, user);
    if (!hasAccess) {
      console.error('❌ [DRIVER ACCESS] Acesso negado ao motorista:', driver.fullName);
      toast.error('Você não tem permissão para alterar este motorista');
      return false;
    }

    console.log('✅ [DRIVER ACCESS] Acesso confirmado ao motorista:', driver.fullName);
    return true;
  };

  return {
    ensureAuthenticated,
    ensureDriverAccess,
    user
  };
};
