
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Driver } from "../types/Driver";
import { verifyDriverAccess } from "../utils/driverAccessUtils";

export const useDriverStatusUpdater = () => {
  /**
   * Atualiza o status do motorista no banco de dados
   */
  const updateDriverStatus = async (
    driverId: string,
    newStatus: string,
    user: any,
    drivers: Driver[]
  ): Promise<boolean> => {
    console.log('🔄 [UPDATE] Iniciando atualização de status:', {
      driverId,
      newStatus,
      userRole: user?.role,
      userId: user?.id
    });

    try {
      // Encontrar o motorista na lista local primeiro
      const driver = drivers.find(d => d.id === driverId);
      if (!driver) {
        console.error('❌ [UPDATE] Motorista não encontrado na lista local');
        toast.error('Motorista não encontrado');
        return false;
      }

      console.log('📋 [UPDATE] Motorista encontrado:', {
        driverId: driver.id,
        driverName: driver.fullName,
        source: driver.source,
        referralCompanyId: driver.referralCompanyId
      });

      // Verificar acesso antes de atualizar
      const hasAccess = await verifyDriverAccess(driver, user);
      if (!hasAccess) {
        console.error('❌ [UPDATE] Usuário não tem permissão para alterar este motorista');
        toast.error('Você não tem permissão para alterar este motorista');
        return false;
      }

      console.log('✅ [UPDATE] Usuário tem permissão, procedendo com atualização');

      // Determinar qual tabela atualizar baseado na origem do motorista
      const tableName = driver.source === 'registrations' ? 'driver_registrations' : 'drivers';
      
      console.log('📋 [UPDATE] Atualizando tabela:', tableName);

      // Log detalhado dos dados antes da atualização
      console.log('🔍 [UPDATE] Dados para atualização:', {
        tableName,
        driverId,
        newStatus,
        currentStatus: driver.status,
        userRole: user?.role,
        userId: user?.id
      });

      // Atualizar diretamente na tabela usando Supabase, sem RPC
      // Isso evita problemas com autenticação customizada vs Supabase auth
      let updateQuery;
      
      if (tableName === 'driver_registrations') {
        // Para registros pendentes, verificar referral_company_id
        updateQuery = supabase
          .from('driver_registrations')
          .update({ 
            status: newStatus, 
            updated_at: new Date().toISOString() 
          })
          .eq('id', driverId);
          
        // Admin pode atualizar qualquer registro, locadora só os seus
        if (user.role === 'rental_company') {
          updateQuery = updateQuery.eq('referral_company_id', user.id);
        }
      } else {
        // Para motoristas ativos, verificar company_id
        updateQuery = supabase
          .from('drivers')
          .update({ 
            status: newStatus, 
            updated_at: new Date().toISOString() 
          })
          .eq('id', driverId);
          
        // Admin pode atualizar qualquer motorista, locadora só os seus
        if (user.role === 'rental_company') {
          updateQuery = updateQuery.eq('company_id', user.id);
        }
      }

      const { data, error } = await updateQuery.select();

      if (error) {
        console.error('❌ [UPDATE] Erro na atualização direta:', error);
        toast.error('Erro ao atualizar status do motorista: ' + error.message);
        return false;
      }

      console.log('✅ [UPDATE] Query executada com sucesso:', data);

      if (!data || data.length === 0) {
        console.error('❌ [UPDATE] Nenhum registro foi atualizado - verificar permissões');
        toast.error('Falha na atualização: sem permissão ou registro não encontrado');
        return false;
      }

      console.log('✅ [UPDATE] Status atualizado com sucesso:', {
        driverId,
        oldStatus: driver.status,
        newStatus,
        tableName,
        affectedRows: data.length
      });

      toast.success('Status do motorista atualizado com sucesso!');
      return true;

    } catch (error) {
      console.error('❌ [UPDATE] Erro crítico na atualização:', error);
      toast.error('Erro crítico ao atualizar motorista: ' + (error as Error).message);
      return false;
    }
  };

  return {
    updateDriverStatus
  };
};
