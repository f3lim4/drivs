
import type { Driver } from "../types/Driver";

export const processDriversTableData = (driversData: any[]): Driver[] => {
  return driversData.map((driver): Driver => ({
    id: driver.id,
    fullName: driver.full_name,
    cpf: driver.cpf,
    email: driver.email || '',
    phone: driver.phone,
    status: driver.status,
    documents: {
      cnh: { 
        status: driver.cnh ? "approved" : "pending", 
        url: driver.cnh_document || '',
        number: driver.cnh || '',
        expiryDate: driver.cnh_expires || ''
      },
      rg: { status: "pending", url: '' },
      cpf: { status: "approved", url: '' },
      comprovante_residencia: { 
        status: driver.address_proof ? "approved" : "pending", 
        url: driver.address_proof || '' 
      }
    },
    address: {
      street: driver.address,
      neighborhood: '',
      city: driver.city,
      state: driver.state,
      zipCode: driver.zip_code || ''
    },
    created_at: driver.created_at,
    violations: driver.violations || 0,
    rating: driver.rating || 0,
    referralCompanyId: driver.company_id,
    source: 'drivers' as const
  }));
};

export const processRegistrationsData = (registrationsData: any[], existingDrivers: Driver[]): Driver[] => {
  const existingDriverEmails = new Set(existingDrivers.map(d => d.email?.toLowerCase()));
  const existingDriverCpfs = new Set(existingDrivers.map(d => d.cpf));

  const visibleStatuses = [
    'pending', 
    'under_review', 
    'approved', 
    'active', 
    'pending_documents',
    'in_analysis',
    'rejected'
  ];

  const visibleRegistrations = registrationsData.filter(reg => {
    const emailExists = reg.email && existingDriverEmails.has(reg.email.toLowerCase());
    const cpfExists = reg.cpf && existingDriverCpfs.has(reg.cpf);
    
    if (emailExists || cpfExists) {
      console.log('⚠️ [DUPLICATE] Motorista já existe na tabela drivers:', reg.full_name);
      return false;
    }
    
    const isVisible = visibleStatuses.includes(reg.status);
    console.log('📊 [STATUS CHECK] Motorista:', reg.full_name, 'Status:', reg.status, 'Visível:', isVisible);
    return isVisible;
  });

  return visibleRegistrations.map((reg): Driver => ({
    id: reg.id,
    fullName: reg.full_name,
    cpf: reg.cpf,
    email: reg.email || '',
    phone: reg.phone,
    status: reg.status,
    documents: {
      cnh: { 
        status: reg.cnh_document ? "approved" : "pending", 
        url: reg.cnh_document || '',
        number: reg.cnh || ''
      },
      rg: { status: "pending", url: '' },
      cpf: { status: "approved", url: '' },
      comprovante_residencia: { 
        status: reg.address_proof ? "approved" : "pending", 
        url: reg.address_proof || '' 
      }
    },
    address: {
      street: reg.address,
      neighborhood: '',
      city: reg.city,
      state: reg.state,
      zipCode: reg.zip_code || ''
    },
    created_at: reg.created_at,
    violations: 0,
    rating: 0,
    referralCompanyId: reg.referral_company_id,
    source: 'registrations' as const
  }));
};

export const logDriverStatistics = (allDrivers: Driver[]) => {
  const statusBreakdown = {
    pending: allDrivers.filter(d => d.status === 'pending').length,
    under_review: allDrivers.filter(d => d.status === 'under_review').length,
    approved: allDrivers.filter(d => d.status === 'approved').length,
    active: allDrivers.filter(d => d.status === 'active').length,
    rejected: allDrivers.filter(d => d.status === 'rejected').length,
    pending_documents: allDrivers.filter(d => d.status === 'pending_documents').length,
    in_analysis: allDrivers.filter(d => d.status === 'in_analysis').length
  };
  
  console.log(`📊 [STATUS BREAKDOWN]`, statusBreakdown);
  console.log(`📝 [MOTORISTAS CARREGADOS]`, allDrivers.map(d => ({ 
    name: d.fullName, 
    status: d.status, 
    id: d.id,
    source: d.source,
    referralCompanyId: d.referralCompanyId
  })));
};
