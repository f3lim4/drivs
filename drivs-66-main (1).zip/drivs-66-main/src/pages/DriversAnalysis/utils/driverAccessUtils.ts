
import { supabase } from "@/integrations/supabase/client";
import type { Driver } from "../types/Driver";

interface DriverAccessResult {
  hasAccess: boolean;
  driver?: any;
  error?: string;
}

/**
 * Verifica se o usuário tem acesso ao motorista e retorna os dados atualizados
 */
const verifyAndFetchDriverAccess = async (
  driverId: string,
  userId: string,
  userRole: string
): Promise<DriverAccessResult> => {
  console.log('🔍 [VERIFY ACCESS] Verificando acesso ao motorista:', {
    driverId,
    userId,
    userRole
  });

  // Admin tem acesso total
  if (userRole === 'admin') {
    console.log('✅ [VERIFY ACCESS] Admin tem acesso total');
    return { hasAccess: true };
  }

  if (userRole !== 'rental_company') {
    console.error('❌ [VERIFY ACCESS] Tipo de usuário não suportado:', userRole);
    return { hasAccess: false, error: 'Tipo de usuário não suportado' };
  }

  try {
    // Primeiro tentar buscar na tabela drivers
    console.log('🔍 [VERIFY ACCESS] Buscando na tabela drivers...');
    const { data: driverData, error: driverError } = await supabase
      .from('drivers')
      .select('*')
      .eq('id', driverId)
      .maybeSingle();

    if (!driverError && driverData) {
      console.log('📋 [VERIFY ACCESS] Motorista encontrado na tabela drivers:', {
        driverId: driverData.id,
        companyId: driverData.company_id,
        status: driverData.status
      });

      const hasAccess = driverData.company_id === userId;
      console.log('🏢 [VERIFY ACCESS] Verificação de acesso (drivers):', {
        driverCompanyId: driverData.company_id,
        userCompanyId: userId,
        hasAccess
      });

      return {
        hasAccess,
        driver: driverData,
        error: hasAccess ? undefined : 'Você não tem permissão para acessar este motorista'
      };
    }

    // Se não encontrar na tabela drivers, tentar na tabela driver_registrations
    console.log('🔍 [VERIFY ACCESS] Buscando na tabela driver_registrations...');
    const { data: registrationData, error: registrationError } = await supabase
      .from('driver_registrations')
      .select('*')
      .eq('id', driverId)
      .maybeSingle();

    if (!registrationError && registrationData) {
      console.log('📋 [VERIFY ACCESS] Motorista encontrado na tabela driver_registrations:', {
        driverId: registrationData.id,
        referralCompanyId: registrationData.referral_company_id,
        status: registrationData.status
      });

      const hasAccess = registrationData.referral_company_id === userId;
      console.log('🏢 [VERIFY ACCESS] Verificação de acesso (registrations):', {
        referralCompanyId: registrationData.referral_company_id,
        userCompanyId: userId,
        hasAccess
      });

      return {
        hasAccess,
        driver: registrationData,
        error: hasAccess ? undefined : 'Você não tem permissão para acessar este motorista'
      };
    }

    // Motorista não encontrado em nenhuma tabela
    console.error('❌ [VERIFY ACCESS] Motorista não encontrado em nenhuma tabela');
    return {
      hasAccess: false,
      error: 'Motorista não encontrado'
    };

  } catch (error) {
    console.error('❌ [VERIFY ACCESS] Erro crítico na verificação:', error);
    return {
      hasAccess: false,
      error: 'Erro interno ao verificar permissões'
    };
  }
};

/**
 * Debug: Lista todos os motoristas e suas associações
 */
export const debugDriverAssociations = async (userId: string) => {
  console.log('🐛 [DEBUG] Listando associações de motoristas para locadora:', userId);

  try {
    // Buscar na tabela drivers
    const { data: driversData } = await supabase
      .from('drivers')
      .select('id, full_name, company_id, status')
      .eq('company_id', userId);

    console.log('📋 [DEBUG] Motoristas na tabela drivers:', driversData);

    // Buscar na tabela driver_registrations
    const { data: registrationsData } = await supabase
      .from('driver_registrations')
      .select('id, full_name, referral_company_id, status')
      .eq('referral_company_id', userId);

    console.log('📋 [DEBUG] Motoristas na tabela driver_registrations:', registrationsData);

    return {
      drivers: driversData || [],
      registrations: registrationsData || []
    };
  } catch (error) {
    console.error('❌ [DEBUG] Erro ao listar associações:', error);
    return { drivers: [], registrations: [] };
  }
};

/**
 * Verifica se o usuário tem acesso ao motorista
 */
export const verifyDriverAccess = async (driver: Driver, user: any): Promise<boolean> => {
  console.log('🔍 [ACCESS CHECK] Verificando acesso ao motorista:', {
    driverId: driver.id,
    driverName: driver.fullName,
    driverSource: driver.source,
    userRole: user?.role,
    userId: user?.id
  });

  if (!user) {
    console.error('❌ [ACCESS] Usuário não autenticado');
    return false;
  }

  // Admin tem acesso total
  if (user.role === 'admin') {
    console.log('✅ [ACCESS] Admin tem acesso total');
    return true;
  }

  // Para locadoras, verificar associação
  if (user.role === 'rental_company') {
    // Verificar baseado na origem do motorista
    if (driver.source === 'registrations') {
      // Da tabela driver_registrations - verificar referral_company_id
      const hasAccess = driver.referralCompanyId === user.id;
      console.log('🏢 [ACCESS] Verificação via driver_registrations:', {
        driverReferralCompanyId: driver.referralCompanyId,
        userCompanyId: user.id,
        hasAccess
      });
      return hasAccess;
    } else if (driver.source === 'drivers') {
      // Da tabela drivers - verificar company_id
      // Buscar dados atualizados do motorista para garantir que temos o company_id correto
      try {
        const { data: driverData, error } = await supabase
          .from('drivers')
          .select('company_id')
          .eq('id', driver.id)
          .single();

        if (error) {
          console.error('❌ [ACCESS] Erro ao buscar dados do motorista:', error);
          return false;
        }

        const hasAccess = driverData?.company_id === user.id;
        console.log('🏢 [ACCESS] Verificação via drivers table:', {
          driverCompanyId: driverData?.company_id,
          userCompanyId: user.id,
          hasAccess
        });
        return hasAccess;
      } catch (error) {
        console.error('❌ [ACCESS] Erro crítico na verificação:', error);
        return false;
      }
    }
  }

  console.log('❌ [ACCESS] Tipo de usuário não suportado ou sem permissão');
  return false;
};

/**
 * Corrige a associação do motorista com a locadora
 */
const fixDriverAssociation = async (
  driverId: string,
  companyId: string,
  source: 'drivers' | 'registrations'
): Promise<boolean> => {
  console.log('🔧 [FIX ASSOCIATION] Corrigindo associação do motorista:', {
    driverId,
    companyId,
    source
  });

  try {
    if (source === 'drivers') {
      const { error } = await supabase
        .from('drivers')
        .update({ company_id: companyId })
        .eq('id', driverId);

      if (error) {
        console.error('❌ [FIX ASSOCIATION] Erro ao corrigir drivers:', error);
        return false;
      }
    } else {
      const { error } = await supabase
        .from('driver_registrations')
        .update({ referral_company_id: companyId })
        .eq('id', driverId);

      if (error) {
        console.error('❌ [FIX ASSOCIATION] Erro ao corrigir driver_registrations:', error);
        return false;
      }
    }

    console.log('✅ [FIX ASSOCIATION] Associação corrigida com sucesso');
    return true;
  } catch (error) {
    console.error('❌ [FIX ASSOCIATION] Erro crítico:', error);
    return false;
  }
};
