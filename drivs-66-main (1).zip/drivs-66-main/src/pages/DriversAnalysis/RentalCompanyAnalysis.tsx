
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { DriverAnalysisModal } from "./components/DriverAnalysisModal";
import { RentalCompanyStatsCards } from "./components/RentalCompanyStatsCards";
import { RentalCompanyFilters } from "./components/RentalCompanyFilters";
import { RentalCompanyDriversTable } from "./components/RentalCompanyDriversTable";
import { RentalCompanyInfoCard } from "./components/RentalCompanyInfoCard";
import { FuturisticLoading } from "@/components/ui/futuristic-loading";
import { useDriversData } from "./hooks/useDriversData";
import { useDriverActions } from "./components/DriverActions";
import type { Driver } from "./types/Driver";

const RentalCompanyAnalysis = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState(false);
  const [isViewOnly, setIsViewOnly] = useState(false);

  const { drivers, loading, updateLocalDriverStatus, refreshFromDatabase } = useDriversData(user?.id);

  // ✅ ESCUTAR EVENTOS DE REFRESH
  useEffect(() => {
    const handleRefresh = () => {
      console.log('🔄 [EVENT] Recebido evento de refresh, recarregando dados...');
      refreshFromDatabase();
    };

    window.addEventListener('refreshDriversData', handleRefresh);
    
    return () => {
      window.removeEventListener('refreshDriversData', handleRefresh);
    };
  }, [refreshFromDatabase]);

  const driverActionsProps = {
    drivers,
    onDriverStatusUpdate: updateLocalDriverStatus,
    onAnalyzeDriver: (driver: Driver) => {
      setSelectedDriver(driver);
      setIsViewOnly(false);
      setIsAnalysisModalOpen(true);
    },
    onViewDriver: (driver: Driver) => {
      setSelectedDriver(driver);
      setIsViewOnly(true);
      setIsAnalysisModalOpen(true);
    }
  };

  const {
    handleSendToDrivs,
    handleApproveDriver,
    handleRejectDriver,
    handleRequestResubmission,
    handleAnalyzeDriver,
    handleViewDriver
  } = useDriverActions(driverActionsProps);

  // ✅ APLICAR FILTROS DE BUSCA E STATUS
  const filteredDrivers = drivers.filter((driver) => {
    const matchesSearch = driver.fullName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         driver.cpf?.includes(searchQuery) ||
                         driver.email?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || driver.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const stats = {
    awaitingAnalysis: filteredDrivers.filter(d => d.status === "pending").length,
    sentToDrivs: filteredDrivers.filter(d => d.status === "under_review").length,
    approved: filteredDrivers.filter(d => d.status === "approved" || d.status === "active").length
  };

  if (!user || user.role !== UserRole.RENTAL_COMPANY) {
    return (
      <div className="container py-6">
        <div className="text-center">
          <p className="text-muted-foreground">Acesso não autorizado</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return <FuturisticLoading />;
  }

  const handleModalClose = () => {
    setIsAnalysisModalOpen(false);
    setSelectedDriver(null);
    
    // ✅ REFRESH OPCIONAL AO FECHAR MODAL
    setTimeout(() => {
      console.log('🔄 [MODAL CLOSE] Recarregando dados após fechar modal');
      refreshFromDatabase();
    }, 500);
  };

  return (
    <div className="container py-6 space-y-6">
      <div className="space-y-6">
        <div className="page-header">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">ANÁLISE DE MOTORISTAS</h1>
            <p className="page-subtitle">
              Analise motoristas cadastrados através do seu link de referência ou envie para análise profissional da DRIVS
            </p>
          </div>
          {/* ✅ BOTÃO DE REFRESH MANUAL */}
          <button
            onClick={refreshFromDatabase}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            disabled={loading}
          >
            {loading ? 'Carregando...' : 'Atualizar Lista'}
          </button>
        </div>

        <RentalCompanyInfoCard driversCount={drivers.length} />

        <RentalCompanyStatsCards stats={stats} />
        
        <RentalCompanyFilters 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          statusFilter={statusFilter}
          onStatusFilterChange={setStatusFilter}
        />

        <RentalCompanyDriversTable 
          drivers={filteredDrivers}
          onViewDriver={handleViewDriver}
          onAnalyzeDriver={handleAnalyzeDriver}
          onSendToDrivs={handleSendToDrivs}
        />

        <DriverAnalysisModal
          driver={selectedDriver}
          isOpen={isAnalysisModalOpen}
          onClose={handleModalClose}
          onApprove={handleApproveDriver}
          onReject={handleRejectDriver}
          onRequestResubmission={handleRequestResubmission}
          isViewOnly={isViewOnly}
        />
      </div>
    </div>
  );
};

export default RentalCompanyAnalysis;
