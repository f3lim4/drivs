
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import RentalCompanyAnalysis from "./RentalCompanyAnalysis";
import { AnalystDriversAnalysis } from "./components/AnalystDriversAnalysis";

const DriversAnalysis = () => {
  const { user } = useAuth();

  if (!user) {
    return <div>Acesso não autorizado</div>;
  }

  // Agora ADMIN e ANALYST podem acessar a análise de motoristas enviados para DRIVS
  if (
    user.role === UserRole.RENTAL_COMPANY ||
    user.role === UserRole.MANAGER
  ) {
    return <RentalCompanyAnalysis />;
  }

  if (
    user.role === UserRole.ANALYST ||
    user.role === UserRole.ADMIN
  ) {
    return <AnalystDriversAnalysis />;
  }

  return <div>Acesso não autorizado para este tipo de usuário</div>;
};

export default DriversAnalysis;
