
export interface Driver {
  id: string;
  fullName: string;
  cpf: string;
  email: string;
  phone: string;
  status: string;
  documents: {
    cnh: { status: string; url: string; number?: string; category?: string; issueDate?: string; expiryDate?: string };
    rg: { status: string; url: string; reason?: string };
    cpf: { status: string; url: string };
    comprovante_residencia: { status: string; url: string; reason?: string };
  };
  address: {
    street: string;
    neighborhood: string;
    city: string;
    state: string;
    zipCode: string;
  };
  created_at: string;
  violations: number;
  rating: number;
  vehicle?: {
    model: string;
    plate: string;
    year: string;
  };
  rentalCompany?: string;
  referralCompanyId?: string;
  source: 'drivers' | 'registrations';
}
