
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Trophy, Medal, Award, Star, CheckCircle, Target, Gift, Settings, Plus, X, ChevronDown, ChevronUp } from "lucide-react";
import { RankingTable } from "./components/RankingTable";
import { UserRole, Driver } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useDriverData } from "@/pages/Drivers/hooks/useDriverData";
import { getVehiclesByCompany } from "@/pages/RentalCompanies/data/mockVehicles";
import { DriverStatus } from "@/types";
import { useRankingData } from "./hooks/useRankingData";
import { useRankingRules } from "./hooks/useRankingRules";
import { useRankingRewards } from "./hooks/useRankingRewards";
import { RankingHeader } from "./components/RankingHeader";
import { CompanyStatsCards } from "./components/CompanyStatsCards";
import { DriverPositionCard } from "./components/DriverPositionCard";

const Ranking = () => {
  const { user } = useAuth();
  const { drivers } = useDriverData();
  const [isRulesExpanded, setIsRulesExpanded] = useState(false);
  const [isRewardsExpanded, setIsRewardsExpanded] = useState(false);

  if (!user || (user.role !== UserRole.DRIVER && user.role !== UserRole.RENTAL_COMPANY && user.role !== UserRole.MANAGER)) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Card className="bg-card">
            <CardContent className="p-6 text-center">
              <p className="text-muted-foreground">Acesso não autorizado</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const isDriver = user.role === UserRole.DRIVER;
  const driver = isDriver ? user as Driver : null;

  // Dados reais da locadora
  const companyVehicles = user?.role === "rental_company" ? getVehiclesByCompany(user.id) : [];
  const companyName = isDriver ? "Auto Rental Plus" : (user as any).companyName || "Locadora Atual";
  
  // Filtrar motoristas da locadora atual
  const companyDrivers = drivers.filter(d => {
    if (user.role === UserRole.RENTAL_COMPANY) {
      return d.rentalCompanyId === user.id;
    }
    return true; // Para motoristas, mostrar todos da mesma locadora
  });

  // Apenas motoristas ativos para o ranking
  const activeDrivers = companyDrivers.filter(d => d.status === DriverStatus.ACTIVE);
  
  const { generateRankingData } = useRankingData(companyDrivers);
  const mockRankingData = generateRankingData();

  // Dados do motorista logado
  const myPosition = isDriver ? activeDrivers.findIndex(d => d.id === driver?.id) + 1 : null;
  const myPoints = isDriver ? 1250 : null;
  const tasksCompleted = isDriver ? 45 : null;

  // Hooks para regras e recompensas
  const {
    isEditingRules,
    setIsEditingRules,
    newRule,
    setNewRule,
    rules,
    handleConfigureRules,
    handleSaveRules,
    handleAddRule,
    handleRemoveRule
  } = useRankingRules();

  const {
    isEditingRewards,
    setIsEditingRewards,
    newReward,
    setNewReward,
    rewards,
    handleEditRewards,
    handleSaveRewards,
    handleAddReward,
    handleRemoveReward
  } = useRankingRewards();

  // Converter para o formato esperado pelo RankingTable
  const convertedRankings = mockRankingData.map(item => ({
    id: parseInt(item.id.replace(/\D/g, '') || '0'),
    position: item.position,
    driverName: item.driverName,
    companyName: companyName,
    points: item.points,
    badges: item.achievements,
    monthlyGrowth: item.change === "up" ? "+5%" : item.change === "down" ? "-2%" : "0%",
    avatar: item.avatar || "",
    isMe: item.isMe || false
  }));

  const getPositionIcon = (position: number) => {
    switch (position) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />;
      default:
        return <span className="text-lg font-bold text-gray-600">#{position}</span>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="space-y-6">
          <RankingHeader 
            companyName={companyName} 
            isDriver={isDriver} 
            activeDriversCount={activeDrivers.length} 
          />

          {/* Estatísticas da Locadora */}
          {!isDriver && (
            <CompanyStatsCards
              totalVehicles={companyVehicles.length}
              activeDrivers={activeDrivers.length}
              rentedVehicles={companyVehicles.filter(v => v.status === "rented").length}
              occupancyRate={Math.round((companyVehicles.filter(v => v.status === "rented").length / companyVehicles.length) * 100) || 0}
            />
          )}

          {/* Minha Posição - apenas para motoristas */}
          {isDriver && myPosition && (
            <DriverPositionCard 
              position={myPosition} 
              points={myPoints || 0} 
              tasksCompleted={tasksCompleted || 0} 
            />
          )}

          {/* Regras da Locadora */}
          <Card className="bg-card border-border">
            <Collapsible open={isRulesExpanded} onOpenChange={setIsRulesExpanded}>
              <CardHeader>
                <CardTitle className="text-lg text-foreground flex items-center gap-2">
                  <Target className="h-5 w-5 text-green-600" />
                  Regras de Pontuação - {companyName}
                  <div className="ml-auto flex gap-2">
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" size="sm">
                        {isRulesExpanded ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </Button>
                    </CollapsibleTrigger>
                    {!isDriver && (
                      <>
                        {isEditingRules ? (
                          <>
                            <Button variant="outline" size="sm" onClick={handleSaveRules}>
                              Salvar
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => setIsEditingRules(false)}>
                              Cancelar
                            </Button>
                          </>
                        ) : (
                          <Button variant="outline" size="sm" onClick={handleConfigureRules}>
                            <Settings className="h-4 w-4 mr-2" />
                            Configurar
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </CardTitle>
              </CardHeader>
              <CollapsibleContent>
                <CardContent>
                  {isEditingRules && !isDriver && (
                    <div className="mb-4 space-y-4">
                      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm text-blue-800">
                          💡 Modo de configuração ativo. Você pode editar as regras de pontuação.
                        </p>
                      </div>
                      
                      {/* Formulário para adicionar nova regra */}
                      <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg">
                        <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                          <Plus className="h-4 w-4" />
                          Adicionar Nova Missão
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <div>
                            <Label htmlFor="new-task">Título da Missão</Label>
                            <Input
                              id="new-task"
                              value={newRule.task}
                              onChange={(e) => setNewRule({...newRule, task: e.target.value})}
                              placeholder="Ex: Viagem sem infrações"
                            />
                          </div>
                          <div>
                            <Label htmlFor="new-points">Pontos</Label>
                            <Input
                              id="new-points"
                              type="number"
                              value={newRule.points}
                              onChange={(e) => setNewRule({...newRule, points: parseInt(e.target.value) || 0})}
                              placeholder="Ex: 50"
                            />
                          </div>
                          <div>
                            <Label htmlFor="new-description">Descrição</Label>
                            <Input
                              id="new-description"
                              value={newRule.description}
                              onChange={(e) => setNewRule({...newRule, description: e.target.value})}
                              placeholder="Descrição da missão"
                            />
                          </div>
                        </div>
                        <Button onClick={handleAddRule} className="mt-3" size="sm">
                          <Plus className="h-4 w-4 mr-2" />
                          Adicionar Missão
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {rules.map((rule, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <div>
                            <span className="text-sm text-foreground font-medium">{rule.task}</span>
                            <p className="text-xs text-muted-foreground">{rule.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-blue-100 text-blue-800">
                            +{rule.points} pts
                          </Badge>
                          {isEditingRules && !isDriver && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveRule(index)}
                              className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>

          {/* Prêmios e Recompensas */}
          <Card className="bg-card border-border">
            <Collapsible open={isRewardsExpanded} onOpenChange={setIsRewardsExpanded}>
              <CardHeader>
                <CardTitle className="text-lg text-foreground flex items-center gap-2">
                  <Gift className="h-5 w-5 text-purple-600" />
                  Prêmios e Recompensas
                  <div className="ml-auto flex gap-2">
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" size="sm">
                        {isRewardsExpanded ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </Button>
                    </CollapsibleTrigger>
                    {!isDriver && (
                      <>
                        {isEditingRewards ? (
                          <>
                            <Button variant="outline" size="sm" onClick={handleSaveRewards}>
                              Salvar
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => setIsEditingRewards(false)}>
                              Cancelar
                            </Button>
                          </>
                        ) : (
                          <Button variant="outline" size="sm" onClick={handleEditRewards}>
                            <Settings className="h-4 w-4 mr-2" />
                            Editar
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </CardTitle>
              </CardHeader>
              <CollapsibleContent>
                <CardContent>
                  {isEditingRewards && !isDriver && (
                    <div className="mb-4 space-y-4">
                      <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                        <p className="text-sm text-purple-800">
                          💡 Modo de edição ativo. Você pode editar os prêmios e recompensas.
                        </p>
                      </div>
                      
                      {/* Formulário para adicionar novo prêmio */}
                      <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg">
                        <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                          <Plus className="h-4 w-4" />
                          Adicionar Novo Prêmio
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <div>
                            <Label htmlFor="new-position">Posição/Critério</Label>
                            <Input
                              id="new-position"
                              value={newReward.position}
                              onChange={(e) => setNewReward({...newReward, position: e.target.value})}
                              placeholder="Ex: Top 5, 1000+ pts"
                            />
                          </div>
                          <div>
                            <Label htmlFor="new-reward">Prêmio</Label>
                            <Input
                              id="new-reward"
                              value={newReward.reward}
                              onChange={(e) => setNewReward({...newReward, reward: e.target.value})}
                              placeholder="Ex: R$ 300 + Bônus"
                            />
                          </div>
                          <div>
                            <Label htmlFor="new-reward-description">Descrição</Label>
                            <Input
                              id="new-reward-description"
                              value={newReward.description}
                              onChange={(e) => setNewReward({...newReward, description: e.target.value})}
                              placeholder="Detalhes do prêmio"
                            />
                          </div>
                        </div>
                        <Button onClick={handleAddReward} className="mt-3" size="sm">
                          <Plus className="h-4 w-4 mr-2" />
                          Adicionar Prêmio
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {rewards.map((reward, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg">
                        <div>
                          <div className="font-semibold text-foreground">{reward.position}</div>
                          <div className="text-sm text-purple-600 font-medium">{reward.reward}</div>
                          <p className="text-xs text-muted-foreground">{reward.description}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Gift className="h-6 w-6 text-purple-600" />
                          {isEditingRewards && !isDriver && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveReward(index)}
                              className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>

          {/* Top 3 Podium - apenas se houver motoristas */}
          {mockRankingData.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {mockRankingData.slice(0, Math.min(3, mockRankingData.length)).map((driver, index) => (
                <Card key={driver.id} className={`bg-card border-border ${index === 0 ? 'md:order-2 transform md:scale-105' : index === 1 ? 'md:order-1' : 'md:order-3'} ${driver.isMe ? 'ring-2 ring-blue-500' : ''}`}>
                  <CardHeader className="text-center pb-2">
                    <div className="flex justify-center mb-2">
                      {getPositionIcon(driver.position)}
                    </div>
                    <CardTitle className="text-lg text-foreground">
                      {driver.isMe ? "Você" : driver.driverName}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center space-y-3">
                    <Avatar className="h-16 w-16 mx-auto">
                      <AvatarImage src={driver.avatar || ""} />
                      <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-lg">
                        {driver.driverName.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-center gap-1">
                        <Star className="h-4 w-4 text-yellow-500 fill-current" />
                        <span className="font-semibold text-foreground">{driver.rating}</span>
                      </div>
                      
                      <div className="text-2xl font-bold text-blue-600">
                        {driver.points.toLocaleString()} pts
                      </div>
                      
                      <div className="text-sm text-muted-foreground">
                        {driver.completedTrips} viagens
                      </div>
                      
                      <div className="flex flex-wrap gap-1 justify-center">
                        {driver.achievements.slice(0, 2).map((achievement, i) => (
                          <Badge key={i} variant="outline" className="text-xs border-border text-foreground">
                            {achievement}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Full Ranking Table */}
          {mockRankingData.length > 0 ? (
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-2xl text-foreground text-center">
                  Ranking Completo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <RankingTable rankings={convertedRankings} />
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-card border-border">
              <CardContent className="p-6 text-center">
                <p className="text-muted-foreground">
                  Nenhum motorista ativo encontrado para esta locadora.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Ranking;
