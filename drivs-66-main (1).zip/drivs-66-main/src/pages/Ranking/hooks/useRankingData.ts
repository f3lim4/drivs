
import { useDriverData } from "@/pages/Drivers/hooks/useDriverData";
import { DriverStatus } from "@/types";

export const useRankingData = (companyDrivers: any[]) => {
  const { drivers } = useDriverData();

  const generateRankingData = () => {
    const activeDrivers = companyDrivers.filter(d => d.status === DriverStatus.ACTIVE);
    
    return activeDrivers.map((driverData, index) => {
      const basePoints = 2000 + (activeDrivers.length - index) * 150;
      const randomVariation = Math.floor(Math.random() * 200) - 100;
      const finalPoints = Math.max(basePoints + randomVariation, 500);
      
      return {
        id: driverData.id,
        position: index + 1,
        driverName: driverData.fullName,
        points: finalPoints,
        completedTrips: Math.floor(Math.random() * 50) + 80,
        rating: Number((4.2 + Math.random() * 0.8).toFixed(1)),
        achievements: getRandomAchievements(),
        avatar: null,
        change: getRandomChange(),
        isMe: false // Will be set in the component
      };
    });
  };

  const getRandomAchievements = () => {
    const achievements = ["Motorista do Mês", "Sem Infrações", "Pontualidade", "Eco Driver", "Cliente Satisfeito", "Avaliação 5★"];
    const count = Math.floor(Math.random() * 3) + 1;
    return achievements.sort(() => 0.5 - Math.random()).slice(0, count);
  };

  const getRandomChange = () => {
    const changes = ["up", "down", "same"];
    return changes[Math.floor(Math.random() * changes.length)] as "up" | "down" | "same";
  };

  return {
    generateRankingData,
    getRandomAchievements,
    getRandomChange
  };
};
