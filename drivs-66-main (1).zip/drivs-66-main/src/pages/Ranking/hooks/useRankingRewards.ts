
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface RankingReward {
  position: string;
  reward: string;
  description: string;
}

export const useRankingRewards = () => {
  const { toast } = useToast();
  const [isEditingRewards, setIsEditingRewards] = useState(false);
  const [newReward, setNewReward] = useState<RankingReward>({
    position: "",
    reward: "",
    description: ""
  });

  const [rewards, setRewards] = useState<RankingReward[]>([
    { position: "1º Lugar", reward: "R$ 500 + Bônus Mensal", description: "Motorista do mês" },
    { position: "Top 3", reward: "R$ 200 + Desconto Combustível", description: "10% desconto em postos parceiros" },
    { position: "Top 10", reward: "R$ 100", description: "Bônus em dinheiro" },
    { position: "500+ pts", reward: "Vale Presente", description: "R$ 50 em compras" }
  ]);

  const handleEditRewards = () => {
    setIsEditingRewards(true);
  };

  const handleSaveRewards = () => {
    setIsEditingRewards(false);
    toast({
      title: "Prêmios salvos",
      description: "Os prêmios e recompensas foram atualizados com sucesso."
    });
  };

  const handleAddReward = () => {
    if (newReward.position && newReward.reward && newReward.description) {
      setRewards([...rewards, newReward]);
      setNewReward({ position: "", reward: "", description: "" });
      toast({
        title: "Prêmio adicionado",
        description: "Novo prêmio foi adicionado com sucesso."
      });
    } else {
      toast({
        title: "Erro",
        description: "Preencha todos os campos do prêmio.",
        variant: "destructive"
      });
    }
  };

  const handleRemoveReward = (index: number) => {
    setRewards(rewards.filter((_, i) => i !== index));
    toast({
      title: "Prêmio removido",
      description: "O prêmio foi removido com sucesso."
    });
  };

  return {
    isEditingRewards,
    setIsEditingRewards,
    newReward,
    setNewReward,
    rewards,
    setRewards,
    handleEditRewards,
    handleSaveRewards,
    handleAddReward,
    handleRemoveReward
  };
};
