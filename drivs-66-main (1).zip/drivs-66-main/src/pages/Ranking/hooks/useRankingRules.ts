
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface RankingRule {
  task: string;
  points: number;
  description: string;
}

export const useRankingRules = () => {
  const { toast } = useToast();
  const [isEditingRules, setIsEditingRules] = useState(false);
  const [newRule, setNewRule] = useState<RankingRule>({
    task: "",
    points: 0,
    description: ""
  });

  const [rules, setRules] = useState<RankingRule[]>([
    { task: "Viagem sem infrações", points: 50, description: "Complete uma viagem sem receber multas" },
    { task: "Avaliação 5 estrelas", points: 25, description: "Receba avaliação máxima do cliente" },
    { task: "Vistoria em dia", points: 20, description: "Realize vistoria dentro do prazo" },
    { task: "Pontualidade", points: 15, description: "Entregue o veículo no horário" },
    { task: "Combustível acima de 50%", points: 10, description: "Retorne com tanque meio cheio ou mais" },
    { task: "Relatório de problemas", points: 30, description: "Reporte problemas no veículo" }
  ]);

  const handleConfigureRules = () => {
    setIsEditingRules(true);
  };

  const handleSaveRules = () => {
    setIsEditingRules(false);
    toast({
      title: "Regras salvas",
      description: "As regras de pontuação foram atualizadas com sucesso."
    });
  };

  const handleAddRule = () => {
    if (newRule.task && newRule.points > 0 && newRule.description) {
      setRules([...rules, newRule]);
      setNewRule({ task: "", points: 0, description: "" });
      toast({
        title: "Regra adicionada",
        description: "Nova regra de pontuação foi adicionada."
      });
    } else {
      toast({
        title: "Erro",
        description: "Preencha todos os campos da regra.",
        variant: "destructive"
      });
    }
  };

  const handleRemoveRule = (index: number) => {
    setRules(rules.filter((_, i) => i !== index));
    toast({
      title: "Regra removida",
      description: "A regra foi removida com sucesso."
    });
  };

  return {
    isEditingRules,
    setIsEditingRules,
    newRule,
    setNewRule,
    rules,
    setRules,
    handleConfigureRules,
    handleSaveRules,
    handleAddRule,
    handleRemoveRule
  };
};
