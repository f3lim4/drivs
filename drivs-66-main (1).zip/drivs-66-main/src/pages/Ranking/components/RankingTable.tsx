
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trophy, Medal, Award, TrendingUp, TrendingDown } from "lucide-react";

interface RankingItem {
  id: number;
  position: number;
  driverName: string;
  companyName: string;
  points: number;
  badges: string[];
  monthlyGrowth: string;
  avatar: string;
  isMe?: boolean;
}

interface RankingTableProps {
  rankings: RankingItem[];
}

export const RankingTable = ({ rankings }: RankingTableProps) => {
  const getPositionIcon = (position: number) => {
    switch (position) {
      case 1:
        return <Trophy className="w-5 h-5 text-yellow-500" />;
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />;
      case 3:
        return <Award className="w-5 h-5 text-amber-600" />;
      default:
        return <span className="w-5 h-5 flex items-center justify-center text-sm font-bold text-foreground">#{position}</span>;
    }
  };

  const getGrowthIcon = (growth: string) => {
    const isPositive = growth.startsWith('+');
    return isPositive ? (
      <TrendingUp className="w-4 h-4 text-green-600" />
    ) : (
      <TrendingDown className="w-4 h-4 text-red-600" />
    );
  };

  return (
    <Card className="bg-card dark:bg-gray-800 border-border">
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-border">
              <TableHead className="w-16 text-foreground">Posição</TableHead>
              <TableHead className="text-foreground">Motorista</TableHead>
              <TableHead className="text-foreground">Locadora</TableHead>
              <TableHead className="text-center text-foreground">Pontos</TableHead>
              <TableHead className="text-foreground">Conquistas</TableHead>
              <TableHead className="text-center text-foreground">Crescimento</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rankings.map((driver) => (
              <TableRow 
                key={driver.id} 
                className={`border-border hover:bg-muted/50 ${driver.isMe ? 'bg-blue-50 dark:bg-blue-900/20 ring-1 ring-blue-500' : ''}`}
              >
                <TableCell>
                  <div className="flex items-center justify-center">
                    {getPositionIcon(driver.position)}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={driver.avatar} alt={driver.driverName} />
                      <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                        {driver.driverName.split(" ").map(n => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-foreground">
                        {driver.isMe ? "Você" : driver.driverName}
                        {driver.isMe && <span className="ml-2 text-xs text-blue-600 dark:text-blue-400">(Você)</span>}
                      </p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="text-sm text-muted-foreground">{driver.companyName}</span>
                </TableCell>
                <TableCell className="text-center">
                  <span className="font-bold text-blue-600 dark:text-blue-400">{driver.points}</span>
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {driver.badges.map((badge, index) => (
                      <Badge key={index} variant="secondary" className="text-xs bg-muted text-foreground border-border">
                        {badge}
                      </Badge>
                    ))}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center justify-center space-x-1">
                    {getGrowthIcon(driver.monthlyGrowth)}
                    <span className={`text-sm font-medium ${
                      driver.monthlyGrowth.startsWith('+') ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {driver.monthlyGrowth}
                    </span>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};
