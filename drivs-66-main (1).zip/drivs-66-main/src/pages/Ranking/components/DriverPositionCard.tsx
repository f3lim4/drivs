
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Medal, Award } from "lucide-react";

interface DriverPositionCardProps {
  position: number;
  points: number;
  tasksCompleted: number;
}

export const DriverPositionCard = ({ position, points, tasksCompleted }: DriverPositionCardProps) => {
  const getPositionIcon = (position: number) => {
    switch (position) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />;
      default:
        return <span className="text-lg font-bold text-gray-600">#{position}</span>;
    }
  };

  const getMyPositionText = () => {
    if (position <= 3) {
      const positions = ["🥇 1º Lugar", "🥈 2º Lugar", "🥉 3º Lugar"];
      return positions[position - 1];
    }
    return `#${position}`;
  };

  return (
    <Card className="bg-card border-border border-l-4 border-l-blue-500">
      <CardHeader>
        <CardTitle className="text-lg text-foreground flex items-center gap-2">
          <Trophy className="h-5 w-5 text-blue-600" />
          Minha Posição no Ranking
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="flex justify-center mb-2">
              {getPositionIcon(position)}
            </div>
            <div className="text-2xl font-bold text-foreground">{getMyPositionText()}</div>
            <p className="text-sm text-muted-foreground">Posição Atual</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600">{points}</div>
            <p className="text-sm text-muted-foreground">Pontos Acumulados</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600">{tasksCompleted}</div>
            <p className="text-sm text-muted-foreground">Tarefas Concluídas</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
