
import { Trophy } from "lucide-react";

interface RankingHeaderProps {
  companyName: string;
  isDriver: boolean;
  activeDriversCount: number;
}

export const RankingHeader = ({ companyName, isDriver, activeDriversCount }: RankingHeaderProps) => {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-4xl font-bold text-foreground">
        Ranking - {companyName}
      </h1>
      <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto rounded-full"></div>
      <p className="text-muted-foreground max-w-2xl mx-auto">
        {isDriver ? "Seu ranking e desempenho na locadora" : `Ranking dos ${activeDriversCount} motoristas ativos da sua locadora`}
      </p>
    </div>
  );
};
