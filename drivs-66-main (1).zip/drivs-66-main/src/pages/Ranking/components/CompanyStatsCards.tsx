
import { Card, CardContent } from "@/components/ui/card";

interface CompanyStatsCardsProps {
  totalVehicles: number;
  activeDrivers: number;
  rentedVehicles: number;
  occupancyRate: number;
}

export const CompanyStatsCards = ({ 
  totalVehicles, 
  activeDrivers, 
  rentedVehicles, 
  occupancyRate 
}: CompanyStatsCardsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <Card className="bg-card border-border">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-blue-600">{totalVehicles}</div>
          <p className="text-sm text-muted-foreground">Veículos Totais</p>
        </CardContent>
      </Card>
      <Card className="bg-card border-border">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-green-600">{activeDrivers}</div>
          <p className="text-sm text-muted-foreground">Motoristas Ativos</p>
        </CardContent>
      </Card>
      <Card className="bg-card border-border">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-purple-600">{rentedVehicles}</div>
          <p className="text-sm text-muted-foreground">Veículos Alugados</p>
        </CardContent>
      </Card>
      <Card className="bg-card border-border">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-orange-600">{occupancyRate}%</div>
          <p className="text-sm text-muted-foreground">Taxa de Ocupação</p>
        </CardContent>
      </Card>
    </div>
  );
};
