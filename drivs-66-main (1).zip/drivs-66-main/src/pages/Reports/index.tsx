import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { CalendarIcon, Download, FileDown, Printer } from 'lucide-react';
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { RentalCompanyReports } from "./components/RentalCompanyReports";

const Reports = () => {
  const { user } = useAuth();
  
  const [reportType, setReportType] = useState("maintenance");
  const [dateRange, setDateRange] = useState<{from: Date | undefined, to: Date | undefined}>({
    from: undefined,
    to: undefined,
  });
  const [selectedDriver, setSelectedDriver] = useState("");
  const [selectedVehicle, setSelectedVehicle] = useState("");
  
  // Renderiza componente específico para locadoras
  if (user && [UserRole.ADMIN, UserRole.MANAGER].includes(user.role as any)) {
    return <RentalCompanyReports />;
  }
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Relatórios</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Gerar Relatório</CardTitle>
          <CardDescription>
            Selecione o tipo de relatório e período para gerar
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Tipo de Relatório</label>
                <Select
                  value={reportType}
                  onValueChange={setReportType}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="maintenance">Manutenções</SelectItem>
                      <SelectItem value="inspection">Vistorias</SelectItem>
                      <SelectItem value="violation">Infrações</SelectItem>
                      <SelectItem value="payment">Pagamentos</SelectItem>
                      <SelectItem value="contract">Contratos</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Período</label>
                <div className="flex gap-2">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateRange.from ? (
                          dateRange.to ? (
                            <>
                              {format(dateRange.from, "dd/MM/yyyy")} - {format(dateRange.to, "dd/MM/yyyy")}
                            </>
                          ) : (
                            format(dateRange.from, "dd/MM/yyyy")
                          )
                        ) : (
                          <span>Selecione o período</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="range"
                        selected={dateRange}
                        onSelect={setDateRange as any}
                        locale={ptBR}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Filtrar por</label>
                <Tabs defaultValue="driver" className="w-full">
                  <TabsList className="w-full">
                    <TabsTrigger value="driver" className="flex-1">Motorista</TabsTrigger>
                    <TabsTrigger value="vehicle" className="flex-1">Veículo</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="driver" className="mt-2">
                    <Select
                      value={selectedDriver}
                      onValueChange={setSelectedDriver}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um motorista" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          <SelectItem value="all">Todos os motoristas</SelectItem>
                          <SelectItem value="driver1">João Silva</SelectItem>
                          <SelectItem value="driver2">Maria Oliveira</SelectItem>
                          <SelectItem value="driver3">Carlos Santos</SelectItem>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </TabsContent>
                  
                  <TabsContent value="vehicle" className="mt-2">
                    <Select
                      value={selectedVehicle}
                      onValueChange={setSelectedVehicle}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um veículo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          <SelectItem value="all">Todos os veículos</SelectItem>
                          <SelectItem value="vehicle1">ABC-1234 - Onix</SelectItem>
                          <SelectItem value="vehicle2">DEF-5678 - HB20</SelectItem>
                          <SelectItem value="vehicle3">GHI-9012 - Kwid</SelectItem>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline">
                <Printer className="mr-2 h-4 w-4" />
                Imprimir
              </Button>
              <Button variant="outline">
                <FileDown className="mr-2 h-4 w-4" />
                Excel
              </Button>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                PDF
              </Button>
              <Button>Gerar Relatório</Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Prévia do Relatório</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-muted h-96 rounded-md flex items-center justify-center">
            <p className="text-muted-foreground">Selecione os filtros acima e clique em "Gerar Relatório" para visualizar</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Reports;
