
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  CalendarIcon, 
  FileDown, 
  Users, 
  Car, 
  DollarSign, 
  AlertTriangle, 
  Settings,
  FileCheck
} from 'lucide-react';

interface ReportData {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  category: string;
}

export const RentalCompanyReports = () => {
  const [selectedReport, setSelectedReport] = useState("");
  const [dateRange, setDateRange] = useState<{from: Date | undefined, to: Date | undefined}>({
    from: undefined,
    to: undefined,
  });
  const [exportFormat, setExportFormat] = useState("excel");

  const reportTypes: ReportData[] = [
    {
      id: "drivers-performance",
      title: "Desempenho de Motoristas",
      description: "Análise completa de performance, infrações e lucratividade por motorista",
      icon: Users,
      category: "Motoristas"
    },
    {
      id: "fleet-status",
      title: "Status da Frota",
      description: "Ocupação, manutenções e disponibilidade dos veículos",
      icon: Car,
      category: "Veículos"
    },
    {
      id: "financial-summary",
      title: "Resumo Financeiro",
      description: "Receitas, despesas e margem de lucro por período",
      icon: DollarSign,
      category: "Financeiro"
    },
    {
      id: "violations-report",
      title: "Relatório de Infrações",
      description: "Infrações por motorista, custos e status de pagamento",
      icon: AlertTriangle,
      category: "Infrações"
    },
    {
      id: "maintenance-costs",
      title: "Custos de Manutenção",
      description: "Gastos com manutenção preventiva e corretiva por veículo",
      icon: Settings,
      category: "Manutenção"
    },
    {
      id: "inspections-report",
      title: "Relatório de Vistorias",
      description: "Vistorias realizadas, pendentes e resultados por período",
      icon: FileCheck,
      category: "Vistorias"
    }
  ];

  const handleExportReport = () => {
    if (!selectedReport) {
      alert("Por favor, selecione um relatório");
      return;
    }

    const selectedReportData = reportTypes.find(r => r.id === selectedReport);
    const fileName = `${selectedReportData?.title.replace(/\s+/g, '_')}_${format(new Date(), 'dd-MM-yyyy')}`;
    
    // Simula exportação
    console.log(`Exportando relatório: ${selectedReportData?.title}`);
    console.log(`Formato: ${exportFormat}`);
    console.log(`Período: ${dateRange.from ? format(dateRange.from, 'dd/MM/yyyy') : 'N/A'} - ${dateRange.to ? format(dateRange.to, 'dd/MM/yyyy') : 'N/A'}`);
    
    // Aqui você implementaria a lógica real de exportação
    alert(`Relatório "${selectedReportData?.title}" exportado com sucesso em formato ${exportFormat.toUpperCase()}!`);
  };

  const groupedReports = reportTypes.reduce((acc, report) => {
    if (!acc[report.category]) {
      acc[report.category] = [];
    }
    acc[report.category].push(report);
    return acc;
  }, {} as Record<string, ReportData[]>);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Relatórios da Locadora</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Gerar Relatório</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Tipo de Relatório</label>
              <Select value={selectedReport} onValueChange={setSelectedReport}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o relatório" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(groupedReports).map(([category, reports]) => (
                    <div key={category}>
                      <div className="px-2 py-1 text-xs font-semibold text-muted-foreground bg-muted">
                        {category}
                      </div>
                      {reports.map((report) => (
                        <SelectItem key={report.id} value={report.id}>
                          {report.title}
                        </SelectItem>
                      ))}
                    </div>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Período</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, "dd/MM/yyyy")} - {format(dateRange.to, "dd/MM/yyyy")}
                        </>
                      ) : (
                        format(dateRange.from, "dd/MM/yyyy")
                      )
                    ) : (
                      "Selecione o período"
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="range"
                    selected={dateRange}
                    onSelect={setDateRange as any}
                    locale={ptBR}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Formato de Exportação</label>
              <Select value={exportFormat} onValueChange={setExportFormat}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="excel">Excel (.xlsx)</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={handleExportReport} className="flex items-center gap-2">
              <FileDown className="h-4 w-4" />
              Exportar Relatório
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {reportTypes.map((report) => (
          <Card 
            key={report.id} 
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedReport === report.id ? 'ring-2 ring-primary' : ''
            }`}
            onClick={() => setSelectedReport(report.id)}
          >
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <div className="bg-primary/10 p-2 rounded-lg">
                  <report.icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm">{report.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {report.description}
                  </p>
                  <div className="mt-2">
                    <span className="text-xs bg-muted px-2 py-1 rounded">
                      {report.category}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};
