
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { PaymentStatus } from "@/types";

export const useRealDriverData = () => {
  const { user } = useAuth();

  // Buscar dados das vistorias
  const { data: inspections = [], isLoading: inspectionsLoading } = useQuery({
    queryKey: ['driver-inspections', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('inspections')
        .select('*')
        .eq('driver_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Erro ao buscar vistorias:', error);
        return [];
      }

      return data || [];
    },
    enabled: !!user?.id,
  });

  // Buscar dados de pagamentos
  const { data: payments = [], isLoading: paymentsLoading } = useQuery({
    queryKey: ['driver-payments', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('payments')
        .select('*')
        .eq('driver_id', user.id)
        .order('due_date', { ascending: false });

      if (error) {
        console.error('Erro ao buscar pagamentos:', error);
        return [];
      }

      return data || [];
    },
    enabled: !!user?.id,
  });

  // Buscar dados de infrações
  const { data: violations = [], isLoading: violationsLoading } = useQuery({
    queryKey: ['driver-violations', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('violations')
        .select('*')
        .eq('driver_id', user.id)
        .order('date', { ascending: false });

      if (error) {
        console.error('Erro ao buscar infrações:', error);
        return [];
      }

      return data || [];
    },
    enabled: !!user?.id,
  });

  // Buscar dados de manutenções
  const { data: maintenances = [], isLoading: maintenancesLoading } = useQuery({
    queryKey: ['driver-maintenances', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('maintenances')
        .select('*')
        .eq('driver_id', user.id)
        .order('scheduled_date', { ascending: false });

      if (error) {
        console.error('Erro ao buscar manutenções:', error);
        return [];
      }

      return data || [];
    },
    enabled: !!user?.id,
  });

  // Buscar dados do contrato ativo
  const { data: activeContract, isLoading: contractLoading } = useQuery({
    queryKey: ['driver-active-contract', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('contracts')
        .select(`
          *,
          rental_companies(company_name)
        `)
        .eq('driver_id', user.id)
        .eq('status', 'active')
        .maybeSingle();

      if (error) {
        console.error('Erro ao buscar contrato ativo:', error);
        return null;
      }

      return data;
    },
    enabled: !!user?.id,
  });

  // Buscar veículos para obter informações dos veículos
  const { data: vehicles = [], isLoading: vehiclesLoading } = useQuery({
    queryKey: ['rental-vehicles', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('rental_company_vehicles')
        .select('*');

      if (error) {
        console.error('Erro ao buscar veículos:', error);
        return [];
      }

      return data || [];
    },
    enabled: !!user?.id,
  });

  const isLoading = inspectionsLoading || paymentsLoading || violationsLoading || maintenancesLoading || contractLoading || vehiclesLoading;

  // Função para obter informações do veículo por ID
  const getVehicleInfo = (vehicleId: string) => {
    return vehicles.find(v => v.id === vehicleId);
  };

  // Processar dados para os componentes
  const inspectionInfo = {
    pending: inspections.filter(i => i.status === 'pending').length,
    completed: inspections.filter(i => i.status === 'completed').length,
    nextInspection: inspections.find(i => i.status === 'pending') ? {
      type: inspections.find(i => i.status === 'pending')?.type || 'Vistoria',
      date: inspections.find(i => i.status === 'pending')?.inspection_date || new Date().toISOString().split('T')[0],
      location: 'A definir'
    } : null
  };

  const paymentInfo = {
    status: payments.length > 0 ? (payments[0].status as PaymentStatus) : PaymentStatus.OPEN,
    nextPayment: payments.find(p => p.status === 'pending') ? {
      amount: Number(payments.find(p => p.status === 'pending')?.amount || 0),
      dueDate: payments.find(p => p.status === 'pending')?.due_date || new Date().toISOString().split('T')[0]
    } : null
  };

  const violationsData = violations.map(v => ({
    id: v.id,
    type: v.violation_type,
    amount: Number(v.amount),
    date: v.date,
    status: (v.status === 'paid' || v.status === 'pending' || v.status === 'overdue') 
      ? v.status as 'pending' | 'overdue' | 'paid'
      : 'pending' as const
  }));

  const assignedInspections = inspections
    .filter(i => i.status === 'pending')
    .map(i => {
      const vehicle = getVehicleInfo(i.vehicle_id);
      return {
        id: i.id,
        type: i.type,
        time: '14:00',
        vehicle: vehicle ? `${vehicle.brand} ${vehicle.model} - ${vehicle.plate}` : 'Veículo não identificado',
        driver: user?.fullName || 'Motorista',
        location: 'A definir',
        status: 'Agendada',
        statusColor: 'bg-blue-100 text-blue-800',
        requestedBy: 'Sistema',
        description: i.observations || 'Vistoria de rotina'
      };
    });

  const scheduledMaintenances = maintenances
    .filter(m => m.status === 'scheduled')
    .map(m => {
      const vehicle = getVehicleInfo(m.vehicle_id);
      return {
        id: m.id,
        vehicleModel: vehicle ? `${vehicle.brand} ${vehicle.model}` : 'Veículo não identificado',
        vehiclePlate: vehicle?.plate || '',
        maintenanceType: m.maintenance_type === 'preventive' ? 'preventive' as const : 'corrective' as const,
        scheduledDate: m.scheduled_date,
        scheduledTime: '09:00',
        location: 'A definir',
        description: m.description,
        status: new Date(m.scheduled_date) < new Date() ? 'overdue' as const : 'pending' as const,
        requestedBy: 'Sistema'
      };
    });

  const rankingInfo = {
    position: 0, // Não temos dados de ranking ainda
    points: user?.rating || 0,
    monthlyChange: 0,
    totalDrivers: 0
  };

  return {
    inspectionInfo,
    paymentInfo,
    violations: violationsData,
    assignedInspections,
    scheduledMaintenances,
    rankingInfo,
    activeContract: activeContract ? {
      companyId: Number(activeContract.company_id),
      companyName: activeContract.rental_companies?.company_name || 'Locadora',
      vehicleModel: (() => {
        const vehicle = getVehicleInfo(activeContract.vehicle_id);
        return vehicle ? `${vehicle.brand} ${vehicle.model}` : 'Veículo não identificado';
      })(),
      contractStart: activeContract.start_date,
      contractEnd: activeContract.end_date,
      paymentStatus: paymentInfo.status
    } : null,
    isLoading
  };
};
