
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trophy, Medal, Award, TrendingUp, TrendingDown } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface RankingInfo {
  position: number;
  points: number;
  monthlyChange: number;
  totalDrivers: number;
}

interface DriverRankingStatusProps {
  rankingInfo: RankingInfo;
}

export const DriverRankingStatus = ({ rankingInfo }: DriverRankingStatusProps) => {
  const navigate = useNavigate();

  const getPositionIcon = () => {
    switch (rankingInfo.position) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />;
      default:
        return (
          <div className="h-6 w-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-xs font-bold">
            #{rankingInfo.position}
          </div>
        );
    }
  };

  const getTrendIcon = () => {
    if (rankingInfo.monthlyChange > 0) {
      return <TrendingUp className="h-4 w-4 text-green-600" />;
    } else if (rankingInfo.monthlyChange < 0) {
      return <TrendingDown className="h-4 w-4 text-red-600" />;
    }
    return null;
  };

  const getPositionText = () => {
    if (rankingInfo.position <= 3) {
      const positions = ["🥇 1º Lugar", "🥈 2º Lugar", "🥉 3º Lugar"];
      return positions[rankingInfo.position - 1];
    }
    return `#${rankingInfo.position}`;
  };

  return (
    <Card className="bg-card border border-border">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-foreground">Ranking</CardTitle>
        <Trophy className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {getPositionIcon()}
              <span className="font-semibold text-foreground">{getPositionText()}</span>
            </div>
          </div>

          <div>
            <p className="text-2xl font-bold text-foreground">{rankingInfo.points}</p>
            <p className="text-xs text-muted-foreground">
              pontos acumulados
            </p>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">
              de {rankingInfo.totalDrivers} motoristas
            </span>
            
            {rankingInfo.monthlyChange !== 0 && (
              <div className="flex items-center gap-1">
                {getTrendIcon()}
                <span className={rankingInfo.monthlyChange > 0 ? "text-green-600" : "text-red-600"}>
                  {rankingInfo.monthlyChange > 0 ? "+" : ""}{rankingInfo.monthlyChange} posições
                </span>
              </div>
            )}
          </div>

          <Button 
            variant="outline" 
            size="sm" 
            className="w-full mt-3 border-border text-foreground hover:bg-accent"
            onClick={() => navigate('/ranking')}
          >
            Ver Ranking
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
