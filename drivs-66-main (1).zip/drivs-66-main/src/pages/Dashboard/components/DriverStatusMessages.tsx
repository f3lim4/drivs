
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Driver, DriverStatus } from "@/types";
import { AlertCircle, Clock, XCircle, Ban, CreditCard, Trash2, HelpCircle, Upload } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface DriverStatusMessagesProps {
  driver: Driver;
}

export const DriverStatusMessages = ({ driver }: DriverStatusMessagesProps) => {
  const [paymentFile, setPaymentFile] = useState<File | null>(null);

  const handleDeleteAccount = () => {
    toast.success("Solicitação de exclusão enviada. Sua conta será removida em breve.");
  };

  const handlePaymentUpload = () => {
    if (!paymentFile) {
      toast.error("Por favor, selecione um comprovante de pagamento.");
      return;
    }
    toast.success("Comprovante de pagamento enviado com sucesso! Aguarde a confirmação.");
  };

  const handleOpenTicket = () => {
    // Aqui seria implementada a abertura de chamado com a DRIVS
    toast.success("Chamado aberto com a DRIVS. Você receberá retorno em breve.");
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setPaymentFile(file);
    }
  };

  if (driver.status === DriverStatus.UNDER_REVIEW) {
    return (
      <Card className="border-yellow-200 bg-yellow-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-yellow-800">
            <Clock className="h-5 w-5" />
            Cadastro em Análise
          </CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-yellow-700 text-base">
            Seu cadastro está em análise. Aguarde a revisão dos seus documentos.
            Você será notificado assim que o processo for concluído.
          </CardDescription>
        </CardContent>
      </Card>
    );
  }

  if (driver.status === DriverStatus.REJECTED) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-800">
            <XCircle className="h-5 w-5" />
            Cadastro Reprovado
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-red-200 bg-red-100">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-red-800">
              Infelizmente seu cadastro foi reprovado.
              {driver.rejection_reason && (
                <div className="mt-2">
                  <strong>Motivo da reprovação:</strong> {driver.rejection_reason}
                </div>
              )}
            </AlertDescription>
          </Alert>
          
          <div className="bg-red-100 border border-red-200 rounded-md p-4">
            <h4 className="font-medium text-red-800 mb-2">Informações importantes:</h4>
            <ul className="text-sm text-red-700 space-y-1">
              <li>• Você não pode mais editar ou reenviar dados</li>
              <li>• Não é possível reverter esta decisão</li>
              <li>• Se desejar, pode excluir definitivamente seu cadastro</li>
            </ul>
          </div>

          <Button 
            variant="destructive" 
            onClick={handleDeleteAccount}
            className="w-full"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Excluir Cadastro Definitivamente
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (driver.status === DriverStatus.BLACKLISTED) {
    return (
      <Card className="border-red-400 bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-800">
            <CreditCard className="h-5 w-5" />
            Conta Bloqueada - Pendência Financeira
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-red-200 bg-red-100">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-red-800 font-medium">
              Sua conta está bloqueada devido a pendências financeiras.
            </AlertDescription>
          </Alert>
          
          <div className="bg-white border border-red-200 rounded-md p-4">
            <h4 className="font-semibold text-red-800 mb-3">Informações da Dívida</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Valor total:</span>
                <span className="text-lg font-bold text-red-600">
                  R$ {(driver.debt_amount || 0).toFixed(2)}
                </span>
              </div>
              
              {driver.pix_key && (
                <div className="border-t pt-3">
                  <p className="text-sm font-medium text-gray-700 mb-2">Chave Pix para pagamento:</p>
                  <div className="bg-gray-100 p-2 rounded border">
                    <p className="font-mono text-sm text-blue-600 break-all">{driver.pix_key}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
            <h4 className="font-medium text-blue-800 mb-3">Enviar Comprovante de Pagamento</h4>
            <div className="space-y-3">
              <div>
                <Label htmlFor="payment-proof" className="text-sm font-medium">
                  Selecione o comprovante (PDF, PNG, JPG):
                </Label>
                <Input
                  id="payment-proof"
                  type="file"
                  accept=".pdf,.png,.jpg,.jpeg"
                  onChange={handleFileChange}
                  className="mt-1"
                />
              </div>
              
              <Button 
                onClick={handlePaymentUpload} 
                className="w-full"
                disabled={!paymentFile}
              >
                <Upload className="h-4 w-4 mr-2" />
                Enviar Comprovante
              </Button>
              
              <p className="text-xs text-gray-600 text-center">
                Após a confirmação do pagamento, sua conta será reativada automaticamente.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (driver.status === DriverStatus.DEACTIVATED) {
    return (
      <Card className="border-gray-400 bg-gray-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-800">
            <Ban className="h-5 w-5" />
            Conta Desativada
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-gray-300 bg-gray-100">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-gray-800">
              Sua conta está desativada. Você não pode realizar nenhuma ação até que a empresa destrave sua conta.
            </AlertDescription>
          </Alert>
          
          <div className="bg-white border border-gray-300 rounded-md p-4">
            <h4 className="font-medium text-gray-800 mb-2">O que fazer?</h4>
            <p className="text-sm text-gray-600 mb-3">
              Se você não sabe o motivo da desativação ou precisa de esclarecimentos, 
              abra um chamado com nossa central de atendimento.
            </p>
            
            <Button 
              onClick={handleOpenTicket}
              className="w-full"
              variant="outline"
            >
              <HelpCircle className="h-4 w-4 mr-2" />
              Abrir Chamado com a DRIVS
            </Button>
          </div>
          
          <div className="text-xs text-gray-500 text-center">
            Nossa equipe de suporte entrará em contato em até 24 horas úteis.
          </div>
        </CardContent>
      </Card>
    );
  }

  return null;
};
