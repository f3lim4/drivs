
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Car, MapPin, User, Play } from "lucide-react";

interface AssignedInspection {
  id: string;
  type: string;
  time: string;
  vehicle: string;
  driver: string;
  location: string;
  status: string;
  statusColor: string;
  requestedBy: string;
  description: string;
}

interface AssignedInspectionsCardProps {
  inspections: AssignedInspection[];
}

export const AssignedInspectionsCard = ({ inspections }: AssignedInspectionsCardProps) => {
  const getTypeColor = (type: string) => {
    switch (type) {
      case "Vistoria Inicial":
        return "bg-blue-100 text-blue-800";
      case "Vistoria de Entrega":
        return "bg-green-100 text-green-800";
      case "Vistoria de Manutenção":
        return "bg-purple-100 text-purple-800";
      case "Vistoria Semanal":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (inspections.length === 0) {
    return null;
  }

  return (
    <Card className="content-card border-l-2 border-l-blue-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Vistorias Solicitadas pela Locadora
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Vistorias que você precisa realizar conforme solicitado pela locadora
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {inspections.map((inspection) => (
            <div key={inspection.id} className="flex items-center justify-between p-4 border rounded-lg bg-gray-50">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <Badge className={getTypeColor(inspection.type)}>
                    {inspection.type}
                  </Badge>
                  <span className="font-medium text-lg">{inspection.time}</span>
                  <Badge className={inspection.statusColor}>
                    {inspection.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <Car className="h-4 w-4 text-gray-500" />
                  <p className="font-medium">{inspection.vehicle}</p>
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <p className="text-sm text-muted-foreground">{inspection.location}</p>
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <User className="h-4 w-4 text-gray-500" />
                  <p className="text-xs text-muted-foreground">Solicitado por: {inspection.requestedBy}</p>
                </div>
                <p className="text-xs text-muted-foreground">{inspection.description}</p>
              </div>
              <Button size="sm" className="flex items-center gap-2">
                <Play className="h-4 w-4" />
                Realizar
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
