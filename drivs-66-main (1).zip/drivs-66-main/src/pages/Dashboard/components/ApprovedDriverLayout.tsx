
import { Driver } from "@/types";
import { DriverStatsCards } from "@/pages/Drivers/components/DriverStatsCards";
import { NextActionCard } from "./NextActionCard";
import { NotificationsCard } from "./NotificationsCard";
import { ReservationCard } from "./ReservationCard";
import { UserRole } from "@/types";
import { useRealDriverData } from "../hooks/useRealDriverData";
import { Card, CardContent } from "@/components/ui/card";
import { RefreshCw } from "lucide-react";

interface ApprovedDriverLayoutProps {
  driver: Driver;
  statusInfo: {
    label: string;
    color: string;
    icon: any;
    description: string;
  };
  onViewVehicles: () => void;
}

interface Notification {
  id: number;
  title: string;
  message: string;
  type: "info" | "warning" | "error";
  time: string;
  read: boolean;
}

export const ApprovedDriverLayout = ({ driver, statusInfo, onViewVehicles }: ApprovedDriverLayoutProps) => {
  const { paymentInfo, isLoading } = useRealDriverData();

  const mockNotifications: Notification[] = [
    {
      id: 1,
      title: "Documentação Aprovada!",
      message: "Seus documentos foram aprovados. Agora você pode visualizar veículos disponíveis.",
      type: "info" as const,
      time: new Date().toISOString(),
      read: false
    }
  ];

  // Ensure driver has all required properties for DriverStatsCards
  const driverWithDefaults = {
    ...driver,
    rating: driver.rating ?? 0,
    violations: driver.violations ?? 0,
    available: driver.available ?? false
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="flex items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin mr-2" />
            <span>Carregando dados...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-6">
        <DriverStatsCards driver={driverWithDefaults} />
        <NextActionCard userRole={UserRole.DRIVER} driverStatus={driver.status} />
        <ReservationCard paymentStatus={paymentInfo.status} />
      </div>
      
      <div className="space-y-6">
        <NotificationsCard notifications={mockNotifications} />
      </div>
    </div>
  );
};
