
import { Driver, UserRole } from "@/types";
import { DocumentationStatusCard } from "./DocumentationStatusCard";
import { NextActionCard } from "./NextActionCard";
import { NotificationsCard } from "./NotificationsCard";
import { useRealDriverData } from "../hooks/useRealDriverData";
import { Card, CardContent } from "@/components/ui/card";
import { RefreshCw } from "lucide-react";

interface PendingDriverLayoutProps {
  driver: Driver;
  statusInfo: {
    label: string;
    color: string;
    icon: any;
    description: string;
  };
  documentProgress: number;
  navigate: (path: string) => void;
}

export const PendingDriverLayout = ({ driver, statusInfo, documentProgress, navigate }: PendingDriverLayoutProps) => {
  const { isLoading } = useRealDriverData();

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="flex items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin mr-2" />
            <span>Carregando dados...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-6">
        <DocumentationStatusCard 
          driver={driver}
          documentProgress={documentProgress}
        />
      </div>
      
      <div className="space-y-6">
        <NotificationsCard />
      </div>
    </div>
  );
};
