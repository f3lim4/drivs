
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Wrench, AlertTriangle } from "lucide-react";

interface ScheduledMaintenance {
  id: string;
  vehicleModel: string;
  vehiclePlate: string;
  maintenanceType: string;
  scheduledDate: string;
  scheduledTime: string;
  location: string;
  description: string;
  status: "pending" | "confirmed" | "overdue";
  requestedBy: string;
}

interface ScheduledMaintenanceCardProps {
  maintenances: ScheduledMaintenance[];
}

export const ScheduledMaintenanceCard = ({ maintenances }: ScheduledMaintenanceCardProps) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "confirmed":
        return <Badge className="bg-green-100 text-green-800">Confirmada</Badge>;
      case "overdue":
        return <Badge className="bg-red-100 text-red-800">Atrasada</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "preventive":
        return "bg-blue-100 text-blue-800";
      case "corrective":
        return "bg-orange-100 text-orange-800";
      case "revision":
        return "bg-purple-100 text-purple-800";
      case "inspection":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getMaintenanceTypeName = (type: string) => {
    switch (type) {
      case "preventive":
        return "Preventiva";
      case "corrective":
        return "Corretiva";
      case "revision":
        return "Revisão";
      case "inspection":
        return "Vistoria";
      default:
        return type;
    }
  };

  if (maintenances.length === 0) {
    return (
      <Card className="content-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wrench className="h-5 w-5" />
            Manutenções Agendadas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Wrench className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Nenhuma manutenção agendada</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="content-card border-l-4 border-l-orange-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wrench className="h-5 w-5" />
          Manutenções Agendadas
          {maintenances.some(m => m.status === "overdue") && (
            <AlertTriangle className="h-4 w-4 text-red-500" />
          )}
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Manutenções solicitadas pela locadora
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {maintenances.map((maintenance) => (
            <div key={maintenance.id} className="p-4 border rounded-lg bg-gray-50">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Badge className={getTypeColor(maintenance.maintenanceType)}>
                    {getMaintenanceTypeName(maintenance.maintenanceType)}
                  </Badge>
                  {getStatusBadge(maintenance.status)}
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Wrench className="h-4 w-4 text-gray-500" />
                  <span className="font-medium">{maintenance.vehicleModel} - {maintenance.vehiclePlate}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <span className="text-sm">
                    {new Date(maintenance.scheduledDate).toLocaleDateString('pt-BR')}
                  </span>
                  <Clock className="h-4 w-4 text-gray-500 ml-2" />
                  <span className="text-sm">{maintenance.scheduledTime}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <span className="text-sm">{maintenance.location}</span>
                </div>
                
                <p className="text-sm text-muted-foreground mt-2">
                  {maintenance.description}
                </p>
                
                <p className="text-xs text-muted-foreground">
                  Solicitado por: {maintenance.requestedBy}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
