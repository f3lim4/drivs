
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Car, MapPin, Calendar } from "lucide-react";
import { Driver } from "@/types";

interface ActiveDriverStatusCardProps {
  driver: Driver;
}

export const ActiveDriverStatusCard = ({ driver }: ActiveDriverStatusCardProps) => {
  if (!driver.activeContract) {
    return null;
  }

  return (
    <Card className="content-card content-card-green">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Car className="h-6 w-6 text-green-600" />
            <div>
              <h3 className="font-semibold text-lg">Contrato Ativo</h3>
              <p className="text-sm text-muted-foreground">Status do seu veículo</p>
            </div>
          </div>
          <Badge className="bg-green-100 text-green-800">
            Ativo
          </Badge>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Car className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{driver.activeContract.vehicleModel}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">{driver.activeContract.companyName}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">
              Início: {new Date(driver.activeContract.contractStart).toLocaleDateString('pt-BR')}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
