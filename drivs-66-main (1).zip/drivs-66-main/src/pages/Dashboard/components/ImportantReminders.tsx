
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver } from "@/types";

export const ImportantReminders = () => {
  const { user } = useAuth();
  
  if (!user || user.role !== UserRole.DRIVER) {
    return null;
  }

  const driver = user as Driver;
  const isActiveDriver = !!driver.activeContract;

  // Só mostra lembretes para motoristas ativos
  if (!isActiveDriver) {
    return null;
  }

  const reminders = [
    "Manter o carro com cuidado, olhando água e óleo. Se notar baixa excessiva, avisar locadora.",
    "Realize vistorias quando solicitadas",
    "Comunique problemas imediatamente",
    "Respeite os termos do contrato"
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-amber-600">
          <AlertCircle className="h-5 w-5" />
          Lembretes Importantes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {reminders.map((reminder, index) => (
            <li key={index} className="flex items-start gap-2 text-sm">
              <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 flex-shrink-0" />
              <span className="text-gray-700 dark:text-gray-300">{reminder}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};
