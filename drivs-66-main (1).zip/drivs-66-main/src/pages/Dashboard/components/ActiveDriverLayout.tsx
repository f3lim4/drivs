
import { Driver } from "@/types";
import { DriverStatusHeader } from "./DriverStatusHeader";
import { ActiveDriverStatusCard } from "./ActiveDriverStatusCard";
import { DriverInspectionStatus } from "./DriverInspectionStatus";
import { DriverPaymentStatus } from "./DriverPaymentStatus";
import { DriverViolationsStatus } from "./DriverViolationsStatus";
import { DriverRankingStatus } from "./DriverRankingStatus";
import { ImportantReminders } from "./ImportantReminders";
import { AssignedInspectionsCard } from "./AssignedInspectionsCard";
import { ScheduledMaintenanceCard } from "./ScheduledMaintenanceCard";
import { CheckCircle } from "lucide-react";
import { useRealDriverData } from "../hooks/useRealDriverData";
import { Card, CardContent } from "@/components/ui/card";
import { RefreshCw } from "lucide-react";

interface ActiveDriverLayoutProps {
  driver: Driver;
}

export const ActiveDriverLayout = ({ driver }: ActiveDriverLayoutProps) => {
  const {
    inspectionInfo,
    paymentInfo,
    violations,
    assignedInspections,
    scheduledMaintenances,
    rankingInfo,
    activeContract,
    isLoading
  } = useRealDriverData();

  const statusInfo = {
    label: "Ativo",
    color: "bg-green-500",
    icon: CheckCircle,
    description: "Dirigindo ativamente"
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <DriverStatusHeader driver={driver} statusInfo={statusInfo} />
        <Card>
          <CardContent className="py-8">
            <div className="flex items-center justify-center">
              <RefreshCw className="h-6 w-6 animate-spin mr-2" />
              <span>Carregando dados...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Atualizar o driver com dados do contrato ativo se existir
  const updatedDriver: Driver = activeContract ? {
    ...driver,
    activeContract
  } : driver;

  return (
    <div className="space-y-6">
      <DriverStatusHeader driver={driver} statusInfo={statusInfo} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Coluna principal */}
        <div className="lg:col-span-2 space-y-6">
          <ActiveDriverStatusCard driver={updatedDriver} />
          <AssignedInspectionsCard inspections={assignedInspections} />
          <ScheduledMaintenanceCard maintenances={scheduledMaintenances} />
        </div>
        
        {/* Coluna lateral */}
        <div className="space-y-6">
          <DriverInspectionStatus inspectionInfo={inspectionInfo} />
          <DriverPaymentStatus paymentInfo={paymentInfo} />
          <DriverViolationsStatus violations={violations} />
          <DriverRankingStatus rankingInfo={rankingInfo} />
          <ImportantReminders />
        </div>
      </div>
    </div>
  );
};
