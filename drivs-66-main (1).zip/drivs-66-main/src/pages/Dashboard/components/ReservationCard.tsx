
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Car, CreditCard, Clock, CheckCircle } from "lucide-react";
import { PaymentStatus } from "@/types";
import { useNavigate } from "react-router-dom";

interface ReservationCardProps {
  paymentStatus: PaymentStatus;
}

export const ReservationCard = ({ paymentStatus }: ReservationCardProps) => {
  const navigate = useNavigate();

  const handleViewVehicles = () => {
    navigate("/motoristas/ver-veiculos");
  };

  const getStatusInfo = () => {
    switch (paymentStatus) {
      case PaymentStatus.PAID:
        return {
          icon: CheckCircle,
          label: "Pagamento em Dia",
          color: "bg-green-100 text-green-800",
          iconColor: "text-green-600",
          description: "Você pode reservar veículos disponíveis"
        };
      case PaymentStatus.OVERDUE:
        return {
          icon: Clock,
          label: "Pagamento Atrasado",
          color: "bg-red-100 text-red-800",
          iconColor: "text-red-600",
          description: "Regularize seu pagamento para reservar veículos"
        };
      case PaymentStatus.BLACKLISTED:
        return {
          icon: Clock,
          label: "Negativado",
          color: "bg-red-100 text-red-800",
          iconColor: "text-red-600",
          description: "Entre em contato para regularizar sua situação"
        };
      default:
        return {
          icon: CreditCard,
          label: "Pagamento Pendente",
          color: "bg-yellow-100 text-yellow-800",
          iconColor: "text-yellow-600",
          description: "Complete seu pagamento para reservar veículos"
        };
    }
  };

  const statusInfo = getStatusInfo();
  const StatusIcon = statusInfo.icon;
  const canReserve = paymentStatus === PaymentStatus.PAID;

  return (
    <Card className="content-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Car className="h-5 w-5" />
          Reserva de Veículo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <StatusIcon className={`h-4 w-4 ${statusInfo.iconColor}`} />
          <Badge className={statusInfo.color}>
            {statusInfo.label}
          </Badge>
        </div>

        <p className="text-sm text-muted-foreground">
          {statusInfo.description}
        </p>

        <Button 
          className="w-full" 
          disabled={!canReserve}
          onClick={handleViewVehicles}
        >
          {canReserve ? "Ver Veículos Disponíveis" : "Regularizar Pagamento"}
        </Button>

        {!canReserve && (
          <div className="text-xs text-muted-foreground text-center">
            Entre em contato conosco para regularizar sua situação
          </div>
        )}
      </CardContent>
    </Card>
  );
};
