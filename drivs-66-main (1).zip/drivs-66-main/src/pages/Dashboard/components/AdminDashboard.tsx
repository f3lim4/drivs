import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Building2, Car, AlertTriangle, DollarSign, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { AdminHeader } from "@/components/layout/AdminHeader";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeCompanies: 0,
    totalDrivers: 0,
    totalVehicles: 0,
    pendingReports: 0,
    totalRevenue: 0
  });
  const [loading, setLoading] = useState(true);

  const fetchRealData = async () => {
    try {
      setLoading(true);

      // Fetch rental companies
      const { data: companies, error: companiesError } = await supabase
        .from('rental_companies')
        .select('*');

      if (companiesError) throw companiesError;

      // Fetch drivers
      const { data: drivers, error: driversError } = await supabase
        .from('drivers')
        .select('*');

      if (driversError) throw driversError;

      // Fetch vehicles
      const { data: vehicles, error: vehiclesError } = await supabase
        .from('rental_company_vehicles')
        .select('*');

      if (vehiclesError) throw vehiclesError;

      // Fetch admin users
      const { data: adminUsers, error: adminError } = await supabase
        .from('admin_users')
        .select('*');

      if (adminError) throw adminError;

      // Calculate statistics
      const totalUsers = (companies?.length || 0) + (drivers?.length || 0) + (adminUsers?.length || 0);
      const activeCompanies = companies?.filter(c => c.is_active && c.payment_status === 'paid').length || 0;
      const totalDrivers = drivers?.length || 0;
      const totalVehicles = vehicles?.length || 0;
      
      // Calculate estimated revenue (R$ 50 por locadora ativa por mês)
      const totalRevenue = activeCompanies * 50;

      setStats({
        totalUsers,
        activeCompanies,
        totalDrivers,
        totalVehicles,
        pendingReports: 0, // Pode ser implementado quando houver tabela de relatórios
        totalRevenue
      });

    } catch (error: any) {
      console.error('Error fetching admin data:', error);
      toast.error('Erro ao carregar dados do painel');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRealData();
  }, []);
  
  const statsConfig = [
    {
      title: "Total de Usuários",
      value: stats.totalUsers.toString(),
      icon: Users,
      description: "Todos os usuários do sistema"
    },
    {
      title: "Locadoras Ativas",
      value: stats.activeCompanies.toString(),
      icon: Building2,
      description: "Empresas com pagamentos em dia"
    },
    {
      title: "Motoristas Cadastrados",
      value: stats.totalDrivers.toString(),
      icon: Users,  
      description: "Motoristas no sistema"
    },
    {
      title: "Veículos Total",
      value: stats.totalVehicles.toString(),
      icon: Car,
      description: "Todos os veículos cadastrados"
    },
    {
      title: "Relatórios Pendentes",
      value: stats.pendingReports.toString(),
      icon: AlertTriangle,
      description: "Relatórios aguardando análise"
    },
    {
      title: "Receita Total Plataforma",
      value: `R$ ${stats.totalRevenue.toLocaleString('pt-BR')}`,
      icon: DollarSign,
      description: "Receita mensal estimada"
    }
  ];

  // Mock de solicitações de negativação pendentes
  const blacklistRequests = [
    {
      id: "1",
      driverName: "João Silva",
      driverCpf: "123.456.789-00",
      companyName: "Locadora ABC",
      requestDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      reason: "Não pagamento de débitos"
    },
    {
      id: "2", 
      driverName: "Maria Santos",
      driverCpf: "987.654.321-00",
      companyName: "Locadora XYZ",
      requestDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      reason: "Abandono de veículo"
    }
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <AdminHeader />
        <div>
          <p className="text-muted-foreground">Carregando dados...</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, index) => (
            <Card key={index} className="animate-pulse">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="h-4 bg-gray-200 rounded w-24"></div>
                <div className="h-4 w-4 bg-gray-200 rounded"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-gray-200 rounded w-16 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-32"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <AdminHeader />
      <div>
        <p className="text-muted-foreground">
          Visão geral completa da plataforma DRIVS
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statsConfig.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Atividades Recentes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm">Dados atualizados em tempo real</p>
                  <p className="text-xs text-muted-foreground">Agora mesmo</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm">{stats.activeCompanies} locadoras ativas no sistema</p>
                  <p className="text-xs text-muted-foreground">Dados atuais</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm">{stats.totalVehicles} veículos cadastrados</p>
                  <p className="text-xs text-muted-foreground">Total na plataforma</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate('/negativacao')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              Solicitações de Negativação
              {blacklistRequests.length > 0 && (
                <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {blacklistRequests.length}
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {blacklistRequests.length > 0 ? (
                blacklistRequests.slice(0, 3).map((request) => (
                  <div key={request.id} className="flex items-center justify-between p-2 bg-orange-50 rounded">
                    <div>
                      <p className="font-medium text-sm">{request.driverName}</p>
                      <p className="text-xs text-muted-foreground">{request.companyName}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-orange-600 font-medium">Pendente</p>
                      <p className="text-xs text-muted-foreground">
                        {request.requestDate.toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-sm text-muted-foreground text-center py-4">
                  Nenhuma solicitação pendente
                </div>
              )}
              {blacklistRequests.length > 3 && (
                <p className="text-xs text-muted-foreground text-center">
                  +{blacklistRequests.length - 3} mais solicitações
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Status do Sistema</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">Status do Servidor</span>
              <span className="text-sm text-green-600 font-medium">Online</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Banco de Dados</span>
              <span className="text-sm text-green-600 font-medium">Conectado</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Última Atualização</span>
              <span className="text-sm text-muted-foreground">Agora mesmo</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Total de Registros</span>
              <span className="text-sm text-blue-600 font-medium">{stats.totalUsers}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;
