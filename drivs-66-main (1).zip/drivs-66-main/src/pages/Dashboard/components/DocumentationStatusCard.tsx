
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { FileText, Upload, AlertCircle } from "lucide-react";
import { Driver, DriverStatus } from "@/types";
import { useNavigate } from "react-router-dom";

interface DocumentationStatusCardProps {
  driver: Driver;
  documentProgress: number;
}

export const DocumentationStatusCard = ({ driver, documentProgress }: DocumentationStatusCardProps) => {
  const navigate = useNavigate();

  const getStatusInfo = () => {
    switch (driver.status) {
      case DriverStatus.PENDING:
        return {
          title: "Status da Documentação",
          description: "Aguardando envio de documentos",
          icon: Upload,
          color: "text-blue-600",
          bgColor: "bg-blue-50",
          borderColor: "border-blue-200",
          showButton: true,
          buttonText: "Enviar Documentos",
          buttonAction: () => navigate('/motorista/documentos')
        };
      case DriverStatus.UNDER_REVIEW:
        return {
          title: "Status da Documentação",
          description: "Documentos em análise",
          icon: AlertCircle,
          color: "text-yellow-600",
          bgColor: "bg-yellow-50",
          borderColor: "border-yellow-200",
          showButton: false,
          buttonText: "",
          buttonAction: () => {}
        };
      case DriverStatus.APPROVED:
        return {
          title: "Status da Documentação",
          description: "Documentação aprovada",
          icon: FileText,
          color: "text-green-600",
          bgColor: "bg-green-50",
          borderColor: "border-green-200",
          showButton: false,
          buttonText: "",
          buttonAction: () => {}
        };
      default:
        return {
          title: "Status da Documentação",
          description: "Status indisponível",
          icon: FileText,
          color: "text-gray-600",
          bgColor: "bg-gray-50",
          borderColor: "border-gray-200",
          showButton: false,
          buttonText: "",
          buttonAction: () => {}
        };
    }
  };

  const statusInfo = getStatusInfo();
  const StatusIcon = statusInfo.icon;

  return (
    <Card className={`${statusInfo.borderColor} border-l-4`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <StatusIcon className={`h-5 w-5 ${statusInfo.color}`} />
          {statusInfo.title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className={`p-4 ${statusInfo.bgColor} rounded-lg`}>
          <p className={`text-sm font-medium ${statusInfo.color}`}>
            {statusInfo.description}
          </p>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progresso da Documentação</span>
            <span className="font-medium">{documentProgress}% Completo</span>
          </div>
          <Progress value={documentProgress} className="h-2" />
        </div>

        {statusInfo.showButton && (
          <Button 
            onClick={statusInfo.buttonAction}
            className="w-full"
            size="lg"
          >
            <Upload className="h-4 w-4 mr-2" />
            {statusInfo.buttonText}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};
