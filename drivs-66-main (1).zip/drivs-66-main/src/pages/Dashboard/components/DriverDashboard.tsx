
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver, DriverStatus } from "@/types";
import { useNavigate } from "react-router-dom";
import { DriverStatusHeader } from "./DriverStatusHeader";
import { DriverStatusMessages } from "./DriverStatusMessages";
import { ActiveDriverLayout } from "./ActiveDriverLayout";
import { ApprovedDriverLayout } from "./ApprovedDriverLayout";
import { PendingDriverLayout } from "./PendingDriverLayout";
import { DeactivatedDriverLayout } from "./DeactivatedDriverLayout";
import { Clock, CheckCircle, AlertCircle, XCircle } from "lucide-react";
import { useRealDriverData } from "../hooks/useRealDriverData";
import { Card, CardContent } from "@/components/ui/card";
import { RefreshCw } from "lucide-react";

const DriverDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { isLoading: driverDataLoading } = useRealDriverData();
  
  if (!user || user.role !== UserRole.DRIVER) {
    return <div>Acesso não autorizado</div>;
  }

  // Se ainda está carregando dados, mostrar loading
  if (driverDataLoading) {
    return (
      <div className="space-y-4 md:space-y-6 px-2 md:px-0">
        <div className="flex items-center justify-between pt-4">
          <div>
            <h1 className="text-3xl font-bold">Painel do Motorista</h1>
            <p className="text-muted-foreground">
              Carregando dados...
            </p>
          </div>
        </div>
        <Card>
          <CardContent className="py-8">
            <div className="flex items-center justify-center">
              <RefreshCw className="h-6 w-6 animate-spin mr-2" />
              <span>Carregando informações do motorista...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const driver = user as Driver;
  console.log('DriverDashboard: Driver status:', driver.status);
  console.log('DriverDashboard: Driver data:', driver);
  
  const isActiveDriver = !!driver.activeContract && driver.status !== "deactivated";

  const handleViewVehicles = () => {
    navigate("/motoristas/ver-veiculos");
  };

  const getStatusInfo = () => {
    const statusConfig = {
      pending: { 
        label: "Em Aberto", 
        color: "bg-blue-500", 
        icon: Clock,
        description: "Aguardando envio de documentos" 
      },
      under_review: { 
        label: "Em Análise", 
        color: "bg-yellow-500", 
        icon: AlertCircle,
        description: "Documentos em análise" 
      },
      approved: { 
        label: "Aprovado", 
        color: "bg-green-500", 
        icon: CheckCircle,
        description: "Pronto para dirigir" 
      },
      rejected: { 
        label: "Reprovado", 
        color: "bg-red-500", 
        icon: XCircle,
        description: "Cadastro rejeitado" 
      },
      deactivated: { 
        label: "Desativado", 
        color: "bg-gray-500", 
        icon: XCircle,
        description: "Contrato desativado" 
      },
      blacklisted: { 
        label: "Negativado", 
        color: "bg-red-600", 
        icon: XCircle,
        description: "Bloqueado por pendência" 
      }
    };
    
    return statusConfig[driver.status] || statusConfig.pending;
  };

  const statusInfo = getStatusInfo();

  if (driver.status === "deactivated") {
    return <DeactivatedDriverLayout driver={driver} />;
  }

  // Para motoristas com status "rejected" ou "blacklisted", mostrar mensagens específicas
  if ([DriverStatus.REJECTED, DriverStatus.BLACKLISTED].includes(driver.status)) {
    return (
      <div className="space-y-4 md:space-y-6 px-2 md:px-0">
        <DriverStatusHeader driver={driver} statusInfo={statusInfo} />
        <DriverStatusMessages driver={driver} />
      </div>
    );
  }

  const documentProgress = driver.status === "approved" ? 100 : 
                          driver.status === "under_review" ? 75 : 25;

  // Para motoristas ativos (com contrato)
  if (isActiveDriver) {
    return <ActiveDriverLayout driver={driver} />;
  }

  // Para motoristas aprovados (sem contrato ainda)
  if (driver.status === "approved") {
    return (
      <div className="space-y-4 md:space-y-6 px-2 md:px-0">
        <DriverStatusHeader driver={driver} statusInfo={statusInfo} />
        <ApprovedDriverLayout 
          driver={driver} 
          statusInfo={statusInfo} 
          onViewVehicles={handleViewVehicles} 
        />
      </div>
    );
  }

  // Para motoristas pendentes ("pending") ou em análise ("under_review")
  return (
    <div className="space-y-4 md:space-y-6 px-2 md:px-0">
      <DriverStatusHeader driver={driver} statusInfo={statusInfo} />
      <PendingDriverLayout 
        driver={driver} 
        statusInfo={statusInfo} 
        documentProgress={documentProgress}
        navigate={navigate}
      />
    </div>
  );
};

export default DriverDashboard;
