
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Violation {
  id: string;
  type: string;
  amount: number;
  date: string;
  status: "pending" | "paid" | "overdue";
}

interface DriverViolationsStatusProps {
  violations: Violation[];
}

export const DriverViolationsStatus = ({ violations }: DriverViolationsStatusProps) => {
  const navigate = useNavigate();

  const pendingViolations = violations.filter(v => v.status === "pending" || v.status === "overdue");
  const totalAmount = pendingViolations.reduce((sum, v) => sum + v.amount, 0);
  const hasOverdue = violations.some(v => v.status === "overdue");

  const getStatusInfo = () => {
    if (pendingViolations.length === 0) {
      return {
        icon: CheckCircle,
        label: "Sem Infrações",
        color: "bg-green-100 text-green-800",
        iconColor: "text-green-600"
      };
    }
    
    if (hasOverdue) {
      return {
        icon: AlertTriangle,
        label: "Infrações em Atraso",
        color: "bg-red-100 text-red-800",
        iconColor: "text-red-600"
      };
    }

    return {
      icon: Clock,
      label: "Infrações Pendentes",
      color: "bg-yellow-100 text-yellow-800",
      iconColor: "text-yellow-600"
    };
  };

  const statusInfo = getStatusInfo();
  const StatusIcon = statusInfo.icon;

  return (
    <Card className="content-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Infrações</CardTitle>
        <AlertTriangle className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <StatusIcon className={`h-4 w-4 ${statusInfo.iconColor}`} />
              <Badge className={statusInfo.color}>
                {statusInfo.label}
              </Badge>
            </div>
          </div>

          {pendingViolations.length > 0 && (
            <>
              <div>
                <p className="text-2xl font-bold">R$ {totalAmount.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground">
                  {pendingViolations.length} infração(ões) pendente(s)
                </p>
              </div>

              <div className="space-y-1">
                {pendingViolations.slice(0, 2).map((violation) => (
                  <div key={violation.id} className="text-xs text-muted-foreground">
                    {violation.type} - R$ {violation.amount.toFixed(2)}
                  </div>
                ))}
                {pendingViolations.length > 2 && (
                  <div className="text-xs text-muted-foreground">
                    +{pendingViolations.length - 2} mais
                  </div>
                )}
              </div>
            </>
          )}

          <Button 
            variant="outline" 
            size="sm" 
            className="w-full mt-3"
            onClick={() => navigate('/infracoes')}
          >
            Ver Infrações
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
