
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Calendar, AlertTriangle, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface InspectionInfo {
  pending: number;
  completed: number;
  nextInspection?: {
    type: string;
    date: string;
    location: string;
  };
}

interface DriverInspectionStatusProps {
  inspectionInfo: InspectionInfo;
}

export const DriverInspectionStatus = ({ inspectionInfo }: DriverInspectionStatusProps) => {
  const navigate = useNavigate();

  const getStatusInfo = () => {
    if (inspectionInfo.pending > 0) {
      return {
        icon: AlertTriangle,
        label: "Vistorias Pendentes",
        color: "bg-yellow-100 text-yellow-800",
        iconColor: "text-yellow-600"
      };
    }
    
    return {
      icon: CheckCircle,
      label: "Em Dia",
      color: "bg-green-100 text-green-800",
      iconColor: "text-green-600"
    };
  };

  const statusInfo = getStatusInfo();
  const StatusIcon = statusInfo.icon;

  return (
    <Card className="content-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Vistorias</CardTitle>
        <FileText className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <StatusIcon className={`h-4 w-4 ${statusInfo.iconColor}`} />
              <Badge className={statusInfo.color}>
                {statusInfo.label}
              </Badge>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-xl font-bold">{inspectionInfo.pending}</p>
              <p className="text-xs text-muted-foreground">Pendentes</p>
            </div>
            <div>
              <p className="text-xl font-bold">{inspectionInfo.completed}</p>
              <p className="text-xs text-muted-foreground">Concluídas</p>
            </div>
          </div>

          {inspectionInfo.nextInspection && (
            <div className="pt-2 border-t">
              <p className="text-sm font-medium">Próxima Vistoria</p>
              <div className="flex items-center gap-2 mt-1">
                <Calendar className="h-3 w-3 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">
                  {inspectionInfo.nextInspection.type} - {new Date(inspectionInfo.nextInspection.date).toLocaleDateString('pt-BR')}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">
                {inspectionInfo.nextInspection.location}
              </p>
            </div>
          )}

          <Button 
            variant="outline" 
            size="sm" 
            className="w-full mt-3"
            onClick={() => navigate('/vistorias-motorista')}
          >
            Ver Vistorias
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
