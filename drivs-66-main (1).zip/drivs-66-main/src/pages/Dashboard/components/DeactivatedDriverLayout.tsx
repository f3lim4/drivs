
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Driver } from "@/types";
import { AlertTriangle, Clock, FileText, Car, Users, Camera, CreditCard, Shield, Handshake } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface DeactivatedDriverLayoutProps {
  driver: Driver;
}

export const DeactivatedDriverLayout = ({ driver }: DeactivatedDriverLayoutProps) => {
  const navigate = useNavigate();

  const contractInfo = driver.activeContract;
  const deactivationInfo = (driver as any).deactivationInfo;

  return (
    <div className="space-y-6">
      {/* Status do Contrato Desativado */}
      <Card className="border-red-200 bg-red-50">
        <CardHeader>
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-6 w-6 text-red-600" />
            <div>
              <CardTitle className="text-red-800">Contrato Desativado</CardTitle>
              <p className="text-sm text-red-600 mt-1">
                Seu contrato com a {deactivationInfo?.rentalCompany} foi encerrado
              </p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Motivo da Desativação:</p>
                <p className="font-medium text-red-700">{deactivationInfo?.reason}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Data da Desativação:</p>
                <p className="font-medium">
                  {deactivationInfo?.deactivatedAt ? 
                    new Date(deactivationInfo.deactivatedAt).toLocaleDateString('pt-BR') : 
                    'Não informado'
                  }
                </p>
              </div>
            </div>
            
            {contractInfo && (
              <div className="mt-4 p-3 bg-white rounded-lg border">
                <p className="text-sm text-muted-foreground mb-2">Informações do Contrato Encerrado:</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Veículo:</span>
                    <p className="font-medium">{contractInfo.vehicleModel}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Período:</span>
                    <p className="font-medium">
                      {new Date(contractInfo.contractStart).toLocaleDateString('pt-BR')} - {' '}
                      {new Date(contractInfo.contractEnd).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Locadora:</span>
                    <p className="font-medium">{contractInfo.companyName}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Acesso aos Históricos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/motoristas/contrato')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <FileText className="h-8 w-8 text-blue-600" />
              <div>
                <h3 className="font-semibold">Contratos</h3>
                <p className="text-sm text-muted-foreground">Histórico de contratos</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/motoristas/meu-veiculo')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Car className="h-8 w-8 text-orange-600" />
              <div>
                <h3 className="font-semibold">Meu Veículo</h3>
                <p className="text-sm text-muted-foreground">Informações do veículo</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/motoristas/vistorias-motorista')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Camera className="h-8 w-8 text-purple-600" />
              <div>
                <h3 className="font-semibold">Vistorias</h3>
                <p className="text-sm text-muted-foreground">Histórico de vistorias</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/motoristas/pagamentos')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CreditCard className="h-8 w-8 text-green-600" />
              <div>
                <h3 className="font-semibold">Pagamentos</h3>
                <p className="text-sm text-muted-foreground">Histórico financeiro</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/motoristas/infracoes')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-red-600" />
              <div>
                <h3 className="font-semibold">Infrações</h3>
                <p className="text-sm text-muted-foreground">Histórico de infrações</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/motoristas/minha-locadora')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Users className="h-8 w-8 text-indigo-600" />
              <div>
                <h3 className="font-semibold">Minha Locadora</h3>
                <p className="text-sm text-muted-foreground">Dados da locadora</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate('/motoristas/negociacoes')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Handshake className="h-8 w-8 text-yellow-600" />
              <div>
                <h3 className="font-semibold">Negociações</h3>
                <p className="text-sm text-muted-foreground">Acordos e negociações</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Informações Importantes */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-blue-800 flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Informações Importantes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <p className="text-blue-700">
              • Você ainda pode acessar o histórico de seus contratos e vistorias
            </p>
            <p className="text-blue-700">
              • Para questões sobre o encerramento do contrato, entre em contato com a locadora
            </p>
            <p className="text-blue-700">
              • Seus dados permanecem disponíveis para consulta conforme necessário
            </p>
            <p className="text-blue-700">
              • Acesse "Negociações" para resolver pendências financeiras
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
