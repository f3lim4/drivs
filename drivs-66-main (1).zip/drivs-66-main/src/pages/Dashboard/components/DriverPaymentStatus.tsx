
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CreditCard, AlertTriangle, Clock, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { PaymentStatus } from "@/types";

interface PaymentInfo {
  status: PaymentStatus;
  amount?: number;
  dueDate?: string;
  nextPayment?: {
    amount: number;
    dueDate: string;
  };
}

interface DriverPaymentStatusProps {
  paymentInfo: PaymentInfo;
}

export const DriverPaymentStatus = ({ paymentInfo }: DriverPaymentStatusProps) => {
  const navigate = useNavigate();

  const getStatusInfo = () => {
    switch (paymentInfo.status) {
      case PaymentStatus.PAID:
        return {
          icon: CheckCircle,
          label: "Em Dia",
          color: "bg-green-100 text-green-800",
          iconColor: "text-green-600"
        };
      case PaymentStatus.OPEN:
        return {
          icon: Clock,
          label: "Pendente",
          color: "bg-yellow-100 text-yellow-800",
          iconColor: "text-yellow-600"
        };
      case PaymentStatus.OVERDUE:
      case PaymentStatus.BLACKLISTED:
        return {
          icon: AlertTriangle,
          label: "Em Atraso",
          color: "bg-red-100 text-red-800",
          iconColor: "text-red-600"
        };
      default:
        return {
          icon: Clock,
          label: "Pendente",
          color: "bg-yellow-100 text-yellow-800",
          iconColor: "text-yellow-600"
        };
    }
  };

  const statusInfo = getStatusInfo();
  const StatusIcon = statusInfo.icon;

  return (
    <Card className="content-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Status de Pagamentos</CardTitle>
        <CreditCard className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <StatusIcon className={`h-4 w-4 ${statusInfo.iconColor}`} />
              <Badge className={statusInfo.color}>
                {statusInfo.label}
              </Badge>
            </div>
          </div>

          {paymentInfo.amount && (
            <div>
              <p className="text-2xl font-bold">R$ {paymentInfo.amount.toFixed(2)}</p>
              {paymentInfo.dueDate && (
                <p className="text-xs text-muted-foreground">
                  Vencimento: {new Date(paymentInfo.dueDate).toLocaleDateString('pt-BR')}
                </p>
              )}
            </div>
          )}

          {paymentInfo.nextPayment && (
            <div className="pt-2 border-t">
              <p className="text-sm font-medium">Próximo Pagamento</p>
              <p className="text-lg font-bold">R$ {paymentInfo.nextPayment.amount.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(paymentInfo.nextPayment.dueDate).toLocaleDateString('pt-BR')}
              </p>
            </div>
          )}

          <Button 
            variant="outline" 
            size="sm" 
            className="w-full mt-3"
            onClick={() => navigate('/pagamentos')}
          >
            Ver Detalhes
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
