
import { Badge } from "@/components/ui/badge";
import { Driver, DriverStatus } from "@/types";
import { LucideIcon } from "lucide-react";

interface StatusInfo {
  label: string;
  color: string;
  icon: LucideIcon;
  description: string;
}

interface DriverStatusHeaderProps {
  driver: Driver;
  statusInfo: StatusInfo;
}

export const DriverStatusHeader = ({ driver, statusInfo }: DriverStatusHeaderProps) => {
  const StatusIcon = statusInfo.icon;

  // Função para obter o nome real do motorista
  const getDriverName = () => {
    // Usar fullName que é a propriedade correta no tipo Driver
    return driver.fullName || 'Motorista';
  };

  return (
    <div className="flex items-center justify-between pt-4">
      <div>
        <h1 className="text-3xl font-bold">Painel do Motorista</h1>
        <p className="text-muted-foreground">
          Bem-vindo, {getDriverName()}! Acompanhe seu status e atividades
        </p>
      </div>
      <Badge className={`${statusInfo.color} text-white px-4 py-2`}>
        <StatusIcon className="w-4 h-4 mr-1" />
        {statusInfo.label}
      </Badge>
    </div>
  );
};
