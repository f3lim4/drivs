
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, CreditCard, AlertTriangle, Clock } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { DriverStatus } from "@/types";

interface Notification {
  id: number;
  type: string;
  message: string;
  time: string;
  isPayment?: boolean;
  amount?: number;
  urgent?: boolean;
}

interface NotificationsCardProps {
  notifications?: Notification[];
}

export const NotificationsCard = ({ notifications: propNotifications }: NotificationsCardProps) => {
  const { user } = useAuth();

  const getNotificationIcon = (type: string, urgent?: boolean) => {
    if (type === "payment") {
      return urgent ? (
        <AlertTriangle className="w-4 h-4 text-red-500" />
      ) : (
        <CreditCard className="w-4 h-4 text-blue-500" />
      );
    }
    return <Bell className="w-4 h-4 text-blue-500" />;
  };

  // Gerar notificações baseadas no status real do motorista
  const generateRealNotifications = (): Notification[] => {
    if (!user) return [];

    const notifications: Notification[] = [];
    const today = new Date();
    
    // Criar data de hoje formatada como string
    const todayFormatted = today.toISOString();

    // Notificações baseadas no status do motorista
    if (user.status === DriverStatus.PENDING) {
      notifications.push({
        id: 1,
        type: "info",
        message: "Complete seu cadastro enviando os documentos necessários.",
        time: todayFormatted,
        urgent: true
      });
      
      notifications.push({
        id: 2,
        type: "info",
        message: "Bem-vindo ao sistema DRIVS! Finalize seu cadastro para começar.",
        time: new Date(today.getTime() - 2 * 60 * 60 * 1000).toISOString(), // 2 horas atrás
        urgent: false
      });
    } else if (user.status === DriverStatus.UNDER_REVIEW) {
      notifications.push({
        id: 1,
        type: "info", 
        message: "Seus documentos estão sendo analisados. Aguarde o resultado em até 2 dias úteis.",
        time: todayFormatted,
        urgent: false
      });
    } else if (user.status === DriverStatus.APPROVED) {
      notifications.push({
        id: 1,
        type: "success",
        message: "Documentação aprovada! Agora você pode visualizar veículos disponíveis.",
        time: todayFormatted,
        urgent: false
      });
    } else if (user.status === DriverStatus.REJECTED) {
      notifications.push({
        id: 1,
        type: "error",
        message: "Documentação rejeitada. Verifique os motivos e reenvie os documentos.",
        time: todayFormatted,
        urgent: true
      });
    }

    return notifications;
  };

  const notifications = propNotifications || generateRealNotifications();

  const formatTime = (timeString: string) => {
    try {
      const date = new Date(timeString);
      return date.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return 'Agora mesmo';
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Notificações Recentes
        </CardTitle>
        <Button variant="ghost" size="sm">
          Ver todas
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {notifications.slice(0, 5).map((notification) => (
            <div key={notification.id} className="flex items-start space-x-4 p-3 rounded-lg hover:bg-gray-50 transition-colors">
              <div className="mt-1">
                {getNotificationIcon(notification.type, notification.urgent)}
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium">{notification.message}</p>
                  {notification.urgent && (
                    <Badge variant="destructive" className="text-xs">
                      Urgente
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <p className="text-xs text-muted-foreground">{formatTime(notification.time)}</p>
                  {notification.isPayment && (
                    <Badge variant="outline" className="text-xs">
                      Pagamento
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          ))}
          {notifications.length === 0 && (
            <div className="text-center py-8">
              <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhuma notificação no momento</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
