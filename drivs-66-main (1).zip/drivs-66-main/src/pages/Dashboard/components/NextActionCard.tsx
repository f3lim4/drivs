import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Car, Upload, FileText, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { UserRole, DriverStatus } from "@/types";

interface NextActionCardProps {
  userRole: string;
  driverStatus?: DriverStatus;
}

export const NextActionCard = ({ userRole, driverStatus }: NextActionCardProps) => {
  const navigate = useNavigate();

  const getNextActions = () => {
    switch (userRole) {
      case "DRIVER":
        // Para motoristas em aberto (pending) - não mostrar ações genéricas
        if (driverStatus === DriverStatus.PENDING) {
          return [
            {
              title: "Enviar Documentos",
              description: "Complete sua documentação para aprovação",
              icon: Upload,
              urgent: true,
              action: () => navigate('/motorista/documentos')
            }
          ];
        }
        // Para motoristas aprovados sem contrato
        if (driverStatus === DriverStatus.APPROVED) {
          return [
            {
              title: "Reservar Veículo",
              description: "Escolha um veículo para começar a dirigir",
              icon: Car,
              urgent: true,
              action: () => navigate('/motoristas/ver-veiculos')
            }
          ];
        }
        // Para outros status - não mostrar ações
        return [];
      case "RENTAL_COMPANY":
        return [
          {
            title: "Revisar Contratos",
            description: "3 contratos aguardando aprovação",
            icon: FileText,
            urgent: true,
            action: () => navigate('/contratos')
          },
          {
            title: "Verificar Alertas",
            description: "2 alertas de manutenção",
            icon: AlertTriangle,
            urgent: false,
            action: () => navigate('/manutencao')
          }
        ];
      default:
        return [];
    }
  };

  const actions = getNextActions();

  // Se não há ações, não renderizar o card
  if (actions.length === 0) {
    return null;
  }

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Próximas Ações</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${action.urgent ? 'bg-red-100 text-red-600 dark:bg-red-900 dark:text-red-300' : 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300'}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-gray-100">{action.title}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{action.description}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={action.action}>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};
