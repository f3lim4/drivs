
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { FinancialSummaryCards } from "./components/FinancialSummaryCards";
import { VehiclesTab } from "./components/VehiclesTab";
import { ExpensesTab } from "./components/ExpensesTab";
import { TrendsTab } from "./components/TrendsTab";
import { DriverProfitabilityTab } from "./components/DriverProfitabilityTab";
import { MoreHorizontal, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  mockFinancialSummary, 
  mockVehicleFinancials, 
  mockExpenseCategories, 
  mockMonthlyData, 
  mockAlertsData 
} from "./data/mockFinancialData";

const FinancialPage = () => {
  const [selectedPeriod, setSelectedPeriod] = useState("monthly");
  const [alertsEnabled, setAlertsEnabled] = useState(true);
  const [resolvedAlerts, setResolvedAlerts] = useState<string[]>([]);
  const { toast } = useToast();

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleGenerateReport = () => {
    const reportData = {
      period: selectedPeriod,
      totalRevenue: mockFinancialSummary.totalRevenue,
      totalExpenses: mockFinancialSummary.totalExpenses,
      netProfit: mockFinancialSummary.netProfit,
      vehicles: mockVehicleFinancials.length,
      generatedAt: new Date().toISOString()
    };
    
    console.log('Generating financial report:', reportData);
    
    toast({
      title: "Relatório Gerado com Sucesso",
      description: `Relatório financeiro ${selectedPeriod} gerado. Dados: ${mockVehicleFinancials.length} veículos, Lucro: ${formatCurrency(mockFinancialSummary.netProfit)}`,
    });

    setTimeout(() => {
      toast({
        title: "Relatório Pronto",
        description: "O relatório está pronto para download.",
      });
    }, 2000);
  };

  const handleAddExpense = () => {
    const newExpenseData = {
      category: "Nova Despesa",
      amount: 0,
      date: new Date().toISOString(),
      description: "Despesa adicionada via sistema financeiro"
    };
    
    console.log('Adding new expense:', newExpenseData);
    
    toast({
      title: "Adicionar Nova Despesa",
      description: "Redirecionando para o formulário de despesas...",
    });

    setTimeout(() => {
      toast({
        title: "Formulário Aberto",
        description: "Preencha os dados da nova despesa.",
      });
    }, 1500);
  };

  const handleConfigureAlerts = () => {
    const newAlertStatus = !alertsEnabled;
    setAlertsEnabled(newAlertStatus);
    
    const alertConfig = {
      enabled: newAlertStatus,
      types: ['profit_margin', 'vehicle_loss', 'expense_threshold'],
      configuredAt: new Date().toISOString()
    };
    
    console.log('Alert configuration updated:', alertConfig);
    
    toast({
      title: newAlertStatus ? "Alertas Ativados" : "Alertas Desativados",
      description: `Sistema de alertas financeiros foi ${newAlertStatus ? 'ativado' : 'desativado'}. Configuração salva.`,
    });
  };

  const handleDownloadReport = () => {
    const reportContent = {
      title: "Relatório Financeiro - Últimos 6 Meses",
      data: mockMonthlyData,
      summary: mockFinancialSummary,
      vehicles: mockVehicleFinancials,
      expenses: mockExpenseCategories,
      generatedAt: new Date().toISOString()
    };
    
    console.log('Downloading report:', reportContent);
    
    const blob = new Blob([JSON.stringify(reportContent, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `relatorio-financeiro-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download Iniciado",
      description: "Relatório financeiro está sendo baixado...",
    });
  };

  const handleResolveAlert = (alertType: string) => {
    if (!resolvedAlerts.includes(alertType)) {
      setResolvedAlerts([...resolvedAlerts, alertType]);
      
      const resolutionData = {
        alertType,
        resolvedAt: new Date().toISOString(),
        resolvedBy: 'current_user',
        action: 'manual_resolution'
      };
      
      console.log('Alert resolved:', resolutionData);
      
      toast({
        title: "Alerta Resolvido",
        description: `Alerta "${alertType}" foi marcado como resolvido e arquivado.`,
      });

      if (alertType === "Veículo em Prejuízo") {
        setTimeout(() => {
          toast({
            title: "Ação Sugerida",
            description: "Recomendamos revisar os custos do veículo Nissan Sentra.",
          });
        }, 2000);
      }
    }
  };

  return (
    <div className="page-content px-2 md:px-4 py-3 md:py-6">
      <div className="space-y-4 md:space-y-6">
        <div className="page-header">
          <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-3">
            <div>
              <h1 className="text-xl md:text-3xl font-bold text-gray-900 mb-1 md:mb-2">
                RELATÓRIOS FINANCEIROS
              </h1>
              <p className="page-subtitle text-sm md:text-base text-gray-600">
                Análise completa da performance financeira da sua locadora
              </p>
            </div>
            
            {/* Mobile: Actions dropdown */}
            <div className="md:hidden">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Ações
                    <MoreHorizontal className="h-4 w-4 ml-2" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-background border">
                  <DropdownMenuItem onClick={handleGenerateReport}>
                    Gerar Relatório
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleAddExpense}>
                    Nova Despesa
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleConfigureAlerts}>
                    Configurar Alertas
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleDownloadReport}>
                    Download Relatório
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>

        <FinancialSummaryCards summary={mockFinancialSummary} />

        <Tabs defaultValue="vehicles" className="space-y-4">
          {/* Mobile: Scrollable tabs */}
          <div className="md:hidden">
            <TabsList className="grid w-full grid-cols-2 h-auto">
              <TabsTrigger value="vehicles" className="text-xs p-2">Veículos</TabsTrigger>
              <TabsTrigger value="trends" className="text-xs p-2">Tendências</TabsTrigger>
            </TabsList>
            
            {/* Mobile: Dropdown for additional tabs */}
            <div className="mt-3">
              <select 
                onChange={(e) => {
                  // This would need to be handled by the Tabs component
                  console.log('Selected tab:', e.target.value);
                }}
                className="w-full p-2 border rounded-lg bg-background text-sm"
              >
                <option value="drivers">Análise por Motorista</option>
                <option value="expenses">Despesas por Categoria</option>
              </select>
            </div>
          </div>

          {/* Desktop: Full tabs */}
          <div className="hidden md:block">
            <TabsList>
              <TabsTrigger value="vehicles">Análise por Veículo</TabsTrigger>
              <TabsTrigger value="drivers">Análise por Motorista</TabsTrigger>
              <TabsTrigger value="expenses">Despesas por Categoria</TabsTrigger>
              <TabsTrigger value="trends">Tendências</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="vehicles">
            <VehiclesTab vehicleFinancials={mockVehicleFinancials} />
          </TabsContent>

          <TabsContent value="drivers">
            <DriverProfitabilityTab />
          </TabsContent>

          <TabsContent value="expenses">
            <ExpensesTab expenseCategories={mockExpenseCategories} />
          </TabsContent>

          <TabsContent value="trends">
            <TrendsTab 
              monthlyData={mockMonthlyData}
              alertsData={mockAlertsData}
              alertsEnabled={alertsEnabled}
              resolvedAlerts={resolvedAlerts}
              onGenerateReport={handleGenerateReport}
              onAddExpense={handleAddExpense}
              onConfigureAlerts={handleConfigureAlerts}
              onDownloadReport={handleDownloadReport}
              onResolveAlert={handleResolveAlert}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default FinancialPage;
