
export const mockVehicleFinancials = [];

export const mockFinancialSummary = {
  totalRevenue: 0,
  totalExpenses: 0,
  netProfit: 0,
  profitMargin: 0
};

export const getExpenseCategories = () => {
  return [];
};

export const mockExpenseCategories = [];

export const mockMonthlyData = [];

export const mockAlertsData = [];
