
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  User, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Calendar,
  Eye,
  Wrench,
  Shield,
  Car
} from "lucide-react";
import { DriverProfitabilityModal } from "./DriverProfitabilityModal";

interface DriverProfitability {
  id: string;
  name: string;
  currentVehicle: string;
  contractStart: string;
  contractEnd?: string;
  contractStatus: "ativo" | "encerrado" | "suspenso";
  totalRevenue: number;
  totalExpenses: number;
  maintenanceCosts: number;
  profit: number;
  profitMargin: number;
  contractDuration: number; // meses
  averageMonthlyProfit: number;
}

export const DriverProfitabilityTab = () => {
  const [selectedDriver, setSelectedDriver] = useState<DriverProfitability | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Dados mock dos motoristas
  const driversData: DriverProfitability[] = [
    {
      id: "1",
      name: "João Silva",
      currentVehicle: "Honda Civic - ABC-1234",
      contractStart: "2024-01-15",
      contractStatus: "ativo",
      totalRevenue: 21000.00,
      totalExpenses: 12600.00,
      maintenanceCosts: 2100.00,
      profit: 8400.00,
      profitMargin: 40.0,
      contractDuration: 6,
      averageMonthlyProfit: 1400.00
    },
    {
      id: "2", 
      name: "Maria Santos",
      currentVehicle: "Toyota Corolla - XYZ-5678",
      contractStart: "2024-03-01",
      contractStatus: "ativo",
      totalRevenue: 12800.00,
      totalExpenses: 9600.00,
      maintenanceCosts: 1800.00,
      profit: 3200.00,
      profitMargin: 25.0,
      contractDuration: 4,
      averageMonthlyProfit: 800.00
    },
    {
      id: "3",
      name: "Carlos Lima", 
      currentVehicle: "Nissan Sentra - DEF-9012",
      contractStart: "2023-11-10",
      contractEnd: "2024-05-10",
      contractStatus: "encerrado",
      totalRevenue: 16800.00,
      totalExpenses: 18600.00,
      maintenanceCosts: 3200.00,
      profit: -1800.00,
      profitMargin: -10.7,
      contractDuration: 6,
      averageMonthlyProfit: -300.00
    },
    {
      id: "4",
      name: "Ana Costa",
      currentVehicle: "Hyundai HB20 - GHI-3456",
      contractStart: "2024-02-20",
      contractStatus: "ativo",
      totalRevenue: 15400.00,
      totalExpenses: 11200.00,
      maintenanceCosts: 1400.00,
      profit: 4200.00,
      profitMargin: 27.3,
      contractDuration: 5,
      averageMonthlyProfit: 840.00
    }
  ];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ativo":
        return "bg-green-100 text-green-800";
      case "encerrado":
        return "bg-gray-100 text-gray-800";
      case "suspenso":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getProfitColor = (profit: number) => {
    if (profit > 0) return "text-green-600";
    if (profit < 0) return "text-red-600";
    return "text-gray-600";
  };

  const handleViewDriverDetails = (driver: DriverProfitability) => {
    setSelectedDriver(driver);
    setIsModalOpen(true);
  };

  // Calcular estatísticas gerais
  const activeDrivers = driversData.filter(d => d.contractStatus === "ativo");
  const totalActiveRevenue = activeDrivers.reduce((sum, d) => sum + d.totalRevenue, 0);
  const totalActiveProfit = activeDrivers.reduce((sum, d) => sum + d.profit, 0);
  const averageProfitMargin = activeDrivers.length > 0 
    ? activeDrivers.reduce((sum, d) => sum + d.profitMargin, 0) / activeDrivers.length 
    : 0;

  return (
    <div className="space-y-6">
      {/* Resumo Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Motoristas Ativos
            </CardTitle>
            <User className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-blue-600">
              {activeDrivers.length}
            </div>
            <p className="text-xs text-muted-foreground">
              de {driversData.length} total
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Receita Total Ativa
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-green-600">
              {formatCurrency(totalActiveRevenue)}
            </div>
            <p className="text-xs text-muted-foreground">
              Contratos ativos
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Lucro Total Ativo
            </CardTitle>
            <DollarSign className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-lg font-bold ${getProfitColor(totalActiveProfit)}`}>
              {formatCurrency(totalActiveProfit)}
            </div>
            <p className="text-xs text-muted-foreground">
              Contratos ativos
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Margem Média
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-orange-600">
              {averageProfitMargin.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              Motoristas ativos
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabela de Motoristas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Análise de Lucratividade por Motorista
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Motorista</TableHead>
                <TableHead>Veículo Atual</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Receita Total</TableHead>
                <TableHead className="text-right">Despesas</TableHead>
                <TableHead className="text-right">Lucro Total</TableHead>
                <TableHead className="text-right">Margem</TableHead>
                <TableHead className="text-right">Lucro/Mês</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {driversData.map((driver) => (
                <TableRow key={driver.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{driver.name}</p>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {driver.contractDuration} meses
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Car className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{driver.currentVehicle}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(driver.contractStatus)}>
                      {driver.contractStatus}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-medium text-green-600">
                    {formatCurrency(driver.totalRevenue)}
                  </TableCell>
                  <TableCell className="text-right font-medium text-red-600">
                    {formatCurrency(driver.totalExpenses)}
                  </TableCell>
                  <TableCell className={`text-right font-bold ${getProfitColor(driver.profit)}`}>
                    {formatCurrency(driver.profit)}
                  </TableCell>
                  <TableCell className={`text-right font-medium ${getProfitColor(driver.profit)}`}>
                    {driver.profitMargin.toFixed(1)}%
                  </TableCell>
                  <TableCell className={`text-right font-medium ${getProfitColor(driver.averageMonthlyProfit)}`}>
                    {formatCurrency(driver.averageMonthlyProfit)}
                  </TableCell>
                  <TableCell>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleViewDriverDetails(driver)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Modal de Detalhes do Motorista */}
      <DriverProfitabilityModal
        driver={selectedDriver}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedDriver(null);
        }}
      />
    </div>
  );
};
