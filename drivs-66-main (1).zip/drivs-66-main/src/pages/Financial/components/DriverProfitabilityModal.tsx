
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  User, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Wrench,
  Shield,
  Calendar,
  Car,
  Download,
  AlertCircle,
  CheckCircle,
  FileText
} from "lucide-react";

interface DriverData {
  id: string;
  name: string;
  currentVehicle: string;
  contractStart: string;
  contractEnd?: string;
  contractStatus: "ativo" | "encerrado" | "suspenso";
  totalRevenue: number;
  totalExpenses: number;
  maintenanceCosts: number;
  profit: number;
  profitMargin: number;
  contractDuration: number;
  averageMonthlyProfit: number;
}

interface DriverProfitabilityModalProps {
  driver: DriverData | null;
  isOpen: boolean;
  onClose: () => void;
}

export const DriverProfitabilityModal = ({ driver, isOpen, onClose }: DriverProfitabilityModalProps) => {
  if (!driver) return null;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const getProfitColor = (profit: number) => {
    if (profit > 0) return "text-green-600";
    if (profit < 0) return "text-red-600";
    return "text-gray-600";
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ativo":
        return "bg-green-100 text-green-800";
      case "encerrado":
        return "bg-gray-100 text-gray-800";
      case "suspenso":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  // Dados detalhados de histórico (mock)
  const paymentHistory = [
    { month: "Jun/24", revenue: 3500, expenses: 2100, maintenance: 350, profit: 1400 },
    { month: "Mai/24", revenue: 3400, expenses: 2050, maintenance: 450, profit: 1350 },
    { month: "Abr/24", revenue: 3300, expenses: 2200, maintenance: 300, profit: 1100 },
    { month: "Mar/24", revenue: 3600, expenses: 2000, maintenance: 400, profit: 1600 },
    { month: "Fev/24", revenue: 3500, expenses: 2100, maintenance: 350, profit: 1400 },
    { month: "Jan/24", revenue: 3200, expenses: 2150, maintenance: 250, profit: 1050 }
  ];

  const maintenanceHistory = [
    {
      date: "2024-06-10",
      description: "Troca de óleo e filtros",
      cost: 180.00,
      status: "concluída"
    },
    {
      date: "2024-05-15", 
      description: "Alinhamento e balanceamento",
      cost: 120.00,
      status: "concluída"
    },
    {
      date: "2024-04-20",
      description: "Troca de pastilhas de freio",
      cost: 350.00,
      status: "concluída"
    },
    {
      date: "2024-03-25",
      description: "Revisão geral",
      cost: 450.00,
      status: "concluída"
    }
  ];

  const contractInfo = {
    weeklyPayment: 500.00,
    depositValue: 2000.00,
    insuranceValue: 280.00,
    trackerValue: 40.00,
    totalWeeklyPayments: paymentHistory.length * 500,
    missedPayments: 0,
    onTimePayments: paymentHistory.length
  };

  const handleDownloadReport = () => {
    const reportData = {
      driver: {
        name: driver.name,
        vehicle: driver.currentVehicle,
        contractStatus: driver.contractStatus
      },
      contract: {
        start: driver.contractStart,
        end: driver.contractEnd,
        duration: driver.contractDuration
      },
      financial: {
        totalRevenue: driver.totalRevenue,
        totalExpenses: driver.totalExpenses,
        profit: driver.profit,
        profitMargin: driver.profitMargin,
        averageMonthlyProfit: driver.averageMonthlyProfit
      },
      paymentHistory,
      maintenanceHistory,
      contractInfo,
      generatedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `relatorio-motorista-${driver.name.replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Análise Detalhada - {driver.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Informações do Contrato */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Informações do Contrato</span>
                <Badge className={getStatusColor(driver.contractStatus)}>
                  {driver.contractStatus}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-2">
                  <Car className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Veículo</p>
                    <p className="font-medium">{driver.currentVehicle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Início</p>
                    <p className="font-medium">{formatDate(driver.contractStart)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Duração</p>
                    <p className="font-medium">{driver.contractDuration} meses</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Pagamento Semanal</p>
                    <p className="font-medium">{formatCurrency(contractInfo.weeklyPayment)}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Resumo Financeiro */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-l-4 border-l-green-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Receita Total
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-green-600">
                  {formatCurrency(driver.totalRevenue)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(driver.totalRevenue / driver.contractDuration)}/mês
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-red-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <TrendingDown className="h-4 w-4" />
                  Despesas Totais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-red-600">
                  {formatCurrency(driver.totalExpenses)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(driver.totalExpenses / driver.contractDuration)}/mês
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Lucro Total
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-lg font-bold ${getProfitColor(driver.profit)}`}>
                  {formatCurrency(driver.profit)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(driver.averageMonthlyProfit)}/mês
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Margem de Lucro
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-lg font-bold ${getProfitColor(driver.profit)}`}>
                  {driver.profitMargin.toFixed(1)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Média do período
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Histórico de Pagamentos */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Histórico Mensal de Pagamentos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {paymentHistory.map((payment, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{payment.month}</span>
                    </div>
                    <div className="flex gap-6 text-sm">
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Receita</p>
                        <p className="font-medium text-green-600">{formatCurrency(payment.revenue)}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Despesas</p>
                        <p className="font-medium text-red-600">{formatCurrency(payment.expenses)}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Manutenção</p>
                        <p className="font-medium text-orange-600">{formatCurrency(payment.maintenance)}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-muted-foreground">Lucro</p>
                        <p className={`font-medium ${getProfitColor(payment.profit)}`}>
                          {formatCurrency(payment.profit)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Histórico de Manutenção */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wrench className="h-5 w-5" />
                Histórico de Manutenção
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {maintenanceHistory.map((maintenance, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <div>
                        <p className="font-medium">{maintenance.description}</p>
                        <p className="text-sm text-muted-foreground">{formatDate(maintenance.date)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-red-600">{formatCurrency(maintenance.cost)}</p>
                      <Badge variant="secondary" className="text-xs">
                        {maintenance.status}
                      </Badge>
                    </div>
                  </div>
                ))}
                <div className="pt-3 border-t">
                  <div className="flex justify-between">
                    <span className="font-medium">Total em Manutenção:</span>
                    <span className="font-bold text-lg text-red-600">
                      {formatCurrency(driver.maintenanceCosts)}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Performance e Pontualidade */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  Performance de Pagamentos
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Pagamentos em dia:</span>
                  <span className="font-bold text-green-600">{contractInfo.onTimePayments}</span>
                </div>
                <div className="flex justify-between">
                  <span>Pagamentos em atraso:</span>
                  <span className="font-bold text-red-600">{contractInfo.missedPayments}</span>
                </div>
                <div className="flex justify-between">
                  <span>Taxa de pontualidade:</span>
                  <span className="font-bold text-green-600">100%</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  Recomendações
                </CardTitle>
              </CardHeader>
              <CardContent>
                {driver.profitMargin > 30 ? (
                  <div className="p-3 bg-green-50 border-l-4 border-green-500 rounded">
                    <p className="text-green-800 font-medium">Motorista Excelente</p>
                    <p className="text-green-700 text-sm">Alta lucratividade e boa performance.</p>
                  </div>
                ) : driver.profitMargin > 15 ? (
                  <div className="p-3 bg-yellow-50 border-l-4 border-yellow-500 rounded">
                    <p className="text-yellow-800 font-medium">Performance Regular</p>
                    <p className="text-yellow-700 text-sm">Considerar otimização de custos.</p>
                  </div>
                ) : (
                  <div className="p-3 bg-red-50 border-l-4 border-red-500 rounded">
                    <p className="text-red-800 font-medium">Atenção Necessária</p>
                    <p className="text-red-700 text-sm">Revisar estratégia operacional urgentemente.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Separator />

          {/* Botões de Ação */}
          <div className="flex justify-between">
            <Button variant="outline" onClick={onClose}>
              Fechar
            </Button>
            <Button onClick={handleDownloadReport}>
              <Download className="h-4 w-4 mr-2" />
              Baixar Relatório Completo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
