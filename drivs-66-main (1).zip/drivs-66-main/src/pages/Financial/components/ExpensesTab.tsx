
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, MapPin, Settings, FileText, DollarSign, Wrench } from "lucide-react";
import { getExpenseCategories } from "../data/mockFinancialData";

interface ExpenseCategory {
  category: string;
  amount: number;
  percentage: number;
  color: string;
}

interface ExpensesTabProps {
  expenseCategories: ExpenseCategory[];
}

export const ExpensesTab = ({ expenseCategories }: ExpensesTabProps) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Usar despesas dinâmicas que incluem as cadastradas
  const dynamicExpenses = getExpenseCategories();

  const getIcon = (category: string) => {
    switch (category) {
      case "Seguro":
        return Shield;
      case "Rastreador":
        return MapPin;
      case "Manutenção":
        return Settings;
      case "IPVA":
        return FileText;
      case "Documentação":
        return FileText;
      case "Guincho":
        return Wrench;
      default:
        return DollarSign;
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Despesas por Categoria</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {dynamicExpenses.map((expense, index) => {
            const IconComponent = getIcon(expense.category);
            return (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className={`w-4 h-4 rounded ${expense.color}`}></div>
                  <div className="flex items-center gap-2">
                    <IconComponent className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{expense.category}</p>
                      <p className="text-sm text-muted-foreground">{expense.percentage.toFixed(1)}% do total</p>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg">{formatCurrency(expense.amount)}</p>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Seguros
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatCurrency(8500)}</p>
            <p className="text-sm text-muted-foreground">15 veículos segurados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Rastreamento
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatCurrency(2400)}</p>
            <p className="text-sm text-muted-foreground">15 dispositivos ativos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Manutenção
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatCurrency(6500)}</p>
            <p className="text-sm text-muted-foreground">23 serviços realizados</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
