import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Car, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Wrench,
  Shield,
  Calendar,
  User,
  MapPin,
  Download
} from "lucide-react";
import { mockPayments } from "../../Payments/data/paymentsData";

interface VehicleData {
  id: string;
  plate: string;
  model: string;
  driver: string;
  monthlyRevenue: number;
  monthlyExpenses: number;
  profit: number;
  profitMargin: number;
  status: string;
}

interface VehicleFinancialModalProps {
  vehicle: VehicleData | null;
  isOpen: boolean;
  onClose: () => void;
}

export const VehicleFinancialModal = ({ vehicle, isOpen, onClose }: VehicleFinancialModalProps) => {
  if (!vehicle) return null;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Buscar pagamentos semanais relacionados ao veículo/motorista
  const vehiclePayments = mockPayments.filter(payment => 
    payment.driverName === vehicle.driver && 
    payment.type === 'weekly_rental' &&
    payment.status === 'paid'
  );

  // Calcular total de pagamentos semanais recebidos
  const totalWeeklyPayments = vehiclePayments.reduce((sum, payment) => sum + payment.amount, 0);
  
  // Calcular 35% dos pagamentos semanais para combustível
  const fuelFromWeeklyPayments = totalWeeklyPayments * 0.35;

  // Dados detalhados calculados
  const detailedExpenses = {
    maintenance: vehicle.monthlyExpenses * 0.35,
    insurance: vehicle.monthlyExpenses * 0.30,
    financing: vehicle.monthlyExpenses * 0.25,
    others: vehicle.monthlyExpenses * 0.10
  };

  // Resumo Financeiro
  const monthlyData = [
    { month: "Jan", revenue: vehicle.monthlyRevenue * 0.9, expenses: vehicle.monthlyExpenses * 0.95 },
    { month: "Fev", revenue: vehicle.monthlyRevenue * 0.95, expenses: vehicle.monthlyExpenses * 0.98 },
    { month: "Mar", revenue: vehicle.monthlyRevenue, expenses: vehicle.monthlyExpenses },
    { month: "Abr", revenue: vehicle.monthlyRevenue * 1.05, expenses: vehicle.monthlyExpenses * 1.02 },
    { month: "Mai", revenue: vehicle.monthlyRevenue * 1.1, expenses: vehicle.monthlyExpenses * 1.05 },
    { month: "Jun", revenue: vehicle.monthlyRevenue * 1.08, expenses: vehicle.monthlyExpenses * 1.03 }
  ];

  const performance = {
    efficiency: vehicle.profitMargin > 30 ? 'Alta' : vehicle.profitMargin > 15 ? 'Média' : 'Baixa',
    recommendation: vehicle.profitMargin < 0 ? 'Rever estratégia operacional' : 
                   vehicle.profitMargin < 15 ? 'Otimizar custos' : 'Manter operação atual',
    riskLevel: vehicle.profitMargin < 0 ? 'Alto' : vehicle.profitMargin < 15 ? 'Médio' : 'Baixo'
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Lucrativo":
        return "bg-green-100 text-green-800";
      case "Prejuízo":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleDownloadReport = () => {
    const reportData = {
      vehicle: {
        plate: vehicle.plate,
        model: vehicle.model,
        driver: vehicle.driver
      },
      financial: {
        monthlyRevenue: vehicle.monthlyRevenue,
        monthlyExpenses: vehicle.monthlyExpenses,
        profit: vehicle.profit,
        profitMargin: vehicle.profitMargin
      },
      detailedExpenses,
      weeklyPayments: {
        total: totalWeeklyPayments,
        fuelPortion: fuelFromWeeklyPayments,
        payments: vehiclePayments
      },
      monthlyData,
      performance,
      generatedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `relatorio-${vehicle.plate}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Car className="h-5 w-5" />
            Análise Financeira Detalhada - {vehicle.plate}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Informações Básicas */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Informações do Veículo</span>
                <Badge className={getStatusColor(vehicle.status)}>
                  {vehicle.status}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <Car className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Modelo</p>
                    <p className="font-medium">{vehicle.model}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Motorista</p>
                    <p className="font-medium">{vehicle.driver}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Placa</p>
                    <p className="font-medium">{vehicle.plate}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Resumo Financeiro */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-l-4 border-l-green-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Receita Mensal
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-green-600">
                  {formatCurrency(vehicle.monthlyRevenue)}
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-red-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <TrendingDown className="h-4 w-4" />
                  Despesas Mensais
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-red-600">
                  {formatCurrency(vehicle.monthlyExpenses)}
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Lucro Líquido
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-lg font-bold ${vehicle.profit >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                  {formatCurrency(vehicle.profit)}
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Margem de Lucro
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-lg font-bold ${vehicle.profitMargin >= 0 ? 'text-purple-600' : 'text-red-600'}`}>
                  {vehicle.profitMargin.toFixed(1)}%
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detalhamento de Despesas */}
          <Card>
            <CardHeader>
              <CardTitle>Detalhamento de Despesas Mensais</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Wrench className="h-5 w-5 text-blue-500" />
                    <div>
                      <p className="font-medium">Manutenção</p>
                      <p className="text-sm text-muted-foreground">35% das despesas</p>
                    </div>
                  </div>
                  <p className="font-bold text-lg">{formatCurrency(detailedExpenses.maintenance)}</p>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Shield className="h-5 w-5 text-green-500" />
                    <div>
                      <p className="font-medium">Seguro</p>
                      <p className="text-sm text-muted-foreground">30% das despesas</p>
                    </div>
                  </div>
                  <p className="font-bold text-lg">{formatCurrency(detailedExpenses.insurance)}</p>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <DollarSign className="h-5 w-5 text-purple-500" />
                    <div>
                      <p className="font-medium">Financiamento</p>
                      <p className="text-sm text-muted-foreground">25% das despesas</p>
                    </div>
                  </div>
                  <p className="font-bold text-lg">{formatCurrency(detailedExpenses.financing)}</p>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Calendar className="h-5 w-5 text-gray-500" />
                    <div>
                      <p className="font-medium">Outros</p>
                      <p className="text-sm text-muted-foreground">10% das despesas</p>
                    </div>
                  </div>
                  <p className="font-bold text-lg">{formatCurrency(detailedExpenses.others)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Evolução Mensal */}
          <Card>
            <CardHeader>
              <CardTitle>Evolução Financeira - Últimos 6 Meses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {monthlyData.map((data, index) => {
                  const monthProfit = data.revenue - data.expenses;
                  return (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{data.month}</span>
                      </div>
                      <div className="flex gap-6">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Receita</p>
                          <p className="font-medium text-green-600">{formatCurrency(data.revenue)}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Despesas</p>
                          <p className="font-medium text-red-600">{formatCurrency(data.expenses)}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground">Lucro</p>
                          <p className={`font-medium ${monthProfit >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                            {formatCurrency(monthProfit)}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Análise de Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Análise de Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <p className="text-sm text-muted-foreground">Eficiência</p>
                  <p className={`font-bold text-lg ${
                    performance.efficiency === 'Alta' ? 'text-green-600' : 
                    performance.efficiency === 'Média' ? 'text-yellow-600' : 'text-red-600'
                  }`}>
                    {performance.efficiency}
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <p className="text-sm text-muted-foreground">Nível de Risco</p>
                  <p className={`font-bold text-lg ${
                    performance.riskLevel === 'Baixo' ? 'text-green-600' : 
                    performance.riskLevel === 'Médio' ? 'text-yellow-600' : 'text-red-600'
                  }`}>
                    {performance.riskLevel}
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <p className="text-sm text-muted-foreground">Recomendação</p>
                  <p className="font-medium text-sm">{performance.recommendation}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Botões de Ação */}
          <div className="flex justify-between">
            <Button variant="outline" onClick={onClose}>
              Fechar
            </Button>
            <Button onClick={handleDownloadReport}>
              <Download className="h-4 w-4 mr-2" />
              Baixar Relatório Detalhado
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
