
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Car, Eye } from "lucide-react";
import { VehicleFinancialModal } from "./VehicleFinancialModal";

interface VehicleFinancial {
  id: string;
  plate: string;
  model: string;
  driver: string;
  monthlyRevenue: number;
  monthlyExpenses: number;
  annualRevenue: number;
  annualExpenses: number;
  profit: number;
  profitMargin: number;
  status: string;
}

interface VehiclesTabProps {
  vehicleFinancials: VehicleFinancial[];
}

export const VehiclesTab = ({ vehicleFinancials }: VehiclesTabProps) => {
  const [selectedVehicle, setSelectedVehicle] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Lucrativo":
        return "bg-green-100 text-green-800";
      case "Prejuízo":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleViewVehicleDetails = (vehicleId: string) => {
    const vehicle = vehicleFinancials.find(v => v.plate === vehicleId);
    if (vehicle) {
      setSelectedVehicle(vehicle);
      setIsModalOpen(true);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Car className="h-5 w-5" />
            Análise Financeira por Veículo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Veículo</TableHead>
                <TableHead className="text-right">Receita Mensal</TableHead>
                <TableHead className="text-right">Despesas Mensais</TableHead>
                <TableHead className="text-right">Receita Anual</TableHead>
                <TableHead className="text-right">Despesas Anuais</TableHead>
                <TableHead className="text-right">Lucro</TableHead>
                <TableHead className="text-right">Margem</TableHead>
                <TableHead>Status</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vehicleFinancials.map((vehicle) => (
                <TableRow key={vehicle.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{vehicle.plate}</p>
                      <p className="text-sm text-muted-foreground">{vehicle.model}</p>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-medium text-green-600">
                    {formatCurrency(vehicle.monthlyRevenue)}
                  </TableCell>
                  <TableCell className="text-right font-medium text-red-600">
                    {formatCurrency(vehicle.monthlyExpenses)}
                  </TableCell>
                  <TableCell className="text-right font-medium text-green-600">
                    {formatCurrency(vehicle.annualRevenue)}
                  </TableCell>
                  <TableCell className="text-right font-medium text-red-600">
                    {formatCurrency(vehicle.annualExpenses)}
                  </TableCell>
                  <TableCell className={`text-right font-bold ${
                    vehicle.profit >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {formatCurrency(vehicle.profit)}
                  </TableCell>
                  <TableCell className={`text-right font-medium ${
                    vehicle.profitMargin >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {vehicle.profitMargin}%
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(vehicle.status)}>
                      {vehicle.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleViewVehicleDetails(vehicle.plate)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <VehicleFinancialModal 
        vehicle={selectedVehicle}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedVehicle(null);
        }}
      />
    </div>
  );
};
