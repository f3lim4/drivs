
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Calendar,
  Download,
  FileText,
  Plus,
  Bell,
  Check,
  AlertCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MonthlyData {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
}

interface AlertData {
  id: string;
  type: string;
  message: string;
  severity: string;
  color: string;
}

interface TrendsTabProps {
  monthlyData: MonthlyData[];
  alertsData: AlertData[];
  alertsEnabled: boolean;
  resolvedAlerts: string[];
  onGenerateReport: () => void;
  onAddExpense: () => void;
  onConfigureAlerts: () => void;
  onDownloadReport: () => void;
  onResolveAlert: (alertType: string) => void;
}

export const TrendsTab = ({ 
  monthlyData, 
  alertsData, 
  alertsEnabled, 
  resolvedAlerts,
  onGenerateReport,
  onAddExpense,
  onConfigureAlerts,
  onDownloadReport,
  onResolveAlert
}: TrendsTabProps) => {
  const { toast } = useToast();

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Evolução Financeira - Últimos 6 Meses</CardTitle>
          <Button variant="outline" size="sm" onClick={onDownloadReport}>
            <Download className="h-4 w-4 mr-2" />
            Baixar Relatório
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {monthlyData.map((data, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <Calendar className="h-5 w-5 text-muted-foreground" />
                  <span className="font-medium">{data.month}</span>
                </div>
                <div className="flex gap-8">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Receita</p>
                    <p className="font-bold text-green-600">{formatCurrency(data.revenue)}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Despesas</p>
                    <p className="font-bold text-red-600">{formatCurrency(data.expenses)}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Lucro</p>
                    <p className="font-bold text-blue-600">{formatCurrency(data.profit)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              Alertas Financeiros
              <Badge variant={alertsEnabled ? "default" : "secondary"} className="ml-2">
                {alertsEnabled ? "Ativo" : "Inativo"}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {alertsData.map((alert) => (
              !resolvedAlerts.includes(alert.type) && (
                <div key={alert.id} className={`p-3 bg-${alert.color}-50 border-l-4 border-${alert.color}-500 rounded`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <p className={`font-medium text-${alert.color}-800`}>{alert.type}</p>
                      <p className={`text-sm text-${alert.color}-700`}>{alert.message}</p>
                    </div>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => onResolveAlert(alert.type)}
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )
            ))}
            {resolvedAlerts.length === alertsData.length && (
              <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded">
                <p className="text-green-800 font-medium">Todos os alertas foram resolvidos!</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ações Recomendadas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={onGenerateReport}
            >
              <FileText className="h-4 w-4 mr-2" />
              Gerar Relatório Mensal
            </Button>
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={onAddExpense}
            >
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Nova Despesa
            </Button>
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={onConfigureAlerts}
            >
              <Bell className="h-4 w-4 mr-2" />
              {alertsEnabled ? 'Desativar' : 'Ativar'} Alertas
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
