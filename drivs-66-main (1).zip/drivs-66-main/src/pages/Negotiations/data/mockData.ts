import { Negotiation } from "../types";

export const mockNegotiations: Negotiation[] = [
  {
    id: "1",
    driverId: "driver1",
    driverName: "João Silva",
    driverCpf: "123.456.789-00",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "debt",
    status: "in_progress",
    description: "Débito de multa de trânsito não paga",
    originalAmount: 500.00,
    negotiatedAmount: 350.00,
    installments: 3,
    installmentValue: 116.67,
    dueDate: new Date("2025-01-15"),
    paymentDeadline: new Date("2025-01-15"),
    createdAt: new Date("2024-12-01"),
    updatedAt: new Date("2024-12-08"),
    messages: [
      {
        id: "msg1",
        negotiationId: "1",
        senderId: "company1",
        senderName: "Transportes Rápidos",
        senderType: "company",
        message: "Olá João, vamos negociar este débito? Podemos fazer um desconto de 30% para pagamento parcelado.",
        createdAt: new Date("2024-12-01")
      },
      {
        id: "msg2",
        negotiationId: "1",
        senderId: "driver1",
        senderName: "João Silva",
        senderType: "driver",
        message: "Aceito a proposta. Podem ser 3 parcelas?",
        createdAt: new Date("2024-12-02")
      }
    ],
    debts: [
      {
        id: "debt1",
        type: "fine",
        description: "Multa de trânsito não paga",
        amount: 500.00,
        dueDate: new Date("2024-11-30"),
        isOverdue: true
      }
    ],
    payments: [
      {
        id: "payment1",
        installmentNumber: 1,
        amount: 116.67,
        dueDate: new Date("2025-01-15"),
        status: "pending"
      },
      {
        id: "payment2",
        installmentNumber: 2,
        amount: 116.67,
        dueDate: new Date("2025-02-15"),
        status: "pending"
      },
      {
        id: "payment3",
        installmentNumber: 3,
        amount: 116.66,
        dueDate: new Date("2025-03-15"),
        status: "pending"
      }
    ]
  },
  {
    id: "2",
    driverId: "driver2",
    driverName: "Maria Santos",
    driverCpf: "987.654.321-00",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "violation",
    status: "overdue",
    description: "Infração por excesso de velocidade - VENCIDO",
    originalAmount: 200.00,
    paymentDeadline: new Date("2024-11-20"),
    createdAt: new Date("2024-11-05"),
    updatedAt: new Date("2024-11-05"),
    messages: [],
    debts: [
      {
        id: "debt2",
        type: "fine",
        description: "Infração por excesso de velocidade",
        amount: 200.00,
        dueDate: new Date("2024-11-20"),
        isOverdue: true
      }
    ],
    payments: []
  },
  {
    id: "3",
    driverId: "driver3",
    driverName: "Carlos Oliveira",
    driverCpf: "456.789.123-00",
    companyId: "company2",
    companyName: "Frota Expressa",
    type: "payment",
    status: "agreed",
    description: "Pagamento de taxa de manutenção",
    originalAmount: 800.00,
    negotiatedAmount: 600.00,
    installments: 2,
    installmentValue: 300.00,
    dueDate: new Date("2025-01-20"),
    paymentDeadline: new Date("2025-01-20"),
    createdAt: new Date("2024-11-28"),
    updatedAt: new Date("2024-12-03"),
    messages: [
      {
        id: "msg3",
        negotiationId: "3",
        senderId: "driver3",
        senderName: "Carlos Oliveira",
        senderType: "driver",
        message: "Posso pagar em 2 parcelas?",
        createdAt: new Date("2024-11-28")
      }
    ],
    debts: [
      {
        id: "debt3",
        type: "maintenance",
        description: "Taxa de manutenção em atraso",
        amount: 800.00,
        dueDate: new Date("2024-11-15"),
        isOverdue: true
      }
    ],
    payments: [
      {
        id: "payment4",
        installmentNumber: 1,
        amount: 300.00,
        dueDate: new Date("2025-01-20"),
        status: "pending"
      },
      {
        id: "payment5",
        installmentNumber: 2,
        amount: 300.00,
        dueDate: new Date("2025-02-20"),
        status: "pending"
      }
    ]
  },
  // Novas negociações em andamento
  {
    id: "11",
    driverId: "driver11",
    driverName: "Felipe Santos",
    driverCpf: "111.222.333-44",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "debt",
    status: "in_progress",
    description: "Acordo para débito de combustível - EM NEGOCIAÇÃO",
    originalAmount: 850.00,
    negotiatedAmount: 680.00,
    installments: 4,
    installmentValue: 170.00,
    dueDate: new Date("2025-02-01"),
    paymentDeadline: new Date("2025-01-25"),
    createdAt: new Date("2024-12-10"),
    updatedAt: new Date("2024-12-12"),
    messages: [
      {
        id: "msg11",
        negotiationId: "11",
        senderId: "company1",
        senderName: "Transportes Rápidos",
        senderType: "company",
        message: "Felipe, temos um débito de combustível de R$ 850. Podemos fazer um acordo com 20% de desconto em 4 parcelas?",
        createdAt: new Date("2024-12-10")
      },
      {
        id: "msg12",
        negotiationId: "11",
        senderId: "driver11",
        senderName: "Felipe Santos",
        senderType: "driver",
        message: "Interessante a proposta. Posso ter mais alguns dias para analisar?",
        createdAt: new Date("2024-12-12")
      }
    ],
    debts: [
      {
        id: "debt11",
        type: "maintenance",
        description: "Débito de combustível não reembolsado",
        amount: 850.00,
        dueDate: new Date("2024-12-01"),
        isOverdue: true
      }
    ],
    payments: []
  },
  {
    id: "12",
    driverId: "driver12",
    driverName: "Beatriz Costa",
    driverCpf: "555.666.777-88",
    companyId: "company2",
    companyName: "Frota Expressa",
    type: "violation",
    status: "in_progress",
    description: "Multa por estacionamento - CONTRAPROSTA ENVIADA",
    originalAmount: 180.00,
    negotiatedAmount: 150.00,
    installments: 2,
    installmentValue: 75.00,
    dueDate: new Date("2025-01-30"),
    paymentDeadline: new Date("2025-01-18"),
    createdAt: new Date("2024-12-05"),
    updatedAt: new Date("2024-12-11"),
    messages: [
      {
        id: "msg13",
        negotiationId: "12",
        senderId: "company2",
        senderName: "Frota Expressa",
        senderType: "company",
        message: "Beatriz, multa de estacionamento irregular. Valor: R$ 180. Vamos negociar?",
        createdAt: new Date("2024-12-05")
      },
      {
        id: "msg14",
        negotiationId: "12",
        senderId: "driver12",
        senderName: "Beatriz Costa",
        senderType: "driver",
        message: "Posso pagar R$ 150 em 2 parcelas? Estou com dificuldades financeiras no momento.",
        createdAt: new Date("2024-12-11")
      }
    ],
    debts: [
      {
        id: "debt12",
        type: "fine",
        description: "Multa por estacionamento irregular",
        amount: 180.00,
        dueDate: new Date("2024-11-25"),
        isOverdue: true
      }
    ],
    payments: []
  },
  // Negociações que perderam o prazo
  {
    id: "13",
    driverId: "driver13",
    driverName: "Ricardo Pereira",
    driverCpf: "999.888.777-66",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "debt",
    status: "overdue",
    description: "Aluguel em atraso - PRAZO VENCIDO HÁ 10 DIAS",
    originalAmount: 1800.00,
    paymentDeadline: new Date("2024-12-01"),
    createdAt: new Date("2024-11-15"),
    updatedAt: new Date("2024-11-15"),
    messages: [
      {
        id: "msg15",
        negotiationId: "13",
        senderId: "company1",
        senderName: "Transportes Rápidos",
        senderType: "company",
        message: "Ricardo, seu aluguel de novembro está em atraso. Precisa regularizar urgente.",
        createdAt: new Date("2024-11-15")
      }
    ],
    debts: [
      {
        id: "debt13",
        type: "rental",
        description: "Aluguel mensal - Novembro 2024",
        amount: 1800.00,
        dueDate: new Date("2024-12-01"),
        isOverdue: true
      }
    ],
    payments: []
  },
  {
    id: "14",
    driverId: "driver14",
    driverName: "Amanda Silva",
    driverCpf: "444.333.222-11",
    companyId: "company2",
    companyName: "Frota Expressa",
    type: "payment",
    status: "overdue",
    description: "Taxa de manutenção - VENCIDO HÁ 5 DIAS",
    originalAmount: 420.00,
    paymentDeadline: new Date("2024-12-05"),
    createdAt: new Date("2024-11-20"),
    updatedAt: new Date("2024-11-20"),
    messages: [],
    debts: [
      {
        id: "debt14",
        type: "maintenance",
        description: "Taxa de manutenção preventiva",
        amount: 420.00,
        dueDate: new Date("2024-12-05"),
        isOverdue: true
      }
    ],
    payments: []
  },
  {
    id: "15",
    driverId: "driver15",
    driverName: "Bruno Oliveira",
    driverCpf: "777.888.999-00",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "violation",
    status: "overdue",
    description: "Multa grave - PRAZO EXPIRADO HÁ 15 DIAS",
    originalAmount: 950.00,
    paymentDeadline: new Date("2024-11-25"),
    createdAt: new Date("2024-11-10"),
    updatedAt: new Date("2024-11-12"),
    messages: [
      {
        id: "msg16",
        negotiationId: "15",
        senderId: "company1",
        senderName: "Transportes Rápidos",
        senderType: "company",
        message: "Bruno, multa grave por excesso de velocidade. Valor: R$ 950. Prazo até 25/11.",
        createdAt: new Date("2024-11-10")
      },
      {
        id: "msg17",
        negotiationId: "15",
        senderId: "driver15",
        senderName: "Bruno Oliveira",
        senderType: "driver",
        message: "Vou verificar com meu advogado se procede.",
        createdAt: new Date("2024-11-12")
      }
    ],
    debts: [
      {
        id: "debt15",
        type: "fine",
        description: "Multa por excesso de velocidade - 40km/h acima do limite",
        amount: 950.00,
        dueDate: new Date("2024-11-25"),
        isOverdue: true
      }
    ],
    payments: []
  },
  // Mais uma negociação em andamento com PIX
  {
    id: "16",
    driverId: "driver16",
    driverName: "Carla Rodrigues",
    driverCpf: "123.987.456-78",
    companyId: "company2",
    companyName: "Frota Expressa",
    type: "debt",
    status: "in_progress",
    description: "Acordo com desconto para danos no veículo",
    originalAmount: 2200.00,
    negotiatedAmount: 1650.00,
    installments: 5,
    installmentValue: 330.00,
    dueDate: new Date("2025-02-15"),
    paymentDeadline: new Date("2025-01-20"),
    createdAt: new Date("2024-12-08"),
    updatedAt: new Date("2024-12-13"),
    messages: [
      {
        id: "msg18",
        negotiationId: "16",
        senderId: "company2",
        senderName: "Frota Expressa",
        senderType: "company",
        message: "Carla, temos danos no veículo no valor de R$ 2.200. Podemos fazer um desconto de 25% para pagamento em 5 parcelas. PIX: pix@frotaexpressa.com.br",
        createdAt: new Date("2024-12-08")
      },
      {
        id: "msg19",
        negotiationId: "16",
        senderId: "driver16",
        senderName: "Carla Rodrigues",
        senderType: "driver",
        message: "Boa proposta! Vou aceitar o acordo. Como funciona o pagamento via PIX?",
        createdAt: new Date("2024-12-13")
      }
    ],
    debts: [
      {
        id: "debt16",
        type: "damage",
        description: "Danos no para-choque traseiro e lanterna",
        amount: 2200.00,
        dueDate: new Date("2024-12-15"),
        isOverdue: false
      }
    ],
    payments: [
      {
        id: "payment16_1",
        installmentNumber: 1,
        amount: 330.00,
        dueDate: new Date("2025-01-20"),
        status: "pending"
      },
      {
        id: "payment16_2",
        installmentNumber: 2,
        amount: 330.00,
        dueDate: new Date("2025-02-20"),
        status: "pending"
      },
      {
        id: "payment16_3",
        installmentNumber: 3,
        amount: 330.00,
        dueDate: new Date("2025-03-20"),
        status: "pending"
      },
      {
        id: "payment16_4",
        installmentNumber: 4,
        amount: 330.00,
        dueDate: new Date("2025-04-20"),
        status: "pending"
      },
      {
        id: "payment16_5",
        installmentNumber: 5,
        amount: 330.00,
        dueDate: new Date("2025-05-20"),
        status: "pending"
      }
    ]
  },
  {
    id: "4",
    driverId: "driver4",
    driverName: "Ana Rodrigues",
    driverCpf: "789.123.456-00",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "debt",
    status: "rejected",
    description: "Débito de combustível - REJEITADO PELO MOTORISTA",
    originalAmount: 1200.00,
    negotiatedAmount: 900.00,
    paymentDeadline: new Date("2024-10-30"),
    createdAt: new Date("2024-10-15"),
    updatedAt: new Date("2024-10-20"),
    messages: [
      {
        id: "msg4",
        negotiationId: "4",
        senderId: "company1",
        senderName: "Transportes Rápidos",
        senderType: "company",
        message: "Ana, temos um débito de combustível. Podemos negociar um desconto de 25%?",
        createdAt: new Date("2024-10-15")
      },
      {
        id: "msg5",
        negotiationId: "4",
        senderId: "driver4",
        senderName: "Ana Rodrigues",
        senderType: "driver",
        message: "Não concordo com este valor. Rejeito a proposta.",
        createdAt: new Date("2024-10-20")
      }
    ],
    debts: [
      {
        id: "debt4",
        type: "maintenance",
        description: "Débito de combustível não pago",
        amount: 1200.00,
        dueDate: new Date("2024-10-30"),
        isOverdue: true
      }
    ],
    payments: []
  },
  {
    id: "5",
    driverId: "driver5",
    driverName: "Roberto Costa",
    driverCpf: "321.654.987-00",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "violation",
    status: "pending",
    description: "Multa por estacionamento irregular - PRAZO VENCIDO",
    originalAmount: 150.00,
    paymentDeadline: new Date("2024-11-01"),
    createdAt: new Date("2024-10-20"),
    updatedAt: new Date("2024-10-20"),
    messages: [],
    debts: [
      {
        id: "debt5",
        type: "fine",
        description: "Multa por estacionamento irregular",
        amount: 150.00,
        dueDate: new Date("2024-11-01"),
        isOverdue: true
      }
    ],
    payments: []
  },
  {
    id: "6",
    driverId: "driver6",
    driverName: "Fernanda Lima",
    driverCpf: "654.987.321-00",
    companyId: "company2",
    companyName: "Frota Expressa",
    type: "payment",
    status: "overdue",
    description: "Aluguel em atraso há 30 dias - VENCIDO",
    originalAmount: 2500.00,
    paymentDeadline: new Date("2024-11-15"),
    createdAt: new Date("2024-10-01"),
    updatedAt: new Date("2024-10-01"),
    messages: [
      {
        id: "msg6",
        negotiationId: "6",
        senderId: "company2",
        senderName: "Frota Expressa",
        senderType: "company",
        message: "Fernanda, seu aluguel está em atraso há 30 dias. Precisamos resolver urgente.",
        createdAt: new Date("2024-10-01")
      }
    ],
    debts: [
      {
        id: "debt6",
        type: "rental",
        description: "Aluguel mensal em atraso",
        amount: 2500.00,
        dueDate: new Date("2024-11-15"),
        isOverdue: true
      }
    ],
    payments: []
  },
  {
    id: "7",
    driverId: "driver7",
    driverName: "Pedro Mendes",
    driverCpf: "147.258.369-00",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "debt",
    status: "pending",
    description: "Danos ao veículo - AGUARDANDO RESPOSTA HÁ 10 DIAS",
    originalAmount: 3500.00,
    paymentDeadline: new Date("2024-12-01"),
    createdAt: new Date("2024-11-01"),
    updatedAt: new Date("2024-11-01"),
    messages: [
      {
        id: "msg7",
        negotiationId: "7",
        senderId: "company1",
        senderName: "Transportes Rápidos",
        senderType: "company",
        message: "Pedro, identificamos danos no veículo. Valor para reparo: R$ 3.500,00. Vamos negociar?",
        createdAt: new Date("2024-11-01")
      }
    ],
    debts: [
      {
        id: "debt7",
        type: "damage",
        description: "Danos ao para-choque e farol",
        amount: 3500.00,
        dueDate: new Date("2024-12-01"),
        isOverdue: false
      }
    ],
    payments: []
  },
  {
    id: "8",
    driverId: "driver8",
    driverName: "Juliana Souza",
    driverCpf: "963.852.741-00",
    companyId: "company2",
    companyName: "Frota Expressa",
    type: "violation",
    status: "rejected",
    description: "Multa por velocidade - REJEITADA E VENCIDA",
    originalAmount: 380.00,
    negotiatedAmount: 300.00,
    paymentDeadline: new Date("2024-10-15"),
    createdAt: new Date("2024-09-20"),
    updatedAt: new Date("2024-09-25"),
    messages: [
      {
        id: "msg8",
        negotiationId: "8",
        senderId: "company2",
        senderName: "Frota Expressa",
        senderType: "company",
        message: "Juliana, temos uma multa por excesso de velocidade. Desconto de 20% se pagar à vista.",
        createdAt: new Date("2024-09-20")
      },
      {
        id: "msg9",
        negotiationId: "8",
        senderId: "driver8",
        senderName: "Juliana Souza",
        senderType: "driver",
        message: "Não foi culpa minha. Rejeito a cobrança.",
        createdAt: new Date("2024-09-25")
      }
    ],
    debts: [
      {
        id: "debt8",
        type: "fine",
        description: "Multa por excesso de velocidade - 20km/h acima",
        amount: 380.00,
        dueDate: new Date("2024-10-15"),
        isOverdue: true
      }
    ],
    payments: []
  },
  {
    id: "9",
    driverId: "driver9",
    driverName: "Marcos Silva",
    driverCpf: "159.753.486-00",
    companyId: "company1",
    companyName: "Transportes Rápidos",
    type: "payment",
    status: "completed",
    description: "Taxa de limpeza - PAGO",
    originalAmount: 80.00,
    negotiatedAmount: 80.00,
    installments: 1,
    installmentValue: 80.00,
    dueDate: new Date("2024-12-10"),
    paymentDeadline: new Date("2024-12-10"),
    createdAt: new Date("2024-12-05"),
    updatedAt: new Date("2024-12-08"),
    messages: [
      {
        id: "msg10",
        negotiationId: "9",
        senderId: "driver9",
        senderName: "Marcos Silva",
        senderType: "driver",
        message: "Ok, vou pagar a taxa de limpeza.",
        createdAt: new Date("2024-12-05")
      }
    ],
    debts: [
      {
        id: "debt9",
        type: "maintenance",
        description: "Taxa de limpeza do veículo",
        amount: 80.00,
        dueDate: new Date("2024-12-10"),
        isOverdue: false
      }
    ],
    payments: [
      {
        id: "payment6",
        installmentNumber: 1,
        amount: 80.00,
        dueDate: new Date("2024-12-10"),
        status: "paid"
      }
    ]
  },
  {
    id: "10",
    driverId: "driver10",
    driverName: "Luciana Costa",
    driverCpf: "753.159.486-00",
    companyId: "company2",
    companyName: "Frota Expressa",
    type: "debt",
    status: "overdue",
    description: "Combustível não pago - VENCIDO HÁ 15 DIAS",
    originalAmount: 680.00,
    paymentDeadline: new Date("2024-11-25"),
    createdAt: new Date("2024-10-10"),
    updatedAt: new Date("2024-10-10"),
    messages: [],
    debts: [
      {
        id: "debt10",
        type: "maintenance",
        description: "Combustível não reembolsado",
        amount: 680.00,
        dueDate: new Date("2024-11-25"),
        isOverdue: true
      }
    ],
    payments: []
  }
];
