
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CreateNegotiationDialog } from "./CreateNegotiationDialog";
import { DeactivatedDriverSelector } from "./DeactivatedDriverSelector";
import { DeactivatedDriver, CreateNegotiationData } from "../types";
import { Users, Plus } from "lucide-react";

interface CreateNegotiationFlowProps {
  onCreateNegotiation: (data: CreateNegotiationData) => void;
}

export const CreateNegotiationFlow = ({ onCreateNegotiation }: CreateNegotiationFlowProps) => {
  const [selectedDriver, setSelectedDriver] = useState<DeactivatedDriver | null>(null);
  const [isNegotiationDialogOpen, setIsNegotiationDialogOpen] = useState(false);

  const handleSelectDriver = (driver: DeactivatedDriver) => {
    setSelectedDriver(driver);
    setIsNegotiationDialogOpen(true);
  };

  const handleCreateNegotiation = (data: CreateNegotiationData) => {
    onCreateNegotiation(data);
    setSelectedDriver(null);
    setIsNegotiationDialogOpen(false);
  };

  return (
    <>
      <DeactivatedDriverSelector
        onSelectDriver={handleSelectDriver}
        buttonText="Criar Acordo"
        buttonIcon={<Plus className="h-4 w-4 mr-2" />}
        title="Selecionar Motorista para Acordo"
      />

      {selectedDriver && (
        <CreateNegotiationDialog
          driver={selectedDriver}
          isOpen={isNegotiationDialogOpen}
          onOpenChange={setIsNegotiationDialogOpen}
          onCreateNegotiation={handleCreateNegotiation}
        />
      )}
    </>
  );
};
