
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Negotiation } from "../types";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  User, 
  Calendar, 
  DollarSign, 
  MessageSquare, 
  FileText, 
  AlertTriangle,
  CheckCircle,
  Building
} from "lucide-react";

interface NegotiationDetailsDialogProps {
  negotiation: Negotiation | null;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export const NegotiationDetailsDialog = ({ negotiation, isOpen, onOpenChange }: NegotiationDetailsDialogProps) => {
  if (!negotiation) return null;

  const getStatusBadge = (status: Negotiation["status"]) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pendente</Badge>;
      case "in_progress":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Em Andamento</Badge>;
      case "agreed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Aceito</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Rejeitado</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Concluído</Badge>;
      case "overdue":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Em Atraso</Badge>;
      default:
        return <Badge variant="outline">Status Desconhecido</Badge>;
    }
  };

  const getDebtTypeLabel = (type: string) => {
    switch (type) {
      case "rental": return "Aluguel";
      case "damage": return "Danos";
      case "fine": return "Multa";
      case "maintenance": return "Manutenção";
      default: return type;
    }
  };

  const getDebtTypeBadge = (type: string) => {
    const colorMap = {
      rental: "bg-blue-100 text-blue-800",
      damage: "bg-red-100 text-red-800", 
      fine: "bg-orange-100 text-orange-800",
      maintenance: "bg-green-100 text-green-800"
    };
    return colorMap[type as keyof typeof colorMap] || "bg-gray-100 text-gray-800";
  };

  const getPaymentStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "paid":
        return <Badge variant="outline" className="bg-green-100 text-green-800">Pago</Badge>;
      case "overdue":
        return <Badge variant="outline" className="bg-red-100 text-red-800">Atrasado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const finalAmount = negotiation.negotiatedAmount || negotiation.originalAmount;
  const hasDiscount = negotiation.negotiatedAmount && negotiation.negotiatedAmount < negotiation.originalAmount;
  const discount = hasDiscount ? negotiation.originalAmount - negotiation.negotiatedAmount! : 0;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Detalhes da Negociação
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(90vh-100px)]">
          <div className="space-y-6">
            {/* Header com Status */}
            <div className="flex justify-between items-center">
              <div className="space-y-1">
                <h3 className="text-lg font-semibold">ID: {negotiation.id}</h3>
                <p className="text-sm text-muted-foreground">
                  Criado em {format(negotiation.createdAt, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                </p>
              </div>
              {getStatusBadge(negotiation.status)}
            </div>

            {/* Informações das Partes */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Motorista
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Nome</p>
                    <p className="font-medium">{negotiation.driverName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">CPF</p>
                    <p className="font-medium">{negotiation.driverCpf}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Building className="h-4 w-4" />
                    Locadora
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-fore ground">Nome</p>
                    <p className="font-medium">{negotiation.companyName}</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Resumo Financeiro */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Resumo Financeiro
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Valor Original</p>
                    <p className="text-lg font-semibold text-gray-600">R$ {negotiation.originalAmount.toFixed(2)}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Valor do Acordo</p>
                    <p className="text-lg font-bold text-green-600">R$ {finalAmount.toFixed(2)}</p>
                  </div>
                  {hasDiscount && (
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Desconto</p>
                      <p className="text-lg font-semibold text-green-500">R$ {discount.toFixed(2)}</p>
                    </div>
                  )}
                  {negotiation.installments && negotiation.installments > 1 && (
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Parcelas</p>
                      <p className="text-lg font-semibold">{negotiation.installments}x de R$ {negotiation.installmentValue?.toFixed(2)}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Débitos Incluídos */}
            {negotiation.debts.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Débitos Incluídos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {negotiation.debts.map((debt) => (
                      <div key={debt.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge className={getDebtTypeBadge(debt.type)}>
                              {getDebtTypeLabel(debt.type)}
                            </Badge>
                            {debt.isOverdue && (
                              <Badge variant="destructive">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Vencido
                              </Badge>
                            )}
                          </div>
                          <p className="font-medium">{debt.description}</p>
                          <p className="text-xs text-muted-foreground">
                            Vencimento: {format(debt.dueDate, "dd/MM/yyyy", { locale: ptBR })}
                          </p>
                        </div>
                        <p className="font-bold text-red-600">R$ {debt.amount.toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Cronograma de Pagamentos */}
            {negotiation.payments.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cronograma de Pagamentos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {negotiation.payments.map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="space-y-1">
                          <p className="font-medium">Parcela {payment.installmentNumber}</p>
                          <p className="text-sm text-muted-foreground flex items-center gap-2">
                            <Calendar className="h-4 w-4" />
                            Vencimento: {format(payment.dueDate, "dd/MM/yyyy", { locale: ptBR })}
                          </p>
                          {payment.paidDate && (
                            <p className="text-sm text-green-600 flex items-center gap-2">
                              <CheckCircle className="h-4 w-4" />
                              Pago em: {format(payment.paidDate, "dd/MM/yyyy", { locale: ptBR })}
                            </p>
                          )}
                        </div>
                        <div className="text-right space-y-1">
                          <p className="font-bold">R$ {payment.amount.toFixed(2)}</p>
                          {getPaymentStatusBadge(payment.status)}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Prazos e Datas Importantes */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Prazos e Datas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Data de Criação</p>
                    <p className="font-medium">{format(negotiation.createdAt, "dd/MM/yyyy", { locale: ptBR })}</p>
                  </div>
                  {negotiation.paymentDeadline && (
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Prazo para Resposta</p>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{format(negotiation.paymentDeadline, "dd/MM/yyyy", { locale: ptBR })}</p>
                        {new Date(negotiation.paymentDeadline) < new Date() && negotiation.status !== "completed" && (
                          <Badge variant="destructive">Vencido</Badge>
                        )}
                      </div>
                    </div>
                  )}
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Última Atualização</p>
                    <p className="font-medium">{format(negotiation.updatedAt, "dd/MM/yyyy", { locale: ptBR })}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Histórico de Mensagens */}
            {negotiation.messages.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    Histórico de Mensagens
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {negotiation.messages.map((message) => (
                      <div key={message.id} className="border-l-4 border-blue-200 pl-4 py-2">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium">{message.senderName}</p>
                            <p className="text-xs text-muted-foreground">
                              {message.senderType === "company" ? "Locadora" : 
                               message.senderType === "driver" ? "Motorista" : "Admin"}
                            </p>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {format(message.createdAt, "dd/MM/yyyy HH:mm", { locale: ptBR })}
                          </p>
                        </div>
                        <p className="text-sm">{message.message}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Descrição */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Descrição</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{negotiation.description}</p>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
