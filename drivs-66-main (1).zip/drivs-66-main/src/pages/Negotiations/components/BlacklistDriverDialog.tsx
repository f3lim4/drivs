
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { AlertTriangle, Send } from "lucide-react";

interface BlacklistDriverDialogProps {
  driverName: string;
  driverCpf: string;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (observations?: string) => void;
}

export const BlacklistDriverDialog = ({ 
  driverName, 
  driverCpf, 
  isOpen, 
  onOpenChange, 
  onConfirm 
}: BlacklistDriverDialogProps) => {
  const [observations, setObservations] = useState("");

  const handleConfirm = () => {
    onConfirm(observations || undefined);
    setObservations("");
  };

  const handleCancel = () => {
    setObservations("");
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            Encaminhar para DRIVS
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 bg-red-50 rounded-lg border border-red-200">
            <div className="space-y-2">
              <p className="text-sm font-medium text-red-800">
                Esta ação irá enviar o motorista para análise da DRIVS
              </p>
              <div className="text-xs text-red-600 space-y-1">
                <p><strong>Motorista:</strong> {driverName}</p>
                <p><strong>CPF:</strong> {driverCpf}</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="observations">Observações (Opcional)</Label>
            <Textarea
              id="observations"
              placeholder="Adicione observações sobre o caso para auxiliar a análise da DRIVS..."
              value={observations}
              onChange={(e) => setObservations(e.target.value)}
              rows={4}
            />
            <p className="text-xs text-muted-foreground">
              Estas observações serão enviadas junto com o caso para a DRIVS
            </p>
          </div>

          <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
            <p className="text-xs text-yellow-800">
              <strong>Importante:</strong> Após o envio, a DRIVS analisará o caso e poderá aplicar restrições ou negativar o motorista na plataforma.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleCancel}>
            Cancelar
          </Button>
          <Button variant="destructive" onClick={handleConfirm}>
            <Send className="h-4 w-4 mr-2" />
            Enviar para DRIVS
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
