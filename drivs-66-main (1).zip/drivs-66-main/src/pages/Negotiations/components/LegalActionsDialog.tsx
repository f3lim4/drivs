
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Scale, Download, FileText, Car, CreditCard, Send } from "lucide-react";

interface LegalActionsDialogProps {
  driverName: string;
  driverCpf: string;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSendToLegal: (observations?: string) => void;
  onDownloadDocuments: () => void;
}

export const LegalActionsDialog = ({ 
  driverName, 
  driverCpf, 
  isOpen, 
  onOpenChange, 
  onSendToLegal,
  onDownloadDocuments
}: LegalActionsDialogProps) => {
  const [observations, setObservations] = useState("");
  const [selectedAction, setSelectedAction] = useState<"legal" | "download" | null>(null);

  const handleSendToLegal = () => {
    onSendToLegal(observations || undefined);
    setObservations("");
    setSelectedAction(null);
  };

  const handleDownload = () => {
    onDownloadDocuments();
    setSelectedAction(null);
  };

  const handleCancel = () => {
    setObservations("");
    setSelectedAction(null);
    onOpenChange(false);
  };

  // Documentos que serão incluídos
  const documentsToInclude = [
    { icon: FileText, label: "Contratos de Locação", count: "3 documentos" },
    { icon: Car, label: "Relatórios de Vistorias", count: "5 relatórios" },
    { icon: CreditCard, label: "Histórico de Pagamentos", count: "12 meses" },
    { icon: FileText, label: "Tentativas de Negociação", count: "4 registros" },
    { icon: AlertTriangle, label: "Notificações Enviadas", count: "6 comprovantes" }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-blue-600">
            <Scale className="h-5 w-5" />
            Ações Jurídicas - DRIVS
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="space-y-2">
              <p className="text-sm font-medium text-blue-800">
                Escolha a ação jurídica para o motorista inadimplente
              </p>
              <div className="text-xs text-blue-600 space-y-1">
                <p><strong>Motorista:</strong> {driverName}</p>
                <p><strong>CPF:</strong> {driverCpf}</p>
              </div>
            </div>
          </div>

          {/* Opções de Ação */}
          <div className="space-y-3">
            <h3 className="font-medium text-sm">Selecione uma ação:</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Button
                variant={selectedAction === "legal" ? "default" : "outline"}
                className="h-auto p-4 justify-start"
                onClick={() => setSelectedAction("legal")}
              >
                <div className="flex items-start gap-3">
                  <Send className="h-5 w-5 mt-0.5 text-blue-600" />
                  <div className="text-left">
                    <div className="font-medium">Enviar para Jurídico DRIVS</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      DRIVS iniciará cobrança ou execução judicial
                    </div>
                  </div>
                </div>
              </Button>

              <Button
                variant={selectedAction === "download" ? "default" : "outline"}
                className="h-auto p-4 justify-start"
                onClick={() => setSelectedAction("download")}
              >
                <div className="flex items-start gap-3">
                  <Download className="h-5 w-5 mt-0.5 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium">Baixar Documentos</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Fazer ação legal por conta própria
                    </div>
                  </div>
                </div>
              </Button>
            </div>
          </div>

          <Separator />

          {/* Documentos Incluídos */}
          <div className="space-y-3">
            <h3 className="font-medium text-sm flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Documentos que serão incluídos:
            </h3>
            
            <div className="grid grid-cols-1 gap-2">
              {documentsToInclude.map((doc, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div className="flex items-center gap-2">
                    <doc.icon className="h-4 w-4 text-gray-600" />
                    <span className="text-sm">{doc.label}</span>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {doc.count}
                  </Badge>
                </div>
              ))}
            </div>
          </div>

          {/* Observações */}
          {selectedAction === "legal" && (
            <div className="space-y-2">
              <Label htmlFor="observations">Observações para o Jurídico (Opcional)</Label>
              <Textarea
                id="observations"
                placeholder="Adicione informações relevantes para auxiliar a ação jurídica..."
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                rows={3}
              />
              <p className="text-xs text-muted-foreground">
                Estas observações serão enviadas junto com o processo para o setor jurídico da DRIVS
              </p>
            </div>
          )}

          {/* Avisos */}
          {selectedAction === "legal" && (
            <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
              <p className="text-xs text-orange-800">
                <strong>Importante:</strong> O setor jurídico da DRIVS analisará o caso e poderá iniciar cobrança amigável ou execução judicial contra o motorista.
              </p>
            </div>
          )}

          {selectedAction === "download" && (
            <div className="p-3 bg-green-50 rounded-lg border border-green-200">
              <p className="text-xs text-green-800">
                <strong>Importante:</strong> Todos os documentos serão compilados em um arquivo ZIP para download. Use estes documentos para iniciar sua própria ação legal.
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleCancel}>
            Cancelar
          </Button>
          {selectedAction === "legal" && (
            <Button onClick={handleSendToLegal}>
              <Send className="h-4 w-4 mr-2" />
              Enviar para Jurídico
            </Button>
          )}
          {selectedAction === "download" && (
            <Button onClick={handleDownload} variant="success">
              <Download className="h-4 w-4 mr-2" />
              Baixar Documentos
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
