
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BlacklistDriverDialog } from "./BlacklistDriverDialog";
import { LegalActionsDialog } from "./LegalActionsDialog";
import { Negotiation } from "../types";
import { format, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { AlertTriangle, Clock, Send, Scale } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface NegotiationStatusManagerProps {
  negotiation: Negotiation;
  onBlacklistDriver: (data: { driverId: string; driverName: string; driverCpf: string; observations?: string }) => void;
}

export const NegotiationStatusManager = ({ negotiation, onBlacklistDriver }: NegotiationStatusManagerProps) => {
  const [isBlacklistDialogOpen, setIsBlacklistDialogOpen] = useState(false);
  const [isLegalActionsDialogOpen, setIsLegalActionsDialogOpen] = useState(false);

  // Calcular se já se passaram 7 dias desde a criação ou última atualização
  const daysSinceCreation = differenceInDays(new Date(), negotiation.createdAt);
  const daysSinceUpdate = differenceInDays(new Date(), negotiation.updatedAt);
  const canSendToDrivs = (daysSinceCreation >= 7 || daysSinceUpdate >= 7) && 
                        (negotiation.status === "pending" || negotiation.status === "overdue" || negotiation.status === "rejected");

  // Verificar se o prazo de pagamento já passou
  const isPaymentOverdue = negotiation.paymentDeadline && 
                          new Date(negotiation.paymentDeadline) < new Date() && 
                          negotiation.status !== "completed";

  const handleSendToDrivs = () => {
    setIsBlacklistDialogOpen(true);
  };

  const handleLegalActions = () => {
    setIsLegalActionsDialogOpen(true);
  };

  const handleBlacklistConfirm = (observations?: string) => {
    onBlacklistDriver({
      driverId: negotiation.driverId,
      driverName: negotiation.driverName,
      driverCpf: negotiation.driverCpf,
      observations
    });
    setIsBlacklistDialogOpen(false);
  };

  const handleSendToLegal = (observations?: string) => {
    console.log("Enviando para setor jurídico DRIVS:", {
      driverId: negotiation.driverId,
      driverName: negotiation.driverName,
      driverCpf: negotiation.driverCpf,
      observations,
      documents: {
        contracts: true,
        inspections: true,
        paymentHistory: true,
        negotiations: true,
        notifications: true
      }
    });
    
    toast({
      title: "Enviado para Jurídico DRIVS",
      description: `Caso de ${negotiation.driverName} foi enviado para o setor jurídico com todos os documentos.`,
    });
    
    setIsLegalActionsDialogOpen(false);
  };

  const handleDownloadDocuments = () => {
    console.log("Iniciando download de documentos para:", {
      driverId: negotiation.driverId,
      driverName: negotiation.driverName,
      driverCpf: negotiation.driverCpf
    });
    
    // Simular download
    const link = document.createElement('a');
    link.href = '#'; // Em produção, seria a URL do arquivo ZIP
    link.download = `documentos_${negotiation.driverName.replace(/\s+/g, '_')}_${negotiation.driverCpf.replace(/\D/g, '')}.zip`;
    link.click();
    
    toast({
      title: "Download Iniciado",
      description: `Documentos de ${negotiation.driverName} estão sendo preparados para download.`,
    });
    
    setIsLegalActionsDialogOpen(false);
  };

  // Não mostrar o componente se não há ações necessárias
  if (!canSendToDrivs && !isPaymentOverdue) {
    return null;
  }

  return (
    <>
      <Card className="border-l-4 border-l-orange-500">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
            Ações Necessárias
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {isPaymentOverdue && (
            <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
              <div className="space-y-1">
                <p className="text-sm font-medium text-red-800">Prazo Vencido</p>
                <p className="text-xs text-red-600">
                  Venceu em {format(negotiation.paymentDeadline!, "dd/MM/yyyy", { locale: ptBR })}
                </p>
              </div>
              <Badge variant="destructive">
                <Clock className="h-3 w-3 mr-1" />
                Atrasado
              </Badge>
            </div>
          )}

          {canSendToDrivs && (
            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-orange-800">
                    Disponível para DRIVS
                  </p>
                  <p className="text-xs text-orange-600">
                    {daysSinceCreation >= 7 
                      ? `${daysSinceCreation} dias desde criação`
                      : `${daysSinceUpdate} dias desde última atualização`
                    }
                  </p>
                </div>
                <Badge variant="outline" className="bg-orange-100 text-orange-800">
                  Prazo Atingido
                </Badge>
              </div>
              
              <div className="grid grid-cols-1 gap-2">
                <Button 
                  variant="destructive" 
                  size="sm" 
                  onClick={handleSendToDrivs}
                  className="w-full"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Negativar na DRIVS
                </Button>
                
                <Button 
                  variant="default" 
                  size="sm" 
                  onClick={handleLegalActions}
                  className="w-full"
                >
                  <Scale className="h-4 w-4 mr-2" />
                  Ações Jurídicas
                </Button>
              </div>
            </div>
          )}

          {negotiation.status === "rejected" && (
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-600">
                <strong>Status:</strong> Acordo rejeitado pelo motorista
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <BlacklistDriverDialog
        driverName={negotiation.driverName}
        driverCpf={negotiation.driverCpf}
        isOpen={isBlacklistDialogOpen}
        onOpenChange={setIsBlacklistDialogOpen}
        onConfirm={handleBlacklistConfirm}
      />

      <LegalActionsDialog
        driverName={negotiation.driverName}
        driverCpf={negotiation.driverCpf}
        isOpen={isLegalActionsDialogOpen}
        onOpenChange={setIsLegalActionsDialogOpen}
        onSendToLegal={handleSendToLegal}
        onDownloadDocuments={handleDownloadDocuments}
      />
    </>
  );
};
