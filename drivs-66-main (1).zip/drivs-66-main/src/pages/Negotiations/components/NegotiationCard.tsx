
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Negotiation } from "../types";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  Clock, 
  DollarSign, 
  User, 
  Calendar, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  MessageSquare,
  Eye
} from "lucide-react";

interface NegotiationCardProps {
  negotiation: Negotiation;
  onViewDetails: (negotiation: Negotiation) => void;
  onSendMessage: (negotiation: Negotiation) => void;
}

export const NegotiationCard = ({ negotiation, onViewDetails, onSendMessage }: NegotiationCardProps) => {
  const getStatusIcon = (status: Negotiation["status"]) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "in_progress":
        return <AlertTriangle className="h-4 w-4" />;
      case "agreed":
        return <CheckCircle className="h-4 w-4" />;
      case "rejected":
        return <XCircle className="h-4 w-4" />;
      case "completed":
        return <CheckCircle className="h-4 w-4" />;
      case "overdue":
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusBadge = (status: Negotiation["status"]) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pendente</Badge>;
      case "in_progress":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Em Andamento</Badge>;
      case "agreed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Aceito</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Rejeitado</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Concluído</Badge>;
      case "overdue":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Em Atraso</Badge>;
      default:
        return <Badge variant="outline">Status Desconhecido</Badge>;
    }
  };

  const getTypeLabel = (type: Negotiation["type"]) => {
    switch (type) {
      case "debt": return "Débito";
      case "violation": return "Infração";
      case "contract": return "Contrato";
      case "payment": return "Pagamento";
      default: return type;
    }
  };

  const finalAmount = negotiation.negotiatedAmount || negotiation.originalAmount;
  const hasDiscount = negotiation.negotiatedAmount && negotiation.negotiatedAmount < negotiation.originalAmount;

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="h-4 w-4" />
              {negotiation.driverName}
            </CardTitle>
            <p className="text-sm text-muted-foreground">CPF: {negotiation.driverCpf}</p>
          </div>
          <div className="flex items-center gap-2">
            {getStatusIcon(negotiation.status)}
            {getStatusBadge(negotiation.status)}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Tipo</p>
            <p className="font-medium">{getTypeLabel(negotiation.type)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Criado em</p>
            <p className="font-medium">{format(negotiation.createdAt, "dd/MM/yyyy", { locale: ptBR })}</p>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-sm text-muted-foreground">Descrição</p>
          <p className="text-sm">{negotiation.description}</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Valor Original</p>
            <p className="font-medium text-gray-600">R$ {negotiation.originalAmount.toFixed(2)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Valor do Acordo</p>
            <div className="flex items-center gap-2">
              <p className="font-bold text-green-600">R$ {finalAmount.toFixed(2)}</p>
              {hasDiscount && (
                <Badge variant="outline" className="bg-green-100 text-green-800 text-xs">
                  Desconto
                </Badge>
              )}
            </div>
          </div>
        </div>

        {negotiation.installments && negotiation.installments > 1 && (
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Parcelas</p>
              <p className="font-medium">{negotiation.installments}x</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Valor da Parcela</p>
              <p className="font-medium">R$ {negotiation.installmentValue?.toFixed(2)}</p>
            </div>
          </div>
        )}

        {negotiation.paymentDeadline && (
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">Prazo:</span>
            <span className="font-medium">
              {format(negotiation.paymentDeadline, "dd/MM/yyyy", { locale: ptBR })}
            </span>
            {new Date(negotiation.paymentDeadline) < new Date() && negotiation.status !== "completed" && (
              <Badge variant="destructive" className="ml-2">Vencido</Badge>
            )}
          </div>
        )}

        <div className="flex justify-between items-center pt-2 border-t">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <DollarSign className="h-4 w-4" />
            <span>Total: R$ {finalAmount.toFixed(2)}</span>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => onSendMessage(negotiation)}>
              <MessageSquare className="h-4 w-4 mr-1" />
              Mensagem
            </Button>
            <Button size="sm" onClick={() => onViewDetails(negotiation)}>
              <Eye className="h-4 w-4 mr-1" />
              Detalhes
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
