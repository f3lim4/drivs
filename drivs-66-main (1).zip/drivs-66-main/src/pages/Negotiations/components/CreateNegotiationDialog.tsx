import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CalendarIcon, AlertTriangle, DollarSign, Link, QrCode, Copy } from "lucide-react";
import { DeactivatedDriver, CreateNegotiationData, NegotiationDebt } from "../types";
import { toast } from "sonner";

interface CreateNegotiationDialogProps {
  driver: DeactivatedDriver;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onCreateNegotiation: (data: CreateNegotiationData) => void;
}

export const CreateNegotiationDialog = ({ 
  driver, 
  isOpen, 
  onOpenChange, 
  onCreateNegotiation 
}: CreateNegotiationDialogProps) => {
  const [selectedDebts, setSelectedDebts] = useState<NegotiationDebt[]>([]);
  const [proposedAmount, setProposedAmount] = useState<number>();
  const [installments, setInstallments] = useState<number>(1);
  const [paymentDeadline, setPaymentDeadline] = useState<Date>();
  const [description, setDescription] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"link" | "pix">("pix");
  const [pixLink, setPixLink] = useState("");
  const [pixKey, setPixKey] = useState("pix@minhalocadora.com.br");

  // Add safety checks for undefined openDebts
  const driverDebts = driver.openDebts || [];
  const totalOriginalAmount = driverDebts.reduce((sum, debt) => sum + debt.amount, 0);
  const selectedDebtsTotal = selectedDebts.reduce((sum, debt) => sum + debt.amount, 0);
  const installmentValue = proposedAmount && installments ? proposedAmount / installments : 0;

  const handleDebtSelection = (debt: NegotiationDebt, selected: boolean) => {
    if (selected) {
      setSelectedDebts([...selectedDebts, debt]);
    } else {
      setSelectedDebts(selectedDebts.filter(d => d.id !== debt.id));
    }
  };

  const handleSelectAllDebts = () => {
    if (selectedDebts.length === driverDebts.length) {
      setSelectedDebts([]);
    } else {
      setSelectedDebts([...driverDebts]);
    }
  };

  const handleSubmit = () => {
    if (!paymentDeadline || selectedDebts.length === 0) return;

    if (paymentMethod === "link" && !pixLink) {
      toast.error("Por favor, informe o link PIX");
      return;
    }

    const negotiationData: CreateNegotiationData = {
      driverId: driver.id,
      driverName: driver.fullName,
      driverCpf: driver.cpf,
      type: "debt",
      description: description || `Acordo para ${selectedDebts.length} débito(s) pendente(s)`,
      originalAmount: selectedDebtsTotal,
      selectedDebts,
      totalAmount: selectedDebtsTotal,
      proposedAmount,
      installments: installments > 1 ? installments : undefined,
      paymentDeadline,
      paymentMethod: paymentMethod,
      pixLink: paymentMethod === "link" ? pixLink : undefined,
      pixKey: paymentMethod === "pix" ? pixKey : undefined
    };

    onCreateNegotiation(negotiationData);
  };

  const handleCopyPix = () => {
    navigator.clipboard.writeText(pixKey);
    toast.success("Chave PIX copiada!");
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(pixLink);
    toast.success("Link PIX copiado!");
  };

  const getDebtTypeLabel = (type: string) => {
    switch (type) {
      case "rental": return "Aluguel";
      case "damage": return "Danos";
      case "fine": return "Multa";
      case "maintenance": return "Manutenção";
      default: return type;
    }
  };

  const getDebtTypeBadge = (type: string) => {
    const colorMap = {
      rental: "bg-blue-100 text-blue-800",
      damage: "bg-red-100 text-red-800", 
      fine: "bg-orange-100 text-orange-800",
      maintenance: "bg-green-100 text-green-800"
    };
    return colorMap[type as keyof typeof colorMap] || "bg-gray-100 text-gray-800";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Criar Acordo de Pagamento</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Informações do Motorista */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Informações do Motorista</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Nome</p>
                  <p className="font-medium">{driver.fullName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">CPF</p>
                  <p className="font-medium">{driver.cpf}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Dias Desativado</p>
                  <p className="font-medium">{driver.daysSinceDeactivation} dias</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total em Débito</p>
                  <p className="font-medium text-red-600">R$ {(driver.totalDebt || 0).toFixed(2)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Seleção de Débitos */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">Débitos Pendentes</CardTitle>
                {driverDebts.length > 0 && (
                  <Button variant="outline" size="sm" onClick={handleSelectAllDebts}>
                    {selectedDebts.length === driverDebts.length ? "Desmarcar Todos" : "Selecionar Todos"}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {driverDebts.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhum débito pendente encontrado
                </div>
              ) : (
                <div className="space-y-3">
                  {driverDebts.map((debt) => (
                    <div key={debt.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                      <input
                        type="checkbox"
                        checked={selectedDebts.some(d => d.id === debt.id)}
                        onChange={(e) => handleDebtSelection(debt, e.target.checked)}
                        className="rounded"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={getDebtTypeBadge(debt.type)}>
                            {getDebtTypeLabel(debt.type)}
                          </Badge>
                          {debt.isOverdue && (
                            <Badge variant="destructive">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Vencido
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm font-medium">{debt.description}</p>
                        <p className="text-xs text-muted-foreground">
                          Vencimento: {format(debt.dueDate, "dd/MM/yyyy", { locale: ptBR })}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-red-600">R$ {debt.amount.toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {selectedDebts.length > 0 && (
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Total Selecionado:</span>
                    <span className="font-bold text-blue-600">R$ {selectedDebtsTotal.toFixed(2)}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Configuração do Acordo */}
          {selectedDebts.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Configuração do Acordo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="proposedAmount">Valor Proposto (Opcional)</Label>
                    <Input
                      id="proposedAmount"
                      type="number"
                      step="0.01"
                      placeholder={`Original: R$ ${selectedDebtsTotal.toFixed(2)}`}
                      value={proposedAmount || ""}
                      onChange={(e) => setProposedAmount(parseFloat(e.target.value) || undefined)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Deixe vazio para manter o valor original
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="installments">Número de Parcelas</Label>
                    <Select value={installments.toString()} onValueChange={(v) => setInstallments(parseInt(v))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1x (À vista)</SelectItem>
                        <SelectItem value="2">2x</SelectItem>
                        <SelectItem value="3">3x</SelectItem>
                        <SelectItem value="4">4x</SelectItem>
                        <SelectItem value="5">5x</SelectItem>
                        <SelectItem value="6">6x</SelectItem>
                        <SelectItem value="12">12x</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Prazo para Resposta</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {paymentDeadline ? format(paymentDeadline, "dd/MM/yyyy", { locale: ptBR }) : "Selecionar data"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={paymentDeadline}
                        onSelect={setPaymentDeadline}
                        locale={ptBR}
                        disabled={(date) => date < new Date()}
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Observações (Opcional)</Label>
                  <Textarea
                    id="description"
                    placeholder="Adicione observações sobre o acordo..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>

                {/* Seção de Método de Pagamento */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Método de Pagamento PIX</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <RadioGroup value={paymentMethod} onValueChange={(value: "link" | "pix") => setPaymentMethod(value)}>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="link" id="link" />
                        <Label htmlFor="link" className="flex items-center gap-2">
                          <Link className="h-4 w-4" />
                          Link PIX
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="pix" id="pix" />
                        <Label htmlFor="pix" className="flex items-center gap-2">
                          <QrCode className="h-4 w-4" />
                          Chave PIX Fixa
                        </Label>
                      </div>
                    </RadioGroup>

                    {paymentMethod === "link" && (
                      <div className="space-y-2">
                        <Label htmlFor="pixLink">Link PIX</Label>
                        <div className="flex gap-2">
                          <Input
                            id="pixLink"
                            placeholder="https://pix.exemplo.com/pagamento/123"
                            value={pixLink}
                            onChange={(e) => setPixLink(e.target.value)}
                            required
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            onClick={handleCopyLink}
                            disabled={!pixLink}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Insira o link PIX gerado pela sua instituição financeira
                        </p>
                      </div>
                    )}

                    {paymentMethod === "pix" && (
                      <div className="space-y-2">
                        <Label htmlFor="pixKey">Chave PIX</Label>
                        <div className="flex gap-2">
                          <Input
                            id="pixKey"
                            placeholder="pix@minhalocadora.com.br"
                            value={pixKey}
                            onChange={(e) => setPixKey(e.target.value)}
                          />
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            onClick={handleCopyPix}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Esta chave PIX será enviada junto com a proposta de acordo
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Resumo do Acordo */}
                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-medium mb-2 flex items-center">
                    <DollarSign className="h-4 w-4 mr-2" />
                    Resumo do Acordo
                  </h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Valor Original:</span>
                      <span>R$ {selectedDebtsTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Valor do Acordo:</span>
                      <span className="font-medium">R$ {(proposedAmount || selectedDebtsTotal).toFixed(2)}</span>
                    </div>
                    {installments > 1 && (
                      <div className="flex justify-between">
                        <span>Valor da Parcela:</span>
                        <span className="font-medium">R$ {installmentValue.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Parcelas:</span>
                      <span>{installments}x</span>
                    </div>
                    {proposedAmount && proposedAmount < selectedDebtsTotal && (
                      <div className="flex justify-between text-green-600">
                        <span>Desconto:</span>
                        <span>R$ {(selectedDebtsTotal - proposedAmount).toFixed(2)}</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleSubmit}
              disabled={selectedDebts.length === 0 || !paymentDeadline}
            >
              Criar Acordo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const getDebtTypeLabel = (type: string) => {
  switch (type) {
    case "rental": return "Aluguel";
    case "damage": return "Danos";
    case "fine": return "Multa";
    case "maintenance": return "Manutenção";
    default: return type;
  }
};

const getDebtTypeBadge = (type: string) => {
  const colorMap = {
    rental: "bg-blue-100 text-blue-800",
    damage: "bg-red-100 text-red-800", 
    fine: "bg-orange-100 text-orange-800",
    maintenance: "bg-green-100 text-green-800"
  };
  return colorMap[type as keyof typeof colorMap] || "bg-gray-100 text-gray-800";
};
