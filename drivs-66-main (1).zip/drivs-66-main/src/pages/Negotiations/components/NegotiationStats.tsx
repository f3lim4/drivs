
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Negotiation } from "../types";
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  DollarSign, 
  TrendingUp,
  Users,
  FileText
} from "lucide-react";

interface NegotiationStatsProps {
  negotiations: Negotiation[];
}

export const NegotiationStats = ({ negotiations }: NegotiationStatsProps) => {
  const totalNegotiations = negotiations.length;
  const pendingNegotiations = negotiations.filter(n => n.status === "pending").length;
  const completedNegotiations = negotiations.filter(n => n.status === "completed").length;
  const overdueNegotiations = negotiations.filter(n => n.status === "overdue").length;
  const rejectedNegotiations = negotiations.filter(n => n.status === "rejected").length;
  
  const totalValue = negotiations.reduce((sum, n) => sum + (n.negotiatedAmount || n.originalAmount), 0);
  const completedValue = negotiations
    .filter(n => n.status === "completed")
    .reduce((sum, n) => sum + (n.negotiatedAmount || n.originalAmount), 0);
  
  const successRate = totalNegotiations > 0 ? (completedNegotiations / totalNegotiations) * 100 : 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Total de Negociações
          </CardTitle>
          <FileText className="h-4 w-4 text-blue-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-blue-600">{totalNegotiations}</div>
          <p className="text-xs text-muted-foreground">
            {pendingNegotiations} pendentes
          </p>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-green-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Concluídas
          </CardTitle>
          <CheckCircle className="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-600">{completedNegotiations}</div>
          <p className="text-xs text-muted-foreground">
            R$ {completedValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} recuperados
          </p>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-red-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Problemas
          </CardTitle>
          <AlertTriangle className="h-4 w-4 text-red-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-600">{overdueNegotiations + rejectedNegotiations}</div>
          <p className="text-xs text-muted-foreground">
            {overdueNegotiations} em atraso, {rejectedNegotiations} rejeitadas
          </p>
        </CardContent>
      </Card>

      <Card className="border-l-4 border-l-yellow-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Taxa de Sucesso
          </CardTitle>
          <TrendingUp className="h-4 w-4 text-yellow-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-yellow-600">{successRate.toFixed(1)}%</div>
          <p className="text-xs text-muted-foreground">
            R$ {totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} total
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
