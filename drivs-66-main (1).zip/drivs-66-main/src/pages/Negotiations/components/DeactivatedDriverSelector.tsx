import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Users } from "lucide-react";
import { DeactivatedDriver } from "../types";

interface DeactivatedDriverSelectorProps {
  onSelectDriver: (driver: DeactivatedDriver) => void;
  buttonText?: string;
  buttonIcon?: React.ReactNode;
  title?: string;
  filterForBlacklist?: boolean;
}

export const DeactivatedDriverSelector = ({ 
  onSelectDriver, 
  buttonText = "Selecionar Motorista Desativado",
  buttonIcon = <Users className="h-4 w-4 mr-2" />,
  title = "Selecionar Motorista Desativado",
  filterForBlacklist = false
}: DeactivatedDriverSelectorProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [deactivatedDrivers] = useState<DeactivatedDriver[]>([
    {
      id: "1",
      fullName: "João Silva",
      cpf: "123.456.789-00",
      deactivationDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      canBlacklist: true,
      daysSinceDeactivation: 10,
      totalDebt: 1200.50,
      openDebts: [
        {
          id: "debt1",
          type: "rental",
          description: "Aluguel em atraso - Março 2024",
          amount: 800.00,
          dueDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
          isOverdue: true
        },
        {
          id: "debt2",
          type: "fine",
          description: "Multa por velocidade",
          amount: 400.50,
          dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
          isOverdue: true
        }
      ]
    },
    {
      id: "2", 
      fullName: "Maria Santos",
      cpf: "987.654.321-00",
      deactivationDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      canBlacklist: false,
      daysSinceDeactivation: 5,
      totalDebt: 650.00,
      openDebts: [
        {
          id: "debt3",
          type: "damage",
          description: "Danos no veículo",
          amount: 650.00,
          dueDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          isOverdue: true
        }
      ]
    },
    {
      id: "3",
      fullName: "Carlos Oliveira", 
      cpf: "456.789.123-00",
      deactivationDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
      lastNegotiationDate: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
      canBlacklist: true,
      daysSinceDeactivation: 15,
      totalDebt: 2100.75,
      openDebts: [
        {
          id: "debt4",
          type: "rental",
          description: "Aluguel em atraso - Fevereiro 2024",
          amount: 800.00,
          dueDate: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000),
          isOverdue: true
        },
        {
          id: "debt5",
          type: "maintenance",
          description: "Manutenção preventiva",
          amount: 500.75,
          dueDate: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
          isOverdue: true
        },
        {
          id: "debt6",
          type: "fine",
          description: "Multa por estacionamento irregular",
          amount: 800.00,
          dueDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          isOverdue: true
        }
      ]
    }
  ]);

  const getFilteredDrivers = () => {
    let filtered = deactivatedDrivers;

    if (filterForBlacklist) {
      filtered = filtered.filter(driver => driver.canBlacklist);
    }

    if (searchTerm) {
      filtered = filtered.filter(driver =>
        driver.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        driver.cpf.includes(searchTerm)
      );
    }

    return filtered;
  };

  const filteredDrivers = getFilteredDrivers();

  const handleSelectDriver = (driver: DeactivatedDriver) => {
    onSelectDriver(driver);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          {buttonIcon}
          {buttonText}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="search">Buscar motorista</Label>
            <Input
              id="search"
              placeholder="Digite o nome ou CPF do motorista"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>CPF</TableHead>
                  <TableHead>Dias Desativado</TableHead>
                  <TableHead>Total Débito</TableHead>
                  <TableHead>Última Negociação</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDrivers.map((driver) => (
                  <TableRow key={driver.id}>
                    <TableCell className="font-medium">{driver.fullName}</TableCell>
                    <TableCell>{driver.cpf}</TableCell>
                    <TableCell>{driver.daysSinceDeactivation} dias</TableCell>
                    <TableCell className="text-red-600 font-medium">
                      R$ {driver.totalDebt.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      {driver.lastNegotiationDate 
                        ? new Date(driver.lastNegotiationDate).toLocaleDateString()
                        : "Nunca"
                      }
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        onClick={() => handleSelectDriver(driver)}
                        disabled={filterForBlacklist && !driver.canBlacklist}
                      >
                        Selecionar
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredDrivers.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              Nenhum motorista encontrado
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
