
export interface Negotiation {
  id: string;
  driverId: string;
  driverName: string;
  driverCpf: string;
  companyId: string;
  companyName: string;
  type: "debt" | "violation" | "contract" | "payment";
  status: "pending" | "in_progress" | "agreed" | "rejected" | "completed" | "overdue";
  description: string;
  originalAmount: number;
  negotiatedAmount?: number;
  installments?: number;
  installmentValue?: number;
  dueDate?: Date;
  paymentDeadline?: Date;
  createdAt: Date;
  updatedAt: Date;
  messages: NegotiationMessage[];
  debts: NegotiationDebt[];
  payments: NegotiationPayment[];
}

export interface NegotiationDebt {
  id: string;
  type: "rental" | "damage" | "fine" | "maintenance";
  description: string;
  amount: number;
  dueDate: Date;
  isOverdue: boolean;
}

interface NegotiationPayment {
  id: string;
  installmentNumber: number;
  amount: number;
  dueDate: Date;
  paidDate?: Date;
  status: "pending" | "paid" | "overdue";
}

interface NegotiationMessage {
  id: string;
  negotiationId: string;
  senderId: string;
  senderName: string;
  senderType: "driver" | "company" | "admin";
  message: string;
  createdAt: Date;
  attachments?: MessageAttachment[];
}

interface MessageAttachment {
  id: string;
  name: string;
  type: "image" | "document";
  url: string;
  size: number;
  uploadedAt: Date;
}

export interface CreateNegotiationData {
  driverId: string;
  driverName: string;
  driverCpf: string;
  type: "debt" | "violation" | "contract" | "payment";
  description: string;
  originalAmount: number;
  selectedDebts: NegotiationDebt[];
  totalAmount: number;
  proposedAmount?: number;
  installments?: number;
  paymentDeadline: Date;
  paymentMethod?: "link" | "pix";
  pixLink?: string;
  pixKey?: string;
}

export interface DeactivatedDriver {
  id: string;
  fullName: string;
  cpf: string;
  deactivationDate: Date;
  lastNegotiationDate?: Date;
  canBlacklist: boolean;
  daysSinceDeactivation: number;
  openDebts: NegotiationDebt[];
  totalDebt: number;
}

interface BlacklistRequest {
  id: string;
  driverId: string;
  driverName: string;
  driverCpf: string;
  companyId: string;
  companyName: string;
  requestDate: Date;
  reason: string;
  observations?: string;
  status: "pending" | "approved" | "rejected";
}
