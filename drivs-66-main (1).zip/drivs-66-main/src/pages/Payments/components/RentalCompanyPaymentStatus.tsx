
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Clock, AlertTriangle, Eye, Edit, Trash2 } from "lucide-react";
import { ViewPaymentDialog } from "./ViewPaymentDialog";
import { EditPaymentDialog } from "./EditPaymentDialog";
import { DeletePaymentDialog } from "./DeletePaymentDialog";
import { RentalCompanyPaymentSummary } from "./RentalCompanyPaymentSummary";

interface DriverPayment {
  id: string;
  driverName: string;
  driverCpf: string;
  amount: number;
  dueDate: string;
  status: "paid" | "pending" | "overdue";
  description: string;
}

// Mock data para pagamentos dos motoristas da locadora
const initialMockDriverPayments: DriverPayment[] = [
  {
    id: "1",
    driverName: "João Silva",
    driverCpf: "123.456.789-00",
    amount: 450.00,
    dueDate: "2024-01-15",
    status: "paid",
    description: "Aluguel semanal"
  },
  {
    id: "2", 
    driverName: "Maria Santos",
    driverCpf: "987.654.321-00",
    amount: 450.00,
    dueDate: "2024-01-20",
    status: "pending",
    description: "Aluguel semanal"
  },
  {
    id: "3",
    driverName: "Pedro Costa",
    driverCpf: "456.789.123-00", 
    amount: 200.00,
    dueDate: "2024-01-10",
    status: "overdue",
    description: "Multa de trânsito"
  },
  {
    id: "4",
    driverName: "Ana Lima", 
    driverCpf: "321.654.987-00",
    amount: 450.00,
    dueDate: "2024-01-18",
    status: "paid",
    description: "Aluguel semanal"
  },
  {
    id: "5",
    driverName: "Carlos Oliveira",
    driverCpf: "789.123.456-00",
    amount: 350.00,
    dueDate: "2024-01-12",
    status: "overdue", 
    description: "Reparo no veículo"
  },
  {
    id: "6",
    driverName: "Lucia Ferreira",
    driverCpf: "654.321.987-00",
    amount: 450.00,
    dueDate: "2024-01-22",
    status: "pending",
    description: "Aluguel semanal"
  }
];

export const RentalCompanyPaymentStatus = () => {
  const [mockDriverPayments, setMockDriverPayments] = useState<DriverPayment[]>(initialMockDriverPayments);
  const [selectedPayment, setSelectedPayment] = useState<DriverPayment | null>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  const getStatusBadge = (status: DriverPayment["status"]) => {
    switch (status) {
      case "paid":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Pago</Badge>;
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Em Aberto</Badge>;
      case "overdue":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Atrasado</Badge>;
    }
  };

  const handleView = (payment: DriverPayment) => {
    setSelectedPayment(payment);
    setViewDialogOpen(true);
  };

  const handleEdit = (payment: DriverPayment) => {
    setSelectedPayment(payment);
    setEditDialogOpen(true);
  };

  const handleDelete = (payment: DriverPayment) => {
    setSelectedPayment(payment);
    setDeleteDialogOpen(true);
  };

  const handleSaveEdit = (updatedPayment: DriverPayment) => {
    setMockDriverPayments(prev => 
      prev.map(payment => 
        payment.id === updatedPayment.id ? updatedPayment : payment
      )
    );
  };

  const handleConfirmDelete = (paymentId: string) => {
    setMockDriverPayments(prev => 
      prev.filter(payment => payment.id !== paymentId)
    );
  };

  return (
    <div className="space-y-6">
      {/* Painel de resumo no topo */}
      <RentalCompanyPaymentSummary payments={mockDriverPayments} />
      
      {/* Card único com histórico de pagamentos com borda lateral colorida */}
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader>
          <CardTitle className="text-card-foreground uppercase text-lg">PAGAMENTOS</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Motorista</TableHead>
                  <TableHead>CPF</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockDriverPayments.map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell className="font-medium">{payment.driverName}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{payment.driverCpf}</TableCell>
                    <TableCell>{payment.description}</TableCell>
                    <TableCell>{formatCurrency(payment.amount)}</TableCell>
                    <TableCell>{formatDate(payment.dueDate)}</TableCell>
                    <TableCell>{getStatusBadge(payment.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleView(payment)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleEdit(payment)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleDelete(payment)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialogs */}
      <ViewPaymentDialog 
        payment={selectedPayment}
        open={viewDialogOpen}
        onClose={() => {
          setViewDialogOpen(false);
          setSelectedPayment(null);
        }}
      />

      <EditPaymentDialog 
        payment={selectedPayment}
        open={editDialogOpen}
        onClose={() => {
          setEditDialogOpen(false);
          setSelectedPayment(null);
        }}
        onSave={handleSaveEdit}
      />

      <DeletePaymentDialog 
        payment={selectedPayment}
        open={deleteDialogOpen}
        onClose={() => {
          setDeleteDialogOpen(false);
          setSelectedPayment(null);
        }}
        onDelete={handleConfirmDelete}
      />
    </div>
  );
};
