
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { VehicleExpenseForm } from "./VehicleExpenseForm";

interface Vehicle {
  id: string;
  plate: string;
  model: string;
  brand: string;
  driverName?: string;
  driverPhone?: string;
}

interface VehicleExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vehicles: Vehicle[];
}

export const VehicleExpenseDialog = ({
  open,
  onOpenChange,
  vehicles
}: VehicleExpenseDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Cadastrar Despesa de Veículos</DialogTitle>
        </DialogHeader>

        <VehicleExpenseForm
          vehicles={vehicles}
          onClose={() => onOpenChange(false)}
        />
      </DialogContent>
    </Dialog>
  );
};
