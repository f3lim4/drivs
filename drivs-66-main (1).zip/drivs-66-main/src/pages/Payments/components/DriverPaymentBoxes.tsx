
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, DollarSign, AlertTriangle, Calendar } from "lucide-react";
import { Payment } from "../data";
import { PixPaymentDialog } from "./PixPaymentDialog";
import { useState } from "react";

interface DriverPaymentBoxesProps {
  payments: Payment[];
  onPayment: (payment: Payment) => void;
}

export const DriverPaymentBoxes = ({ payments, onPayment }: DriverPaymentBoxesProps) => {
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);
  const [showPixDialog, setShowPixDialog] = useState(false);

  // Agrupa pagamentos por status
  const pendingPayments = payments.filter(p => p.status === "pending");
  const overduePayments = payments.filter(p => p.status === "overdue");
  const weeklyRentals = payments.filter(p => p.type === "weekly_rental" && (p.status === "pending" || p.status === "overdue"));

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  const handlePayClick = (payment: Payment) => {
    setSelectedPayment(payment);
    setShowPixDialog(true);
  };

  const handlePixPaymentComplete = () => {
    if (selectedPayment) {
      onPayment(selectedPayment);
    }
    setShowPixDialog(false);
    setSelectedPayment(null);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Caixa de Pagamentos Pendentes */}
      {pendingPayments.length > 0 && (
        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-700">
              <Clock className="h-5 w-5" />
              Pagamentos a Fazer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {pendingPayments.slice(0, 3).map((payment) => (
              <div key={payment.id} className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                <div>
                  <p className="font-medium text-sm">{payment.description}</p>
                  <p className="text-xs text-gray-600">Venc: {formatDate(payment.dueDate)}</p>
                  <p className="font-bold text-yellow-700">R$ {payment.amount.toFixed(2)}</p>
                </div>
                <Button 
                  size="sm" 
                  className="bg-yellow-600 hover:bg-yellow-700"
                  onClick={() => handlePayClick(payment)}
                >
                  Pagar
                </Button>
              </div>
            ))}
            {pendingPayments.length > 3 && (
              <p className="text-xs text-gray-500 text-center">
                +{pendingPayments.length - 3} pagamentos pendentes
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Caixa de Pagamentos Atrasados */}
      {overduePayments.length > 0 && (
        <Card className="border-l-4 border-l-red-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="h-5 w-5" />
              Pagamentos Atrasados
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {overduePayments.slice(0, 3).map((payment) => (
              <div key={payment.id} className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                <div>
                  <p className="font-medium text-sm">{payment.description}</p>
                  <p className="text-xs text-red-600">Venceu: {formatDate(payment.dueDate)}</p>
                  <p className="font-bold text-red-700">R$ {payment.amount.toFixed(2)}</p>
                </div>
                <Button 
                  size="sm" 
                  variant="destructive"
                  onClick={() => handlePayClick(payment)}
                >
                  Pagar
                </Button>
              </div>
            ))}
            {overduePayments.length > 3 && (
              <p className="text-xs text-gray-500 text-center">
                +{overduePayments.length - 3} pagamentos atrasados
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Caixa de Pagamento Semanal */}
      {weeklyRentals.length > 0 && (
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-700">
              <Calendar className="h-5 w-5" />
              Aluguel Semanal
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {weeklyRentals.slice(0, 2).map((payment) => (
              <div key={payment.id} className="p-3 bg-blue-50 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-medium text-sm">{payment.description}</p>
                    <p className="text-xs text-gray-600">Venc: {formatDate(payment.dueDate)}</p>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={payment.status === 'overdue' ? 'bg-red-100 text-red-800 border-red-300' : 'bg-yellow-100 text-yellow-800 border-yellow-300'}
                  >
                    {payment.status === 'overdue' ? 'Atrasado' : 'Em Aberto'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <p className="font-bold text-blue-700 text-lg">R$ {payment.amount.toFixed(2)}</p>
                  <Button 
                    size="sm" 
                    variant={payment.status === 'overdue' ? 'destructive' : 'default'}
                    onClick={() => handlePayClick(payment)}
                  >
                    Pagar Agora
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Dialog de Pagamento Pix */}
      <PixPaymentDialog 
        payment={selectedPayment}
        open={showPixDialog}
        onClose={() => {
          setShowPixDialog(false);
          setSelectedPayment(null);
        }}
        onPaymentComplete={handlePixPaymentComplete}
      />
    </div>
  );
};
