
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { QrCode, Upload, Copy, CheckCircle } from "lucide-react";
import { Payment } from "../data";
import { useState } from "react";
import { toast } from "sonner";

interface PixPaymentDialogProps {
  payment: Payment | null;
  open: boolean;
  onClose: () => void;
  onPaymentComplete: () => void;
}

export const PixPaymentDialog = ({ payment, open, onClose, onPaymentComplete }: PixPaymentDialogProps) => {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [pixKey, setPaixKey] = useState("");

  if (!payment) return null;

  // Dados fictícios da empresa para demonstração
  const companyPixData = {
    pixKey: "empresa@autorental.com",
    companyName: payment.companyName,
    qrCode: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==" // QR code placeholder
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  const handleCopyPixKey = () => {
    navigator.clipboard.writeText(companyPixData.pixKey);
    toast.success("Chave Pix copiada!");
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      toast.success("Comprovante anexado com sucesso!");
    }
  };

  const handleConfirmPayment = () => {
    if (!uploadedFile) {
      toast.error("Por favor, anexe o comprovante de pagamento.");
      return;
    }
    
    onPaymentComplete();
    toast.success("Pagamento enviado para análise!");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Pagamento via Pix</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Detalhes do Pagamento */}
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Descrição</p>
                  <p className="font-medium">{payment.description}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Vencimento</p>
                  <p className="font-medium">{formatDate(payment.dueDate)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Empresa</p>
                  <p className="font-medium">{payment.companyName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Valor</p>
                  <p className="font-bold text-xl text-blue-600">{formatCurrency(payment.amount)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Dados Pix da Empresa */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <QrCode className="h-5 w-5" />
                Dados para Pagamento
              </h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                {/* QR Code */}
                <div className="text-center">
                  <div className="bg-gray-100 p-4 rounded-lg mb-3">
                    <div className="w-40 h-40 mx-auto bg-white flex items-center justify-center border-2 border-dashed border-gray-300 rounded">
                      <QrCode className="h-16 w-16 text-gray-400" />
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">Escaneie o QR Code com seu app do banco</p>
                </div>

                {/* Chave Pix */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="pixKey">Chave Pix da Empresa</Label>
                    <div className="flex gap-2 mt-1">
                      <Input 
                        id="pixKey"
                        value={companyPixData.pixKey} 
                        readOnly 
                        className="bg-gray-50"
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={handleCopyPixKey}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Favorecido</p>
                    <p className="font-medium">{companyPixData.companyName}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Valor</p>
                    <p className="font-bold text-lg">{formatCurrency(payment.amount)}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Upload do Comprovante */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Anexar Comprovante
              </h3>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="file-upload">Comprovante de Pagamento</Label>
                  <Input 
                    id="file-upload"
                    type="file" 
                    accept="image/*,.pdf"
                    onChange={handleFileUpload}
                    className="mt-1"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Formatos aceitos: JPG, PNG, PDF (máx. 5MB)
                  </p>
                </div>
                
                {uploadedFile && (
                  <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="text-sm text-green-700">
                      {uploadedFile.name} anexado com sucesso
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Botões de Ação */}
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              onClick={handleConfirmPayment}
              disabled={!uploadedFile}
              className="bg-green-600 hover:bg-green-700"
            >
              Confirmar Pagamento
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
