
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface ExpenseFormFieldsProps {
  amount: string;
  onAmountChange: (value: string) => void;
  date: Date;
  onDateChange: (date: Date) => void;
  description: string;
  onDescriptionChange: (value: string) => void;
}

export const ExpenseFormFields = ({
  amount,
  onAmountChange,
  date,
  onDateChange,
  description,
  onDescriptionChange
}: ExpenseFormFieldsProps) => {
  const formatCurrency = (value: string) => {
    const numericValue = value.replace(/\D/g, '');
    const formattedValue = (parseFloat(numericValue) / 100).toFixed(2);
    return formattedValue;
  };

  const handleAmountChange = (value: string) => {
    const formatted = formatCurrency(value);
    onAmountChange(formatted);
  };

  return (
    <>
      <div>
        <Label htmlFor="amount">Valor Total (R$)</Label>
        <Input
          id="amount"
          type="text"
          value={amount}
          onChange={(e) => handleAmountChange(e.target.value)}
          placeholder="0,00"
        />
      </div>

      <div>
        <Label>Data da Despesa</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-full justify-start text-left font-normal",
                !date && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date ? format(date, "PPP", { locale: ptBR }) : "Selecionar data"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar
              mode="single"
              selected={date}
              onSelect={(date) => date && onDateChange(date)}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      <div>
        <Label htmlFor="description">Observações (Opcional)</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => onDescriptionChange(e.target.value)}
          placeholder="Detalhes adicionais sobre a despesa..."
          rows={3}
        />
      </div>
    </>
  );
};
