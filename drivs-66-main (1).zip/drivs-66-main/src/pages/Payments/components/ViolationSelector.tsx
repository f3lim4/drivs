
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

interface Violation {
  id: string;
  description: string;
  value: number;
}

interface ViolationSelectorProps {
  violations: Violation[];
  selectedViolations: string[];
  onViolationSelect: (violationId: string, checked: boolean) => void;
}

export const ViolationSelector = ({
  violations,
  selectedViolations,
  onViolationSelect
}: ViolationSelectorProps) => {
  if (violations.length === 0) {
    return (
      <div className="text-sm text-muted-foreground p-3 bg-muted rounded-md">
        Este motorista não possui infrações pendentes.
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <Label>Infrações Pendentes</Label>
      <div className="border rounded-md p-3 space-y-2 max-h-32 overflow-y-auto">
        {violations.map((violation) => (
          <div key={violation.id} className="flex items-center space-x-2">
            <Checkbox
              id={violation.id}
              checked={selectedViolations.includes(violation.id)}
              onCheckedChange={(checked) => onViolationSelect(violation.id, !!checked)}
            />
            <div className="flex-1">
              <p className="text-sm font-medium">{violation.description}</p>
              <p className="text-xs text-muted-foreground">R$ {violation.value.toFixed(2)}</p>
            </div>
          </div>
        ))}
      </div>
      <p className="text-xs text-muted-foreground">
        * Multa de 10% será aplicada automaticamente sobre o valor das infrações
      </p>
    </div>
  );
};
