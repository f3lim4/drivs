import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { Driver, DriverStatus, UserRole } from "@/types";
import { addNewPayment } from "../data";
import { useAuth } from "@/contexts/AuthContext";
import { getVehiclesByCompany } from "@/pages/RentalCompanies/data/mockVehicles";
import { PaymentFormFields } from "./PaymentFormFields";
import { ViolationSelector } from "./ViolationSelector";
import { PaymentMethodSelector } from "./PaymentMethodSelector";

interface CreatePaymentDialogProps {
  onPaymentCreated: () => void;
}

// Mock data de valores semanais por motorista
const weeklyRentalValues: Record<string, number> = {
  "motorista-ativo-001": 350.00,
  "1": 350.00,
  "2": 320.00,
  "3": 420.00,
};

// Mock data de infrações pendentes
const pendingViolations: Record<string, Array<{id: string, description: string, value: number}>> = {
  "motorista-ativo-001": [
    { id: "v1", description: "Estacionamento proibido", value: 263.23 },
    { id: "v2", description: "Uso de celular ao volante", value: 130.16 }
  ],
  "1": [
    { id: "v1", description: "Excesso de velocidade", value: 195.23 },
    { id: "v2", description: "Estacionamento proibido", value: 130.16 }
  ],
  "2": [],
  "3": [
    { id: "v3", description: "Avanço de sinal vermelho", value: 293.47 }
  ]
};

export const CreatePaymentDialog = ({ onPaymentCreated }: CreatePaymentDialogProps) => {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [activeDrivers, setActiveDrivers] = useState<Driver[]>([]);
  const [selectedViolations, setSelectedViolations] = useState<string[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<"link" | "pix">("link");
  const [paymentLink, setPaymentLink] = useState("");
  const [pixKey, setPixKey] = useState("pix@minhalocadora.com.br");
  const [formData, setFormData] = useState({
    driverId: "",
    driverName: "",
    amount: "",
    description: "",
    dueDate: "",
    type: "weekly_rental",
    dailyFineRate: "5.00",
    dailyInterestRate: "0.33"
  });

  useEffect(() => {
    if (user?.role === "rental_company") {
      // Obter motoristas da locadora específica através dos veículos alugados
      const companyVehicles = getVehiclesByCompany(user.id);
      const companyDrivers: Driver[] = companyVehicles
        .filter(vehicle => vehicle.status === "rented" && vehicle.driverInfo)
        .map(vehicle => ({
          id: vehicle.driverInfo!.id,
          email: `${vehicle.driverInfo!.name.toLowerCase().replace(' ', '.')}@email.com`,
          role: UserRole.DRIVER,
          fullName: vehicle.driverInfo!.name,
          cpf: "000.000.000-00",
          rg: "12.345.678-9",
          phone: "(11) 99999-9999",
          address: "Endereço do motorista",
          city: "São Paulo",
          state: "SP",
          cnh: "12345678901",
          cnh_expires: "2025-12-31",
          status: DriverStatus.ACTIVE,
          available: true,
          rating: 4.5,
          violations: 0,
          created_at: "2024-01-15",
          updated_at: "2024-01-15",
          activeContract: {
            companyId: parseInt(user.id.replace('r', '')),
            companyName: user.id === 'r1' ? 'Auto Rental Plus' : user.id === 'r2' ? 'Speed Car Rental' : 'Premium Motors',
            vehicleModel: `${vehicle.brand} ${vehicle.model}`,
            contractStart: vehicle.driverInfo!.contractStartDate,
            contractEnd: new Date(new Date(vehicle.driverInfo!.contractStartDate).setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0]
          }
        }));

      setActiveDrivers(companyDrivers);
    }
  }, [user]);

  const handleDriverSelect = (driverId: string) => {
    const selectedDriver = activeDrivers.find(driver => driver.id === driverId);
    if (selectedDriver) {
      setFormData(prev => ({
        ...prev,
        driverId: driverId,
        driverName: selectedDriver.fullName
      }));
      
      // Atualizar valor automaticamente se for aluguel semanal
      if (formData.type === "weekly_rental") {
        const weeklyValue = weeklyRentalValues[driverId] || 0;
        setFormData(prev => ({
          ...prev,
          amount: weeklyValue.toString()
        }));
      }
    }
  };

  const handleTypeChange = (type: string) => {
    setFormData(prev => ({ ...prev, type }));
    
    if (type === "weekly_rental" && formData.driverId) {
      const weeklyValue = weeklyRentalValues[formData.driverId] || 0;
      setFormData(prev => ({
        ...prev,
        amount: weeklyValue.toString()
      }));
    } else if (type === "violation" && formData.driverId) {
      const violations = pendingViolations[formData.driverId] || [];
      const totalViolationValue = violations.reduce((sum, v) => sum + v.value, 0);
      const fineValue = totalViolationValue * 0.1; // 10% de multa
      const totalWithFine = totalViolationValue + fineValue;
      
      setFormData(prev => ({
        ...prev,
        amount: totalWithFine.toFixed(2),
        description: `Infrações pendentes + 10% multa (${violations.length} infrações)`
      }));
    } else {
      setFormData(prev => ({ ...prev, amount: "" }));
    }
  };

  const handleViolationSelect = (violationId: string, checked: boolean) => {
    let newSelectedViolations: string[];
    if (checked) {
      newSelectedViolations = [...selectedViolations, violationId];
    } else {
      newSelectedViolations = selectedViolations.filter(id => id !== violationId);
    }
    setSelectedViolations(newSelectedViolations);
    
    // Recalcular valor das infrações
    if (formData.driverId && formData.type === "violation") {
      const allViolations = pendingViolations[formData.driverId] || [];
      const selectedViolationData = allViolations.filter(v => newSelectedViolations.includes(v.id));
      const totalValue = selectedViolationData.reduce((sum, v) => sum + v.value, 0);
      const fineValue = totalValue * 0.1;
      const totalWithFine = totalValue + fineValue;
      
      setFormData(prev => ({
        ...prev,
        amount: totalWithFine.toFixed(2),
        description: `${selectedViolationData.length} infrações selecionadas + 10% multa`
      }));
    }
  };

  const handleFormDataChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.driverId) {
      toast.error("Por favor, selecione um motorista");
      return;
    }
    
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      toast.error("Por favor, informe um valor válido");
      return;
    }
    
    if (!formData.dueDate) {
      toast.error("Por favor, informe a data de vencimento");
      return;
    }

    if (paymentMethod === "link" && !paymentLink) {
      toast.error("Por favor, informe o link de cobrança");
      return;
    }
    
    // Criar o novo pagamento
    const newPayment = {
      contractId: `CTR-2024-${formData.driverId.padStart(3, '0')}`,
      driverId: formData.driverId,
      driverName: formData.driverName,
      companyId: user?.id || "r1",
      companyName: user?.id === 'r1' ? 'Auto Rental Plus' : user?.id === 'r2' ? 'Speed Car Rental' : 'Premium Motors',
      amount: parseFloat(formData.amount),
      status: "pending" as const,
      dueDate: formData.dueDate,
      description: formData.description,
      type: formData.type,
      dailyFineRate: parseFloat(formData.dailyFineRate),
      dailyInterestRate: parseFloat(formData.dailyInterestRate),
      paymentMethod: paymentMethod,
      paymentLink: paymentMethod === "link" ? paymentLink : undefined,
      pixKey: paymentMethod === "pix" ? pixKey : undefined
    };
    
    // Adicionar o pagamento aos dados mockados
    const savedPayment = addNewPayment(newPayment);
    
    toast.success(`Pagamento ${savedPayment.id} de R$ ${parseFloat(formData.amount).toFixed(2)} criado para ${formData.driverName}`);
    
    setOpen(false);
    setFormData({
      driverId: "",
      driverName: "",
      amount: "",
      description: "",
      dueDate: "",
      type: "weekly_rental",
      dailyFineRate: "5.00",
      dailyInterestRate: "0.33"
    });
    setSelectedViolations([]);
    setPaymentLink("");
    
    onPaymentCreated();
  };

  const driverViolations = formData.driverId ? pendingViolations[formData.driverId] || [] : [];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Criar Pagamento
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Criar Novo Pagamento</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <PaymentFormFields
            activeDrivers={activeDrivers}
            formData={formData}
            onDriverSelect={handleDriverSelect}
            onTypeChange={handleTypeChange}
            onFormDataChange={handleFormDataChange}
          />

          {formData.type === "violation" && (
            <ViolationSelector
              violations={driverViolations}
              selectedViolations={selectedViolations}
              onViolationSelect={handleViolationSelect}
            />
          )}

          <PaymentMethodSelector
            paymentMethod={paymentMethod}
            paymentLink={paymentLink}
            pixKey={pixKey}
            onPaymentMethodChange={setPaymentMethod}
            onPaymentLinkChange={setPaymentLink}
            onPixKeyChange={setPixKey}
          />
          
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit">
              Criar Pagamento
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
