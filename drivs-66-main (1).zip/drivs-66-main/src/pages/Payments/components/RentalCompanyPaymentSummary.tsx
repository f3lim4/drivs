
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, Clock, AlertTriangle, CreditCard } from "lucide-react";

interface DriverPayment {
  id: string;
  driverName: string;
  driverCpf: string;
  amount: number;
  dueDate: string;
  status: "paid" | "pending" | "overdue";
  description: string;
}

interface RentalCompanyPaymentSummaryProps {
  payments: DriverPayment[];
}

export const RentalCompanyPaymentSummary = ({ payments }: RentalCompanyPaymentSummaryProps) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Calcular valores
  const valoresEmAberto = payments
    .filter(p => p.status === "pending")
    .reduce((sum, p) => sum + p.amount, 0);

  const valoresPagos = payments
    .filter(p => p.status === "paid")
    .reduce((sum, p) => sum + p.amount, 0);

  const valoresAtrasados = payments
    .filter(p => p.status === "overdue")
    .reduce((sum, p) => sum + p.amount, 0);

  const valorTotalAReceber = valoresEmAberto + valoresAtrasados;

  const entradaTotal = valoresPagos;

  const summaryCards = [
    {
      title: "Em Aberto",
      value: valoresEmAberto,
      icon: Clock,
      color: "text-yellow-600",
      bgColor: "bg-white",
      borderColor: "border-l-yellow-400"
    },
    {
      title: "Pagos",
      value: valoresPagos,
      icon: CreditCard,
      color: "text-green-600",
      bgColor: "bg-white",
      borderColor: "border-l-green-400"
    },
    {
      title: "Atrasados",
      value: valoresAtrasados,
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-white",
      borderColor: "border-l-red-400"
    },
    {
      title: "Total a Receber",
      value: valorTotalAReceber,
      icon: DollarSign,
      color: "text-blue-600",
      bgColor: "bg-white",
      borderColor: "border-l-blue-400"
    },
    {
      title: "Total Entrada",
      value: entradaTotal,
      icon: TrendingUp,
      color: "text-purple-600",
      bgColor: "bg-white",
      borderColor: "border-l-purple-400"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      {summaryCards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index} className={`${card.bgColor} ${card.borderColor} border-l-2 border border-gray-200`}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  {card.title}
                </CardTitle>
                <Icon className={`h-5 w-5 ${card.color}`} />
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className={`text-base font-bold ${card.color}`}>
                {formatCurrency(card.value)}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};
