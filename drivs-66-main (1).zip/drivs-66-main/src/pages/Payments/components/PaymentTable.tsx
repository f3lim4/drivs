
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { UserRole } from "@/types";
import { AlertTriangle } from "lucide-react";

interface Payment {
  id: string;
  contractId: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  amount: number;
  status: "paid" | "pending" | "overdue" | "cancelled";
  dueDate: string;
  paidDate?: string;
  paymentMethod?: string;
  description: string;
}

interface PaymentTableProps {
  payments: Payment[];
  userRole?: UserRole;
  onPay: (payment: Payment) => void;
  onBlacklist: (payment: Payment) => void;
}

export const PaymentTable = ({ payments, userRole, onPay, onBlacklist }: PaymentTableProps) => {
  // Função para obter a badge de status com a cor correta
  const getStatusBadge = (status: Payment["status"]) => {
    switch (status) {
      case "paid":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Pago</Badge>;
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Em Aberto</Badge>;
      case "overdue":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Atrasado</Badge>;
      case "cancelled":
        return <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">Cancelado</Badge>;
    }
  };

  // Função para formatar data no padrão brasileiro
  const formatDate = (dateString?: string) => {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };

  return (
    <div className="border rounded-md overflow-hidden">
      <Table>
        <TableCaption>Lista de pagamentos</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>ID do Pagamento</TableHead>
            {(userRole === UserRole.RENTAL_COMPANY || userRole === UserRole.ADMIN) && (
              <TableHead>Motorista</TableHead>
            )}
            {(userRole === UserRole.DRIVER || userRole === UserRole.ADMIN) && (
              <TableHead>Empresa</TableHead>
            )}
            <TableHead>Descrição</TableHead>
            <TableHead>Valor</TableHead>
            <TableHead>Vencimento</TableHead>
            <TableHead>Data Pagamento</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {payments.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-4 text-muted-foreground">
                Nenhum pagamento encontrado
              </TableCell>
            </TableRow>
          ) : (
            payments.map((payment) => (
              <TableRow key={payment.id}>
                <TableCell className="font-medium">{payment.id}</TableCell>
                {(userRole === UserRole.RENTAL_COMPANY || userRole === UserRole.ADMIN) && (
                  <TableCell>{payment.driverName}</TableCell>
                )}
                {(userRole === UserRole.DRIVER || userRole === UserRole.ADMIN) && (
                  <TableCell>{payment.companyName}</TableCell>
                )}
                <TableCell>
                  <div>{payment.description}</div>
                  <div className="text-xs text-muted-foreground">
                    Contrato: {payment.contractId}
                  </div>
                </TableCell>
                <TableCell>R$ {payment.amount.toFixed(2)}</TableCell>
                <TableCell>{formatDate(payment.dueDate)}</TableCell>
                <TableCell>
                  {payment.paidDate ? (
                    <div>
                      <div>{formatDate(payment.paidDate)}</div>
                      {payment.paymentMethod && (
                        <div className="text-xs text-muted-foreground">{payment.paymentMethod}</div>
                      )}
                    </div>
                  ) : (
                    <span className="text-muted-foreground">-</span>
                  )}
                </TableCell>
                <TableCell>{getStatusBadge(payment.status)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    {payment.status === "pending" && userRole === UserRole.DRIVER && (
                      <Button size="sm" onClick={() => onPay(payment)}>Pagar</Button>
                    )}
                    {(payment.status === "overdue" || payment.status === "pending") && 
                      userRole === UserRole.RENTAL_COMPANY && (
                      <Button 
                        size="sm" 
                        variant="destructive" 
                        onClick={() => onBlacklist(payment)}
                      >
                        <AlertTriangle className="h-4 w-4 mr-1" /> Negativar
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};
