
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

interface DriverPayment {
  id: string;
  driverName: string;
  driverCpf: string;
  amount: number;
  dueDate: string;
  status: "paid" | "pending" | "overdue";
  description: string;
}

interface DeletePaymentDialogProps {
  payment: DriverPayment | null;
  open: boolean;
  onClose: () => void;
  onDelete: (paymentId: string) => void;
}

export const DeletePaymentDialog = ({ payment, open, onClose, onDelete }: DeletePaymentDialogProps) => {
  const handleDelete = () => {
    if (payment) {
      onDelete(payment.id);
      toast.success(`Pagamento de ${payment.driverName} excluído com sucesso!`);
      onClose();
    }
  };

  if (!payment) return null;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <AlertDialog open={open} onOpenChange={onClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Excluir Pagamento</AlertDialogTitle>
          <AlertDialogDescription>
            Tem certeza que deseja excluir o pagamento de <strong>{formatCurrency(payment.amount)}</strong> do motorista <strong>{payment.driverName}</strong>?
            <br /><br />
            Esta ação não pode ser desfeita.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancelar</AlertDialogCancel>
          <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
            Excluir
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
