
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Driver } from "@/types";

interface PaymentFormFieldsProps {
  activeDrivers: Driver[];
  formData: {
    driverId: string;
    driverName: string;
    amount: string;
    description: string;
    dueDate: string;
    type: string;
    dailyFineRate: string;
    dailyInterestRate: string;
  };
  onDriverSelect: (driverId: string) => void;
  onTypeChange: (type: string) => void;
  onFormDataChange: (field: string, value: string) => void;
}

export const PaymentFormFields = ({
  activeDrivers,
  formData,
  onDriverSelect,
  onTypeChange,
  onFormDataChange
}: PaymentFormFieldsProps) => {
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="driver">Motorista</Label>
        <Select value={formData.driverId} onValueChange={onDriverSelect}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione um motorista" />
          </SelectTrigger>
          <SelectContent>
            {activeDrivers.map((driver) => (
              <SelectItem key={driver.id} value={driver.id}>
                <div className="flex flex-col">
                  <span className="font-medium">{driver.fullName}</span>
                  <span className="text-sm text-muted-foreground">{driver.phone}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {activeDrivers.length === 0 && (
          <p className="text-sm text-muted-foreground">
            Nenhum motorista ativo encontrado para esta locadora
          </p>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="type">Tipo de Pagamento</Label>
        <Select value={formData.type} onValueChange={onTypeChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione o tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="weekly_rental">Aluguel Semanal</SelectItem>
            <SelectItem value="violation">Infrações</SelectItem>
            <SelectItem value="maintenance">Manutenção</SelectItem>
            <SelectItem value="damage">Danos</SelectItem>
            <SelectItem value="other">Outros</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="amount">Valor (R$)</Label>
        <Input
          id="amount"
          type="number"
          step="0.01"
          placeholder="0,00"
          value={formData.amount}
          onChange={(e) => onFormDataChange('amount', e.target.value)}
          required
        />
        {formData.type === "weekly_rental" && formData.driverId && (
          <p className="text-xs text-muted-foreground">
            Valor automático do contrato. Você pode alterar se necessário.
          </p>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="dueDate">Data de Vencimento</Label>
        <Input
          id="dueDate"
          type="date"
          value={formData.dueDate}
          onChange={(e) => onFormDataChange('dueDate', e.target.value)}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="dailyFine">Multa Diária (%)</Label>
          <Input
            id="dailyFine"
            type="number"
            step="0.01"
            value={formData.dailyFineRate}
            onChange={(e) => onFormDataChange('dailyFineRate', e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="dailyInterest">Juros Diários (%)</Label>
          <Input
            id="dailyInterest"
            type="number"
            step="0.01"
            value={formData.dailyInterestRate}
            onChange={(e) => onFormDataChange('dailyInterestRate', e.target.value)}
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Descrição</Label>
        <Textarea
          id="description"
          placeholder="Descrição do pagamento"
          value={formData.description}
          onChange={(e) => onFormDataChange('description', e.target.value)}
          required
        />
      </div>
    </>
  );
};
