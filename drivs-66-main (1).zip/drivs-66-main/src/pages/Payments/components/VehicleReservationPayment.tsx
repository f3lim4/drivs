
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, CheckCircle, QrCode } from "lucide-react";
import { toast } from "sonner";

interface VehicleReservationPaymentProps {
  reservationData: {
    vehicleId: string;
    vehicleModel: string;
    deposit: number;
  };
  userId?: string;
}

export const VehicleReservationPayment = ({ reservationData, userId }: VehicleReservationPaymentProps) => {
  const navigate = useNavigate();
  const [pixGenerated, setPixGenerated] = useState(false);

  // Gera PIX para reserva
  const generatePixCode = () => {
    // Simulação de código PIX (em produção seria gerado via API do banco)
    const pixCode = `00020126330014BR.GOV.BCB.PIX2711${userId || '123456789'}5204000053039865802BR5925LOCADORA VEICULOS LTDA6009SAO PAULO62070503***6304${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
    return pixCode;
  };

  const handlePixPayment = () => {
    const pixCode = generatePixCode();
    setPixGenerated(true);
    
    // Simula o pagamento (em produção seria integrado com webhook do banco)
    setTimeout(() => {
      toast.success(`Pagamento confirmado! Veículo ${reservationData.vehicleModel} reservado por 24h.`);
      
      // Atualizar status da reserva no localStorage
      const existingReservations = JSON.parse(localStorage.getItem('userReservations') || '[]');
      const updatedReservations = existingReservations.map((reservation: any) => {
        if (reservation.id === reservationData.vehicleId) {
          return { ...reservation, status: 'paid' };
        }
        return reservation;
      });
      localStorage.setItem('userReservations', JSON.stringify(updatedReservations));
      
      // Redirecionar para o dashboard
      setTimeout(() => {
        navigate('/painel');
      }, 2000);
    }, 3000);
  };

  const copyPixCode = () => {
    const pixCode = generatePixCode();
    navigator.clipboard.writeText(pixCode);
    toast.success("Código PIX copiado para a área de transferência!");
  };

  return (
    <div className="container py-6 space-y-6">
      <h1 className="text-2xl font-bold">Pagamento da Reserva</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Detalhes da Reserva */}
        <Card>
          <CardHeader>
            <CardTitle>Detalhes da Reserva</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p><strong>Veículo:</strong> {reservationData.vehicleModel}</p>
              <p><strong>Valor da Caução:</strong> R$ {reservationData.deposit},00</p>
              <p><strong>Validade:</strong> 24 horas após confirmação do pagamento</p>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-800 mb-2">Importante:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• A reserva é válida por 24 horas</li>
                <li>• Após o pagamento, você tem 24h para retirar o veículo</li>
                <li>• Caso não retire no prazo, perderá o valor pago</li>
                <li>• Na retirada, será necessário pagar o sinal restante</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* PIX */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <QrCode className="h-5 w-5" />
              Pagamento via PIX
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!pixGenerated ? (
              <div className="text-center space-y-4">
                <div className="text-3xl font-bold text-green-600">
                  R$ {reservationData.deposit},00
                </div>
                
                <Button 
                  onClick={handlePixPayment}
                  className="w-full bg-green-600 hover:bg-green-700"
                  size="lg"
                >
                  Gerar PIX para Pagamento
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-green-600 text-xl font-semibold mb-2">
                    PIX Gerado com Sucesso!
                  </div>
                  <div className="text-3xl font-bold text-green-600 mb-4">
                    R$ {reservationData.deposit},00
                  </div>
                </div>

                {/* QR Code simulado */}
                <div className="flex justify-center">
                  <div className="w-48 h-48 bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center rounded-lg">
                    <div className="text-center">
                      <QrCode className="h-16 w-16 mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500">QR Code PIX</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm text-center text-gray-600">
                    Escaneie o QR Code ou copie o código PIX
                  </p>
                  
                  <Button 
                    onClick={copyPixCode}
                    variant="outline"
                    className="w-full"
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copiar Código PIX
                  </Button>
                </div>

                <div className="bg-yellow-50 p-3 rounded-lg text-center">
                  <p className="text-sm text-yellow-700">
                    Aguardando confirmação do pagamento...
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
