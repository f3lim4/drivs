
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, Clock, CheckCircle, AlertTriangle, CreditCard } from "lucide-react";

interface PaymentSummaryCardsProps {
  totalValue: number;
  paidValue: number;
  pendingValue: number;
  overdueValue: number;
  paymentCount: number;
}

export const PaymentSummaryCards = ({ 
  totalValue, 
  paidValue, 
  pendingValue, 
  overdueValue, 
  paymentCount 
}: PaymentSummaryCardsProps) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const summaryCards = [
    {
      title: "Total",
      value: formatCurrency(totalValue),
      icon: DollarSign,
      color: "text-blue-600",
      bgColor: "bg-white",
      borderColor: "border-l-blue-400"
    },
    {
      title: "Pagos",
      value: formatCurrency(paidValue),
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-white",
      borderColor: "border-l-green-400"
    },
    {
      title: "Pendentes",
      value: formatCurrency(pendingValue),
      icon: Clock,
      color: "text-yellow-600",
      bgColor: "bg-white",
      borderColor: "border-l-yellow-400"
    },
    {
      title: "Atrasados",
      value: formatCurrency(overdueValue),
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-white",
      borderColor: "border-l-red-400"
    },
    {
      title: "Quantidade",
      value: paymentCount.toString(),
      icon: CreditCard,
      color: "text-purple-600",
      bgColor: "bg-white",
      borderColor: "border-l-purple-400"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
      {summaryCards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index} className={`${card.bgColor} ${card.borderColor} border-l-2 border border-gray-200`}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  {card.title}
                </CardTitle>
                <Icon className={`h-5 w-5 ${card.color}`} />
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className={`text-lg font-bold ${card.color}`}>
                {card.value}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};
