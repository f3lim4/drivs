
import { useState } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { FileUp } from "lucide-react";
import { toast } from "sonner";

interface Payment {
  id: string;
  driverName: string;
  amount: number;
  description: string;
  contractId: string;
}

interface BlacklistDriverFormProps {
  payment: Payment;
  open: boolean;
  onClose: () => void;
}

export const BlacklistDriverForm = ({ payment, open, onClose }: BlacklistDriverFormProps) => {
  const [reason, setReason] = useState("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!reason.trim()) {
      toast.error("Por favor, informe o motivo da negativação.");
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulando uma chamada de API
    setTimeout(() => {
      toast.success(`Motorista ${payment.driverName} negativado com sucesso.`);
      setIsSubmitting(false);
      onClose();
    }, 1000);
  };
  
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Negativar Motorista: {payment.driverName}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="valor">Valor Devido</Label>
              <Input id="valor" value={`R$ ${payment.amount.toFixed(2)}`} disabled />
            </div>
            <div>
              <Label htmlFor="contrato">Contrato</Label>
              <Input id="contrato" value={payment.contractId} disabled />
            </div>
          </div>
          
          <div>
            <Label htmlFor="motivo">Motivo da Negativação*</Label>
            <Input 
              id="motivo" 
              placeholder="Ex: Inadimplência, Danos ao Veículo" 
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="descricao">Descrição Detalhada</Label>
            <Textarea 
              id="descricao" 
              placeholder="Descreva os detalhes da ocorrência..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Documentos Comprobatórios</Label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-4 h-24">
                <div className="flex flex-col items-center space-y-2 text-center">
                  <FileUp className="h-6 w-6 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Contrato</span>
                </div>
              </div>
              <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-4 h-24">
                <div className="flex flex-col items-center space-y-2 text-center">
                  <FileUp className="h-6 w-6 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Comprovantes</span>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Enviando..." : "Confirmar Negativação"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
