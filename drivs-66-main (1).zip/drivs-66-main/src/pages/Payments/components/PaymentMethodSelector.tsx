
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link, QrCode, Copy } from "lucide-react";
import { toast } from "sonner";

interface PaymentMethodSelectorProps {
  paymentMethod: "link" | "pix";
  paymentLink: string;
  pixKey: string;
  onPaymentMethodChange: (method: "link" | "pix") => void;
  onPaymentLinkChange: (link: string) => void;
  onPixKeyChange: (key: string) => void;
}

export const PaymentMethodSelector = ({
  paymentMethod,
  paymentLink,
  pixKey,
  onPaymentMethodChange,
  onPaymentLinkChange,
  onPixKeyChange
}: PaymentMethodSelectorProps) => {
  const handleCopyPix = () => {
    navigator.clipboard.writeText(pixKey);
    toast.success("Chave PIX copiada!");
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(paymentLink);
    toast.success("Link de cobrança copiado!");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Método de Cobrança</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <RadioGroup value={paymentMethod} onValueChange={onPaymentMethodChange}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="link" id="link" />
            <Label htmlFor="link" className="flex items-center gap-2">
              <Link className="h-4 w-4" />
              Link de Cobrança
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="pix" id="pix" />
            <Label htmlFor="pix" className="flex items-center gap-2">
              <QrCode className="h-4 w-4" />
              PIX Fixo
            </Label>
          </div>
        </RadioGroup>

        {paymentMethod === "link" && (
          <div className="space-y-2">
            <Label htmlFor="paymentLink">Link de Cobrança</Label>
            <div className="flex gap-2">
              <Input
                id="paymentLink"
                placeholder="https://pagamento.exemplo.com/cobranca/123"
                value={paymentLink}
                onChange={(e) => onPaymentLinkChange(e.target.value)}
                required
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleCopyLink}
                disabled={!paymentLink}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Insira o link da sua plataforma de cobrança (ex: PagSeguro, Mercado Pago, etc.)
            </p>
          </div>
        )}

        {paymentMethod === "pix" && (
          <div className="space-y-2">
            <Label htmlFor="pixKey">Chave PIX</Label>
            <div className="flex gap-2">
              <Input
                id="pixKey"
                placeholder="pix@minhalocadora.com.br"
                value={pixKey}
                onChange={(e) => onPixKeyChange(e.target.value)}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleCopyPix}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Esta chave PIX será enviada junto com a cobrança para o motorista
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
