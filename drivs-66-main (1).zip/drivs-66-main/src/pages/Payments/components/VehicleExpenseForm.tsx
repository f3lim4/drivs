
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { VehicleSelector } from "./VehicleSelector";
import { ExpenseCategorySelector } from "./ExpenseCategorySelector";
import { ExpenseFormFields } from "./ExpenseFormFields";

interface Vehicle {
  id: string;
  plate: string;
  model: string;
  brand: string;
  driverName?: string;
  driverPhone?: string;
}

interface VehicleExpenseFormProps {
  vehicles: Vehicle[];
  onClose: () => void;
}

export const VehicleExpenseForm = ({ vehicles, onClose }: VehicleExpenseFormProps) => {
  const [selectedVehicles, setSelectedVehicles] = useState<string[]>([]);
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [otherDescription, setOtherDescription] = useState("");
  const [date, setDate] = useState<Date>(new Date());
  const { toast } = useToast();

  const handleVehicleToggle = (vehicleId: string) => {
    setSelectedVehicles(prev => 
      prev.includes(vehicleId) 
        ? prev.filter(id => id !== vehicleId)
        : [...prev, vehicleId]
    );
  };

  const handleSubmit = () => {
    if (!category || !amount || selectedVehicles.length === 0) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios e selecione pelo menos um veículo.",
        variant: "destructive"
      });
      return;
    }

    if (category === "outros" && !otherDescription) {
      toast({
        title: "Erro",
        description: "Para categoria 'Outros', especifique o tipo de despesa.",
        variant: "destructive"
      });
      return;
    }

    const expenseData = {
      category,
      amount: parseFloat(amount),
      description: category === "outros" ? otherDescription : description,
      selectedVehicles,
      date: date.toISOString(),
      createdAt: new Date().toISOString()
    };

    console.log('Despesa cadastrada:', expenseData);

    // Salvar no localStorage para integração com o financeiro
    const existingExpenses = JSON.parse(localStorage.getItem('vehicleExpenses') || '[]');
    existingExpenses.push(expenseData);
    localStorage.setItem('vehicleExpenses', JSON.stringify(existingExpenses));

    toast({
      title: "Despesa Cadastrada",
      description: `Despesa de ${category} no valor de R$ ${parseFloat(amount).toFixed(2)} cadastrada para ${selectedVehicles.length} veículo(s).`
    });

    // Reset form
    setSelectedVehicles([]);
    setCategory("");
    setAmount("");
    setDescription("");
    setOtherDescription("");
    setDate(new Date());
    onClose();
  };

  return (
    <div className="space-y-6">
      <VehicleSelector
        vehicles={vehicles}
        selectedVehicles={selectedVehicles}
        onVehicleToggle={handleVehicleToggle}
      />

      <ExpenseCategorySelector
        category={category}
        onCategoryChange={setCategory}
        otherDescription={otherDescription}
        onOtherDescriptionChange={setOtherDescription}
      />

      <ExpenseFormFields
        amount={amount}
        onAmountChange={setAmount}
        date={date}
        onDateChange={setDate}
        description={description}
        onDescriptionChange={setDescription}
      />

      <div className="flex justify-end gap-3">
        <Button variant="outline" onClick={onClose}>
          Cancelar
        </Button>
        <Button onClick={handleSubmit}>
          Cadastrar Despesa
        </Button>
      </div>
    </div>
  );
};
