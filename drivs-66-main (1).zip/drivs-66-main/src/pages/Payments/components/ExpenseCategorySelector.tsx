
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

const expenseCategories = [
  { value: "ipva", label: "IPVA" },
  { value: "documentacao", label: "Documentação" },
  { value: "seguro", label: "Seguro" },
  { value: "rastreador", label: "Rastreador" },
  { value: "guincho", label: "Guincho" },
  { value: "outros", label: "Outros" }
];

interface ExpenseCategorySelectorProps {
  category: string;
  onCategoryChange: (value: string) => void;
  otherDescription: string;
  onOtherDescriptionChange: (value: string) => void;
}

export const ExpenseCategorySelector = ({
  category,
  onCategoryChange,
  otherDescription,
  onOtherDescriptionChange
}: ExpenseCategorySelectorProps) => {
  return (
    <>
      <div>
        <Label htmlFor="category">Categoria da Despesa</Label>
        <Select value={category} onValueChange={onCategoryChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione a categoria" />
          </SelectTrigger>
          <SelectContent>
            {expenseCategories.map((cat) => (
              <SelectItem key={cat.value} value={cat.value}>
                {cat.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {category === "outros" && (
        <div>
          <Label htmlFor="otherDescription">Especificar Tipo de Despesa</Label>
          <Input
            id="otherDescription"
            value={otherDescription}
            onChange={(e) => onOtherDescriptionChange(e.target.value)}
            placeholder="Ex: Multa, Combustível, etc."
          />
        </div>
      )}
    </>
  );
};
