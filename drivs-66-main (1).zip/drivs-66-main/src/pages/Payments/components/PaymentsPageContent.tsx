import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver, DriverStatus } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Clock, DollarSign, AlertTriangle, Receipt } from "lucide-react";
import { PaymentSummaryCards } from "./PaymentSummaryCards";
import { PaymentTable } from "./PaymentTable";
import { BlacklistDriverForm } from "./BlacklistDriverForm";
import { CreatePaymentDialog } from "./CreatePaymentDialog";
import { PaymentFilters } from "./PaymentFilters";
import { RentalCompanyPaymentStatus } from "./RentalCompanyPaymentStatus";
import { DriverPaymentBoxes } from "./DriverPaymentBoxes";
import { VehicleExpenseDialog } from "./VehicleExpenseDialog";
import { toast } from "sonner";
import { mockPayments, Payment } from "../data";
import { filterPayments, calculatePaymentSummary } from "../utils/paymentUtils";

// Mock vehicles data - in a real app this would come from an API
const mockVehicles = [{
  id: "1",
  plate: "ABC-1234",
  model: "Civic",
  brand: "Honda"
}, {
  id: "2",
  plate: "XYZ-5678",
  model: "Corolla",
  brand: "Toyota"
}, {
  id: "3",
  plate: "DEF-9012",
  model: "Sentra",
  brand: "Nissan"
}, {
  id: "4",
  plate: "GHI-3456",
  model: "Onix",
  brand: "Chevrolet"
}, {
  id: "5",
  plate: "JKL-7890",
  model: "HB20",
  brand: "Hyundai"
}];
export const PaymentsPageContent = () => {
  const {
    user
  } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);
  const [showBlacklistForm, setShowBlacklistForm] = useState(false);
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);

  // Debug: log do usuário atual
  console.log("Current user:", user);
  console.log("All payments:", mockPayments);

  // Filtra pagamentos específicos do motorista logado
  const driverPayments = user?.role === UserRole.DRIVER ? mockPayments.filter(payment => {
    console.log(`Comparing payment.driverId (${payment.driverId}) with user.id (${user.id})`);
    return payment.driverId === user.id;
  }) : [];
  console.log("Filtered driver payments:", driverPayments);

  // Filtra pagamentos com base no usuário atual e nos filtros
  const filteredPayments = filterPayments(mockPayments, searchTerm, statusFilter, user?.role, user?.id);
  const handlePayment = (payment: Payment) => {
    toast.success(`Pagamento de R$ ${payment.amount.toFixed(2)} registrado com sucesso.`);
  };
  const handleBlacklist = (payment: Payment) => {
    setSelectedPayment(payment);
    setShowBlacklistForm(true);
  };
  const handleExportReport = () => {
    toast.success("Relatório de pagamentos gerado com sucesso.");
  };
  const summary = calculatePaymentSummary(user?.role, user?.id);
  const handlePaymentCreated = () => {
    // Refresh payments list in a real app
    console.log("Payment created, refreshing list...");
  };
  return <div className="space-y-6">
      {/* Cabeçalho sempre visível */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">
          {user?.role === UserRole.DRIVER ? "MEUS PAGAMENTOS" : "PAGAMENTOS"}
        </h1>
        
        <div className="flex gap-2">
          {(user?.role === UserRole.MANAGER || user?.role === UserRole.RENTAL_COMPANY) && <>
              <Button variant="outline" onClick={() => setShowExpenseDialog(true)} className="flex items-center gap-2">
                <Receipt className="h-4 w-4" />
                Cadastrar Despesa
              </Button>
              <CreatePaymentDialog onPaymentCreated={handlePaymentCreated} />
            </>}
        </div>
      </div>
      
      {/* Mostra o novo componente para locadoras, o antigo para outros usuários */}
      {user?.role === UserRole.RENTAL_COMPANY ? <RentalCompanyPaymentStatus /> : user?.role === UserRole.DRIVER ? <>
          {/* Debug info para motoristas */}
          

          {/* Caixas específicas para motoristas - só mostra se há pagamentos */}
          {driverPayments.length > 0 && <DriverPaymentBoxes payments={driverPayments} onPayment={handlePayment} />}
          
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-card-foreground uppercase text-lg">
                HISTÓRICO DE PAGAMENTOS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <PaymentFilters searchTerm={searchTerm} setSearchTerm={setSearchTerm} statusFilter={statusFilter} setStatusFilter={setStatusFilter} />
              
              <PaymentTable payments={driverPayments} userRole={user?.role} onPay={handlePayment} onBlacklist={handleBlacklist} />
            </CardContent>
          </Card>
        </> : <>
          {/* Mostra cards de resumo para outros usuários que não são motoristas */}
          <PaymentSummaryCards totalValue={summary.totalPaid + summary.totalPending + summary.totalOverdue} paidValue={summary.totalPaid} pendingValue={summary.totalPending} overdueValue={summary.totalOverdue} paymentCount={mockPayments.length} />
          
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-card-foreground uppercase text-lg">
                PAGAMENTOS
              </CardTitle>
              
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={handleExportReport}>
                  <Download className="mr-2 h-4 w-4" />
                  Exportar
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <PaymentFilters searchTerm={searchTerm} setSearchTerm={setSearchTerm} statusFilter={statusFilter} setStatusFilter={setStatusFilter} />
              
              <PaymentTable payments={filteredPayments} userRole={user?.role} onPay={handlePayment} onBlacklist={handleBlacklist} />
            </CardContent>
          </Card>
        </>}
      
      {/* Modal para negativar motoristas */}
      {selectedPayment && <BlacklistDriverForm payment={selectedPayment} open={showBlacklistForm} onClose={() => {
      setShowBlacklistForm(false);
      setSelectedPayment(null);
    }} />}

      {/* Modal para cadastrar despesas de veículos */}
      <VehicleExpenseDialog open={showExpenseDialog} onOpenChange={setShowExpenseDialog} vehicles={mockVehicles} />
    </div>;
};