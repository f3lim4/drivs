
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { User } from "lucide-react";

interface Vehicle {
  id: string;
  plate: string;
  model: string;
  brand: string;
  driverName?: string;
  driverPhone?: string;
}

interface VehicleSelectorProps {
  vehicles: Vehicle[];
  selectedVehicles: string[];
  onVehicleToggle: (vehicleId: string) => void;
}

export const VehicleSelector = ({
  vehicles,
  selectedVehicles,
  onVehicleToggle
}: VehicleSelectorProps) => {
  return (
    <div>
      <Label className="text-base font-medium">Selecionar Veículos e Motoristas</Label>
      <div className="mt-3 max-h-60 overflow-y-auto border rounded-lg p-3">
        {vehicles.map((vehicle) => (
          <div key={vehicle.id} className="flex items-start space-x-3 py-3 border-b last:border-b-0">
            <Checkbox
              id={vehicle.id}
              checked={selectedVehicles.includes(vehicle.id)}
              onCheckedChange={() => onVehicleToggle(vehicle.id)}
              className="mt-1"
            />
            <div className="flex-1 min-w-0">
              <Label htmlFor={vehicle.id} className="text-sm font-medium cursor-pointer">
                {vehicle.plate} - {vehicle.brand} {vehicle.model}
              </Label>
              {vehicle.driverName && (
                <div className="flex items-center gap-2 mt-1 text-xs text-gray-600">
                  <User className="h-3 w-3" />
                  <span>{vehicle.driverName}</span>
                  {vehicle.driverPhone && (
                    <span className="text-gray-500">• {vehicle.driverPhone}</span>
                  )}
                </div>
              )}
              {!vehicle.driverName && (
                <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                  <User className="h-3 w-3" />
                  <span>Sem motorista designado</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      <p className="text-sm text-muted-foreground mt-2">
        {selectedVehicles.length} veículo(s) selecionado(s)
      </p>
    </div>
  );
};
