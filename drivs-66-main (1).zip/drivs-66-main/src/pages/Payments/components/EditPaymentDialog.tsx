
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface DriverPayment {
  id: string;
  driverName: string;
  driverCpf: string;
  amount: number;
  dueDate: string;
  status: "paid" | "pending" | "overdue";
  description: string;
}

interface EditPaymentDialogProps {
  payment: DriverPayment | null;
  open: boolean;
  onClose: () => void;
  onSave: (updatedPayment: DriverPayment) => void;
}

export const EditPaymentDialog = ({ payment, open, onClose, onSave }: EditPaymentDialogProps) => {
  const [formData, setFormData] = useState({
    amount: "",
    dueDate: "",
    status: "pending" as "paid" | "pending" | "overdue",
    description: ""
  });

  useEffect(() => {
    if (payment) {
      setFormData({
        amount: payment.amount.toString(),
        dueDate: payment.dueDate,
        status: payment.status,
        description: payment.description
      });
    }
  }, [payment]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!payment) return;
    
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      toast.error("Por favor, informe um valor válido");
      return;
    }
    
    if (!formData.dueDate) {
      toast.error("Por favor, informe a data de vencimento");
      return;
    }
    
    const updatedPayment: DriverPayment = {
      ...payment,
      amount: parseFloat(formData.amount),
      dueDate: formData.dueDate,
      status: formData.status,
      description: formData.description
    };
    
    onSave(updatedPayment);
    toast.success("Pagamento atualizado com sucesso!");
    onClose();
  };

  if (!payment) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Editar Pagamento</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Motorista</Label>
              <Input value={payment.driverName} disabled />
            </div>
            <div className="space-y-2">
              <Label>CPF</Label>
              <Input value={payment.driverCpf} disabled />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="amount">Valor (R$)</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="0,00"
              value={formData.amount}
              onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="dueDate">Data de Vencimento</Label>
            <Input
              id="dueDate"
              type="date"
              value={formData.dueDate}
              onChange={(e) => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select value={formData.status} onValueChange={(value: any) => setFormData(prev => ({ ...prev, status: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Em Aberto</SelectItem>
                <SelectItem value="paid">Pago</SelectItem>
                <SelectItem value="overdue">Atrasado</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Descrição</Label>
            <Textarea
              id="description"
              placeholder="Descrição do pagamento"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              required
            />
          </div>
          
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit">
              Salvar Alterações
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
