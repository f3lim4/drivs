
import { useAuth } from "@/contexts/AuthContext";
import { VehicleReservationPayment } from "./components/VehicleReservationPayment";
import { PaymentsPageContent } from "./components/PaymentsPageContent";
import { useReservationData } from "./hooks/useReservationData";

const PaymentsPage = () => {
  const { user } = useAuth();
  const reservationData = useReservationData();
  const loading = false;

  if (loading) {
    return (
      <div className="px-2 md:px-4 py-4 md:py-6">
        <div className="h-8 md:h-10 w-full max-w-xs bg-gradient-to-r from-blue-200 to-purple-200 animate-pulse rounded"></div>
        <div className="h-10 md:h-12 w-full bg-gradient-to-r from-blue-100 to-purple-100 animate-pulse rounded mt-4"></div>
        <div className="h-64 md:h-96 w-full bg-gradient-to-r from-blue-50 to-purple-50 animate-pulse rounded mt-4"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-2 md:px-6 py-4 md:py-6">
      <div className="container mx-auto space-y-6 md:space-y-8 max-w-7xl">
        {reservationData ? (
          <VehicleReservationPayment 
            reservationData={reservationData} 
            userId={user?.id}
          />
        ) : (
          <PaymentsPageContent />
        )}
      </div>
    </div>
  );
};

export default PaymentsPage;
