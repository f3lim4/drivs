
// Payment-related type definitions
export interface Payment {
  id: string;
  contractId: string;
  driverId: string;
  driverName: string;
  companyId: string;
  companyName: string;
  amount: number;
  status: "paid" | "pending" | "overdue" | "cancelled";
  dueDate: string;
  paidDate?: string;
  paymentMethod?: string;
  description: string;
  type: string;
  dailyFineRate?: number;
  dailyInterestRate?: number;
}

export interface AdditionalCharge {
  id: string;
  driverId: string;
  companyId: string;
  type: "violation" | "maintenance" | "damage";
  description: string;
  amount: number;
  status: "pending" | "paid";
}
