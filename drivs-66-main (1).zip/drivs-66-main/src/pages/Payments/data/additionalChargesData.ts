
import { AdditionalCharge } from "./types";

export const mockAdditionalCharges: AdditionalCharge[] = [];
