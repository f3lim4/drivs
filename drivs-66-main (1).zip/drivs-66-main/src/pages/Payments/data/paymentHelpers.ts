
import { Payment } from "./types";
import { mockPayments } from "./paymentsData";

// Helper function to add a new payment to the mock data
export const addNewPayment = (payment: Omit<Payment, 'id'>) => {
  const newId = `PAG-2024-${(mockPayments.length + 1).toString().padStart(3, '0')}`;
  const newPayment: Payment = {
    ...payment,
    id: newId
  };
  mockPayments.push(newPayment);
  return newPayment;
};
