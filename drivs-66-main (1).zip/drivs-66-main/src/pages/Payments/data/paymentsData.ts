
import { Payment } from "./types";

export const mockPayments: Payment[] = [];
