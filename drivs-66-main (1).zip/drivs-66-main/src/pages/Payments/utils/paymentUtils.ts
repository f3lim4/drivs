import { UserRole } from "@/types";
import { Payment, AdditionalCharge, mockPayments, mockAdditionalCharges } from "../data";

export const filterPayments = (
  payments: Payment[], 
  searchTerm: string, 
  statusFilter: string, 
  userRole?: UserRole, 
  userId?: string
) => {
  return payments.filter(payment => {
    // Filtro baseado na busca
    const matchesSearch = 
      payment.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.contractId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.id.toLowerCase().includes(searchTerm.toLowerCase());
      
    // Filtro baseado no status
    const matchesStatus = statusFilter === "all" || payment.status === statusFilter;
      
    // Filtro baseado no tipo de usuário
    if (userRole === UserRole.DRIVER) {
      return matchesSearch && matchesStatus && payment.driverId === userId;
    } else if (userRole === UserRole.RENTAL_COMPANY) {
      return matchesSearch && matchesStatus && payment.companyId === userId;
    }
      
    return matchesSearch && matchesStatus;
  });
};

export const calculatePaymentSummary = (userRole?: UserRole, userId?: string) => {
  let userPayments = mockPayments;
  let userCharges = mockAdditionalCharges;
  
  // Filtra pagamentos pelo usuário atual
  if (userRole === UserRole.DRIVER) {
    userPayments = userPayments.filter(p => p.driverId === userId);
    userCharges = userCharges.filter(c => c.driverId === userId);
  } else if (userRole === UserRole.RENTAL_COMPANY) {
    userPayments = userPayments.filter(p => p.companyId === userId);
    userCharges = userCharges.filter(c => c.companyId === userId);
  }
  
  const totalPaid = userPayments
    .filter(p => p.status === "paid")
    .reduce((sum, p) => sum + p.amount, 0);
    
  const totalPending = userPayments
    .filter(p => p.status === "pending")
    .reduce((sum, p) => sum + p.amount, 0);
    
  const totalOverdue = userPayments
    .filter(p => p.status === "overdue")
    .reduce((sum, p) => sum + p.amount, 0);

  const totalViolations = userCharges
    .filter(c => c.type === "violation" && c.status === "pending")
    .reduce((sum, c) => sum + c.amount, 0);

  const totalMaintenance = userCharges
    .filter(c => c.type === "maintenance" && c.status === "pending")
    .reduce((sum, c) => sum + c.amount, 0);

  const totalDamages = userCharges
    .filter(c => c.type === "damage" && c.status === "pending")
    .reduce((sum, c) => sum + c.amount, 0);
    
  return { 
    totalPaid, 
    totalPending, 
    totalOverdue, 
    totalViolations, 
    totalMaintenance, 
    totalDamages 
  };
};

const formatDate = (dateString?: string) => {
  if (!dateString) return "-";
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('pt-BR').format(date);
};
