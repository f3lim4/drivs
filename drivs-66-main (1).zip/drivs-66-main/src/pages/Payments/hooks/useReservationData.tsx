
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { toast } from "sonner";

interface ReservationData {
  vehicleId: string;
  vehicleModel: string;
  deposit: number;
  paymentType: string;
}

export const useReservationData = () => {
  const location = useLocation();
  const [reservationData, setReservationData] = useState<ReservationData | null>(null);

  useEffect(() => {
    if (location.state?.paymentType === 'reservation') {
      const newReservation = {
        id: location.state.vehicleId,
        vehicleModel: location.state.vehicleModel,
        deposit: location.state.deposit,
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 10 * 60 * 1000).toISOString(), // 10 minutos
        status: "pending" as const
      };

      // Salvar no localStorage
      const existingReservations = JSON.parse(localStorage.getItem('userReservations') || '[]');
      const updatedReservations = [...existingReservations, newReservation];
      localStorage.setItem('userReservations', JSON.stringify(updatedReservations));

      setReservationData(location.state);
      toast.success(`Reserva criada! Você tem 10 minutos para efetuar o pagamento.`);
    }
  }, [location.state]);

  return reservationData;
};
