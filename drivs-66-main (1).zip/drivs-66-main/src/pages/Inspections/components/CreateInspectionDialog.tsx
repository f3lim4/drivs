
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, User, Car, Clock, UserCheck } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useRentalCompanyVehicles } from "@/hooks/useRentalCompanyVehicles";
import { LocalInspection } from "../types/inspection";

interface CreateInspectionDialogProps {
  onCreateInspection: (inspection: Omit<LocalInspection, 'id'>) => void;
}

const CreateInspectionDialog = ({ onCreateInspection }: CreateInspectionDialogProps) => {
  const { user } = useAuth();
  const { vehicles, loading: vehiclesLoading } = useRentalCompanyVehicles();
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    selectedVehicle: "",
    inspectionType: "",
    recipient: "",
    deadline: "",
    observations: ""
  });

  const resetForm = () => {
    setFormData({
      selectedVehicle: "",
      inspectionType: "",
      recipient: "",
      deadline: "",
      observations: ""
    });
  };

  const handleVehicleChange = (vehicleId: string) => {
    setFormData(prev => ({ ...prev, selectedVehicle: vehicleId }));
  };

  const getSelectedVehicleInfo = () => {
    if (!formData.selectedVehicle) return null;
    return vehicles.find(v => v.id === formData.selectedVehicle);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const selectedVehicle = getSelectedVehicleInfo();
    
    if (!selectedVehicle || !formData.inspectionType || !formData.recipient) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    const vehicleInfo = `${selectedVehicle.brand} ${selectedVehicle.model} ${selectedVehicle.year}`;

    const newInspection: Omit<LocalInspection, 'id'> = {
      vehiclePlate: selectedVehicle.plate,
      vehicleModel: vehicleInfo,
      driverName: "Motorista do veículo", // Será preenchido pelo backend
      type: formData.inspectionType,
      status: "Pendente",
      inspector: formData.recipient === "inspector" ? "Vistoriador" : "Motorista",
      vistoriador: formData.recipient === "inspector" ? "Vistoriador" : "Motorista",
      observations: formData.observations,
      photos: 0,
      recipient: formData.recipient as "inspector" | "driver",
      contractId: `CTR-${Date.now()}`,
      inspectionDate: new Date().toISOString().split('T')[0]
    };

    onCreateInspection(newInspection);
    setOpen(false);
    resetForm();
  };

  const selectedVehicle = getSelectedVehicleInfo();

  if (user?.role !== "rental_company") {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nova Vistoria
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Criar Nova Vistoria</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="selectedVehicle" className="flex items-center gap-2">
              <Car className="h-4 w-4" />
              Veículo da Frota *
            </Label>
            <Select 
              value={formData.selectedVehicle} 
              onValueChange={handleVehicleChange}
              disabled={vehiclesLoading}
            >
              <SelectTrigger>
                <SelectValue placeholder={
                  vehiclesLoading 
                    ? "Carregando veículos..." 
                    : vehicles.length === 0 
                      ? "Nenhum veículo encontrado"
                      : "Selecione um veículo da sua frota"
                } />
              </SelectTrigger>
              <SelectContent>
                {vehicles.map((vehicle) => (
                  <SelectItem key={vehicle.id} value={vehicle.id}>
                    <div className="flex flex-col items-start">
                      <div className="font-medium">
                        {vehicle.brand} {vehicle.model} {vehicle.year} - {vehicle.plate}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Status: {vehicle.status === 'available' ? 'Disponível' : 
                                vehicle.status === 'rented' ? 'Alugado' : 
                                vehicle.status === 'maintenance' ? 'Em Manutenção' : 'Indisponível'}
                      </div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {vehicles.length === 0 && !vehiclesLoading && (
              <p className="text-sm text-muted-foreground">
                Nenhum veículo encontrado na sua frota. Cadastre veículos primeiro.
              </p>
            )}
          </div>

          {selectedVehicle && (
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <h4 className="font-medium text-blue-800 dark:text-blue-300 mb-2">
                Veículo Selecionado:
              </h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-blue-700 dark:text-blue-400 font-medium">Veículo:</span>
                  <span className="ml-2">{selectedVehicle.brand} {selectedVehicle.model} {selectedVehicle.year}</span>
                </div>
                <div>
                  <span className="text-blue-700 dark:text-blue-400 font-medium">Placa:</span>
                  <span className="ml-2">{selectedVehicle.plate}</span>
                </div>
                <div>
                  <span className="text-blue-700 dark:text-blue-400 font-medium">Cor:</span>
                  <span className="ml-2">{selectedVehicle.color}</span>
                </div>
                <div>
                  <span className="text-blue-700 dark:text-blue-400 font-medium">Status:</span>
                  <span className="ml-2">
                    {selectedVehicle.status === 'available' ? 'Disponível' : 
                     selectedVehicle.status === 'rented' ? 'Alugado' : 
                     selectedVehicle.status === 'maintenance' ? 'Em Manutenção' : 'Indisponível'}
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="inspectionType" className="flex items-center gap-2">
              <UserCheck className="h-4 w-4" />
              Tipo de Vistoria *
            </Label>
            <Select 
              value={formData.inspectionType} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, inspectionType: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o tipo de vistoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Inicial">Vistoria Inicial</SelectItem>
                <SelectItem value="Entrega">Vistoria de Entrega</SelectItem>
                <SelectItem value="Manutenção">Vistoria de Manutenção</SelectItem>
                <SelectItem value="Retorno">Vistoria de Retorno</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="recipient" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Responsável pela Vistoria *
            </Label>
            <Select 
              value={formData.recipient} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, recipient: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Quem realizará a vistoria?" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="driver">Motorista</SelectItem>
                <SelectItem value="inspector">Vistoriador da Locadora</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="deadline" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Prazo para Realização
            </Label>
            <Input
              id="deadline"
              type="date"
              value={formData.deadline}
              onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
              min={new Date().toISOString().split('T')[0]}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="observations">Observações</Label>
            <Textarea
              id="observations"
              value={formData.observations}
              onChange={(e) => setFormData(prev => ({ ...prev, observations: e.target.value }))}
              placeholder="Observações especiais sobre a vistoria..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={vehiclesLoading}>
              Criar Vistoria
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateInspectionDialog;
