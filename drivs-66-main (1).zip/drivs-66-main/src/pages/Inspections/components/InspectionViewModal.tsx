
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { LocalInspection } from "../types/inspection";

interface InspectionViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  inspection: LocalInspection | null;
  onUpdateStatus: (inspectionId: string, status: LocalInspection["status"], observations?: string) => void;
  onRejectPhoto: (inspectionId: string, photoId: string) => void;
  onRejectAllPhotos: (inspectionId: string) => void;
}

export const InspectionViewModal = ({
  isOpen,
  onClose,
  inspection,
  onUpdateStatus,
  onRejectPhoto,
  onRejectAllPhotos
}: InspectionViewModalProps) => {
  const [observations, setObservations] = useState("");

  if (!inspection) return null;

  const handleStatusUpdate = (status: LocalInspection["status"]) => {
    onUpdateStatus(inspection.id, status, observations);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Detalhes da Vistoria</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Tipo</label>
              <p>{inspection.type}</p>
            </div>
            <div>
              <label className="text-sm font-medium">Status</label>
              <Badge>{inspection.status}</Badge>
            </div>
            <div>
              <label className="text-sm font-medium">Veículo</label>
              <p>{inspection.vehicleModel} - {inspection.vehiclePlate}</p>
            </div>
            <div>
              <label className="text-sm font-medium">Motorista</label>
              <p>{inspection.driverName}</p>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">Observações</label>
            <Textarea
              value={observations}
              onChange={(e) => setObservations(e.target.value)}
              placeholder="Adicione observações..."
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={() => handleStatusUpdate("Concluída")} className="bg-green-600">
              Aprovar
            </Button>
            <Button onClick={() => handleStatusUpdate("Rejeitada")} variant="destructive">
              Rejeitar
            </Button>
            <Button onClick={onClose} variant="outline">
              Fechar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
