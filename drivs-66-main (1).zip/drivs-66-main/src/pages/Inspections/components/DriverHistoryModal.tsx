
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Camera, Car, FileText, MapPin, User, Download, Eye, X } from "lucide-react";
import { useState } from "react";

interface CompletedInspection {
  id: number;
  type: string;
  date: string;
  time: string;
  location: string;
  photos: number;
  observations: string;
  status: "Aprovada" | "Pendente de Revisão" | "Rejeitada";
  vehiclePlate: string;
  vehicleModel: string;
  contractId: string;
  requestedBy?: string;
}

interface DriverHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  driverName: string;
  vehiclePlate: string;
  vehicleModel: string;
  selectedInspection?: CompletedInspection | null;
}

// Mock photos data
const generateMockPhotos = (inspectionId: number, count: number) => {
  return Array.from({ length: count }, (_, i) => ({
    id: `photo-${inspectionId}-${i + 1}`,
    url: `https://picsum.photos/400/300?random=${inspectionId}-${i}`,
    title: `Foto ${i + 1}`,
    timestamp: new Date().toISOString(),
  }));
};

// Histórico completo de vistorias do motorista
const completedInspections: CompletedInspection[] = [
  {
    id: 1,
    type: "Vistoria Inicial",
    date: "2024-01-15",
    time: "09:30",
    location: "São Paulo - SP",
    photos: 14,
    observations: "Veículo em perfeitas condições",
    status: "Aprovada",
    vehiclePlate: "ABC-1234",
    vehicleModel: "Honda Civic",
    contractId: "CON-2024-001",
    requestedBy: "Auto Rental Plus"
  },
  {
    id: 2,
    type: "Vistoria de Manutenção",
    date: "2024-01-10",
    time: "14:15",
    location: "São Paulo - SP",
    photos: 5,
    observations: "Verificação dos pneus conforme solicitado",
    status: "Pendente de Revisão",
    vehiclePlate: "ABC-1234",
    vehicleModel: "Honda Civic",
    contractId: "CON-2024-001",
    requestedBy: "Auto Rental Plus"
  },
  {
    id: 3,
    type: "Vistoria de Entrega",
    date: "2024-01-05",
    time: "16:45",
    location: "São Paulo - SP",
    photos: 14,
    observations: "Veículo entregue nas mesmas condições",
    status: "Aprovada",
    vehiclePlate: "DEF-5678",
    vehicleModel: "Toyota Corolla",
    contractId: "CON-2023-005",
    requestedBy: "Auto Rental Plus"
  },
  {
    id: 4,
    type: "Vistoria Inicial",
    date: "2023-12-20",
    time: "10:00",
    location: "São Paulo - SP",
    photos: 14,
    observations: "Pequeno arranhão já existente documentado",
    status: "Aprovada",
    vehiclePlate: "DEF-5678",
    vehicleModel: "Toyota Corolla",
    contractId: "CON-2023-005",
    requestedBy: "Auto Rental Plus"
  }
];

export const DriverHistoryModal = ({ 
  isOpen, 
  onClose, 
  driverName, 
  vehiclePlate, 
  vehicleModel,
  selectedInspection 
}: DriverHistoryModalProps) => {
  const [showPhotos, setShowPhotos] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  
  const getTypeColor = (type: string) => {
    switch (type) {
      case "Vistoria Inicial":
        return "bg-blue-100 text-blue-800";
      case "Vistoria de Entrega":
        return "bg-green-100 text-green-800";
      case "Vistoria de Manutenção":
        return "bg-purple-100 text-purple-800";
      case "Vistoria Semanal":
        return "bg-orange-100 text-orange-800";
      case "Vistoria Eventual":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusBadge = (status: CompletedInspection["status"]) => {
    switch (status) {
      case "Aprovada":
        return <Badge className="bg-green-500 text-white">Aprovada</Badge>;
      case "Pendente de Revisão":
        return <Badge className="bg-yellow-500 text-white">Pendente de Revisão</Badge>;
      case "Rejeitada":
        return <Badge variant="destructive">Rejeitada</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const downloadInspectionData = (inspection: CompletedInspection) => {
    const data = {
      id: inspection.id,
      tipo: inspection.type,
      data: inspection.date,
      hora: inspection.time,
      local: inspection.location,
      veiculo: `${inspection.vehiclePlate} - ${inspection.vehicleModel}`,
      motorista: driverName,
      status: inspection.status,
      observacoes: inspection.observations,
      numeroFotos: inspection.photos,
      contrato: inspection.contractId,
      solicitadoPor: inspection.requestedBy || "N/A",
      dataDownload: new Date().toISOString()
    };

    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `vistoria-${inspection.id}-${inspection.date}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Se uma vistoria específica foi selecionada, mostra apenas ela
  if (selectedInspection) {
    const mockPhotos = generateMockPhotos(selectedInspection.id, selectedInspection.photos);

    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Detalhes da Vistoria #{selectedInspection.id}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Informações básicas */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center justify-between">
                  Informações Gerais
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => downloadInspectionData(selectedInspection)}
                    className="flex items-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Baixar Dados
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <Car className="h-4 w-4 text-blue-500" />
                    <span className="font-medium">Veículo:</span>
                    <span>{selectedInspection.vehiclePlate} - {selectedInspection.vehicleModel}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-green-500" />
                    <span className="font-medium">Motorista:</span>
                    <span>{driverName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-purple-500" />
                    <span className="font-medium">Tipo:</span>
                    <Badge className={getTypeColor(selectedInspection.type)}>
                      {selectedInspection.type}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-orange-500" />
                    <span className="font-medium">Status:</span>
                    {getStatusBadge(selectedInspection.status)}
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-blue-500" />
                    <span className="font-medium">Data/Hora:</span>
                    <span>
                      {new Date(selectedInspection.date).toLocaleDateString()} às {selectedInspection.time}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-red-500" />
                    <span className="font-medium">Local:</span>
                    <span>{selectedInspection.location}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Camera className="h-4 w-4 text-blue-500" />
                  <span className="font-medium">Fotos:</span>
                  <span>{selectedInspection.photos} foto(s) anexada(s)</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowPhotos(!showPhotos)}
                    className="ml-2"
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    {showPhotos ? 'Ocultar' : 'Ver'} Fotos
                  </Button>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">Contrato:</span>
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                    {selectedInspection.contractId}
                  </span>
                </div>
                {selectedInspection.requestedBy && (
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Solicitado por:</span>
                    <span>{selectedInspection.requestedBy}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Galeria de fotos */}
            {showPhotos && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Fotos da Vistoria</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {mockPhotos.map((photo) => (
                      <div 
                        key={photo.id} 
                        className="relative cursor-pointer group"
                        onClick={() => setSelectedPhoto(photo.url)}
                      >
                        <img
                          src={photo.url}
                          alt={photo.title}
                          className="w-full h-24 object-cover rounded-lg border hover:shadow-lg transition-shadow"
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all rounded-lg flex items-center justify-center">
                          <Eye className="h-6 w-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <p className="text-xs text-center mt-1">{photo.title}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Observações */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Observações</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {selectedInspection.observations}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Modal de foto ampliada */}
          {selectedPhoto && (
            <div 
              className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50"
              onClick={() => setSelectedPhoto(null)}
            >
              <div className="relative max-w-4xl max-h-[90vh] p-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedPhoto(null)}
                  className="absolute top-2 right-2 z-10"
                >
                  <X className="h-4 w-4" />
                </Button>
                <img
                  src={selectedPhoto}
                  alt="Foto ampliada"
                  className="max-w-full max-h-full object-contain rounded-lg"
                />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    );
  }

  // Caso contrário, mostra o histórico completo (comportamento original)
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Histórico de Vistorias - {driverName}
          </DialogTitle>
          <p className="text-sm text-muted-foreground">
            Veículo: {vehiclePlate} - {vehicleModel}
          </p>
        </DialogHeader>

        <div className="space-y-4">
          {completedInspections.length > 0 ? (
            <div className="space-y-4">
              {completedInspections.map((inspection) => (
                <Card key={inspection.id} className="border">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Badge className={getTypeColor(inspection.type)}>
                          {inspection.type}
                        </Badge>
                        {getStatusBadge(inspection.status)}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          ID: #{inspection.id}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => downloadInspectionData(inspection)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Car className="h-4 w-4 text-blue-500" />
                        <span>{inspection.vehiclePlate} - {inspection.vehicleModel}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-blue-500" />
                        <span>
                          {new Date(inspection.date).toLocaleDateString()} às {inspection.time}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-red-500" />
                        <span>{inspection.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Camera className="h-4 w-4 text-blue-500" />
                        <span>{inspection.photos} fotos</span>
                      </div>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t">
                      <p className="text-sm text-muted-foreground">
                        <strong>Observações:</strong> {inspection.observations}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Contrato: {inspection.contractId}
                        {inspection.requestedBy && ` • Solicitado por: ${inspection.requestedBy}`}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-muted-foreground">
                Nenhuma vistoria encontrada no histórico.
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
