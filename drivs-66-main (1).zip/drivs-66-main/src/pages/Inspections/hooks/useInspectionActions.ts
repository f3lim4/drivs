
import { useState } from "react";
import { LocalInspection } from "../types/inspection";
import { toast } from "sonner";

export const useInspectionActions = (
  createInspection: (inspection: Omit<LocalInspection, 'id'>) => Promise<void>,
  updateInspection: (id: string, updates: Partial<LocalInspection>) => Promise<void>
) => {
  const [selectedInspection, setSelectedInspection] = useState<LocalInspection | null>(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [showDriverHistory, setShowDriverHistory] = useState(false);
  const [showInspectionView, setShowInspectionView] = useState(false);
  const [selectedDriverForHistory, setSelectedDriverForHistory] = useState<{
    name: string;
    vehiclePlate: string;
    vehicleModel: string;
  } | null>(null);

  const handleCreateInspection = async (newInspection: Omit<LocalInspection, 'id'>) => {
    try {
      await createInspection(newInspection);
      toast.success("Vistoria solicitada com sucesso.");
    } catch (error) {
      console.error("Error creating inspection:", error);
      toast.error("Erro ao solicitar vistoria. Tente novamente.");
    }
  };

  const handleApproveInspection = async (inspectionId: string) => {
    try {
      await updateInspection(inspectionId, { status: "Concluída" });
      toast.success("Vistoria aprovada com sucesso.");
    } catch (error) {
      console.error("Error approving inspection:", error);
      toast.error("Erro ao aprovar vistoria. Tente novamente.");
    }
  };

  const handleRejectInspection = async (inspectionId: string, observations?: string) => {
    try {
      await updateInspection(inspectionId, { status: "Rejeitada", observations });
      toast.success("Vistoria rejeitada com sucesso.");
    } catch (error) {
      console.error("Error rejecting inspection:", error);
      toast.error("Erro ao rejeitar vistoria. Tente novamente.");
    }
  };

  const handleViewDetails = (inspection: LocalInspection) => {
    setSelectedInspection(inspection);
    setIsDetailsDialogOpen(true);
  };

  const handleInspectionClick = (inspection: LocalInspection) => {
    setSelectedInspection(inspection);
    setShowCamera(true);
  };

  const handleViewDriverHistory = (inspection: LocalInspection) => {
    setSelectedDriverForHistory({
      name: inspection.driverName,
      vehiclePlate: inspection.vehiclePlate,
      vehicleModel: inspection.vehicleModel
    });
    setShowDriverHistory(true);
  };

  const handleCameraComplete = () => {
    setShowCamera(false);
    setSelectedInspection(null);
  };

  const handleInspectionViewUpdate = (inspectionId: string, status: LocalInspection["status"], observations?: string) => {
    updateInspection(inspectionId, { status, observations });
  };

  return {
    selectedInspection,
    isDetailsDialogOpen,
    showCamera,
    showDriverHistory,
    showInspectionView,
    selectedDriverForHistory,
    setIsDetailsDialogOpen,
    setShowCamera,
    setShowDriverHistory,
    setShowInspectionView,
    setSelectedInspection,
    setSelectedDriverForHistory,
    handleCreateInspection,
    handleApproveInspection,
    handleRejectInspection,
    handleViewDetails,
    handleInspectionClick,
    handleViewDriverHistory,
    handleCameraComplete,
    handleInspectionViewUpdate
  };
};
