import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { LocalInspection } from "../types/inspection";

// Mock data for demonstration - this will be replaced with real API calls
const mockInspections: LocalInspection[] = [
  {
    id: "1",
    vehiclePlate: "ABC-1234",
    vehicleModel: "Honda Civic",
    driverName: "João Santos",
    type: "Inicial",
    status: "Pendente",
    inspector: "Sistema",
    vistoriador: "Sistema",
    observations: "Vistoria inicial automática",
    photos: 0,
    recipient: "inspector",
    contractId: "CTR-001",
    inspectionDate: "2024-01-15",
    rentalCompanyId: "company1"
  },
  {
    id: "2",
    vehiclePlate: "DEF-5678",
    vehicleModel: "Toyota Corolla",
    driverName: "Carlos Silva",
    type: "Entrega",
    status: "Aguardando Aprovação",
    inspector: "Vistoriador João",
    vistoriador: "Vistoriador João",
    observations: "Vistoria realizada com sucesso",
    photos: 14,
    recipient: "company",
    contractId: "CTR-002",
    inspectionDate: "2024-01-14",
    rentalCompanyId: "company1"
  }
];

export const useInspectionsData = () => {
  const { user } = useAuth();
  const [inspections, setInspections] = useState<LocalInspection[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Filter inspections based on user role
    let filteredInspections = mockInspections;
    
    if (user?.role === UserRole.RENTAL_COMPANY) {
      filteredInspections = mockInspections.filter(
        inspection => inspection.rentalCompanyId === user.id
      );
    }
    
    setInspections(filteredInspections);
    setLoading(false);
  }, [user]);

  const createInspection = async (inspectionData: Omit<LocalInspection, 'id'>) => {
    const newId = (Math.max(...inspections.map(i => parseInt(i.id) || 0), 0) + 1).toString();
    const inspectionWithId = {
      ...inspectionData,
      id: newId,
      rentalCompanyId: user?.role === UserRole.RENTAL_COMPANY ? user.id : undefined
    };
    setInspections(prev => [...prev, inspectionWithId]);
  };

  const getFilteredInspections = (status: string) => {
    return inspections.filter(inspection => {
      if (status === "Pendente") return inspection.status === "Pendente";
      if (status === "Aguardando Aprovação") return inspection.status === "Aguardando Aprovação";
      if (status === "Concluída") return inspection.status === "Concluída";
      return true;
    });
  };

  const updateInspectionStatus = (inspectionId: string, status: LocalInspection["status"], observations?: string) => {
    setInspections(prev => prev.map(inspection => 
      inspection.id === inspectionId 
        ? { ...inspection, status, observations: observations || inspection.observations }
        : inspection
    ));
  };

  const addDeliveryInspection = (vehiclePlate: string, driverName: string) => {
    const newId = (Math.max(...inspections.map(i => parseInt(i.id) || 0), 0) + 1).toString();
    const newInspection: LocalInspection = {
      id: newId,
      vehiclePlate,
      vehicleModel: "Modelo do Veículo",
      driverName,
      type: "Entrega",
      status: "Pendente",
      inspector: "Sistema",
      vistoriador: "Sistema",
      observations: "Vistoria de entrega criada automaticamente",
      photos: 0,
      recipient: "driver",
      contractId: `CTR-${Date.now()}`,
      inspectionDate: new Date().toISOString().split('T')[0],
      rentalCompanyId: user?.role === UserRole.RENTAL_COMPANY ? user.id : undefined
    };
    setInspections(prev => [...prev, newInspection]);
  };

  const rejectPhoto = (inspectionId: string, photoId: string) => {
    console.log('Rejecting photo:', photoId, 'for inspection:', inspectionId);
  };

  const rejectAllPhotos = (inspectionId: string) => {
    console.log('Rejecting all photos for inspection:', inspectionId);
  };

  const pendingInspectionsCount = getFilteredInspections("Pendente").length;
  const awaitingApprovalInspectionsCount = getFilteredInspections("Aguardando Aprovação").length;
  const completedInspectionsCount = getFilteredInspections("Concluída").length;

  return {
    inspections,
    loading,
    createInspection,
    getFilteredInspections,
    updateInspectionStatus,
    addDeliveryInspection,
    rejectPhoto,
    rejectAllPhotos,
    pendingInspectionsCount,
    awaitingApprovalInspectionsCount,
    completedInspectionsCount
  };
};
;
