
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { UserRole } from "@/types";
import { LocalInspection } from "../types/inspection";

export const useRealInspectionsData = () => {
  const { user } = useAuth();
  const [inspections, setInspections] = useState<LocalInspection[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchInspections = async () => {
    try {
      setLoading(true);
      
      if (!user) {
        setInspections([]);
        return;
      }

      // Se for locadora, buscar apenas vistorias da empresa
      let query = supabase
        .from('inspections')
        .select(`
          *,
          rental_company_vehicles!inner(
            brand,
            model,
            plate
          ),
          drivers(
            full_name
          )
        `)
        .order('created_at', { ascending: false });

      // Filtrar por empresa se for locadora
      if (user.role === UserRole.RENTAL_COMPANY) {
        query = query.eq('company_id', user.id);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching inspections:', error);
        toast.error('Erro ao carregar vistorias');
        return;
      }

      // Transformar dados para o formato esperado
      const formattedInspections: LocalInspection[] = data?.map(inspection => ({
        id: inspection.id,
        vehiclePlate: inspection.rental_company_vehicles?.plate || 'N/A',
        vehicleModel: `${inspection.rental_company_vehicles?.brand || ''} ${inspection.rental_company_vehicles?.model || ''}`.trim(),
        driverName: inspection.drivers?.full_name || 'Sem motorista',
        type: inspection.type || 'Inicial',
        status: mapDbStatusToLocal(inspection.status),
        inspector: inspection.inspector || 'Sistema',
        vistoriador: inspection.inspector || 'Sistema',
        observations: inspection.observations || '',
        photos: inspection.photos_count || 0,
        recipient: inspection.assigned_to as "driver" | "inspector" | "company",
        contractId: inspection.contract_id || `INS-${inspection.id}`,
        inspectionDate: inspection.inspection_date || inspection.created_at,
        rentalCompanyId: user.role === UserRole.RENTAL_COMPANY ? user.id : undefined
      })) || [];

      setInspections(formattedInspections);
    } catch (error) {
      console.error('Error in fetchInspections:', error);
      toast.error('Erro ao carregar vistorias');
    } finally {
      setLoading(false);
    }
  };

  // Helper function to map database status to local status
  const mapDbStatusToLocal = (dbStatus: string): LocalInspection['status'] => {
    switch (dbStatus) {
      case 'pending':
        return 'Pendente';
      case 'completed':
        return 'Concluída';
      case 'rejected':
        return 'Rejeitada';
      case 'awaiting_approval':
        return 'Aguardando Aprovação';
      case 'in_progress':
        return 'Em Andamento';
      default:
        return 'Pendente';
    }
  };

  // Helper function to map local status to database status
  const mapLocalStatusToDb = (localStatus: LocalInspection['status']): string => {
    switch (localStatus) {
      case 'Pendente':
        return 'pending';
      case 'Concluída':
        return 'completed';
      case 'Rejeitada':
        return 'rejected';
      case 'Aguardando Aprovação':
        return 'awaiting_approval';
      case 'Em Andamento':
        return 'in_progress';
      default:
        return 'pending';
    }
  };

  const createInspection = async (inspectionData: Omit<LocalInspection, 'id'>) => {
    try {
      if (!user || user.role !== UserRole.RENTAL_COMPANY) {
        toast.error('Acesso não autorizado');
        return null;
      }

      // Buscar o veículo para obter informações completas
      const { data: vehicleData, error: vehicleError } = await supabase
        .from('rental_company_vehicles')
        .select('*')
        .eq('plate', inspectionData.vehiclePlate)
        .eq('company_id', user.id)
        .single();

      if (vehicleError || !vehicleData) {
        toast.error('Veículo não encontrado');
        return null;
      }

      const { data, error } = await supabase
        .from('inspections')
        .insert([{
          vehicle_id: vehicleData.id,
          company_id: user.id,
          driver_id: vehicleData.driver_id,
          type: inspectionData.type,
          status: mapLocalStatusToDb(inspectionData.status),
          assigned_to: inspectionData.recipient,
          inspector: inspectionData.inspector,
          observations: inspectionData.observations,
          inspection_date: inspectionData.inspectionDate,
          contract_id: inspectionData.contractId
        }])
        .select()
        .single();

      if (error) {
        console.error('Error creating inspection:', error);
        toast.error('Erro ao criar vistoria');
        return null;
      }

      toast.success('Vistoria criada com sucesso');
      await fetchInspections(); // Refresh the list
      return data;
    } catch (error) {
      console.error('Error in createInspection:', error);
      toast.error('Erro ao criar vistoria');
      return null;
    }
  };

  const updateInspection = async (inspectionId: string, updates: Partial<LocalInspection>) => {
    try {
      const { error } = await supabase
        .from('inspections')
        .update({
          status: updates.status ? mapLocalStatusToDb(updates.status) : undefined,
          observations: updates.observations,
          updated_at: new Date().toISOString()
        })
        .eq('id', inspectionId);

      if (error) {
        console.error('Error updating inspection:', error);
        toast.error('Erro ao atualizar vistoria');
        return;
      }

      toast.success('Vistoria atualizada com sucesso');
      await fetchInspections(); // Refresh the list
    } catch (error) {
      console.error('Error in updateInspection:', error);
      toast.error('Erro ao atualizar vistoria');
    }
  };

  useEffect(() => {
    fetchInspections();
  }, [user]);

  return {
    inspections,
    loading,
    createInspection,
    updateInspection,
    refetch: fetchInspections
  };
};
