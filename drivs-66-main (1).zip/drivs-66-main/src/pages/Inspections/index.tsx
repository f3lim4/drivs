
import { useRealInspectionsData } from "./hooks/useRealInspectionsData";
import { useInspectionActions } from "./hooks/useInspectionActions";
import OriginalInspections from "./OriginalInspections";

const Inspections = () => {
  return <OriginalInspections />;
};

export default Inspections;
