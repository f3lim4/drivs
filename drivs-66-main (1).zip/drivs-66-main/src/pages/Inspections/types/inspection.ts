
export interface LocalInspection {
  id: string; // Changed from number to string to match UUID
  vehiclePlate: string;
  vehicleModel: string;
  driverName: string;
  type: string;
  status: "Pendente" | "Concluída" | "Rejeitada" | "Aguardando Aprovação" | "Em Andamento";
  inspector: string;
  vistoriador: string; // Made required to match existing usage
  observations: string;
  photos: number;
  recipient: "driver" | "inspector" | "company";
  contractId: string;
  inspectionDate: string;
  rentalCompanyId?: string;
}
