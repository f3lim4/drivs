import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Building,
  Upload,
  Save,
  Phone,
  Mail,
  MapPin,
  FileText,
  Image as ImageIcon
} from "lucide-react";

const SettingsPage = () => {
  const { user } = useAuth();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [whatsappNotifications, setWhatsappNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [language, setLanguage] = useState("pt-BR");

  // Estados para configurações da empresa
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [companyData, setCompanyData] = useState({
    name: "Auto Rental Plus",
    cnpj: "12.345.678/0001-90",
    email: "contato@autorentalplus.com",
    phone: "(11) 9999-8888",
    whatsapp: "5511999998888",
    emergencyPhone: "(11) 9999-9999",
    address: "Av. Paulista, 1000 - Bela Vista, São Paulo - SP",
    cep: "01310-100",
    city: "São Paulo",
    state: "SP",
    description: "Especializada em veículos premium para motoristas profissionais com foco em qualidade e atendimento diferenciado.",
    website: "https://autorentalplus.com",
    operatingHours: "Segunda a Sexta: 8h às 18h | Sábado: 8h às 14h"
  });
  
  // Função para mudar a senha (mockada)
  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newPassword !== confirmPassword) {
      toast.error("As senhas não coincidem");
      return;
    }
    
    // Aqui implementaria a lógica real de mudança de senha
    toast.success("Senha alterada com sucesso");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };
  
  // Função para salvar preferências (mockada)
  const handleSavePreferences = () => {
    toast.success("Preferências salvas com sucesso");
  };

  // Funções para configurações da empresa
  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setLogoFile(file);
      
      // Criar preview da imagem
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveCompanyInfo = async () => {
    setIsSubmitting(true);
    try {
      // Aqui seria feita a integração com a API
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simular API call
      toast.success("Informações da locadora atualizadas com sucesso!");
    } catch (error) {
      toast.error("Erro ao salvar informações");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveLogo = async () => {
    if (!logoFile) {
      toast.error("Selecione uma logo primeiro");
      return;
    }

    setIsSubmitting(true);
    try {
      // Aqui seria feito o upload da logo
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simular upload
      toast.success("Logo atualizada com sucesso!");
    } catch (error) {
      toast.error("Erro ao fazer upload da logo");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Renderiza configurações específicas para administradores
  const renderAdminSettings = () => {
    if (user?.role !== UserRole.ADMIN) return null;
    
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Configurações do Sistema</CardTitle>
          <CardDescription>Gerencie as configurações globais do sistema.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="systemName">Nome do Sistema</Label>
              <Input id="systemName" defaultValue="Drivs" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="supportEmail">Email de Suporte</Label>
              <Input id="supportEmail" defaultValue="suporte@drivs.com.br" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="pointsLimit">Limite de Pontos para Lista Negra</Label>
              <Input id="pointsLimit" type="number" defaultValue="20" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="approvalProcess">Processo de Aprovação</Label>
              <Select defaultValue="manual">
                <SelectTrigger id="approvalProcess">
                  <SelectValue placeholder="Selecionar processo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">Aprovação Manual</SelectItem>
                  <SelectItem value="automatic">Aprovação Automática</SelectItem>
                  <SelectItem value="hybrid">Processo Híbrido</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="pt-4">
            <Button onClick={() => toast.success("Configurações do sistema atualizadas")}>
              Salvar Configurações do Sistema
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  const isRentalCompany = user?.role === UserRole.RENTAL_COMPANY || user?.role === UserRole.MANAGER;

  // Determine default tab based on user role
  const defaultTab = isRentalCompany ? "company" : "account";

  return (
    <div className="container py-6 space-y-6">
      <h1 className="text-2xl font-bold">Configurações</h1>
      
      <Tabs defaultValue={defaultTab} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="account">Conta</TabsTrigger>
          <TabsTrigger value="preferences">Preferências</TabsTrigger>
          <TabsTrigger value="notifications">Notificações</TabsTrigger>
          {isRentalCompany && (
            <TabsTrigger value="company">Empresa</TabsTrigger>
          )}
          {user?.role === UserRole.ADMIN && (
            <TabsTrigger value="system">Sistema</TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Configurações da Conta</CardTitle>
              <CardDescription>Gerencie as informações e segurança da sua conta.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handlePasswordChange} className="space-y-4">
                <h3 className="text-lg font-medium">Alterar Senha</h3>
                <div className="space-y-2">
                  <Label htmlFor="current-password">Senha Atual</Label>
                  <Input
                    id="current-password"
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-password">Nova Senha</Label>
                  <Input
                    id="new-password"
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirmar Nova Senha</Label>
                  <Input
                    id="confirm-password"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit">Alterar Senha</Button>
              </form>
              
              <div className="border-t pt-6 space-y-4">
                <h3 className="text-lg font-medium">Dados da Conta</h3>
                <div className="space-y-2">
                  <Label htmlFor="account-email">Email da Conta</Label>
                  <Input id="account-email" defaultValue={user?.email} disabled />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="account-role">Tipo de Conta</Label>
                  <Input id="account-role" defaultValue={
                    user?.role === UserRole.ADMIN ? "Administrador" :
                    user?.role === UserRole.DRIVER ? "Motorista" :
                    user?.role === UserRole.MANAGER ? "Gestor" :
                    "Empresa de Aluguel"
                  } disabled />
                </div>
                <div className="flex items-center space-x-2 pt-4">
                  <Button variant="destructive">Desativar Conta</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="preferences">
          <Card>
            <CardHeader>
              <CardTitle>Preferências</CardTitle>
              <CardDescription>Personalize sua experiência no sistema.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="pt-2">
                  <Label htmlFor="language">Idioma</Label>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Selecionar idioma" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                      <SelectItem value="en-US">English (US)</SelectItem>
                      <SelectItem value="es-ES">Español</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="pt-2">
                  <Label htmlFor="timezone">Fuso Horário</Label>
                  <Select defaultValue="America/Sao_Paulo">
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Selecionar fuso horário" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="America/Sao_Paulo">Brasília (UTC-3)</SelectItem>
                      <SelectItem value="America/Manaus">Manaus (UTC-4)</SelectItem>
                      <SelectItem value="America/Rio_Branco">Rio Branco (UTC-5)</SelectItem>
                      <SelectItem value="America/New_York">New York (UTC-5)</SelectItem>
                      <SelectItem value="Europe/London">Londres (UTC+0)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="pt-4">
                  <Button onClick={handleSavePreferences}>
                    Salvar Preferências
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notificações</CardTitle>
              <CardDescription>Gerencie suas preferências de notificação.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications">Notificações por Email</Label>
                    <p className="text-sm text-muted-foreground">
                      Receba atualizações e alertas importantes por email
                    </p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="whatsapp-notifications">Notificações por WhatsApp</Label>
                    <p className="text-sm text-muted-foreground">
                      Receba notificações importantes via WhatsApp
                    </p>
                  </div>
                  <Switch
                    id="whatsapp-notifications"
                    checked={whatsappNotifications}
                    onCheckedChange={setWhatsappNotifications}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="push-notifications">Notificações Push</Label>
                    <p className="text-sm text-muted-foreground">
                      Receba alertas em tempo real no seu dispositivo
                    </p>
                  </div>
                  <Switch
                    id="push-notifications"
                    checked={pushNotifications}
                    onCheckedChange={setPushNotifications}
                  />
                </div>
                
                {user?.role === UserRole.RENTAL_COMPANY && (
                  <div className="pt-2 space-y-2">
                    <h3 className="text-sm font-medium">Notificar sobre:</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Switch id="notify-drivers" defaultChecked />
                        <Label htmlFor="notify-drivers">Novos motoristas interessados</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="notify-contracts" defaultChecked />
                        <Label htmlFor="notify-contracts">Contratos expirando</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="notify-maintenance" defaultChecked />
                        <Label htmlFor="notify-maintenance">Manutenções agendadas</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="notify-payments" defaultChecked />
                        <Label htmlFor="notify-payments">Pagamentos recebidos</Label>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="pt-4">
                  <Button onClick={() => toast.success("Preferências de notificação salvas")}>
                    Salvar Preferências de Notificação
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {isRentalCompany && (
          <TabsContent value="company" className="space-y-6">
            <Tabs defaultValue="info" className="space-y-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="info" className="flex items-center gap-2">
                  <Building className="h-4 w-4" />
                  Informações da Empresa
                </TabsTrigger>
                <TabsTrigger value="branding" className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4" />
                  Logo e Identidade
                </TabsTrigger>
              </TabsList>

              <TabsContent value="info" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Building className="h-5 w-5" />
                      Dados da Empresa
                    </CardTitle>
                    <CardDescription>
                      Mantenha as informações da sua locadora sempre atualizadas
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nome da Empresa</Label>
                        <Input
                          id="name"
                          value={companyData.name}
                          onChange={(e) => setCompanyData({ ...companyData, name: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cnpj">CNPJ</Label>
                        <Input
                          id="cnpj"
                          value={companyData.cnpj}
                          onChange={(e) => setCompanyData({ ...companyData, cnpj: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="flex items-center gap-2">
                          <Mail className="h-4 w-4" />
                          Email Principal
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={companyData.email}
                          onChange={(e) => setCompanyData({ ...companyData, email: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          Telefone Principal
                        </Label>
                        <Input
                          id="phone"
                          value={companyData.phone}
                          onChange={(e) => setCompanyData({ ...companyData, phone: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="whatsapp">WhatsApp</Label>
                        <Input
                          id="whatsapp"
                          value={companyData.whatsapp}
                          onChange={(e) => setCompanyData({ ...companyData, whatsapp: e.target.value })}
                          placeholder="5511999999999"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="emergencyPhone">Telefone de Emergência</Label>
                        <Input
                          id="emergencyPhone"
                          value={companyData.emergencyPhone}
                          onChange={(e) => setCompanyData({ ...companyData, emergencyPhone: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address" className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        Endereço Completo
                      </Label>
                      <Input
                        id="address"
                        value={companyData.address}
                        onChange={(e) => setCompanyData({ ...companyData, address: e.target.value })}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="cep">CEP</Label>
                        <Input
                          id="cep"
                          value={companyData.cep}
                          onChange={(e) => setCompanyData({ ...companyData, cep: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="city">Cidade</Label>
                        <Input
                          id="city"
                          value={companyData.city}
                          onChange={(e) => setCompanyData({ ...companyData, city: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="state">Estado</Label>
                        <Input
                          id="state"
                          value={companyData.state}
                          onChange={(e) => setCompanyData({ ...companyData, state: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description" className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Descrição da Empresa
                      </Label>
                      <Textarea
                        id="description"
                        value={companyData.description}
                        onChange={(e) => setCompanyData({ ...companyData, description: e.target.value })}
                        rows={3}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="website">Website</Label>
                        <Input
                          id="website"
                          value={companyData.website}
                          onChange={(e) => setCompanyData({ ...companyData, website: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="operatingHours">Horário de Funcionamento</Label>
                        <Input
                          id="operatingHours"
                          value={companyData.operatingHours}
                          onChange={(e) => setCompanyData({ ...companyData, operatingHours: e.target.value })}
                        />
                      </div>
                    </div>

                    <Button onClick={handleSaveCompanyInfo} disabled={isSubmitting}>
                      <Save className="h-4 w-4 mr-2" />
                      {isSubmitting ? "Salvando..." : "Salvar Informações"}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="branding" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ImageIcon className="h-5 w-5" />
                      Logo da Empresa
                    </CardTitle>
                    <CardDescription>
                      Faça upload da logo da sua locadora
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="logo">Selecionar Logo</Label>
                        <Input
                          id="logo"
                          type="file"
                          accept="image/*"
                          onChange={handleLogoChange}
                        />
                        <p className="text-sm text-muted-foreground">
                          Formatos aceitos: PNG, JPG, SVG. Tamanho recomendado: 300x100 pixels
                        </p>
                      </div>

                      {logoPreview && (
                        <div className="space-y-2">
                          <Label>Preview da Logo</Label>
                          <div className="border rounded-lg p-4 bg-gray-50">
                            <img
                              src={logoPreview}
                              alt="Preview da logo"
                              className="max-h-24 object-contain"
                            />
                          </div>
                        </div>
                      )}

                      <Button onClick={handleSaveLogo} disabled={isSubmitting || !logoFile}>
                        <Upload className="h-4 w-4 mr-2" />
                        {isSubmitting ? "Fazendo Upload..." : "Salvar Logo"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-blue-50 border-blue-200">
                  <CardHeader>
                    <CardTitle>Diretrizes para Logo</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      <div>
                        <h4 className="font-medium">Tamanho Recomendado:</h4>
                        <p>300x100 pixels ou proporção 3:1</p>
                      </div>
                      <div>
                        <h4 className="font-medium">Formatos Aceitos:</h4>
                        <p>PNG (recomendado), JPG, SVG</p>
                      </div>
                      <div>
                        <h4 className="font-medium">Qualidade:</h4>
                        <p>Use imagens de alta qualidade com fundo transparente (PNG)</p>
                      </div>
                      <div>
                        <h4 className="font-medium">Onde Aparece:</h4>
                        <p>A logo será exibida no painel, relatórios e documentos da locadora</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </TabsContent>
        )}
        
        <TabsContent value="system">
          {renderAdminSettings()}
          
          <Card>
            <CardHeader>
              <CardTitle>Backup e Dados</CardTitle>
              <CardDescription>Gerencie backups e dados do sistema.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Backup do Sistema</h3>
                  <p className="text-sm text-muted-foreground">Último backup: 19/05/2025 08:30</p>
                  <Button variant="outline" className="mt-2">Fazer Backup Manual</Button>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Gerenciamento de Dados</h3>
                  <p className="text-sm text-muted-foreground">Exportar ou limpar dados do sistema</p>
                  <div className="flex space-x-2 mt-2">
                    <Button variant="outline">Exportar Dados</Button>
                    <Button variant="destructive">Limpar Dados</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SettingsPage;
