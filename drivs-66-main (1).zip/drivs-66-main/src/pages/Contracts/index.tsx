
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import ContractViewer from "./components/ContractViewer";
import { DriverContractsView } from "./components/DriverContractsView";
import { RentalCompanyContractsView } from "./components/RentalCompanyContractsView";
import { AdminContractsView } from "./components/AdminContractsView";
import { useRealContractsData } from "./hooks/useRealContractsData";
import { useContractsData, type Contract } from "./hooks/useContractsData";
import { toast } from "sonner";

const ContractsPage = () => {
  const { user } = useAuth();
  
  // Para locadoras, usar dados reais. Para outros roles, usar dados mock
  const realContractsData = useRealContractsData();
  const mockContractsData = useContractsData();
  
  const isRentalCompany = user?.role === UserRole.RENTAL_COMPANY;
  const { contracts, setContracts, loading } = isRentalCompany ? realContractsData : mockContractsData;
  
  const [selectedContractForView, setSelectedContractForView] = useState<Contract | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);

  const handleViewContract = (contract: Contract) => {
    setSelectedContractForView(contract);
    setIsViewerOpen(true);
  };

  const handleCancelContract = (contractId: string) => {
    setContracts(prev => prev.map(contract => 
      contract.id === contractId 
        ? { ...contract, status: "cancelled" as const }
        : contract
    ));
    toast.success("Contrato cancelado com sucesso!");
  };

  const handleDeactivateContract = (contractId: string, reason: string, selectedPayments: string[]) => {
    const hasBreachFine = selectedPayments.includes("PAY-BREACH");
    
    setContracts(prev => prev.map(contract => 
      contract.id === contractId 
        ? { 
            ...contract, 
            status: "deactivated" as const,
            deactivation_reason: reason,
            deactivated_at: new Date().toISOString()
          }
        : contract
    ));

    if (hasBreachFine) {
      console.log(`Multa por quebra de contrato aplicada para contrato ${contractId}`);
    }
    
    toast.success("Contrato desativado com sucesso!");
  };

  if (loading) {
    return (
      <div className="page-content ml-4">
        <div className="h-10 w-full max-w-xs bg-gradient-to-r from-blue-200 to-purple-200 animate-pulse rounded"></div>
        <div className="h-12 w-full bg-gradient-to-r from-blue-100 to-purple-100 animate-pulse rounded mt-4"></div>
        <div className="h-96 w-full bg-gradient-to-r from-blue-50 to-purple-50 animate-pulse rounded mt-4"></div>
      </div>
    );
  }

  // Render appropriate view based on user role
  const renderContractsView = () => {
    if (user?.role === UserRole.DRIVER) {
      return (
        <DriverContractsView
          contracts={contracts}
          onViewContract={handleViewContract}
        />
      );
    }

    if (user?.role === UserRole.RENTAL_COMPANY || user?.role === UserRole.MANAGER) {
      return (
        <RentalCompanyContractsView
          contracts={contracts}
          onViewContract={handleViewContract}
          onCancelContract={handleCancelContract}
          onDeactivateContract={handleDeactivateContract}
        />
      );
    }

    if (user?.role === UserRole.ADMIN) {
      return (
        <AdminContractsView
          contracts={contracts}
          onViewContract={handleViewContract}
        />
      );
    }

    return null;
  };

  return (
    <>
      {renderContractsView()}
      
      {/* Modal de Visualização de Contratos */}
      <ContractViewer 
        isOpen={isViewerOpen}
        onClose={() => setIsViewerOpen(false)}
        contract={selectedContractForView}
      />
    </>
  );
};

export default ContractsPage;
