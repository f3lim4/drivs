
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { ContractGenerator } from "./components/ContractGenerator";

const ContractGeneratorPage = () => {
  const navigate = useNavigate();

  const handleClose = () => {
    navigate("/locadora/contratos");
  };

  return (
    <div className="min-h-screen bg-background dark:bg-gray-900">
      <div className="page-content">
        <div className="space-y-6">
          <div className="page-header">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  GERADOR DE CONTRATOS
                </h1>
                <p className="page-subtitle">
                  Crie contratos personalizados para seus motoristas
                </p>
              </div>
              <Button 
                variant="ghost" 
                onClick={handleClose}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar para Contratos
              </Button>
            </div>
          </div>
          
          <ContractGenerator onClose={handleClose} />
        </div>
      </div>
    </div>
  );
};

export default ContractGeneratorPage;
