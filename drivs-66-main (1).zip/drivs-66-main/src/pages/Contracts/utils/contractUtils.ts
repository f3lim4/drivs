
import { ContractData } from '../types/contractGenerator';
import { Driver, RentalCompany, RentalVehicle, UserRole } from '@/types';
import { Contract } from '../types/contract';
import { Badge } from "@/components/ui/badge";
import React from 'react';

export const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

export const calculateContractValues = (
  weeklyValue: number,
  contractMonths: number,
  depositValue: number
) => {
  const monthlyValue = weeklyValue * 4;
  const totalValue = (monthlyValue * contractMonths) + depositValue;
  return { monthlyValue, totalValue };
};

export const createContractData = (
  driver: Driver,
  vehicle: any,
  monthlyValue: number,
  contractMonths: number,
  userEmail?: string
): ContractData => {
  const company: RentalCompany = {
    id: 'company-1',
    companyName: 'Locadora Demo',
    email: userEmail || 'locadora@email.com',
    role: UserRole.RENTAL_COMPANY,
    cnpj: '12.345.678/0001-90',
    phone: '(31) 98765-4321',
    address: 'Av. Antônio Carlos, 123',
    verified: true,
    vehicleCount: 1,
    rating: 4.5
  };

  const mappedVehicle: RentalVehicle = {
    id: vehicle.id,
    brand: vehicle.brand,
    model: vehicle.model,
    plate: vehicle.plate,
    year: vehicle.year,
    color: vehicle.color,
    status: vehicle.status as 'available',
    documentExpiry: vehicle.document_expiry || '2024-12-31',
    vehicleValue: vehicle.vehicle_value || 0,
    isFinanced: vehicle.is_financed,
    monthlyInsurance: vehicle.monthly_insurance || 0,
    monthlyTracker: vehicle.monthly_tracker || 0,
    images: vehicle.images || [],
    depositValue: vehicle.deposit_value,
    weeklyValue: vehicle.weekly_value,
    vehicleType: vehicle.vehicle_type
  };

  return {
    driver,
    company,
    vehicle: mappedVehicle,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + contractMonths * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    monthlyAmount: monthlyValue,
    terms: 'Termos padrão do contrato',
    signatureType: 'online'
  };
};

export const generateContract = async (data: ContractData) => {
  // Simular geração do contrato
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  return {
    success: true,
    contractUrl: '/api/contracts/generated-contract.pdf'
  };
};

export const getStatusBadge = (status: string) => {
  const statusConfig = {
    active: { variant: "default" as const, label: "Ativo" },
    pending: { variant: "secondary" as const, label: "Pendente" },
    unsigned: { variant: "destructive" as const, label: "Não Assinado" },
    signed_pending: { variant: "outline" as const, label: "Aguardando Assinatura" },
    cancelled: { variant: "destructive" as const, label: "Cancelado" }
  };

  const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
  
  return React.createElement(Badge, { variant: config.variant }, config.label);
};

export const filterContracts = (contracts: Contract[], searchTerm: string, statusFilter: string) => {
  return contracts.filter(contract => {
    const matchesSearch = !searchTerm || 
      contract.driver_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.vehicle_info?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || contract.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
};
