
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Car } from "lucide-react";
import { Driver } from "@/types";

interface VehicleDriverSelectorProps {
  approvedDrivers: Driver[];
  selectedDriverId: string;
  setSelectedDriverId: (id: string) => void;
  availableVehicles: any[];
  selectedVehicleId: string;
  handleVehicleChange: (vehicleId: string) => void;
  formatCurrency: (value: number) => string;
}

export const VehicleDriverSelector = ({
  approvedDrivers,
  selectedDriverId,
  setSelectedDriverId,
  availableVehicles,
  selectedVehicleId,
  handleVehicleChange,
  formatCurrency,
}: VehicleDriverSelectorProps) => {
  return (
    <>
      {/* Seleção do Motorista */}
      <div className="space-y-2">
        <Label htmlFor="driver" className="flex items-center gap-2">
          <Users className="h-4 w-4" />
          Motorista Aprovado
        </Label>
        <Select value={selectedDriverId} onValueChange={setSelectedDriverId}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione um motorista aprovado" />
          </SelectTrigger>
          <SelectContent>
            {approvedDrivers.map((driver) => (
              <SelectItem key={driver.id} value={driver.id}>
                <div className="flex flex-col">
                  <span className="font-medium">{driver.fullName}</span>
                  <span className="text-sm text-muted-foreground">
                    CPF: {driver.cpf} • CNH: {driver.cnh}
                  </span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {approvedDrivers.length === 0 && (
          <p className="text-sm text-muted-foreground">
            Nenhum motorista aprovado encontrado no banco de dados. Para gerar contratos, primeiro é necessário ter motoristas com status "Aprovado" no sistema.
          </p>
        )}
      </div>

      {/* Seleção do Veículo */}
      <div className="space-y-2">
        <Label htmlFor="vehicle" className="flex items-center gap-2">
          <Car className="h-4 w-4" />
          Veículo Disponível
        </Label>
        <Select value={selectedVehicleId} onValueChange={handleVehicleChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione um veículo disponível" />
          </SelectTrigger>
          <SelectContent>
            {availableVehicles.map((vehicle) => (
              <SelectItem key={vehicle.id} value={vehicle.id}>
                <div className="flex flex-col">
                  <span className="font-medium">{vehicle.brand} {vehicle.model}</span>
                  <span className="text-sm text-muted-foreground">
                    Placa: {vehicle.plate} • Ano: {vehicle.year} • Cor: {vehicle.color}
                  </span>
                  <span className="text-sm text-green-600 font-medium">
                    Semanal: {formatCurrency(vehicle.weekly_value)} • Depósito: {formatCurrency(vehicle.deposit_value)}
                  </span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {availableVehicles.length === 0 && (
          <p className="text-sm text-muted-foreground">
            Nenhum veículo disponível encontrado. Apenas veículos com status "Disponível" podem ser selecionados para contrato.
          </p>
        )}
      </div>
    </>
  );
};
