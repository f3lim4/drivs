
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { FileText } from "lucide-react";

interface ContractSuccessProps {
  onClose: () => void;
}

export const ContractSuccess = ({
  onClose,
}: ContractSuccessProps) => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-600">
            <FileText className="h-5 w-5" />
            Contrato Enviado com Sucesso!
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-green-800">
              O contrato foi enviado e está aguardando assinatura do motorista.
            </p>
          </div>

          <Separator />

          <div className="flex gap-3 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>
              Voltar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
