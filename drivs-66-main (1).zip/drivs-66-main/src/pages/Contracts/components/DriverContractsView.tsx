
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Car, FileText, AlertTriangle } from "lucide-react";
import { ContractsTable } from "./ContractsTable";
import type { Contract } from "../hooks/useContractsData";

interface DriverContractsViewProps {
  contracts: Contract[];
  onViewContract: (contract: Contract) => void;
}

export const DriverContractsView = ({ contracts, onViewContract }: DriverContractsViewProps) => {
  const isTerminated = contracts[0]?.status === "terminated";

  return (
    <div className="min-h-screen bg-background dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground dark:text-white">Contratos</h1>
            <p className="text-lg text-muted-foreground dark:text-gray-300 mt-1">
              {isTerminated ? "Histórico de contratos com locadoras" : "Meus contratos com locadoras"}
            </p>
          </div>
        </div>

        {/* Alerta para contrato encerrado */}
        {isTerminated && (
          <Card className="border-red-200 bg-red-50 mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-800">
                <AlertTriangle className="h-5 w-5" />
                Contrato Encerrado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-700">
                Este contrato foi encerrado pela locadora. Você pode visualizar o histórico e documentos abaixo.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Resumo dos Contratos para Motoristas */}
        {contracts.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
              <CardContent className="p-6 text-center">
                <Building2 className="h-8 w-8 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-foreground dark:text-white">{contracts[0]?.company_name}</div>
                <p className="text-sm text-muted-foreground dark:text-gray-400">Locadora</p>
              </CardContent>
            </Card>

            <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
              <CardContent className="p-6 text-center">
                <Car className="h-8 w-8 text-green-600 dark:text-green-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-foreground dark:text-white">{contracts[0]?.vehicle_info}</div>
                <p className="text-sm text-muted-foreground dark:text-gray-400">Veículo</p>
              </CardContent>
            </Card>

            <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
              <CardContent className="p-6 text-center">
                <FileText className="h-8 w-8 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-foreground dark:text-white">{contracts[0]?.id}</div>
                <p className="text-sm text-muted-foreground dark:text-gray-400">ID do Contrato</p>
              </CardContent>
            </Card>
          </div>
        )}

        <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-foreground dark:text-white">
              {isTerminated ? "Histórico de Contratos" : "Contrato Ativo"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {contracts.length > 0 ? (
              <ContractsTable
                contracts={contracts}
                onViewContract={onViewContract}
                showActions={true}
                userRole="DRIVER"
              />
            ) : (
              <div className="text-center py-10">
                <FileText className="h-12 w-12 text-muted-foreground dark:text-gray-500 mx-auto mb-4" />
                <p className="text-muted-foreground dark:text-gray-400 text-lg">Nenhum contrato encontrado.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
