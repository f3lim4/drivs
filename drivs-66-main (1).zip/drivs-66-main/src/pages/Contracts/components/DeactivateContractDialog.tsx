
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Ban, Calculator, Settings } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useRealRentalCompanyData } from "../hooks/useRealRentalCompanyData";

interface PendingPayment {
  id: string;
  description: string;
  amount: number;
  dueDate: string;
  type: "monthly_rent" | "fine" | "maintenance" | "other" | "contract_breach";
}

interface DeactivateContractDialogProps {
  contractId: string;
  driverName: string;
  contractEndDate: string;
  monthlyAmount: number;
  onDeactivate: (contractId: string, reason: string, selectedPayments: string[]) => void;
}

const DeactivateContractDialog = ({ 
  contractId, 
  driverName, 
  contractEndDate, 
  monthlyAmount, 
  onDeactivate 
}: DeactivateContractDialogProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [selectedPayments, setSelectedPayments] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Buscar dados reais da locadora
  const { pendingPayments: realPendingPayments, loading } = useRealRentalCompanyData(contractId, driverName);
  
  // Configurações da multa por quebra de contrato
  const [breachFineType, setBreachFineType] = useState<"none" | "full" | "custom">("full");
  const [customFineAmount, setCustomFineAmount] = useState("");
  const [customFineMonths, setCustomFineMonths] = useState("1");

  // Verificar se o contrato ainda está na validade
  const isContractValid = new Date(contractEndDate) > new Date();

  // Calcular valor da multa baseado na configuração
  const getContractBreachFine = () => {
    if (!isContractValid || breachFineType === "none") return 0;
    
    if (breachFineType === "full") return monthlyAmount * 2;
    
    if (breachFineType === "custom") {
      if (customFineAmount) {
        return parseFloat(customFineAmount) || 0;
      } else {
        const months = parseFloat(customFineMonths) || 1;
        return monthlyAmount * months;
      }
    }
    
    return 0;
  };

  const contractBreachFine = getContractBreachFine();

  // Combinar pagamentos reais com multa por quebra de contrato se aplicável
  const pendingPayments = (isContractValid && contractBreachFine > 0) ? [
    ...realPendingPayments,
    {
      id: "PAY-BREACH",
      description: `Multa por quebra de contrato ${breachFineType === "full" ? "(2 aluguéis)" : "(personalizada)"}`,
      amount: contractBreachFine,
      dueDate: new Date().toISOString().split('T')[0],
      type: "contract_breach" as const
    }
  ] : realPendingPayments;

  // Auto-selecionar a multa por quebra de contrato quando aplicável
  useState(() => {
    if (isContractValid && contractBreachFine > 0) {
      setSelectedPayments(["PAY-BREACH"]);
    }
  });

  const handlePaymentToggle = (paymentId: string) => {
    // Não permitir desmarcar a multa por quebra de contrato obrigatória
    if (paymentId === "PAY-BREACH" && isContractValid && contractBreachFine > 0) {
      return;
    }
    
    setSelectedPayments(prev => 
      prev.includes(paymentId) 
        ? prev.filter(id => id !== paymentId)
        : [...prev, paymentId]
    );
  };

  const handleSubmit = async () => {
    if (!reason.trim()) {
      toast.error("Por favor, informe o motivo da desativação");
      return;
    }

    setIsSubmitting(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simular API call
      onDeactivate(contractId, reason, selectedPayments);
      
      if (isContractValid && contractBreachFine > 0) {
        toast.success(`Contrato desativado com multa de R$ ${contractBreachFine.toFixed(2)} aplicada`);
      } else if (isContractValid && contractBreachFine === 0) {
        toast.success("Contrato desativado sem multa por quebra de contrato");
      } else {
        toast.success("Contrato desativado com sucesso");
      }
      
      setIsOpen(false);
      setReason("");
      setSelectedPayments(isContractValid && contractBreachFine > 0 ? ["PAY-BREACH"] : []);
    } catch (error) {
      toast.error("Erro ao desativar contrato");
    } finally {
      setIsSubmitting(false);
    }
  };

  const getPaymentTypeBadge = (type: string) => {
    switch (type) {
      case "monthly_rent":
        return <Badge variant="outline" className="text-blue-600">Aluguel</Badge>;
      case "fine":
        return <Badge variant="destructive">Multa</Badge>;
      case "maintenance":
        return <Badge variant="outline" className="text-orange-600">Manutenção</Badge>;
      case "contract_breach":
        return <Badge variant="destructive" className="bg-red-600">Quebra de Contrato</Badge>;
      default:
        return <Badge variant="outline">Outros</Badge>;
    }
  };

  const totalSelectedAmount = pendingPayments
    .filter(payment => selectedPayments.includes(payment.id))
    .reduce((total, payment) => total + payment.amount, 0);

  if (loading) {
    return (
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            variant="destructive"
            size="sm"
            className="flex items-center gap-2"
          >
            <Ban className="h-4 w-4" />
            Desativar
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-center p-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p>Carregando dados da locadora...</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="destructive"
          size="sm"
          className="flex items-center gap-2"
        >
          <Ban className="h-4 w-4" />
          Desativar
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            Desativar Contrato
          </DialogTitle>
          <DialogDescription>
            Você está prestes a desativar o contrato de <strong>{driverName}</strong>. 
            Esta ação colocará o motorista em status desativado.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Configuração de multa por quebra de contrato */}
          {isContractValid && (
            <Card className="bg-orange-50 border-orange-200">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-orange-800">
                  <Settings className="h-5 w-5" />
                  Configuração da Multa por Quebra de Contrato
                </CardTitle>
                <p className="text-sm text-orange-700">
                  Contrato válido até {new Date(contractEndDate).toLocaleDateString('pt-BR')}
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <RadioGroup
                  value={breachFineType}
                  onValueChange={(value: "none" | "full" | "custom") => setBreachFineType(value)}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="none" id="none" />
                    <Label htmlFor="none" className="flex-1">
                      <div className="font-medium">Não aplicar multa</div>
                      <div className="text-sm text-muted-foreground">
                        Desativar sem cobrança de multa por quebra de contrato
                      </div>
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="full" id="full" />
                    <Label htmlFor="full" className="flex-1">
                      <div className="font-medium">Multa padrão (2 aluguéis)</div>
                      <div className="text-sm text-muted-foreground">
                        R$ {(monthlyAmount * 2).toFixed(2)} - Conforme termos do contrato
                      </div>
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="custom" id="custom" />
                    <Label htmlFor="custom" className="flex-1">
                      <div className="font-medium">Valor personalizado</div>
                      <div className="text-sm text-muted-foreground">
                        Definir valor específico ou número de parcelas
                      </div>
                    </Label>
                  </div>
                </RadioGroup>

                {breachFineType === "custom" && (
                  <div className="mt-4 space-y-3 p-4 bg-white rounded-lg border">
                    <div className="space-y-2">
                      <Label htmlFor="custom-amount">Valor fixo (opcional)</Label>
                      <Input
                        id="custom-amount"
                        type="number"
                        placeholder="Ex: 1500.00"
                        value={customFineAmount}
                        onChange={(e) => setCustomFineAmount(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="text-center text-sm text-muted-foreground">ou</div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="custom-months">Número de aluguéis</Label>
                      <select 
                        id="custom-months"
                        value={customFineMonths}
                        onChange={(e) => setCustomFineMonths(e.target.value)}
                        className="w-full p-2 border rounded-md"
                      >
                        <option value="0.5">0.5 aluguel (R$ {(monthlyAmount * 0.5).toFixed(2)})</option>
                        <option value="1">1 aluguel (R$ {monthlyAmount.toFixed(2)})</option>
                        <option value="1.5">1.5 aluguéis (R$ {(monthlyAmount * 1.5).toFixed(2)})</option>
                        <option value="2">2 aluguéis (R$ {(monthlyAmount * 2).toFixed(2)})</option>
                        <option value="3">3 aluguéis (R$ {(monthlyAmount * 3).toFixed(2)})</option>
                      </select>
                    </div>

                    {contractBreachFine > 0 && (
                      <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <div className="flex items-center gap-2">
                          <Calculator className="h-4 w-4 text-red-600" />
                          <span className="font-medium text-red-800">
                            Valor da multa: R$ {contractBreachFine.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Motivo da desativação */}
          <div className="space-y-2">
            <Label htmlFor="reason">Motivo da Desativação *</Label>
            <Textarea
              id="reason"
              placeholder="Descreva o motivo da desativação do contrato..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="min-h-[100px]"
            />
          </div>

          {/* Pagamentos pendentes com dados reais */}
          {pendingPayments.length > 0 && (
            <div className="space-y-4">
              <div>
                <Label className="text-base font-medium">Pagamentos Pendentes (Dados Reais da Locadora)</Label>
                <p className="text-sm text-muted-foreground">
                  Selecione os pagamentos em aberto que devem ser incluídos na desativação:
                </p>
              </div>

              <div className="space-y-3">
                {pendingPayments.map((payment) => (
                  <Card key={payment.id} className={`border ${payment.type === 'contract_breach' ? 'border-red-300 bg-red-50' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <Checkbox
                          id={payment.id}
                          checked={selectedPayments.includes(payment.id)}
                          onCheckedChange={() => handlePaymentToggle(payment.id)}
                          disabled={payment.type === 'contract_breach' && isContractValid && contractBreachFine > 0}
                        />
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{payment.description}</p>
                              <p className="text-sm text-muted-foreground">
                                Vencimento: {new Date(payment.dueDate).toLocaleDateString('pt-BR')}
                              </p>
                              {payment.type === 'contract_breach' && isContractValid && contractBreachFine > 0 && (
                                <p className="text-xs text-red-600 mt-1">
                                  * Aplicação obrigatória conforme configuração
                                </p>
                              )}
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-lg">R$ {payment.amount.toFixed(2)}</p>
                              {getPaymentTypeBadge(payment.type)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {selectedPayments.length > 0 && (
                <Card className="bg-red-50 border-red-200">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-red-800">
                        Total selecionado ({selectedPayments.length} pagamentos):
                      </span>
                      <span className="font-bold text-xl text-red-800">
                        R$ {totalSelectedAmount.toFixed(2)}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Botões de ação */}
          <div className="flex gap-3 pt-4">
            <Button 
              variant="outline" 
              onClick={() => setIsOpen(false)}
              disabled={isSubmitting}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleSubmit}
              disabled={isSubmitting || !reason.trim()}
              className="flex-1"
            >
              {isSubmitting ? "Desativando..." : "Confirmar Desativação"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DeactivateContractDialog;
