
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText } from "lucide-react";
import { ContractsTable } from "./ContractsTable";
import type { Contract } from "../hooks/useContractsData";

interface AdminContractsViewProps {
  contracts: Contract[];
  onViewContract: (contract: Contract) => void;
}

export const AdminContractsView = ({ contracts, onViewContract }: AdminContractsViewProps) => {
  return (
    <div className="min-h-screen bg-background dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground dark:text-white">Contratos</h1>
            <p className="text-lg text-muted-foreground dark:text-gray-300 mt-1">
              Gestão de contratos
            </p>
          </div>
        </div>

        {/* Para admin - apenas visualização de contratos */}
        <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-foreground dark:text-white">Todos os Contratos</CardTitle>
          </CardHeader>
          <CardContent>
            {contracts.length > 0 ? (
              <ContractsTable
                contracts={contracts}
                onViewContract={onViewContract}
                showActions={true}
                userRole="ADMIN"
              />
            ) : (
              <div className="text-center py-10">
                <FileText className="h-12 w-12 text-muted-foreground dark:text-gray-500 mx-auto mb-4" />
                <p className="text-muted-foreground dark:text-gray-400 text-lg">Nenhum contrato encontrado.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
