
import { Button } from "@/components/ui/button";
import { DialogTrigger } from "@/components/ui/dialog";
import { Eye, Download, Upload } from "lucide-react";
import { toast } from "sonner";
import type { Contract } from "../hooks/useContractsData";
import CancelContractDialog from "./CancelContractDialog";
import DeactivateContractDialog from "./DeactivateContractDialog";

interface ContractActionsProps {
  contract: Contract;
  onViewContract: (contract: Contract) => void;
  onCancelContract?: (contractId: string) => void;
  onDeactivateContract?: (contractId: string, reason: string, selectedPayments: string[]) => void;
  onUploadClick: (contract: Contract) => void;
  isAdminView: boolean;
}

export const ContractActions = ({
  contract,
  onViewContract,
  onCancelContract,
  onDeactivateContract,
  onUploadClick,
  isAdminView
}: ContractActionsProps) => {
  const handleDownloadContract = (contractId: string) => {
    toast.success("Download do contrato iniciado...");
  };

  return (
    <div className="flex gap-2">
      <Button 
        variant="ghost" 
        size="icon"
        onClick={() => onViewContract(contract)}
        className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
      >
        <Eye className="h-4 w-4" />
      </Button>
      
      {(contract.document_url || contract.status === "active") && (
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => handleDownloadContract(contract.id)}
          className="text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300"
        >
          <Download className="h-4 w-4" />
        </Button>
      )}
      
      {contract.status === "signed_pending" && 
       contract.signature_type === "physical" && !isAdminView && (
        <DialogTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => onUploadClick(contract)}
            className="text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"
          >
            <Upload className="h-4 w-4" />
          </Button>
        </DialogTrigger>
      )}
      
      {contract.status === "active" && onDeactivateContract && !isAdminView && (
        <DeactivateContractDialog
          contractId={contract.id}
          driverName={contract.driver_name || ""}
          contractEndDate={contract.end_date}
          monthlyAmount={contract.monthly_amount}
          onDeactivate={onDeactivateContract}
        />
      )}
      
      {contract.status !== "cancelled" && 
       contract.status !== "deactivated" && 
       contract.status !== "terminated" &&
       contract.status !== "active" && 
       onCancelContract && 
       !isAdminView && (
        <CancelContractDialog 
          contractId={contract.id}
          onCancel={onCancelContract}
        />
      )}
    </div>
  );
};
