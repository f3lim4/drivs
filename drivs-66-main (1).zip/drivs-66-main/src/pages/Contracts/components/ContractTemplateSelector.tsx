
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Upload } from "lucide-react";
import { toast } from "sonner";

interface ContractTemplateSelectorProps {
  contractTemplate: string;
  setContractTemplate: (template: string) => void;
  customContractFile: File | null;
  setCustomContractFile: (file: File | null) => void;
}

export const ContractTemplateSelector = ({
  contractTemplate,
  setContractTemplate,
  customContractFile,
  setCustomContractFile,
}: ContractTemplateSelectorProps) => {
  const handleCustomContractUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCustomContractFile(file);
      toast.success("Contrato personalizado carregado com sucesso");
    }
  };

  return (
    <div className="space-y-4">
      <Label className="text-base font-medium">Modelo de Contrato</Label>
      <RadioGroup value={contractTemplate} onValueChange={setContractTemplate}>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="drivs" id="drivs" />
          <Label htmlFor="drivs">Usar modelo padrão da Drivs</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="custom" id="custom" />
          <Label htmlFor="custom">Upload de contrato personalizado da empresa</Label>
        </div>
      </RadioGroup>
      
      {contractTemplate === "custom" && (
        <div className="ml-6 space-y-2">
          <Label htmlFor="customContract">Contrato Personalizado</Label>
          <div className="flex items-center gap-2">
            <Input
              id="customContract"
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={handleCustomContractUpload}
              className="max-w-xs"
            />
            <Upload className="h-4 w-4 text-gray-400" />
          </div>
          {customContractFile && (
            <p className="text-sm text-green-600">
              Arquivo carregado: {customContractFile.name}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
