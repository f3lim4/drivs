
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Clock, CheckCircle, XCircle, AlertTriangle, FileX } from "lucide-react";

interface Contract {
  id: string;
  status: "active" | "pending" | "completed" | "cancelled" | "unsigned" | "signed_pending" | "deactivated" | "terminated";
}

interface ContractStatusCardsProps {
  contracts: Contract[];
}

export const ContractStatusCards = ({ contracts }: ContractStatusCardsProps) => {
  // Calcular contadores por status
  const activeCount = contracts.filter(c => c.status === "active").length;
  const pendingCount = contracts.filter(c => c.status === "pending" || c.status === "signed_pending").length;
  const unsignedCount = contracts.filter(c => c.status === "unsigned").length;
  const completedCount = contracts.filter(c => c.status === "completed").length;
  const cancelledCount = contracts.filter(c => c.status === "cancelled").length;
  const deactivatedCount = contracts.filter(c => c.status === "deactivated" || c.status === "terminated").length;

  const statusCards = [
    {
      title: "Ativos",
      count: activeCount,
      icon: CheckCircle,
      color: "text-green-600",
      borderColor: "border-l-green-500"
    },
    {
      title: "Pendentes",
      count: pendingCount,
      icon: Clock,
      color: "text-yellow-600",
      borderColor: "border-l-yellow-500"
    },
    {
      title: "Não Assinados",
      count: unsignedCount,
      icon: FileX,
      color: "text-red-600",
      borderColor: "border-l-red-500"
    },
    {
      title: "Concluídos",
      count: completedCount,
      icon: FileText,
      color: "text-blue-600",
      borderColor: "border-l-blue-500"
    },
    {
      title: "Cancelados",
      count: cancelledCount,
      icon: XCircle,
      color: "text-gray-600",
      borderColor: "border-l-gray-500"
    },
    {
      title: "Desativados",
      count: deactivatedCount,
      icon: AlertTriangle,
      color: "text-orange-600",
      borderColor: "border-l-orange-500"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
      {statusCards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index} className={`bg-white ${card.borderColor} border-l-4 border border-gray-200`}>
            <CardHeader className="pb-1 px-3 pt-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xs font-medium text-gray-600 truncate">
                  {card.title}
                </CardTitle>
                <Icon className={`h-4 w-4 ${card.color} flex-shrink-0`} />
              </div>
            </CardHeader>
            <CardContent className="pt-0 px-3 pb-3">
              <div className={`text-xl font-bold ${card.color}`}>
                {card.count}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};
