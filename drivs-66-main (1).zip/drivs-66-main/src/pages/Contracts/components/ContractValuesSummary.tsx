
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calculator } from "lucide-react";

interface ContractValuesSummaryProps {
  selectedVehicleId: string;
  contractMonths: number;
  weeklyValue: number;
  monthlyValue: number;
  depositValue: number;
  totalValue: number;
  formatCurrency: (value: number) => string;
}

export const ContractValuesSummary = ({
  selectedVehicleId,
  contractMonths,
  weeklyValue,
  monthlyValue,
  depositValue,
  totalValue,
  formatCurrency,
}: ContractValuesSummaryProps) => {
  if (!selectedVehicleId) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          Resumo Financeiro
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Valor Semanal</p>
            <p className="font-semibold">{formatCurrency(weeklyValue)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Valor Mensal</p>
            <p className="font-semibold">{formatCurrency(monthlyValue)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Depósito</p>
            <p className="font-semibold">{formatCurrency(depositValue)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Duração</p>
            <p className="font-semibold">{contractMonths} meses</p>
          </div>
        </div>
        <div className="border-t pt-3">
          <div className="flex justify-between items-center">
            <p className="text-lg font-bold">Valor Total do Contrato:</p>
            <p className="text-lg font-bold text-primary">{formatCurrency(totalValue)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
