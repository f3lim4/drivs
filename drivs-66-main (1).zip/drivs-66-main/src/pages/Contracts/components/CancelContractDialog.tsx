
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X } from "lucide-react";
import { toast } from "sonner";

interface CancelContractDialogProps {
  contractId: string;
  onCancel: (contractId: string) => void;
}

const CancelContractDialog: React.FC<CancelContractDialogProps> = ({ contractId, onCancel }) => {
  const [password, setPassword] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const handleCancel = () => {
    if (!password) {
      toast.error("Digite a senha para cancelar o contrato");
      return;
    }

    // Validar senha (simulação)
    if (password !== "admin123") {
      toast.error("Senha incorreta");
      return;
    }

    onCancel(contractId);
    setPassword("");
    setIsOpen(false);
    toast.success("Contrato cancelado com sucesso!");
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          size="icon"
          className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300"
        >
          <X className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Cancelar Contrato</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Para cancelar o contrato {contractId}, digite a senha de confirmação:
          </p>
          <div>
            <Label htmlFor="cancel-password">Senha de Confirmação</Label>
            <Input
              id="cancel-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Digite a senha"
              className="mt-2"
            />
          </div>
          <div className="flex gap-2 justify-end">
            <Button 
              variant="outline" 
              onClick={() => setIsOpen(false)}
            >
              Cancelar
            </Button>
            <Button 
              variant="destructive"
              onClick={handleCancel}
            >
              Confirmar Cancelamento
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CancelContractDialog;
