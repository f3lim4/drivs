
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { FileText, Loader2 } from "lucide-react";
import { ContractTemplateSelector } from "./ContractTemplateSelector";
import { VehicleDriverSelector } from "./VehicleDriverSelector";
import { ContractFormFields } from "./ContractFormFields";
import { ContractValuesSummary } from "./ContractValuesSummary";
import { ContractPreview } from "./ContractPreview";
import { ContractSuccess } from "./ContractSuccess";
import { ContractPendingSignature } from "./ContractPendingSignature";
import { SignatureOptionsDialog } from "./SignatureOptionsDialog";
import { useContractGenerator } from "../hooks/useContractGenerator";

interface ContractGeneratorProps {
  onClose: () => void;
}

export const ContractGenerator = ({ onClose }: ContractGeneratorProps) => {
  const {
    approvedDrivers,
    availableVehicles,
    selectedDriverId,
    setSelectedDriverId,
    selectedVehicleId,
    contractMonths,
    weeklyValue,
    monthlyValue,
    depositValue,
    totalValue,
    contractGenerated,
    contractTemplate,
    setContractTemplate,
    customContractFile,
    setCustomContractFile,
    showPreview,
    setShowPreview,
    contractText,
    setContractText,
    showSignatureOptions,
    setShowSignatureOptions,
    contractStatus,
    loadingDrivers,
    handleVehicleChange,
    handleMonthsChange,
    formatCurrency,
    handleSubmit,
    handleSendContract,
    handleSignatureTypeSelected,
    handleSignedDocumentUpload,
    resetContract,
  } = useContractGenerator();

  if (contractGenerated) {
    return (
      <ContractSuccess
        onClose={onClose}
      />
    );
  }

  if (contractStatus === "pending_signature") {
    const selectedDriver = approvedDrivers.find(d => d.id === selectedDriverId);
    const selectedVehicle = availableVehicles.find(v => v.id === selectedVehicleId);
    const vehicleInfo = selectedVehicle ? `${selectedVehicle.brand} ${selectedVehicle.model} - ${selectedVehicle.plate}` : "";

    return (
      <ContractPendingSignature
        driverName={selectedDriver?.fullName || ""}
        vehicleInfo={vehicleInfo}
        onFileUpload={handleSignedDocumentUpload}
        onBack={resetContract}
        onClose={onClose}
      />
    );
  }

  if (showPreview) {
    const selectedDriver = approvedDrivers.find(d => d.id === selectedDriverId);
    const selectedVehicle = availableVehicles.find(v => v.id === selectedVehicleId);

    return (
      <>
        <ContractPreview
          contractText={contractText}
          setContractText={setContractText}
          onBack={() => setShowPreview(false)}
          onSend={handleSendContract}
          onClose={onClose}
        />
        
        <SignatureOptionsDialog
          open={showSignatureOptions}
          onClose={() => setShowSignatureOptions(false)}
          onSignatureTypeSelected={handleSignatureTypeSelected}
          contractData={{
            driverName: selectedDriver?.fullName || "",
            vehiclePlate: selectedVehicle?.plate || "",
            vehicleModel: `${selectedVehicle?.brand} ${selectedVehicle?.model}` || ""
          }}
        />
      </>
    );
  }

  // Mostrar loading se ainda está carregando dados
  if (loadingDrivers) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card>
          <CardContent className="flex items-center justify-center py-12">
            <div className="flex items-center gap-3 text-muted-foreground">
              <Loader2 className="h-6 w-6 animate-spin" />
              <span>Carregando motoristas do banco de dados...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Gerador de Contratos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <ContractTemplateSelector
              contractTemplate={contractTemplate}
              setContractTemplate={setContractTemplate}
              customContractFile={customContractFile}
              setCustomContractFile={setCustomContractFile}
            />

            <Separator />

            <VehicleDriverSelector
              approvedDrivers={approvedDrivers}
              selectedDriverId={selectedDriverId}
              setSelectedDriverId={setSelectedDriverId}
              availableVehicles={availableVehicles}
              selectedVehicleId={selectedVehicleId}
              handleVehicleChange={handleVehicleChange}
              formatCurrency={formatCurrency}
            />

            <ContractFormFields
              contractMonths={contractMonths}
              handleMonthsChange={handleMonthsChange}
            />

            <ContractValuesSummary
              selectedVehicleId={selectedVehicleId}
              contractMonths={contractMonths}
              weeklyValue={weeklyValue}
              monthlyValue={monthlyValue}
              depositValue={depositValue}
              totalValue={totalValue}
              formatCurrency={formatCurrency}
            />

            <Separator />

            <div className="flex gap-3 justify-end">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancelar
              </Button>
              <Button 
                type="submit" 
                className="bg-blue-600 hover:bg-blue-700"
                disabled={approvedDrivers.length === 0}
              >
                Gerar Prévia do Contrato
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
