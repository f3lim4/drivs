
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, FileText } from "lucide-react";
import { toast } from "sonner";

interface Contract {
  id: string;
  driver_name?: string;
  company_name?: string;
  vehicle_info?: string;
  start_date: string;
  end_date: string;
  monthly_amount: number;
  status: string;
  document_url: string | null;
  signed_document_url: string | null;
}

interface ContractViewerProps {
  isOpen: boolean;
  onClose: () => void;
  contract: Contract | null;
}

const ContractViewer: React.FC<ContractViewerProps> = ({ isOpen, onClose, contract }) => {
  if (!contract) return null;

  const handleDownload = (url: string, filename: string) => {
    // Simular download do documento
    toast.success(`Download de ${filename} iniciado...`);
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "active": return "Ativo";
      case "pending": return "Pendente";
      case "unsigned": return "Não Assinado";
      case "signed_pending": return "Aguardando Ativação";
      case "completed": return "Concluído";
      case "cancelled": return "Cancelado";
      default: return "Desconhecido";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Visualizar Contrato - {contract.id}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Informações do Contrato */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-2">INFORMAÇÕES GERAIS</h3>
              <div className="space-y-2">
                <div>
                  <span className="font-medium">ID do Contrato:</span>
                  <p className="text-sm text-muted-foreground">{contract.id}</p>
                </div>
                <div>
                  <span className="font-medium">Status:</span>
                  <p className="text-sm text-muted-foreground">{getStatusText(contract.status)}</p>
                </div>
                <div>
                  <span className="font-medium">Valor Mensal:</span>
                  <p className="text-sm text-muted-foreground">R$ {contract.monthly_amount.toFixed(2)}</p>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-2">PERÍODO</h3>
              <div className="space-y-2">
                <div>
                  <span className="font-medium">Data de Início:</span>
                  <p className="text-sm text-muted-foreground">
                    {new Date(contract.start_date).toLocaleDateString('pt-BR')}
                  </p>
                </div>
                <div>
                  <span className="font-medium">Data de Término:</span>
                  <p className="text-sm text-muted-foreground">
                    {new Date(contract.end_date).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Informações das Partes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-2">MOTORISTA</h3>
              <p className="text-sm">{contract.driver_name}</p>
            </div>
            
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-2">LOCADORA</h3>
              <p className="text-sm">{contract.company_name}</p>
            </div>
          </div>

          {/* Veículo */}
          <div>
            <h3 className="font-semibold text-sm text-muted-foreground mb-2">VEÍCULO</h3>
            <p className="text-sm">{contract.vehicle_info}</p>
          </div>

          {/* Documentos */}
          <div>
            <h3 className="font-semibold text-sm text-muted-foreground mb-2">DOCUMENTOS</h3>
            <div className="flex gap-2">
              {contract.document_url && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleDownload(contract.document_url!, 'contrato-original.pdf')}
                  className="flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Contrato Original
                </Button>
              )}
              {contract.signed_document_url && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleDownload(contract.signed_document_url!, 'contrato-assinado.pdf')}
                  className="flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Contrato Assinado
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ContractViewer;
