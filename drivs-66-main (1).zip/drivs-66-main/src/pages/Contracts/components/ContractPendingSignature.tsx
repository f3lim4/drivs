
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { FileText, Upload, AlertTriangle } from "lucide-react";

interface ContractPendingSignatureProps {
  driverName: string;
  vehicleInfo: string;
  onFileUpload: (file: File) => void;
  onBack: () => void;
  onClose: () => void;
}

export const ContractPendingSignature = ({
  driverName,
  vehicleInfo,
  onFileUpload,
  onBack,
  onClose,
}: ContractPendingSignatureProps) => {
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onFileUpload(file);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-600">
            <FileText className="h-5 w-5" />
            Contrato Pendente de Assinatura
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
              <div>
                <p className="font-medium text-orange-800">
                  Aguardando Assinatura Física
                </p>
                <p className="text-sm text-orange-700 mt-1">
                  O contrato foi enviado para <strong>{driverName}</strong> imprimir e assinar em cartório.
                  Veículo: <strong>{vehicleInfo}</strong>
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signedDocument">
                Upload do Documento Assinado
              </Label>
              <Input
                id="signedDocument"
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              <p className="text-sm text-muted-foreground">
                Formatos aceitos: PDF, JPG, JPEG, PNG
              </p>
            </div>
          </div>

          <Separator />

          <div className="flex gap-3 justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onBack}
            >
              Voltar para Edição
            </Button>
            
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
            >
              Fechar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
