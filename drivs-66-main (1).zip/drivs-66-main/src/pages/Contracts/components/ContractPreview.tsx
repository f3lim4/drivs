
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { FileText, ArrowLeft, Send } from "lucide-react";

interface ContractPreviewProps {
  contractText: string;
  setContractText: (text: string) => void;
  onBack: () => void;
  onSend: () => void;
  onClose: () => void;
}

export const ContractPreview = ({
  contractText,
  setContractText,
  onBack,
  onSend,
  onClose,
}: ContractPreviewProps) => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Prévia do Contrato
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Revise o contrato antes de enviar. Você pode fazer alterações no texto abaixo.
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="contractPreview">Texto do Contrato</Label>
            <Textarea
              id="contractPreview"
              value={contractText}
              onChange={(e) => setContractText(e.target.value)}
              className="min-h-[500px] font-mono text-sm"
              placeholder="Texto do contrato aparecerá aqui..."
            />
          </div>

          <Separator />

          <div className="flex gap-3 justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onBack}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar para Edição
            </Button>
            
            <div className="flex gap-3">
              <Button 
                type="button" 
                variant="outline"
                onClick={onClose}
              >
                Cancelar
              </Button>
              <Button 
                onClick={onSend}
                className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
              >
                <Send className="h-4 w-4" />
                Enviar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
