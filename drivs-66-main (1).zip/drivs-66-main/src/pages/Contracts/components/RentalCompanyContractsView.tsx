
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FilePlus, FileText } from "lucide-react";
import { ContractsTable } from "./ContractsTable";
import { ContractsFilters } from "./ContractsFilters";
import { ContractStatusCards } from "./ContractStatusCards";
import { filterContracts } from "../utils/contractUtils";
import type { Contract } from "../hooks/useContractsData";

interface RentalCompanyContractsViewProps {
  contracts: Contract[];
  onViewContract: (contract: Contract) => void;
  onCancelContract: (contractId: string) => void;
  onDeactivateContract: (contractId: string, reason: string, selectedPayments: string[]) => void;
}

export const RentalCompanyContractsView = ({
  contracts,
  onViewContract,
  onCancelContract,
  onDeactivateContract
}: RentalCompanyContractsViewProps) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filteredContracts = filterContracts(contracts, searchTerm, statusFilter);

  const handleNewContract = () => {
    navigate("/locadora/gerar-contrato");
  };

  return (
    <div className="min-h-screen bg-background dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground dark:text-white">Contratos</h1>
            <p className="text-lg text-muted-foreground dark:text-gray-300 mt-1">
              Gestão de contratos
            </p>
          </div>
        </div>

        {/* Cards de Status para Locadoras */}
        <ContractStatusCards contracts={contracts} />

        {/* Contratos para Locadoras */}
        <Card className="bg-card dark:bg-gray-800 border-border dark:border-gray-700">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-foreground dark:text-white">Todos os Contratos</CardTitle>
              <Button 
                onClick={handleNewContract}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <FilePlus className="mr-2 h-4 w-4" />
                Novo Contrato
              </Button>
            </div>
            
            {/* Filtros de busca */}
            <ContractsFilters
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              statusFilter={statusFilter}
              onStatusFilterChange={setStatusFilter}
            />
          </CardHeader>
          <CardContent>
            {filteredContracts.length > 0 ? (
              <ContractsTable
                contracts={filteredContracts}
                onViewContract={onViewContract}
                onCancelContract={onCancelContract}
                onDeactivateContract={onDeactivateContract}
                showActions={true}
                userRole="RENTAL_COMPANY"
              />
            ) : (
              <div className="text-center py-10">
                <FileText className="h-12 w-12 text-muted-foreground dark:text-gray-500 mx-auto mb-4" />
                <p className="text-muted-foreground dark:text-gray-400 text-lg">Nenhum contrato encontrado.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
