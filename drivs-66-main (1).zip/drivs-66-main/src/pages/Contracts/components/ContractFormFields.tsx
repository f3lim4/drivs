
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface ContractFormFieldsProps {
  contractMonths: number;
  handleMonthsChange: (months: number) => void;
}

export const ContractFormFields = ({
  contractMonths,
  handleMonthsChange,
}: ContractFormFieldsProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="contractMonths">Tempo de Contrato (Meses)</Label>
      <Input
        id="contractMonths"
        type="number"
        placeholder="Digite o número de meses"
        value={contractMonths.toString()}
        onChange={(e) => handleMonthsChange(parseInt(e.target.value) || 1)}
        min="1"
        max="60"
        required
      />
      <p className="text-sm text-muted-foreground">
        O contrato entrará em vigor a partir da data de assinatura
      </p>
    </div>
  );
};
