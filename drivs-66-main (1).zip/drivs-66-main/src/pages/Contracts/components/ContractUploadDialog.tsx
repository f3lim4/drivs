
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import type { Contract } from "../hooks/useContractsData";

interface ContractUploadDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  contract: Contract | null;
  contracts: Contract[];
}

export const ContractUploadDialog = ({
  isOpen,
  onOpenChange,
  contract,
  contracts
}: ContractUploadDialogProps) => {
  const [uploadFile, setUploadFile] = useState<File | null>(null);

  const handleUploadSignedContract = async () => {
    if (!uploadFile || !contract) return;

    try {
      // Criar vistoria inicial automaticamente
      const initialInspection = {
        id: Date.now(),
        vehiclePlate: contract.vehicle_info?.split(' - ')[1] || 'N/A',
        vehicleModel: contract.vehicle_info?.split(' - ')[0] || 'N/A',
        driverName: contract.driver_name || 'N/A',
        type: "Inicial",
        status: "Pendente" as const,
        inspector: "Sistema",
        observations: `Vistoria inicial criada automaticamente após upload do contrato assinado`,
        photos: 0,
        recipient: "inspector" as const,
        contractId: contract.id,
        inspectionDate: new Date().toISOString().split('T')[0]
      };

      // Salvar no localStorage para que apareça no painel do vistoriador
      const existingInspections = JSON.parse(localStorage.getItem('pendingInspections') || '[]');
      localStorage.setItem('pendingInspections', JSON.stringify([...existingInspections, initialInspection]));

      // Update contract status to active
      contract.status = "active";

      toast.success("Contrato assinado enviado, motorista ativado e vistoria inicial criada com sucesso!");
      
      // Close the dialog and reset states
      setUploadFile(null);
      onOpenChange(false);
      
    } catch (error) {
      toast.error("Erro ao enviar contrato assinado");
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Enviar Contrato Assinado</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="contract-upload">Selecionar arquivo do contrato assinado</Label>
            <Input
              id="contract-upload"
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
              className="mt-2"
            />
          </div>
          <Button 
            onClick={handleUploadSignedContract}
            disabled={!uploadFile}
            className="w-full"
          >
            Enviar e Ativar Motorista
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
