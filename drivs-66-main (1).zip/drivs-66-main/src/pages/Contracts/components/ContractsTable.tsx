
import { useState } from "react";
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Dialog } from "@/components/ui/dialog";
import type { Contract } from "../hooks/useContractsData";
import { ContractUploadDialog } from "./ContractUploadDialog";
import { ContractTableRow } from "./ContractTableRow";

interface ContractsTableProps {
  contracts: Contract[];
  onViewContract: (contract: Contract) => void;
  onCancelContract?: (contractId: string) => void;
  onDeactivateContract?: (contractId: string, reason: string, selectedPayments: string[]) => void;
  showActions?: boolean;
  userRole?: string;
}

export const ContractsTable = ({
  contracts,
  onViewContract,
  onCancelContract,
  onDeactivateContract,
  showActions = true,
  userRole
}: ContractsTableProps) => {
  const [selectedContractForUpload, setSelectedContractForUpload] = useState<Contract | null>(null);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);

  const isAdminView = userRole === "ADMIN";

  const handleUploadClick = (contract: Contract) => {
    setSelectedContractForUpload(contract);
    setIsUploadDialogOpen(true);
  };

  return (
    <div className="overflow-x-auto">
      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <Table>
          <TableHeader>
            <TableRow className="border-border dark:border-gray-700">
              <TableHead className="text-foreground dark:text-gray-300">ID do Contrato</TableHead>
              <TableHead className="text-foreground dark:text-gray-300">Veículo</TableHead>
              <TableHead className="text-foreground dark:text-gray-300">Motorista</TableHead>
              {isAdminView && (
                <TableHead className="text-foreground dark:text-gray-300">Locadora</TableHead>
              )}
              <TableHead className="text-foreground dark:text-gray-300">Início</TableHead>
              <TableHead className="text-foreground dark:text-gray-300">Término</TableHead>
              <TableHead className="text-foreground dark:text-gray-300">Valor Mensal</TableHead>
              <TableHead className="text-foreground dark:text-gray-300">Status</TableHead>
              {showActions && (
                <TableHead className="text-foreground dark:text-gray-300">Ações</TableHead>
              )}
            </TableRow>
          </TableHeader>
          <TableBody>
            {contracts.map((contract) => (
              <ContractTableRow
                key={contract.id}
                contract={contract}
                onViewContract={onViewContract}
                onCancelContract={onCancelContract}
                onDeactivateContract={onDeactivateContract}
                onUploadClick={handleUploadClick}
                showActions={showActions}
                isAdminView={isAdminView}
              />
            ))}
          </TableBody>
        </Table>

        <ContractUploadDialog
          isOpen={isUploadDialogOpen}
          onOpenChange={setIsUploadDialogOpen}
          contract={selectedContractForUpload}
          contracts={contracts}
        />
      </Dialog>
    </div>
  );
};
