
import { TableCell, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { getStatusBadge } from "../utils/contractUtils";
import type { Contract } from "../hooks/useContractsData";
import { ContractActions } from "./ContractActions";

interface ContractTableRowProps {
  contract: Contract;
  onViewContract: (contract: Contract) => void;
  onCancelContract?: (contractId: string) => void;
  onDeactivateContract?: (contractId: string, reason: string, selectedPayments: string[]) => void;
  onUploadClick: (contract: Contract) => void;
  showActions: boolean;
  isAdminView: boolean;
}

export const ContractTableRow = ({
  contract,
  onViewContract,
  onCancelContract,
  onDeactivateContract,
  onUploadClick,
  showActions,
  isAdminView
}: ContractTableRowProps) => {
  return (
    <TableRow className="border-border dark:border-gray-700">
      <TableCell className="font-medium text-foreground dark:text-white">
        {contract.id}
      </TableCell>
      <TableCell className="text-foreground dark:text-white">{contract.vehicle_info}</TableCell>
      <TableCell className="text-foreground dark:text-white">{contract.driver_name}</TableCell>
      {isAdminView && (
        <TableCell className="text-foreground dark:text-white">{contract.company_name}</TableCell>
      )}
      <TableCell className="text-foreground dark:text-white">
        {new Date(contract.start_date).toLocaleDateString('pt-BR')}
      </TableCell>
      <TableCell className="text-foreground dark:text-white">
        {new Date(contract.end_date).toLocaleDateString('pt-BR')}
      </TableCell>
      <TableCell className="text-foreground dark:text-white">
        R$ {contract.monthly_amount.toFixed(2)}
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-2">
          {getStatusBadge(contract.status)}
          {contract.signature_type === "online" && (
            <Badge variant="outline" className="text-xs">
              Online
            </Badge>
          )}
          {contract.signature_type === "physical" && (
            <Badge variant="outline" className="text-xs">
              Presencial
            </Badge>
          )}
        </div>
      </TableCell>
      {showActions && (
        <TableCell>
          <ContractActions
            contract={contract}
            onViewContract={onViewContract}
            onCancelContract={onCancelContract}
            onDeactivateContract={onDeactivateContract}
            onUploadClick={onUploadClick}
            isAdminView={isAdminView}
          />
        </TableCell>
      )}
    </TableRow>
  );
};
