
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FileText, Upload, Pen, Printer } from "lucide-react";
import { toast } from "sonner";

interface SignatureOptionsDialogProps {
  open: boolean;
  onClose: () => void;
  onSignatureTypeSelected: (type: "online" | "physical", signedDocument?: File) => void;
  contractData: {
    driverName: string;
    vehiclePlate: string;
    vehicleModel: string;
  };
}

export const SignatureOptionsDialog = ({
  open,
  onClose,
  onSignatureTypeSelected,
  contractData
}: SignatureOptionsDialogProps) => {
  const [selectedType, setSelectedType] = useState<"online" | "physical" | null>(null);
  const [signedDocument, setSignedDocument] = useState<File | null>(null);
  const [showPhysicalUpload, setShowPhysicalUpload] = useState(false);

  const handleOnlineSignature = () => {
    onSignatureTypeSelected("online");
    toast.success("Contrato enviado para assinatura online!");
    onClose();
  };

  const handlePhysicalSignature = () => {
    onSignatureTypeSelected("physical");
    toast.success("Contrato enviado para o motorista imprimir e assinar!");
    onClose();
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSignedDocument(file);
    }
  };

  const handlePhysicalSubmit = () => {
    if (signedDocument) {
      onSignatureTypeSelected("physical", signedDocument);
      toast.success("Documento assinado enviado com sucesso!");
      onClose();
    } else {
      toast.error("Por favor, faça upload do documento assinado");
    }
  };

  const resetDialog = () => {
    setSelectedType(null);
    setShowPhysicalUpload(false);
    setSignedDocument(null);
  };

  const handleClose = () => {
    resetDialog();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Escolha o tipo de assinatura
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-muted-foreground">
            Como você gostaria que o motorista <strong>{contractData.driverName}</strong> assinasse o contrato 
            do veículo <strong>{contractData.vehicleModel} - {contractData.vehiclePlate}</strong>?
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={handleOnlineSignature}>
              <CardContent className="p-6 text-center">
                <Pen className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Assinatura Online</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  O motorista receberá o contrato para assinar digitalmente
                </p>
                <Button className="w-full">
                  Enviar para Assinatura Online
                </Button>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={handlePhysicalSignature}>
              <CardContent className="p-6 text-center">
                <Printer className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Imprimir e Assinar</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  O motorista imprimirá e assinará em cartório
                </p>
                <Button variant="outline" className="w-full">
                  Enviar para Imprimir
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
