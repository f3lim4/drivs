
import { Driver } from "@/types";
import { Contract } from "../types/contract";

export const generateDriverContracts = (driver: Driver): Contract[] => {
  return [];
};
