
import type { Contract } from "../hooks/useContractsData";

export const generateRentalCompanyContracts = (companyId: string): Contract[] => {
  return [];
};

const createRentalCompanyContractsMock = generateRentalCompanyContracts;
