
import { Contract } from "../types/contract";

export const generateAdminContracts = (): Contract[] => {
  return [];
};
