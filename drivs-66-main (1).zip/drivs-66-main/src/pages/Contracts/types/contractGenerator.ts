
import { Driver, RentalCompany, RentalVehicle } from '@/types';

export interface ContractData {
  driver: Driver;
  company: RentalCompany;
  vehicle: RentalVehicle;
  startDate: string;
  endDate: string;
  monthlyAmount: number;
  terms: string;
  signatureType: 'online' | 'physical';
}

export interface ContractFormState {
  selectedDriverId: string;
  selectedVehicleId: string;
  contractMonths: number;
  weeklyValue: number;
  monthlyValue: number;
  depositValue: number;
  totalValue: number;
  contractTemplate: string;
  customContractFile: File | null;
}

export interface ContractUIState {
  contractGenerated: boolean;
  showPreview: boolean;
  contractText: string;
  showSignatureOptions: boolean;
  contractStatus: string;
  isGenerating: boolean;
}
