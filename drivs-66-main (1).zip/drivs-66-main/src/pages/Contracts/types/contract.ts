
export interface Contract {
  id: string;
  driver_id: string;
  company_id: string;
  vehicle_id: string;
  start_date: string;
  end_date: string;
  status: "active" | "pending" | "completed" | "cancelled" | "unsigned" | "signed_pending" | "deactivated" | "terminated";
  monthly_amount: number;
  created_at: string;
  updated_at: string;
  document_url: string | null;
  signed_document_url: string | null;
  driver_name?: string;
  company_name?: string;
  vehicle_info?: string;
  vehicles?: any;
  drivers?: any;
  rental_companies?: any;
  signature_type?: "online" | "physical";
  deactivation_reason?: string;
  deactivated_at?: string;
}
