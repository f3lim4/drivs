
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Driver, UserRole, DriverStatus } from '@/types';

export const useContractDrivers = () => {
  const { user } = useAuth();
  const [approvedDrivers, setApprovedDrivers] = useState<Driver[]>([]);
  const [loadingDrivers, setLoadingDrivers] = useState(true);

  const fetchApprovedDrivers = async () => {
    try {
      setLoadingDrivers(true);
      console.log('Buscando motoristas aprovados do banco de dados para empresa:', user?.id);

      if (!user?.id) {
        console.log('No user ID found');
        setApprovedDrivers([]);
        return;
      }

      // Buscar motoristas diretamente da tabela drivers com status 'approved'
      const { data: driversData, error } = await supabase
        .from('drivers')
        .select('*')
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Erro ao buscar motoristas aprovados:', error);
        toast.error('Erro ao carregar motoristas aprovados');
        setApprovedDrivers([]);
        return;
      }

      // Mapear os dados do banco para o formato Driver esperado
      const mappedDrivers: Driver[] = (driversData || []).map(driver => ({
        id: driver.id,
        fullName: driver.full_name,
        email: '', // Não temos email na tabela drivers
        role: UserRole.DRIVER,
        cpf: driver.cpf,
        rg: driver.rg,
        phone: driver.phone,
        address: driver.address,
        city: driver.city,
        state: driver.state,
        cnh: driver.cnh,
        cnh_expires: driver.cnh_expires,
        status: driver.status as DriverStatus,
        available: driver.available || false,
        rating: driver.rating || 0,
        violations: driver.violations || 0,
        created_at: driver.created_at,
        updated_at: driver.updated_at
      }));

      console.log('Motoristas aprovados encontrados no banco:', mappedDrivers);
      setApprovedDrivers(mappedDrivers);

    } catch (error: any) {
      console.error('Erro ao buscar motoristas aprovados:', error);
      toast.error('Erro ao carregar motoristas aprovados');
      setApprovedDrivers([]);
    } finally {
      setLoadingDrivers(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      fetchApprovedDrivers();
    }
  }, [user?.id]);

  return {
    approvedDrivers,
    loadingDrivers,
    refetchDrivers: fetchApprovedDrivers
  };
};
