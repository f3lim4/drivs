
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver, RentalCompany } from "@/types";
import { toast } from "sonner";
import { Contract } from "../types/contract";
import { generateDriverContracts } from "../data/driverContractsMock";
import { generateRentalCompanyContracts } from "../data/rentalCompanyContractsMock";
import { generateAdminContracts } from "../data/adminContractsMock";

export const useContractsData = () => {
  const { user } = useAuth();
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchContracts = async () => {
      if (!user) return;

      try {
        let mockContracts: Contract[] = [];

        if (user.role === UserRole.DRIVER) {
          const driver = user as Driver;
          mockContracts = generateDriverContracts(driver);
        } else if (user.role === UserRole.RENTAL_COMPANY) {
          const rentalCompany = user as RentalCompany;
          mockContracts = generateRentalCompanyContracts(rentalCompany.id);
        } else if (user.role === UserRole.ADMIN) {
          mockContracts = generateAdminContracts();
        }

        console.log("Contratos carregados:", mockContracts);
        console.log("IDs dos motoristas:", mockContracts.map(c => c.driver_id));
        console.log("IDs dos veículos:", mockContracts.map(c => c.vehicle_id));

        setContracts(mockContracts);
      } catch (error: any) {
        console.error("Error fetching contracts:", error);
        toast.error("Erro ao carregar contratos");
      } finally {
        setLoading(false);
      }
    };

    fetchContracts();
  }, [user]);

  return { contracts, setContracts, loading };
};

export type { Contract };
