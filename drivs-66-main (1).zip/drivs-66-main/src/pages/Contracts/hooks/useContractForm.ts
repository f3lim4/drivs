
import { useState } from 'react';
import { ContractFormState, ContractUIState } from '../types/contractGenerator';

export const useContractForm = () => {
  const [formState, setFormState] = useState<ContractFormState>({
    selectedDriverId: '',
    selectedVehicleId: '',
    contractMonths: 12,
    weeklyValue: 0,
    monthlyValue: 0,
    depositValue: 0,
    totalValue: 0,
    contractTemplate: 'standard',
    customContractFile: null,
  });

  const [uiState, setUIState] = useState<ContractUIState>({
    contractGenerated: false,
    showPreview: false,
    contractText: '',
    showSignatureOptions: false,
    contractStatus: 'draft',
    isGenerating: false,
  });

  const updateFormState = (updates: Partial<ContractFormState>) => {
    setFormState(prev => ({ ...prev, ...updates }));
  };

  const updateUIState = (updates: Partial<ContractUIState>) => {
    setUIState(prev => ({ ...prev, ...updates }));
  };

  const resetForm = () => {
    setFormState({
      selectedDriverId: '',
      selectedVehicleId: '',
      contractMonths: 12,
      weeklyValue: 0,
      monthlyValue: 0,
      depositValue: 0,
      totalValue: 0,
      contractTemplate: 'standard',
      customContractFile: null,
    });

    setUIState({
      contractGenerated: false,
      showPreview: false,
      contractText: '',
      showSignatureOptions: false,
      contractStatus: 'draft',
      isGenerating: false,
    });
  };

  return {
    formState,
    uiState,
    updateFormState,
    updateUIState,
    resetForm,
  };
};
