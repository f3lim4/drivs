
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { useRentalCompanyVehicles } from '@/hooks/useRentalCompanyVehicles';
import { useContractDrivers } from './useContractDrivers';
import { useContractForm } from './useContractForm';
import { ContractData } from '../types/contractGenerator';
import { calculateContractValues, createContractData, formatCurrency, generateContract } from '../utils/contractUtils';

export const useContractGenerator = () => {
  const { user } = useAuth();
  const { vehicles: availableVehicles } = useRentalCompanyVehicles();
  const { approvedDrivers, loadingDrivers } = useContractDrivers();
  const { formState, uiState, updateFormState, updateUIState, resetForm } = useContractForm();
  
  const [contractData, setContractData] = useState<ContractData | null>(null);

  // Filtrar apenas veículos disponíveis
  const availableVehiclesList = availableVehicles.filter(vehicle => vehicle.status === 'available');

  const handleVehicleChange = (vehicleId: string) => {
    updateFormState({ selectedVehicleId: vehicleId });
    const vehicle = availableVehiclesList.find(v => v.id === vehicleId);
    if (vehicle) {
      const { monthlyValue, totalValue } = calculateContractValues(
        vehicle.weekly_value,
        formState.contractMonths,
        vehicle.deposit_value
      );
      updateFormState({
        weeklyValue: vehicle.weekly_value,
        depositValue: vehicle.deposit_value,
        monthlyValue,
        totalValue,
      });
    }
  };

  const handleMonthsChange = (months: number) => {
    updateFormState({ contractMonths: months });
    if (formState.selectedVehicleId) {
      const vehicle = availableVehiclesList.find(v => v.id === formState.selectedVehicleId);
      if (vehicle) {
        const { totalValue } = calculateContractValues(
          vehicle.weekly_value,
          months,
          vehicle.deposit_value
        );
        updateFormState({ totalValue });
      }
    }
  };

  const handleSubmit = async () => {
    if (!formState.selectedDriverId || !formState.selectedVehicleId) {
      toast.error('Selecione um motorista e um veículo');
      return { success: false, error: 'Selecione um motorista e um veículo' };
    }

    const driver = approvedDrivers.find(d => d.id === formState.selectedDriverId);
    const vehicle = availableVehiclesList.find(v => v.id === formState.selectedVehicleId);

    if (!driver || !vehicle) {
      toast.error('Dados inválidos');
      return { success: false, error: 'Dados inválidos' };
    }

    const contractData = createContractData(
      driver,
      vehicle,
      formState.monthlyValue,
      formState.contractMonths,
      user?.email
    );

    setContractData(contractData);
    updateUIState({ showPreview: true });
    return { success: true };
  };

  const handleSendContract = async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    updateUIState({ showSignatureOptions: true });
    return { success: true };
  };

  const handleSignatureTypeSelected = (type: 'online' | 'physical') => {
    if (contractData) {
      setContractData({
        ...contractData,
        signatureType: type
      });
    }
    updateUIState({ showSignatureOptions: false });
    if (type === 'online') {
      updateUIState({ contractStatus: 'pending_signature' });
    } else {
      updateUIState({ contractStatus: 'sent_for_physical_signature' });
    }
  };

  const handleSignedDocumentUpload = (file: File) => {
    updateFormState({ customContractFile: file });
    updateUIState({ contractStatus: 'signed' });
  };

  const resetContract = () => {
    setContractData(null);
    resetForm();
  };

  return {
    contractData,
    isGenerating: uiState.isGenerating,
    approvedDrivers,
    availableVehicles: availableVehiclesList,
    selectedDriverId: formState.selectedDriverId,
    setSelectedDriverId: (id: string) => updateFormState({ selectedDriverId: id }),
    selectedVehicleId: formState.selectedVehicleId,
    contractMonths: formState.contractMonths,
    weeklyValue: formState.weeklyValue,
    monthlyValue: formState.monthlyValue,
    depositValue: formState.depositValue,
    totalValue: formState.totalValue,
    contractGenerated: uiState.contractGenerated,
    contractTemplate: formState.contractTemplate,
    setContractTemplate: (template: string) => updateFormState({ contractTemplate: template }),
    customContractFile: formState.customContractFile,
    setCustomContractFile: (file: File | null) => updateFormState({ customContractFile: file }),
    showPreview: uiState.showPreview,
    setShowPreview: (show: boolean) => updateUIState({ showPreview: show }),
    contractText: uiState.contractText,
    setContractText: (text: string) => updateUIState({ contractText: text }),
    showSignatureOptions: uiState.showSignatureOptions,
    setShowSignatureOptions: (show: boolean) => updateUIState({ showSignatureOptions: show }),
    contractStatus: uiState.contractStatus,
    handleVehicleChange,
    handleMonthsChange,
    formatCurrency,
    handleSubmit,
    handleSendContract,
    handleSignatureTypeSelected,
    handleSignedDocumentUpload,
    resetContract,
    generateContract,
    setContractData,
    loadingDrivers
  };
};
