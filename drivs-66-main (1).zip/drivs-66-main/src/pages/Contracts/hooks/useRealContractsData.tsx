
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, RentalCompany } from "@/types";
import { Contract } from "../types/contract";
import { getDriversByCompany } from "@/pages/Drivers/utils/driverCompanyUtils";
import { getVehiclesByCompany } from "@/pages/RentalCompanies/data/mockVehicles";

export const useRealContractsData = () => {
  const { user } = useAuth();
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const generateRealContracts = () => {
      if (!user || user.role !== UserRole.RENTAL_COMPANY) {
        setContracts([]);
        setLoading(false);
        return;
      }

      const rentalCompanyUser = user as RentalCompany;

      // Obter motoristas reais da locadora
      const companyDrivers = getDriversByCompany(user.id);
      
      // Obter veículos reais da locadora
      const companyVehicles = getVehiclesByCompany(user.id);

      console.log("Motoristas da locadora:", companyDrivers);
      console.log("Veículos da locadora:", companyVehicles);

      const realContracts: Contract[] = [];

      // Gerar contratos baseados em veículos alugados (com motoristas)
      const rentedVehicles = companyVehicles.filter(vehicle => 
        vehicle.status === "rented" && vehicle.driverInfo
      );

      rentedVehicles.forEach((vehicle, index) => {
        const driver = companyDrivers.find(d => d.id === vehicle.driverInfo?.id);
        if (!driver) return;

        const startDate = new Date(vehicle.driverInfo.contractStartDate);
        const endDate = new Date(startDate);
        endDate.setFullYear(endDate.getFullYear() + 1); // Contrato de 1 ano

        const contract: Contract = {
          id: `CTR-${user.id.slice(-3)}-${String(index + 1).padStart(3, '0')}`,
          driver_id: driver.id,
          company_id: user.id,
          vehicle_id: vehicle.id,
          start_date: startDate.toISOString().split('T')[0],
          end_date: endDate.toISOString().split('T')[0],
          status: "active",
          monthly_amount: vehicle.weeklyValue * 4,
          created_at: startDate.toISOString(),
          updated_at: new Date().toISOString(),
          document_url: null,
          signed_document_url: null,
          driver_name: driver.fullName,
          company_name: rentalCompanyUser.companyName || rentalCompanyUser.name || "Locadora",
          vehicle_info: `${vehicle.brand} ${vehicle.model} ${vehicle.year} - ${vehicle.plate}`,
          signature_type: Math.random() > 0.5 ? "online" : "physical"
        };

        realContracts.push(contract);
      });

      // Gerar alguns contratos pendentes/não assinados para motoristas aprovados sem veículo
      const driversWithoutVehicle = companyDrivers.filter(driver => 
        driver.status === "approved" && 
        !rentedVehicles.some(v => v.driverInfo?.id === driver.id)
      );

      const availableVehicles = companyVehicles.filter(v => v.status === "available");

      driversWithoutVehicle.slice(0, Math.min(3, availableVehicles.length)).forEach((driver, index) => {
        const vehicle = availableVehicles[index];
        if (!vehicle) return;

        const createdDate = new Date();
        createdDate.setDate(createdDate.getDate() - Math.floor(Math.random() * 10));

        const contract: Contract = {
          id: `CTR-${user.id.slice(-3)}-${String(realContracts.length + index + 1).padStart(3, '0')}`,
          driver_id: driver.id,
          company_id: user.id,
          vehicle_id: vehicle.id,
          start_date: new Date().toISOString().split('T')[0],
          end_date: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          status: Math.random() > 0.5 ? "unsigned" : "signed_pending",
          monthly_amount: vehicle.weeklyValue * 4,
          created_at: createdDate.toISOString(),
          updated_at: createdDate.toISOString(),
          document_url: "/contracts/sample-contract.pdf",
          signed_document_url: null,
          driver_name: driver.fullName,
          company_name: rentalCompanyUser.companyName || rentalCompanyUser.name || "Locadora",
          vehicle_info: `${vehicle.brand} ${vehicle.model} ${vehicle.year} - ${vehicle.plate}`,
          signature_type: Math.random() > 0.5 ? "online" : "physical"
        };

        realContracts.push(contract);
      });

      // Ordenar contratos: ativos primeiro, depois por data de criação
      realContracts.sort((a, b) => {
        if (a.status === "active" && b.status !== "active") return -1;
        if (b.status === "active" && a.status !== "active") return 1;
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      });

      console.log("Contratos reais gerados:", realContracts);
      setContracts(realContracts);
      setLoading(false);
    };

    generateRealContracts();
  }, [user]);

  return { contracts, setContracts, loading };
};
