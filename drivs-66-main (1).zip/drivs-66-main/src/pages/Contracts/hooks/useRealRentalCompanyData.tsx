
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, RentalCompany } from "@/types";
import { getDriversByCompany } from "@/pages/Drivers/utils/driverCompanyUtils";
import { getVehiclesByCompany } from "@/pages/RentalCompanies/data/mockVehicles";

interface PendingPayment {
  id: string;
  description: string;
  amount: number;
  dueDate: string;
  type: "monthly_rent" | "fine" | "maintenance" | "other" | "contract_breach";
}

export const useRealRentalCompanyData = (contractId: string, driverName: string) => {
  const { user } = useAuth();
  const [pendingPayments, setPendingPayments] = useState<PendingPayment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRealData = () => {
      if (!user || user.role !== UserRole.RENTAL_COMPANY) {
        setLoading(false);
        return;
      }

      const rentalCompanyUser = user as RentalCompany;
      
      // Buscar motoristas e veículos reais da locadora
      const companyDrivers = getDriversByCompany(user.id);
      const companyVehicles = getVehiclesByCompany(user.id);

      // Encontrar o motorista específico
      const driver = companyDrivers.find(d => d.fullName === driverName);
      
      // Encontrar veículo do motorista
      const driverVehicle = companyVehicles.find(v => 
        v.driverInfo && v.driverInfo.name === driverName
      );

      const realPendingPayments: PendingPayment[] = [];

      if (driver && driverVehicle) {
        // Gerar pagamentos baseados em dados reais
        const monthlyRent = driverVehicle.weeklyValue * 4;
        
        // Aluguel mensal em atraso (simular baseado na data atual)
        const currentDate = new Date();
        const lastMonth = new Date(currentDate.setMonth(currentDate.getMonth() - 1));
        
        realPendingPayments.push({
          id: `PAY-RENT-${contractId}`,
          description: `Aluguel mensal - ${lastMonth.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}`,
          amount: monthlyRent,
          dueDate: new Date(lastMonth.setDate(15)).toISOString().split('T')[0],
          type: "monthly_rent"
        });

        // Simular multas baseadas no histórico do motorista
        if (driver.violations && driver.violations > 0) {
          realPendingPayments.push({
            id: `PAY-FINE-${contractId}`,
            description: `Multa de trânsito pendente`,
            amount: 195.23,
            dueDate: new Date().toISOString().split('T')[0],
            type: "fine"
          });
        }

        // Simular manutenção se o veículo tem quilometragem alta (usando optional chaining)
        const vehicleMileage = (driverVehicle as any).mileage;
        if (vehicleMileage && vehicleMileage > 50000) {
          realPendingPayments.push({
            id: `PAY-MAINT-${contractId}`,
            description: `Manutenção preventiva - ${driverVehicle.brand} ${driverVehicle.model}`,
            amount: 450.00,
            dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            type: "maintenance"
          });
        }

        // Adicionar taxa adicional baseada no score do motorista (usando optional chaining)
        const driverScore = (driver as any).score;
        if (driver.status === "active" && driverScore && driverScore < 7) {
          realPendingPayments.push({
            id: `PAY-OTHER-${contractId}`,
            description: `Taxa de risco - Score baixo`,
            amount: 200.00,
            dueDate: new Date().toISOString().split('T')[0],
            type: "other"
          });
        }
      }

      console.log("Pagamentos reais gerados para a locadora:", realPendingPayments);
      console.log("Dados do motorista:", driver);
      console.log("Dados do veículo:", driverVehicle);

      setPendingPayments(realPendingPayments);
      setLoading(false);
    };

    fetchRealData();
  }, [user, contractId, driverName]);

  return { pendingPayments, loading };
};
