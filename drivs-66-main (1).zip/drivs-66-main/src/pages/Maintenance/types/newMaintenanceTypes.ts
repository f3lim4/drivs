
import { z } from "zod";

export const newMaintenanceSchema = z.object({
  vehicleId: z.string().min(1, "Selecione um veículo"),
  maintenanceType: z.string().min(1, "Selecione o tipo"),
  locationId: z.string().min(1, "Selecione o local"),
  completedDate: z.date({
    required_error: "Selecione a data",
  }),
  completedTime: z.string().min(1, "Informe o horário"),
  odometer: z.number().min(0, "Quilometragem inválida"),
  items: z.array(z.object({
    description: z.string().min(1, "Descrição obrigatória"),
    cost: z.number().min(0, "Custo inválido"),
  })).min(1, "Adicione pelo menos um item"),
  notes: z.string().optional(),
});

export type NewMaintenanceForm = z.infer<typeof newMaintenanceSchema>;

export interface NewMaintenanceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: any) => void;
}

export interface NewVehicleWithOdometer {
  id: string;
  name: string;
  odometer: number;
}

interface NewMaintenanceType {
  id: string;
  name: string;
  description?: string;
  is_system_default: boolean;
  company_id?: string;
}

interface NewMaintenanceLocation {
  id: string;
  company_id: string;
  name: string;
  address?: string;
  phone?: string;
  email?: string;
  specialties?: string[];
  is_active: boolean;
}
