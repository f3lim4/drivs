
import { useRealVehiclesWithDrivers } from "@/hooks/useRealVehiclesWithDrivers";

export const useNewMaintenanceVehicles = () => {
  const { vehiclesWithDrivers, loading } = useRealVehiclesWithDrivers();

  const realVehicles = vehiclesWithDrivers.map(v => ({
    id: v.vehicleId,
    name: v.name,
    odometer: v.odometer
  }));

  return {
    realVehicles,
    loading
  };
};
