
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useRealVehiclesWithDrivers } from "@/hooks/useRealVehiclesWithDrivers";

interface VehicleDriverSelectionProps {
  selectedVehicle: string;
  selectedDriver: string;
  onVehicleChange: (vehicleId: string) => void;
  onDriverChange: (driverId: string) => void;
}

export function VehicleDriverSelection({ 
  selectedVehicle, 
  selectedDriver, 
  onVehicleChange, 
  onDriverChange 
}: VehicleDriverSelectionProps) {
  const { vehiclesWithDrivers, loading } = useRealVehiclesWithDrivers();

  if (loading) {
    return <div>Carregando veículos...</div>;
  }

  return (
    <div className="grid grid-cols-2 gap-4">
      <div>
        <Label htmlFor="vehicle">Veículo</Label>
        <Select value={selectedVehicle} onValueChange={onVehicleChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione o veículo" />
          </SelectTrigger>
          <SelectContent>
            {vehiclesWithDrivers.map((vehicle) => (
              <SelectItem key={vehicle.id} value={vehicle.id}>
                {vehicle.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="driver">Motorista</Label>
        <Select value={selectedDriver} onValueChange={onDriverChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione o motorista" />
          </SelectTrigger>
          <SelectContent>
            {vehiclesWithDrivers
              .filter(vehicle => vehicle.driverId)
              .map((vehicle) => (
                <SelectItem key={vehicle.driverId} value={vehicle.driverId!}>
                  {vehicle.driverName || 'Motorista não identificado'}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
