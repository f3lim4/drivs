
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useMaintenanceLocations } from "@/hooks/useMaintenanceLocations";
import { VehicleDriverSelection } from "./VehicleDriverSelection";

interface ScheduleMaintenanceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSchedule: (data: any) => void;
}

export function ScheduleMaintenanceDialog({
  open,
  onOpenChange,
  onSchedule,
}: ScheduleMaintenanceDialogProps) {
  const { locations } = useMaintenanceLocations();
  const [formData, setFormData] = useState({
    vehicle_id: "",
    driver_id: "",
    maintenance_type: "",
    description: "",
    scheduled_date: "",
    estimated_cost: "",
    location_id: "",
    odometer: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const maintenanceData = {
      ...formData,
      estimated_cost: formData.estimated_cost ? parseFloat(formData.estimated_cost) : 0,
      odometer: formData.odometer ? parseInt(formData.odometer) : 0,
      status: "scheduled",
    };
    
    onSchedule(maintenanceData);
    
    // Reset form
    setFormData({
      vehicle_id: "",
      driver_id: "",
      maintenance_type: "",
      description: "",
      scheduled_date: "",
      estimated_cost: "",
      location_id: "",
      odometer: "",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Agendar Manutenção</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <VehicleDriverSelection
            selectedVehicle={formData.vehicle_id}
            selectedDriver={formData.driver_id}
            onVehicleChange={(vehicleId) => setFormData({ ...formData, vehicle_id: vehicleId })}
            onDriverChange={(driverId) => setFormData({ ...formData, driver_id: driverId })}
          />

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="maintenance_type">Tipo de Manutenção</Label>
              <Select value={formData.maintenance_type} onValueChange={(value) => setFormData({ ...formData, maintenance_type: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="preventiva">Preventiva</SelectItem>
                  <SelectItem value="corretiva">Corretiva</SelectItem>
                  <SelectItem value="revisao">Revisão</SelectItem>
                  <SelectItem value="pneus">Pneus</SelectItem>
                  <SelectItem value="oleo">Óleo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="scheduled_date">Data Agendada</Label>
              <Input
                id="scheduled_date"
                type="date"
                value={formData.scheduled_date}
                onChange={(e) => setFormData({ ...formData, scheduled_date: e.target.value })}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="description">Descrição</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Descreva o serviço a ser realizado..."
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="estimated_cost">Custo Estimado (R$)</Label>
              <Input
                id="estimated_cost"
                type="number"
                step="0.01"
                value={formData.estimated_cost}
                onChange={(e) => setFormData({ ...formData, estimated_cost: e.target.value })}
                placeholder="0,00"
              />
            </div>

            <div>
              <Label htmlFor="odometer">Quilometragem</Label>
              <Input
                id="odometer"
                type="number"
                value={formData.odometer}
                onChange={(e) => setFormData({ ...formData, odometer: e.target.value })}
                placeholder="Ex: 50000"
              />
            </div>
          </div>

          {locations.length > 0 && (
            <div>
              <Label htmlFor="location">Local de Manutenção</Label>
              <Select value={formData.location_id} onValueChange={(value) => setFormData({ ...formData, location_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o local" />
                </SelectTrigger>
                <SelectContent>
                  {locations.map((location) => (
                    <SelectItem key={location.id} value={location.id}>
                      {location.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">
              Agendar Manutenção
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
