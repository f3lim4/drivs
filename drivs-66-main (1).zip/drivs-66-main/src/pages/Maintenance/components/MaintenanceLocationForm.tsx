
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useMaintenanceLocations } from "@/hooks/useMaintenanceLocations";
import { toast } from "sonner";

interface MaintenanceLocationFormProps {
  editingLocation?: any | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export function MaintenanceLocationForm({
  editingLocation,
  onSuccess,
  onCancel,
}: MaintenanceLocationFormProps) {
  const { createLocation, updateLocation } = useMaintenanceLocations();
  const [formData, setFormData] = useState({
    name: editingLocation?.name || "",
    address: editingLocation?.address || "",
    phone: editingLocation?.phone || "",
    email: editingLocation?.email || "",
    specialties: editingLocation?.specialties?.join(", ") || "",
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast.error("Nome é obrigatório");
      return;
    }

    setLoading(true);

    try {
      console.log("Enviando dados do formulário:", formData);

      const locationData = {
        name: formData.name.trim(),
        address: formData.address.trim(),
        phone: formData.phone.trim(),
        email: formData.email.trim(),
        specialties: formData.specialties 
          ? formData.specialties.split(",").map(s => s.trim()).filter(s => s.length > 0)
          : [],
        is_active: true,
      };

      console.log("Dados processados para criação:", locationData);

      if (editingLocation) {
        await updateLocation(editingLocation.id, locationData);
      } else {
        await createLocation(locationData);
      }

      onSuccess();
    } catch (error) {
      console.error("Erro no formulário:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nome *</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Nome do local de manutenção"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="address">Endereço</Label>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
          placeholder="Endereço completo"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone">Telefone</Label>
        <Input
          id="phone"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          placeholder="(11) 99999-9999"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">E-mail</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          placeholder="contato@oficina.com"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="specialties">Especialidades</Label>
        <Textarea
          id="specialties"
          value={formData.specialties}
          onChange={(e) => setFormData({ ...formData, specialties: e.target.value })}
          placeholder="Ex: Motor, Freios, Suspensão (separado por vírgulas)"
          rows={3}
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? "Salvando..." : editingLocation ? "Atualizar" : "Criar"}
        </Button>
      </div>
    </form>
  );
}
