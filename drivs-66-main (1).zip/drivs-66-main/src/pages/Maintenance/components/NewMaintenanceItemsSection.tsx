
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2 } from "lucide-react";
import { Control, FieldArrayWithId, UseFieldArrayAppend, UseFieldArrayRemove } from "react-hook-form";
import { NewMaintenanceForm } from "../types/newMaintenanceTypes";

interface NewMaintenanceItemsSectionProps {
  control: Control<NewMaintenanceForm>;
  fields: FieldArrayWithId<NewMaintenanceForm, "items", "id">[];
  append: UseFieldArrayAppend<NewMaintenanceForm, "items">;
  remove: UseFieldArrayRemove;
  totalCost: number;
}

export function NewMaintenanceItemsSection({ 
  control, 
  fields, 
  append, 
  remove, 
  totalCost 
}: NewMaintenanceItemsSectionProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Itens da Manutenção</span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => append({ description: "", cost: 0 })}
          >
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Item
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {fields.map((field, index) => (
          <div key={field.id} className="flex gap-4 items-end">
            <FormField
              control={control}
              name={`items.${index}.description`}
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Ex: Troca de óleo, filtro de ar..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={control}
              name={`items.${index}.cost`}
              render={({ field }) => (
                <FormItem className="w-32">
                  <FormLabel>Valor (R$)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {fields.length > 1 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => remove(index)}
                className="text-red-600 hover:text-red-700"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))}

        <div className="flex justify-end pt-4 border-t">
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Total:</p>
            <p className="text-lg font-bold">R$ {totalCost.toFixed(2)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
