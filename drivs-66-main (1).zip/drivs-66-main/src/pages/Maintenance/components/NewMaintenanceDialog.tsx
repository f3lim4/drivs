
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNewMaintenanceVehicles } from "../hooks/useNewMaintenanceVehicles";
import { NewMaintenanceBasicFields } from "./NewMaintenanceBasicFields";
import { NewMaintenanceItemsSection } from "./NewMaintenanceItemsSection";
import {
  NewMaintenanceDialogProps,
  NewMaintenanceForm,
  newMaintenanceSchema,
} from "../types/newMaintenanceTypes";

export function NewMaintenanceDialog({
  open,
  onOpenChange,
  onSave,
}: NewMaintenanceDialogProps) {
  const { realVehicles } = useNewMaintenanceVehicles();

  const form = useForm<NewMaintenanceForm>({
    resolver: zodResolver(newMaintenanceSchema),
    defaultValues: {
      items: [{ description: "", cost: 0 }],
      notes: "",
      odometer: 0,
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  const selectedVehicleId = form.watch("vehicleId");
  const selectedVehicle = realVehicles.find(v => v.id === selectedVehicleId);

  const handleVehicleChange = (vehicleId: string) => {
    const vehicle = realVehicles.find(v => v.id === vehicleId);
    if (vehicle) {
      form.setValue("odometer", vehicle.odometer);
    }
  };

  const onSubmit = (data: NewMaintenanceForm) => {
    const totalCost = data.items.reduce((sum, item) => sum + item.cost, 0);
    
    onSave({
      vehicle_id: data.vehicleId,
      maintenance_type: data.maintenanceType,
      location_id: data.locationId,
      completed_date: data.completedDate.toISOString().split('T')[0],
      completed_time: data.completedTime,
      odometer: data.odometer,
      actual_cost: totalCost,
      notes: data.notes,
      items: data.items,
      description: `Manutenção ${data.maintenanceType} realizada`,
      status: 'completed'
    });
    form.reset();
  };

  const totalCost = fields.reduce((total, _, index) => {
    const itemCost = form.watch(`items.${index}.cost`) || 0;
    return total + itemCost;
  }, 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Registrar Nova Manutenção</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <NewMaintenanceBasicFields
                control={form.control}
                realVehicles={realVehicles}
                onVehicleChange={handleVehicleChange}
                selectedVehicle={selectedVehicle}
              />
            </div>

            <NewMaintenanceItemsSection
              control={form.control}
              fields={fields}
              append={append}
              remove={remove}
              totalCost={totalCost}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Observações (Opcional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Observações sobre a manutenção realizada..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-2 justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancelar
              </Button>
              <Button type="submit">
                Salvar Manutenção
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
