
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MapPin } from "lucide-react";
import { MaintenanceLocationsDialog } from "./MaintenanceLocationsDialog";

export function MaintenanceLocationManager() {
  const [showLocationsDialog, setShowLocationsDialog] = useState(false);

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => setShowLocationsDialog(true)}
        className="flex items-center gap-2"
      >
        <MapPin className="h-4 w-4" />
        Gerenciar Locais
      </Button>

      <MaintenanceLocationsDialog
        open={showLocationsDialog}
        onOpenChange={setShowLocationsDialog}
      />
    </>
  );
}
