import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { Control } from "react-hook-form";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { NewMaintenanceForm, NewVehicleWithOdometer } from "../types/newMaintenanceTypes";
import { useMaintenanceTypes } from "@/hooks/useMaintenanceTypes";
import { useMaintenanceLocations } from "@/hooks/useMaintenanceLocations";
import { MaintenanceLocationManager } from "./MaintenanceLocationManager";

interface NewMaintenanceBasicFieldsProps {
  control: Control<NewMaintenanceForm>;
  realVehicles: NewVehicleWithOdometer[];
  onVehicleChange: (vehicleId: string) => void;
  selectedVehicle?: NewVehicleWithOdometer;
}

export function NewMaintenanceBasicFields({ 
  control, 
  realVehicles, 
  onVehicleChange, 
  selectedVehicle 
}: NewMaintenanceBasicFieldsProps) {
  const { maintenanceTypes } = useMaintenanceTypes();
  const { locations } = useMaintenanceLocations();

  return (
    <>
      <FormField
        control={control}
        name="vehicleId"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Veículo</FormLabel>
            <Select 
              onValueChange={(value) => {
                field.onChange(value);
                onVehicleChange(value);
              }} 
              defaultValue={field.value}
            >
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o veículo" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {realVehicles.map((vehicle) => (
                  <SelectItem key={vehicle.id} value={vehicle.id}>
                    {vehicle.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {realVehicles.length === 0 && (
              <p className="text-sm text-muted-foreground">
                Nenhum veículo encontrado para esta locadora
              </p>
            )}
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="maintenanceType"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Tipo de Manutenção</FormLabel>
            <Select onValueChange={field.onChange} defaultValue={field.value}>
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {maintenanceTypes.map((type) => (
                  <SelectItem key={type.id} value={type.name}>
                    {type.name.charAt(0).toUpperCase() + type.name.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="locationId"
        render={({ field }) => (
          <FormItem>
            <div className="flex items-center justify-between">
              <FormLabel>Local</FormLabel>
              <MaintenanceLocationManager />
            </div>
            <Select onValueChange={field.onChange} defaultValue={field.value}>
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o local" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {locations.map((location) => (
                  <SelectItem key={location.id} value={location.id}>
                    {location.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="odometer"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Quilometragem</FormLabel>
            <FormControl>
              <Input
                type="number"
                placeholder="0"
                {...field}
                onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
              />
            </FormControl>
            {selectedVehicle && (
              <p className="text-sm text-muted-foreground">
                Atual: {selectedVehicle.odometer.toLocaleString()} km
              </p>
            )}
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="completedDate"
        render={({ field }) => (
          <FormItem className="flex flex-col">
            <FormLabel>Data de Realização</FormLabel>
            <Popover>
              <PopoverTrigger asChild>
                <FormControl>
                  <Button
                    variant="outline"
                    className={cn(
                      "pl-3 text-left font-normal",
                      !field.value && "text-muted-foreground"
                    )}
                  >
                    {field.value ? (
                      format(field.value, "dd/MM/yyyy", { locale: ptBR })
                    ) : (
                      <span>Selecione a data</span>
                    )}
                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                  </Button>
                </FormControl>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={field.value}
                  onSelect={field.onChange}
                  disabled={(date) => date > new Date()}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="completedTime"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Horário</FormLabel>
            <FormControl>
              <Input
                type="time"
                placeholder="08:00"
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </>
  );
}
