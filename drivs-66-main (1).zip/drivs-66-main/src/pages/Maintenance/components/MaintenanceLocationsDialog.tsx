import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Plus, MapPin } from "lucide-react";
import { useMaintenanceLocations } from "@/hooks/useMaintenanceLocations";
import { MaintenanceLocationForm } from "./MaintenanceLocationForm";
import { MaintenanceLocationsTable } from "./MaintenanceLocationsTable";

interface MaintenanceLocationsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MaintenanceLocationsDialog({
  open,
  onOpenChange,
}: MaintenanceLocationsDialogProps) {
  const { locations, loading, deleteLocation } = useMaintenanceLocations();
  const [editingLocation, setEditingLocation] = useState<any | null>(null);
  const [showForm, setShowForm] = useState(false);

  const handleEdit = (location: any) => {
    setEditingLocation(location);
    setShowForm(true);
  };

  const handleDelete = async (locationId: string) => {
    try {
      await deleteLocation(locationId);
    } catch (error) {
      console.error("Erro ao excluir local:", error);
    }
  };

  const handleNewLocation = () => {
    setEditingLocation(null);
    setShowForm(true);
  };

  const handleFormSuccess = () => {
    setShowForm(false);
    setEditingLocation(null);
  };

  const handleFormCancel = () => {
    setShowForm(false);
    setEditingLocation(null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Locais de Manutenção
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Botão para adicionar novo local */}
          {!showForm && (
            <div className="flex justify-end">
              <Button onClick={handleNewLocation} className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Novo Local
              </Button>
            </div>
          )}

          {/* Formulário */}
          {showForm && (
            <MaintenanceLocationForm
              editingLocation={editingLocation}
              onSuccess={handleFormSuccess}
              onCancel={handleFormCancel}
            />
          )}

          {/* Lista de locais */}
          {!showForm && (
            <MaintenanceLocationsTable
              locations={locations}
              loading={loading}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
