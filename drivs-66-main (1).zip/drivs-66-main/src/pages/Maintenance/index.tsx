import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Plus, Calendar as CalendarIcon, Wrench, MapPin, Clock, Car, MoreHorizontal } from "lucide-react";
import { ScheduleMaintenanceDialog } from "./components/ScheduleMaintenanceDialog";
import { NewMaintenanceDialog } from "./components/NewMaintenanceDialog";
import { MaintenanceLocationsDialog } from "./components/MaintenanceLocationsDialog";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Tipagem para os registros de manutenção
interface MaintenanceRecord {
  id: string;
  vehicleId: string;
  vehicleInfo: string;
  companyId: string;
  type: "preventive" | "corrective" | "revision";
  description: string;
  cost: number;
  status: "scheduled" | "in_progress" | "completed" | "cancelled";
  scheduledDate: Date;
  completedDate?: Date;
  odometer: number;
  serviceName?: string;
  notes?: string;
}

// Dados mockados de manutenção
const mockMaintenanceRecords: MaintenanceRecord[] = [
  {
    id: "m1",
    vehicleId: "v1",
    vehicleInfo: "Chevrolet Onix 2023 - Placa ABC-1234",
    companyId: "r1",
    type: "revision",
    description: "Revisão de 10.000km",
    cost: 450.00,
    status: "completed",
    scheduledDate: new Date("2025-05-05"),
    completedDate: new Date("2025-05-05"),
    odometer: 10120,
    serviceName: "Auto Center Express",
    notes: "Troca de óleo, filtros e verificação geral"
  },
  {
    id: "m2",
    vehicleId: "v3",
    vehicleInfo: "Renault Kwid 2023 - Placa GHI-9012",
    companyId: "r1",
    type: "preventive",
    description: "Troca de pastilhas de freio",
    cost: 380.00,
    status: "scheduled",
    scheduledDate: new Date("2025-05-25"),
    odometer: 15300,
    serviceName: "Central de Freios",
  },
  {
    id: "m3",
    vehicleId: "v5",
    vehicleInfo: "Jeep Renegade 2023 - Placa MNO-7890",
    companyId: "r2",
    type: "corrective",
    description: "Reparo no ar condicionado",
    cost: 750.00,
    status: "in_progress",
    scheduledDate: new Date("2025-05-18"),
    odometer: 8200,
    serviceName: "Oficina Especializada Jeep",
    notes: "Compressor com vazamento"
  },
  {
    id: "m4",
    vehicleId: "v4",
    vehicleInfo: "Volkswagen Gol 2021 - Placa JKL-3456",
    companyId: "r3",
    type: "revision",
    description: "Revisão de 30.000km",
    cost: 520.00,
    status: "cancelled",
    scheduledDate: new Date("2025-05-10"),
    odometer: 29800,
    serviceName: "Concessionária Volkswagen",
  },
  {
    id: "m5",
    vehicleId: "v1",
    vehicleInfo: "Chevrolet Onix 2023 - Placa ABC-1234",
    companyId: "r1",
    type: "corrective",
    description: "Substituição de bateria",
    cost: 550.00,
    status: "completed",
    scheduledDate: new Date("2025-04-28"),
    completedDate: new Date("2025-04-28"),
    odometer: 9800,
    serviceName: "Auto Elétrica Bom Sinal",
    notes: "Bateria original apresentou falha"
  },
  {
    id: "m6",
    vehicleId: "v2",
    vehicleInfo: "Hyundai HB20 2022 - Placa DEF-5678",
    companyId: "r2",
    type: "preventive",
    description: "Alinhamento e balanceamento",
    cost: 280.00,
    status: "scheduled",
    scheduledDate: new Date("2025-05-28"),
    odometer: 18500,
    serviceName: "Pneu Center"
  },
];

const MaintenancePage = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [date, setDate] = useState<Date | undefined>(undefined);
  
  // Estados para os novos diálogos
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [newMaintenanceDialogOpen, setNewMaintenanceDialogOpen] = useState(false);
  const [locationsDialogOpen, setLocationsDialogOpen] = useState(false);
  
  // Acesso apenas para empresas e administradores
  if (user?.role === UserRole.DRIVER) {
    return (
      <div className="container py-3 md:py-6 px-2 md:px-4">
        <h1 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Manutenção</h1>
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm md:text-base">Você não tem permissão para acessar esta página. Apenas empresas de aluguel e administradores podem gerenciar manutenções.</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Filtra os registros de manutenção com base nos critérios
  const filteredRecords = mockMaintenanceRecords.filter(record => {
    // Se o usuário for uma empresa de aluguel, mostrar apenas seus registros
    if (user?.role === UserRole.RENTAL_COMPANY && record.companyId !== user.id) {
      return false;
    }
    
    // Filtro baseado na busca
    const matchesSearch = 
      record.vehicleInfo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (record.serviceName && record.serviceName.toLowerCase().includes(searchTerm.toLowerCase()));
      
    // Filtro baseado no status
    const matchesStatus = statusFilter === "all" || record.status === statusFilter;
    
    // Filtro baseado no tipo
    const matchesType = typeFilter === "all" || record.type === typeFilter;
    
    // Filtro baseado na data
    const matchesDate = !date || format(record.scheduledDate, "yyyy-MM-dd") === format(date, "yyyy-MM-dd");
      
    return matchesSearch && matchesStatus && matchesType && matchesDate;
  });

  // Função para obter a badge de status com a cor correta
  const getStatusBadge = (status: MaintenanceRecord["status"]) => {
    switch (status) {
      case "scheduled":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300 text-xs">Agendada</Badge>;
      case "in_progress":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300 text-xs">Em Andamento</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300 text-xs">Concluída</Badge>;
      case "cancelled":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300 text-xs">Cancelada</Badge>;
    }
  };
  
  // Função para obter a badge de tipo com a cor correta
  const getTypeBadge = (type: MaintenanceRecord["type"]) => {
    switch (type) {
      case "preventive":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300 text-xs">Preventiva</Badge>;
      case "corrective":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300 text-xs">Corretiva</Badge>;
      case "revision":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300 text-xs">Revisão</Badge>;
    }
  };

  // Função para formatar data no padrão brasileiro
  const formatDate = (date: Date | undefined) => {
    if (!date) return "-";
    return format(date, "dd/MM/yyyy", { locale: ptBR });
  };
  
  // Calcula totais para o dashboard
  const calculateSummary = () => {
    let records = mockMaintenanceRecords;
    
    // Se for uma empresa, filtrar apenas seus registros
    if (user?.role === UserRole.RENTAL_COMPANY) {
      records = records.filter(r => r.companyId === user.id);
    }
    
    const scheduled = records.filter(r => r.status === "scheduled").length;
    const inProgress = records.filter(r => r.status === "in_progress").length;
    const completed = records.filter(r => r.status === "completed").length;
    const totalCost = records.reduce((sum, r) => sum + r.cost, 0);
    
    return { scheduled, inProgress, completed, totalCost };
  };
  
  const summary = calculateSummary();

  return (
    <div className="container py-3 md:py-6 space-y-4 md:space-y-6 px-2 md:px-4">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-3 md:gap-0">
        <h1 className="text-xl md:text-2xl font-bold">Manutenção</h1>
        
        {/* Mobile: Dropdown for actions */}
        <div className="md:hidden">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Ações
                <MoreHorizontal className="h-4 w-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-background border">
              <DropdownMenuItem onClick={() => setScheduleDialogOpen(true)}>
                <CalendarIcon className="h-4 w-4 mr-2" />
                Agendar Manutenção
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setNewMaintenanceDialogOpen(true)}>
                <Wrench className="h-4 w-4 mr-2" />
                Nova Manutenção
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLocationsDialogOpen(true)}>
                <MapPin className="h-4 w-4 mr-2" />
                Locais
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Desktop: Individual buttons */}
        <div className="hidden md:flex gap-2">
          <Button 
            onClick={() => setScheduleDialogOpen(true)}
            className="flex items-center gap-2"
          >
            <CalendarIcon className="h-4 w-4" />
            Agendar Manutenção
          </Button>
          <Button 
            onClick={() => setNewMaintenanceDialogOpen(true)}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Wrench className="h-4 w-4" />
            Nova Manutenção
          </Button>
          <Button 
            onClick={() => setLocationsDialogOpen(true)}
            variant="outline"
            className="flex items-center gap-2"
          >
            <MapPin className="h-4 w-4" />
            Locais
          </Button>
        </div>
      </div>

      {/* Cards de resumo */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
        <Card className="border-l-4 border-l-blue-500 bg-white border border-gray-200">
          <CardContent className="p-3 md:p-6">
            <div className="text-center">
              <p className="text-xs md:text-sm font-medium text-muted-foreground">Agendadas</p>
              <h3 className="text-xl md:text-3xl font-bold text-blue-600">{summary.scheduled}</h3>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-yellow-500 bg-white border border-gray-200">
          <CardContent className="p-3 md:p-6">
            <div className="text-center">
              <p className="text-xs md:text-sm font-medium text-muted-foreground">Em Andamento</p>
              <h3 className="text-xl md:text-3xl font-bold text-yellow-600">{summary.inProgress}</h3>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-green-500 bg-white border border-gray-200">
          <CardContent className="p-3 md:p-6">
            <div className="text-center">
              <p className="text-xs md:text-sm font-medium text-muted-foreground">Concluídas</p>
              <h3 className="text-xl md:text-3xl font-bold text-green-600">{summary.completed}</h3>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-purple-500 bg-white border border-gray-200">
          <CardContent className="p-3 md:p-6">
            <div className="text-center">
              <p className="text-xs md:text-sm font-medium text-muted-foreground">Custo Total</p>
              <h3 className="text-base md:text-2xl font-bold text-purple-600">R$ {summary.totalCost.toFixed(2)}</h3>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3 h-auto">
          <TabsTrigger value="overview" className="text-xs md:text-sm p-2 md:p-3">Visão Geral</TabsTrigger>
          <TabsTrigger value="scheduled" className="text-xs md:text-sm p-2 md:p-3">Agendadas</TabsTrigger>
          <TabsTrigger value="completed" className="text-xs md:text-sm p-2 md:p-3">Realizadas</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 md:space-y-6 mt-4 md:mt-6">
          <Card>
            <CardHeader className="pb-3 md:pb-6">
              <CardTitle className="text-lg md:text-xl">Registros de Manutenção</CardTitle>
            </CardHeader>
            <CardContent className="p-3 md:p-6">
              <div className="flex flex-col gap-3 md:flex-row md:flex-wrap md:gap-4 mb-4 md:mb-6 p-3 md:p-4 border rounded-lg bg-muted/50">
                <div className="flex-1 min-w-[200px]">
                  <Input
                    placeholder="Buscar por veículo ou descrição"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="text-sm"
                  />
                </div>
                <div className="w-full md:w-auto">
                  <Select
                    value={statusFilter}
                    onValueChange={setStatusFilter}
                  >
                    <SelectTrigger className="w-full md:w-[180px]">
                      <SelectValue placeholder="Filtrar por status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os status</SelectItem>
                      <SelectItem value="scheduled">Agendada</SelectItem>
                      <SelectItem value="in_progress">Em Andamento</SelectItem>
                      <SelectItem value="completed">Concluída</SelectItem>
                      <SelectItem value="cancelled">Cancelada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full md:w-auto">
                  <Select
                    value={typeFilter}
                    onValueChange={setTypeFilter}
                  >
                    <SelectTrigger className="w-full md:w-[180px]">
                      <SelectValue placeholder="Filtrar por tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os tipos</SelectItem>
                      <SelectItem value="preventive">Preventiva</SelectItem>
                      <SelectItem value="corrective">Corretiva</SelectItem>
                      <SelectItem value="revision">Revisão</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full md:w-auto">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full md:w-[180px] justify-start text-sm">
                        {date ? (
                          format(date, "dd/MM/yyyy", { locale: ptBR })
                        ) : (
                          <span>Filtrar por data</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={(newDate) => {
                          setDate(newDate);
                        }}
                        initialFocus
                      />
                      {date && (
                        <div className="p-3 border-t">
                          <Button 
                            variant="ghost" 
                            onClick={() => setDate(undefined)}
                            size="sm"
                            className="w-full"
                          >
                            Limpar data
                          </Button>
                        </div>
                      )}
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              
              {/* Mobile: Cards View */}
              <div className="md:hidden">
                {filteredRecords.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p className="text-sm">Nenhum registro encontrado</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredRecords.map((record) => (
                      <Card key={record.id} className="border rounded-lg">
                        <CardContent className="p-4 space-y-3">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="font-semibold text-sm">
                                {record.vehicleInfo.split(' - ')[0]}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {record.vehicleInfo.split(' - ')[1]}
                              </div>
                            </div>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-background border">
                                <DropdownMenuItem>
                                  Editar
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <span className="text-muted-foreground">Tipo:</span>
                              <div className="mt-1">{getTypeBadge(record.type)}</div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Status:</span>
                              <div className="mt-1">{getStatusBadge(record.status)}</div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Data:</span>
                              <div className="mt-1">{formatDate(record.scheduledDate)}</div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Custo:</span>
                              <div className="mt-1 font-medium">R$ {record.cost.toFixed(2)}</div>
                            </div>
                          </div>
                          
                          <div className="pt-2 border-t">
                            <p className="text-xs text-muted-foreground truncate">{record.description}</p>
                            {record.serviceName && (
                              <p className="text-xs text-muted-foreground">{record.serviceName}</p>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>

              {/* Desktop: Table View */}
              <div className="hidden md:block border rounded-lg overflow-hidden">
                <Table>
                  <TableCaption>Lista de registros de manutenção</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Veículo</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Custo</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRecords.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-4 text-muted-foreground">
                          Nenhum registro encontrado
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredRecords.map((record) => (
                        <TableRow key={record.id}>
                          <TableCell>
                            {record.vehicleInfo.split(' - ')[0]}
                          </TableCell>
                          <TableCell>{getTypeBadge(record.type)}</TableCell>
                          <TableCell>
                            <div className="max-w-xs truncate">{record.description}</div>
                            {record.serviceName && (
                              <div className="text-xs text-muted-foreground">
                                {record.serviceName}
                              </div>
                            )}
                          </TableCell>
                          <TableCell>{formatDate(record.scheduledDate)}</TableCell>
                          <TableCell>R$ {record.cost.toFixed(2)}</TableCell>
                          <TableCell>{getStatusBadge(record.status)}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm">Editar</Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scheduled" className="space-y-4 md:space-y-6">
          <Card>
            <CardHeader className="pb-3 md:pb-6">
              <CardTitle className="flex items-center gap-2 text-lg md:text-xl">
                <Clock className="h-4 w-4 md:h-5 md:w-5" />
                Manutenções Agendadas
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 md:p-6">
              <div className="space-y-3 md:space-y-4">
                {filteredRecords
                  .filter(record => record.status === "scheduled")
                  .map((record) => (
                    <Card key={record.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-3 md:p-4">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-3">
                          <div className="space-y-2 flex-1">
                            <h4 className="font-semibold text-sm md:text-base">{record.vehicleInfo}</h4>
                            <p className="text-xs md:text-sm text-muted-foreground">{record.description}</p>
                            <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4 text-xs md:text-sm">
                              <span>📅 {formatDate(record.scheduledDate)}</span>
                              <span>🏪 {record.serviceName}</span>
                              <span>💰 R$ {record.cost.toFixed(2)}</span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" className="text-xs">Editar</Button>
                            <Button size="sm" className="text-xs">Iniciar</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="completed" className="space-y-4 md:space-y-6">
          <Card>
            <CardHeader className="pb-3 md:pb-6">
              <CardTitle className="flex items-center gap-2 text-lg md:text-xl">
                <Wrench className="h-4 w-4 md:h-5 md:w-5" />
                Manutenções Realizadas
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 md:p-6">
              <div className="space-y-3 md:space-y-4">
                {filteredRecords
                  .filter(record => record.status === "completed")
                  .map((record) => (
                    <Card key={record.id} className="border-l-4 border-l-green-500">
                      <CardContent className="p-3 md:p-4">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-3">
                          <div className="space-y-2 flex-1">
                            <h4 className="font-semibold text-sm md:text-base">{record.vehicleInfo}</h4>
                            <p className="text-xs md:text-sm text-muted-foreground">{record.description}</p>
                            <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-4 text-xs md:text-sm">
                              <span>📅 {formatDate(record.completedDate)}</span>
                              <span>🏪 {record.serviceName}</span>
                              <span>💰 R$ {record.cost.toFixed(2)}</span>
                            </div>
                            {record.notes && (
                              <p className="text-xs md:text-sm text-green-700 bg-green-50 p-2 rounded">
                                {record.notes}
                              </p>
                            )}
                          </div>
                          <Button size="sm" variant="outline" className="text-xs">Ver Detalhes</Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Diálogos */}
      <ScheduleMaintenanceDialog
        open={scheduleDialogOpen}
        onOpenChange={setScheduleDialogOpen}
        onSchedule={(data) => {
          console.log("Agendando manutenção:", data);
          toast.success("Manutenção agendada com sucesso!");
          setScheduleDialogOpen(false);
        }}
      />

      <NewMaintenanceDialog
        open={newMaintenanceDialogOpen}
        onOpenChange={setNewMaintenanceDialogOpen}
        onSave={(data) => {
          console.log("Salvando manutenção:", data);
          toast.success("Manutenção registrada com sucesso!");
          setNewMaintenanceDialogOpen(false);
        }}
      />

      <MaintenanceLocationsDialog
        open={locationsDialogOpen}
        onOpenChange={setLocationsDialogOpen}
      />
    </div>
  );
};

export default MaintenancePage;
