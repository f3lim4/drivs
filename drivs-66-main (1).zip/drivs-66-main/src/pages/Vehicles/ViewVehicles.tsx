
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Driver as DriverType, UserRole } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Car, Fuel, Users, Calendar, MapPin, MessageCircle, AlertCircle, Star, Shield, Clock } from "lucide-react";
import { toast } from "sonner";
import { generateVehicleImages } from "@/utils/vehicleUtils";

interface Vehicle {
  id: number;
  model: string;
  brand: string;
  year: number;
  plate: string;
  color: string;
  weeklyPrice: number;
  deposit: number;
  category: string;
  fuelType: string;
  seats: number;
  transmission: string;
  status: "Disponível";
  imageUrl: string;
  features: string[];
  companyId: string;
  companyName: string;
  description?: string;
  allowReservation?: boolean;
}

const ViewVehicles = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data for vehicles - only available ones
  const vehicles: Vehicle[] = [
    {
      id: 1,
      model: "Civic",
      brand: "Honda",
      year: 2023,
      plate: "ABC-1234",
      color: "Branco",
      weeklyPrice: 450,
      deposit: 200,
      category: "Sedan",
      fuelType: "Flex",
      seats: 5,
      transmission: "Automático",
      status: "Disponível",
      imageUrl: "https://images.unsplash.com/photo-1549924231-f129b911e442?w=400&h=300&fit=crop",
      features: ["Ar Condicionado", "Direção Hidráulica", "Vidros Elétricos"],
      companyId: "r1",
      companyName: "Best Rentals Inc.",
      description: "Sedan premium com excelente acabamento e tecnologia avançada.",
      allowReservation: true
    },
    {
      id: 2,
      model: "Corolla",
      brand: "Toyota",
      year: 2022,
      plate: "DEF-5678",
      color: "Prata",
      weeklyPrice: 420,
      deposit: 180,
      category: "Sedan",
      fuelType: "Flex",
      seats: 5,
      transmission: "Automático",
      status: "Disponível",
      imageUrl: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?w=400&h=300&fit=crop",
      features: ["Ar Condicionado", "Direção Elétrica", "Câmbio Automático", "Airbag"],
      companyId: "r2",
      companyName: "City Drivers Cars",
      description: "Sedan confortável, ideal para aplicativos de transporte.",
      allowReservation: false
    },
    {
      id: 3,
      model: "HB20",
      brand: "Hyundai",
      year: 2023,
      plate: "JKL-3456",
      color: "Vermelho",
      weeklyPrice: 350,
      deposit: 150,
      category: "Hatch",
      fuelType: "Flex",
      seats: 5,
      transmission: "Manual",
      status: "Disponível",
      imageUrl: "https://images.unsplash.com/photo-1919151184838-ab4d4906e9d5?w=400&h=300&fit=crop",
      features: ["Ar Condicionado", "Direção Elétrica", "Media Center"],
      companyId: "r1",
      companyName: "Best Rentals Inc.",
      description: "Hatch econômico, ideal para cidade, baixo consumo de combustível.",
      allowReservation: true
    },
    {
      id: 4,
      model: "Onix",
      brand: "Chevrolet",
      year: 2023,
      plate: "MNO-7890",
      color: "Azul",
      weeklyPrice: 320,
      deposit: 140,
      category: "Hatch",
      fuelType: "Flex",
      seats: 5,
      transmission: "Manual",
      status: "Disponível",
      imageUrl: "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=500&h=400&fit=crop",
      features: ["Ar Condicionado", "Direção Hidráulica", "Vidros Elétricos"],
      companyId: "r3",
      companyName: "Easy Drive Locadora",
      description: "Compacto confortável com boa economia de combustível.",
      allowReservation: true
    }
  ];

  const filteredVehicles = vehicles.filter(vehicle =>
    vehicle.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
    vehicle.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
    vehicle.plate.toLowerCase().includes(searchQuery.toLowerCase()) ||
    vehicle.color.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleReserve = (vehicleId: number, vehicleModel: string, deposit: number) => {
    // Redirecionar diretamente para a página de pagamentos
    navigate('/pagamentos', { 
      state: { 
        vehicleId: `reservation_${Date.now()}`,
        vehicleModel: `${vehicleModel}`, 
        deposit: deposit,
        paymentType: 'reservation'
      } 
    });
  };

  const handleContactCompany = (vehicleId: number, companyName: string) => {
    // Número de WhatsApp da empresa (exemplo)
    const phoneNumber = "5511999999999";
    const message = `Olá ${companyName}, tenho interesse no veículo ID: ${vehicleId}. Gostaria de conversar sobre a locação.`;
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    toast.success(`Entrando em contato com ${companyName} via WhatsApp...`);
  };

  const driver = user as DriverType;
  const isApprovedDriver = driver?.status === "approved";
  const hasActiveContract = !!driver?.activeContract;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header Section */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
            <Car className="h-4 w-4" />
            Veículos Disponíveis
          </div>
          <h1 className="text-4xl font-bold text-gray-900">
            Encontre o Veículo Ideal
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore nossa frota de veículos disponíveis e encontre o que melhor atende às suas necessidades de trabalho
          </p>
        </div>

        {/* Search Section */}
        <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="relative max-w-md mx-auto">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Buscar por modelo, marca, placa ou cor..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-4 py-3 text-lg border-2 border-gray-200 focus:border-blue-500 rounded-xl"
              />
            </div>
          </CardContent>
        </Card>

        {/* Vehicles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {filteredVehicles.map((vehicle) => {
            const vehicleImages = generateVehicleImages(vehicle.imageUrl);
            
            return (
              <Card key={vehicle.id} className="group bg-white border-0 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden">
                {/* Vehicle Image */}
                <div className="relative overflow-hidden">
                  <img 
                    src={vehicleImages[0]} 
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
                    <Badge className="bg-green-500 hover:bg-green-600 text-white shadow-lg">
                      <Shield className="h-3 w-3 mr-1" />
                      {vehicle.status}
                    </Badge>
                    {vehicle.allowReservation && (
                      <Badge className="bg-blue-500 hover:bg-blue-600 text-white shadow-lg">
                        <Clock className="h-3 w-3 mr-1" />
                        Reserva Rápida
                      </Badge>
                    )}
                  </div>
                  
                  {/* Mini Gallery */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex gap-1 justify-center">
                      {vehicleImages.slice(1, 4).map((image, index) => (
                        <img 
                          key={index}
                          src={image} 
                          alt={`${vehicle.brand} ${vehicle.model} ${index + 2}`}
                          className="w-12 h-8 object-cover rounded border-2 border-white shadow-sm"
                        />
                      ))}
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-6 space-y-6">
                  {/* Vehicle Info */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xl font-bold text-gray-900">
                        {vehicle.brand} {vehicle.model}
                      </h3>
                      <span className="text-lg font-semibold text-blue-600">
                        {vehicle.year}
                      </span>
                    </div>
                    
                    <p className="text-gray-600 text-sm line-clamp-2">
                      {vehicle.description}
                    </p>
                  </div>

                  {/* Vehicle Details */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4 text-blue-500" />
                      <span className="font-mono">{vehicle.plate}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Car className="h-4 w-4 text-blue-500" />
                      <span>{vehicle.color}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Fuel className="h-4 w-4 text-blue-500" />
                      <span>{vehicle.fuelType}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Users className="h-4 w-4 text-blue-500" />
                      <span>{vehicle.seats} lugares</span>
                    </div>
                  </div>

                  {/* Categories and Features */}
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <Badge variant="outline" className="bg-gray-50">{vehicle.category}</Badge>
                      <Badge variant="outline" className="bg-gray-50">{vehicle.transmission}</Badge>
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {vehicle.features.slice(0, 2).map((feature, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs bg-blue-50 text-blue-700">
                          {feature}
                        </Badge>
                      ))}
                      {vehicle.features.length > 2 && (
                        <Badge variant="secondary" className="text-xs bg-blue-50 text-blue-700">
                          +{vehicle.features.length - 2}
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Pricing */}
                  <div className="space-y-3">
                    <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-xl border border-blue-200">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">
                          R$ {vehicle.weeklyPrice}
                        </div>
                        <div className="text-sm text-gray-600">por semana</div>
                      </div>
                    </div>
                    
                    <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                      <div className="text-center">
                        <div className="text-sm font-medium text-yellow-800">
                          + R$ {vehicle.deposit} de caução
                        </div>
                        <div className="text-xs text-yellow-600">
                          (devolvido ao final)
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    {!hasActiveContract && isApprovedDriver ? (
                      vehicle.allowReservation ? (
                        <div className="space-y-2">
                          <Button 
                            onClick={() => handleReserve(vehicle.id, `${vehicle.brand} ${vehicle.model}`, vehicle.deposit)}
                            className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
                            size="lg"
                          >
                            <Calendar className="h-5 w-5 mr-2" />
                            Reservar Agora - R$ {vehicle.deposit}
                          </Button>
                          
                          <Button 
                            variant="outline" 
                            className="w-full border-2 border-blue-200 text-blue-700 hover:bg-blue-50 font-medium py-3 rounded-xl transition-all duration-200"
                            onClick={() => handleContactCompany(vehicle.id, vehicle.companyName)}
                            size="lg"
                          >
                            <MessageCircle className="h-5 w-5 mr-2" />
                            Entrar em Contato
                          </Button>
                        </div>
                      ) : (
                        <Button 
                          className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200" 
                          onClick={() => handleContactCompany(vehicle.id, vehicle.companyName)}
                          size="lg"
                        >
                          <MessageCircle className="h-5 w-5 mr-2" />
                          Entrar em Contato
                        </Button>
                      )
                    ) : !isApprovedDriver ? (
                      <Button className="w-full py-3 rounded-xl" disabled size="lg">
                        Aprovação necessária
                      </Button>
                    ) : (
                      <Button className="w-full py-3 rounded-xl" disabled size="lg">
                        Você já possui um contrato ativo
                      </Button>
                    )}
                  </div>

                  {/* Warning for non-reservation vehicles */}
                  {!vehicle.allowReservation && (
                    <div className="bg-orange-50 border-l-4 border-orange-400 p-3 rounded-r-lg">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="h-4 w-4 text-orange-600 mt-0.5 flex-shrink-0" />
                        <div className="text-sm text-orange-800">
                          <strong>Este veículo não aceita reserva.</strong><br />
                          Entre em contato para alugar.
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* No Results */}
        {filteredVehicles.length === 0 && (
          <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="text-center py-16">
              <Car className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                Nenhum veículo encontrado
              </h3>
              <p className="text-gray-500">
                Tente ajustar seus critérios de busca ou volte mais tarde.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Info Section */}
        <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 shadow-xl">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold mb-2">Informações Importantes</h3>
              <p className="text-blue-100">Tudo que você precisa saber sobre nossos serviços</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h4 className="font-semibold text-lg flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  Sobre a reserva:
                </h4>
                <ul className="space-y-2 text-blue-100">
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></span>
                    Reserva válida por 24 horas
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></span>
                    Valor da caução é devolvido ao final
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></span>
                    Documentos necessários para retirada
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></span>
                    Vistoria obrigatória na entrega
                  </li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="font-semibold text-lg flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Valores inclusos:
                </h4>
                <ul className="space-y-2 text-blue-100">
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></span>
                    Seguro básico
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></span>
                    IPVA e licenciamento
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></span>
                    Manutenção preventiva
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0"></span>
                    Suporte 24h
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ViewVehicles;
