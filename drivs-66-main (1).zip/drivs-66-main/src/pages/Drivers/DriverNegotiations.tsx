
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { Driver } from "@/types";
import { 
  Handshake, 
  MessageSquare, 
  CheckCircle, 
  XCircle, 
  ExternalLink,
  Send,
  Building2,
  User,
  DollarSign,
  Calendar,
  AlertTriangle
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface NegotiationMessage {
  id: string;
  senderType: "driver" | "company";
  senderName: string;
  message: string;
  createdAt: Date;
}

interface DriverNegotiation {
  id: string;
  companyName: string;
  type: "debt" | "violation" | "contract" | "payment";
  description: string;
  originalAmount: number;
  negotiatedAmount: number;
  status: "pending" | "accepted" | "rejected" | "completed";
  paymentLink?: string;
  dueDate: Date;
  createdAt: Date;
  messages: NegotiationMessage[];
}

// Mock data para demonstração
const mockNegotiations: DriverNegotiation[] = [
  {
    id: "neg001",
    companyName: "Velocity Rent",
    type: "debt",
    description: "Débito referente a danos no veículo durante o período de locação",
    originalAmount: 2500.00,
    negotiatedAmount: 1800.00,
    status: "pending",
    paymentLink: "https://pay.stripe.com/example-link",
    dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 dias a partir de hoje
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 dias atrás
    messages: [
      {
        id: "msg1",
        senderType: "company",
        senderName: "Velocity Rent",
        message: "Olá! Estamos oferecendo um desconto de 28% no valor total do débito. O valor original de R$ 2.500,00 pode ser quitado por R$ 1.800,00. Clique no link de pagamento para aceitar esta proposta.",
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
      }
    ]
  },
  {
    id: "neg002",
    companyName: "Velocity Rent",
    type: "violation",
    description: "Multa de trânsito durante o período de locação",
    originalAmount: 300.00,
    negotiatedAmount: 300.00,
    status: "accepted",
    paymentLink: "https://pay.stripe.com/example-link-2",
    dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    messages: [
      {
        id: "msg2",
        senderType: "company",
        senderName: "Velocity Rent",
        message: "Temos uma multa em seu nome no valor de R$ 300,00. Por favor, efetue o pagamento através do link enviado.",
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
      },
      {
        id: "msg3",
        senderType: "driver",
        senderName: "João Silva",
        message: "Aceito a cobrança. Vou efetuar o pagamento hoje.",
        createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000)
      },
      {
        id: "msg4",
        senderType: "company",
        senderName: "Velocity Rent",
        message: "Perfeito! Aguardamos o pagamento. Obrigado pela colaboração.",
        createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000)
      }
    ]
  }
];

export default function DriverNegotiations() {
  const { user } = useAuth();
  const [negotiations, setNegotiations] = useState<DriverNegotiation[]>(mockNegotiations);
  const [selectedNegotiation, setSelectedNegotiation] = useState<DriverNegotiation | null>(null);
  const [newMessage, setNewMessage] = useState("");

  const driver = user as Driver;

  const getStatusBadge = (status: DriverNegotiation["status"]) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pendente</Badge>;
      case "accepted":
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Aceito</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Rejeitado</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Concluído</Badge>;
      default:
        return <Badge variant="outline">Status</Badge>;
    }
  };

  const getTypeLabel = (type: DriverNegotiation["type"]) => {
    switch (type) {
      case "debt": return "Débito";
      case "violation": return "Infração";
      case "contract": return "Contrato";
      case "payment": return "Pagamento";
      default: return type;
    }
  };

  const handleAcceptNegotiation = (negotiation: DriverNegotiation) => {
    setNegotiations(prev => 
      prev.map(n => 
        n.id === negotiation.id 
          ? { ...n, status: "accepted" as const }
          : n
      )
    );

    // Adicionar mensagem automática
    const acceptMessage: NegotiationMessage = {
      id: `msg_${Date.now()}`,
      senderType: "driver",
      senderName: driver?.fullName || "Motorista",
      message: "Aceito a proposta de negociação. Vou proceder com o pagamento.",
      createdAt: new Date()
    };

    setNegotiations(prev => 
      prev.map(n => 
        n.id === negotiation.id 
          ? { ...n, messages: [...n.messages, acceptMessage] }
          : n
      )
    );

    if (selectedNegotiation?.id === negotiation.id) {
      setSelectedNegotiation(prev => prev ? { ...prev, status: "accepted", messages: [...prev.messages, acceptMessage] } : null);
    }

    toast({
      title: "Proposta aceita",
      description: "Você aceitou a proposta. Pode proceder com o pagamento através do link fornecido."
    });
  };

  const handleRejectNegotiation = (negotiation: DriverNegotiation) => {
    setNegotiations(prev => 
      prev.map(n => 
        n.id === negotiation.id 
          ? { ...n, status: "rejected" as const }
          : n
      )
    );

    // Adicionar mensagem automática
    const rejectMessage: NegotiationMessage = {
      id: `msg_${Date.now()}`,
      senderType: "driver",
      senderName: driver?.fullName || "Motorista",
      message: "Não aceito esta proposta de negociação.",
      createdAt: new Date()
    };

    setNegotiations(prev => 
      prev.map(n => 
        n.id === negotiation.id 
          ? { ...n, messages: [...n.messages, rejectMessage] }
          : n
      )
    );

    if (selectedNegotiation?.id === negotiation.id) {
      setSelectedNegotiation(prev => prev ? { ...prev, status: "rejected", messages: [...prev.messages, rejectMessage] } : null);
    }

    toast({
      title: "Proposta rejeitada",
      description: "Você rejeitou a proposta de negociação."
    });
  };

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedNegotiation) return;

    const message: NegotiationMessage = {
      id: `msg_${Date.now()}`,
      senderType: "driver",
      senderName: driver?.fullName || "Motorista",
      message: newMessage.trim(),
      createdAt: new Date()
    };

    setNegotiations(prev => 
      prev.map(n => 
        n.id === selectedNegotiation.id 
          ? { ...n, messages: [...n.messages, message] }
          : n
      )
    );

    setSelectedNegotiation(prev => 
      prev ? { ...prev, messages: [...prev.messages, message] } : null
    );

    setNewMessage("");
    toast({
      title: "Mensagem enviada",
      description: "Sua mensagem foi enviada para a locadora."
    });
  };

  const openPaymentLink = (paymentLink: string) => {
    window.open(paymentLink, '_blank');
  };

  if (selectedNegotiation) {
    return (
      <div className="max-w-4xl mx-auto space-y-6 py-6 px-4">
        <div className="flex items-center gap-4 pb-4 border-b">
          <Button variant="outline" onClick={() => setSelectedNegotiation(null)}>
            ← Voltar
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Negociação com {selectedNegotiation.companyName}</h1>
            <p className="text-muted-foreground">#{selectedNegotiation.id}</p>
          </div>
        </div>

        {/* Detalhes da Negociação */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Detalhes da Negociação
                </CardTitle>
                <div className="flex items-center gap-2 mt-2">
                  <Badge>{getTypeLabel(selectedNegotiation.type)}</Badge>
                  {getStatusBadge(selectedNegotiation.status)}
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Vencimento</p>
                <p className="font-medium flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {format(selectedNegotiation.dueDate, "dd/MM/yyyy", { locale: ptBR })}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Descrição</p>
              <p>{selectedNegotiation.description}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Valor Original</p>
                <p className="text-lg font-semibold text-red-600">R$ {selectedNegotiation.originalAmount.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Valor Negociado</p>
                <p className="text-lg font-bold text-green-600">R$ {selectedNegotiation.negotiatedAmount.toFixed(2)}</p>
              </div>
            </div>

            {selectedNegotiation.originalAmount !== selectedNegotiation.negotiatedAmount && (
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <p className="text-sm text-green-800">
                  <strong>Desconto oferecido:</strong> R$ {(selectedNegotiation.originalAmount - selectedNegotiation.negotiatedAmount).toFixed(2)} 
                  ({(((selectedNegotiation.originalAmount - selectedNegotiation.negotiatedAmount) / selectedNegotiation.originalAmount) * 100).toFixed(1)}%)
                </p>
              </div>
            )}

            {/* Ações */}
            {selectedNegotiation.status === "pending" && (
              <div className="flex gap-3 pt-4 border-t">
                <Button 
                  onClick={() => handleAcceptNegotiation(selectedNegotiation)}
                  className="flex-1"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Aceitar Proposta
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={() => handleRejectNegotiation(selectedNegotiation)}
                  className="flex-1"
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Rejeitar
                </Button>
              </div>
            )}

            {selectedNegotiation.status === "accepted" && selectedNegotiation.paymentLink && (
              <div className="pt-4 border-t">
                <Button 
                  onClick={() => openPaymentLink(selectedNegotiation.paymentLink!)}
                  className="w-full"
                  size="lg"
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Pagar Agora - R$ {selectedNegotiation.negotiatedAmount.toFixed(2)}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Mensagens */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Conversas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 mb-4">
              <div className="space-y-4">
                {selectedNegotiation.messages.map((message) => (
                  <div key={message.id} className="flex gap-3">
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      <AvatarFallback className={message.senderType === "company" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"}>
                        {message.senderType === "company" ? <Building2 className="h-4 w-4" /> : <User className="h-4 w-4" />}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{message.senderName}</span>
                        <span className="text-xs text-muted-foreground">
                          {format(message.createdAt, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                        </span>
                      </div>
                      
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <p className="text-sm">{message.message}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <Separator className="my-4" />

            {/* Input de nova mensagem */}
            <div className="space-y-3">
              <Textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Digite sua mensagem para a locadora..."
                rows={3}
              />
              <div className="flex justify-end">
                <Button
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim()}
                >
                  <Send className="h-4 w-4 mr-2" />
                  Enviar Mensagem
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 py-6 px-4">
      <div className="flex items-center gap-3 pb-4 border-b">
        <Handshake className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold">Minhas Negociações</h1>
          <p className="text-muted-foreground">Visualize e responda às propostas da locadora</p>
        </div>
      </div>

      {negotiations.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Handshake className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Nenhuma negociação</h3>
            <p className="text-muted-foreground">Quando a locadora enviar propostas de acordo, elas aparecerão aqui.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {negotiations.map((negotiation) => (
            <Card key={negotiation.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <h3 className="text-lg font-semibold">{negotiation.companyName}</h3>
                      <Badge>{getTypeLabel(negotiation.type)}</Badge>
                      {getStatusBadge(negotiation.status)}
                    </div>
                    <p className="text-sm text-muted-foreground">#{negotiation.id}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Vencimento</p>
                    <p className="font-medium flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {format(negotiation.dueDate, "dd/MM/yyyy", { locale: ptBR })}
                    </p>
                    {negotiation.dueDate < new Date() && negotiation.status !== "completed" && (
                      <Badge variant="destructive" className="mt-1">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        Vencido
                      </Badge>
                    )}
                  </div>
                </div>

                <p className="text-sm mb-4">{negotiation.description}</p>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Valor Original</p>
                    <p className="font-semibold text-red-600">R$ {negotiation.originalAmount.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Valor Negociado</p>
                    <p className="font-bold text-green-600">R$ {negotiation.negotiatedAmount.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Mensagens</p>
                    <p className="font-medium">{negotiation.messages.length}</p>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <p className="text-xs text-muted-foreground">
                    Criado em {format(negotiation.createdAt, "dd/MM/yyyy", { locale: ptBR })}
                  </p>
                  <Button onClick={() => setSelectedNegotiation(negotiation)}>
                    Ver Detalhes
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
