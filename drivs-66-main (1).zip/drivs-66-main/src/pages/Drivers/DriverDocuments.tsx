
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RefreshCw } from "lucide-react";
import { useDriverDocuments } from "./hooks/useDriverDocuments";
import { DocumentViewModal } from "./components/DocumentViewModal";
import { DriverInfoCard } from "./components/DriverInfoCard";
import { DocumentStatusCard } from "./components/DocumentStatusCard";
import { DocumentsList } from "./components/DocumentsList";
import { ActionsCard } from "./components/ActionsCard";

const DriverDocuments = () => {
  const { user } = useAuth();
  const {
    driverData,
    isLoading,
    documentsList,
    selectedDocument,
    setSelectedDocument,
    getStatusCount,
    handleViewDocument
  } = useDriverDocuments(user?.id);
  
  if (!user || user.role !== UserRole.DRIVER) {
    return (
      <div className="container py-6 px-4">
        <h1 className="text-2xl font-bold mb-6">Documentos</h1>
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você não tem permissão para acessar esta página.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="container py-6 px-4">
        <h1 className="text-2xl font-bold mb-6">Documentos</h1>
        <Card>
          <CardContent className="py-8">
            <div className="flex items-center justify-center">
              <RefreshCw className="h-6 w-6 animate-spin mr-2" />
              <span>Carregando documentos...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { approved, total } = getStatusCount();
  const progressPercentage = (approved / total) * 100;

  return (
    <div className="container py-6 px-4 space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">Documentos</h1>
        <p className="text-muted-foreground">
          Acompanhe o status da análise dos seus documentos
        </p>
      </div>

      <DriverInfoCard 
        driverData={driverData}
        userFullName={user.fullName}
        userEmail={user.email}
      />

      <DocumentStatusCard
        driverData={driverData}
        approved={approved}
        total={total}
        progressPercentage={progressPercentage}
      />

      <DocumentsList
        documentsList={documentsList}
        driverData={driverData}
        onViewDocument={handleViewDocument}
      />

      <ActionsCard />

      <DocumentViewModal
        isOpen={selectedDocument !== null}
        onClose={() => setSelectedDocument(null)}
        documentName={selectedDocument?.name || ""}
        documentData={selectedDocument?.data || ""}
      />
    </div>
  );
};

export default DriverDocuments;
