
import { useState } from "react";
import { DriversTable } from "./components/DriversTable";
import { CreateDriverDialog } from "./components/CreateDriverDialog";
import { EditDriverDialog } from "./components/EditDriverDialog";
import { DeleteDriverDialog } from "./components/DeleteDriverDialog";
import { MassDeleteDriversDialog } from "./components/MassDeleteDriversDialog";
import { IntegrityCheckDialog } from "./components/IntegrityCheckDialog";
import { DriverStatusHistory } from "./components/DriverStatusHistory";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, Database, Search } from "lucide-react";
import { useDriverData } from "./hooks/useDriverData";
import { useAuth } from "@/contexts/AuthContext";

const DriversPage = () => {
  const { user } = useAuth();
  const { drivers, loading, deleteDriver, refetchDrivers } = useDriverData();
  
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showMassDeleteDialog, setShowMassDeleteDialog] = useState(false);
  const [showIntegrityDialog, setShowIntegrityDialog] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<any>(null);

  const handleViewDriver = (driverId: string) => {
    const driver = drivers.find(d => d.id === driverId);
    if (driver) {
      setSelectedDriver(driver);
      setShowEditDialog(true);
    }
  };

  const handleDeleteDriver = async (driverId: string) => {
    try {
      await deleteDriver(driverId);
      setShowDeleteDialog(false);
      setSelectedDriver(null);
    } catch (error) {
      console.error('Erro ao excluir motorista:', error);
    }
  };

  const handleMassDeleteSuccess = () => {
    setShowMassDeleteDialog(false);
    refetchDrivers();
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">Carregando motoristas...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Gestão de Motoristas</span>
            <div className="flex gap-2">
              <Button
                onClick={() => setShowCreateDialog(true)}
                className="flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Novo Motorista
              </Button>
              
              <Button
                variant="outline"
                onClick={() => setShowIntegrityDialog(true)}
                className="flex items-center gap-2"
              >
                <Search className="h-4 w-4" />
                Verificar Integridade
              </Button>
              
              {user?.role === 'admin' && (
                <Button
                  variant="destructive"
                  onClick={() => setShowMassDeleteDialog(true)}
                  className="flex items-center gap-2"
                >
                  <Trash2 className="h-4 w-4" />
                  Exclusão Massiva
                </Button>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <DriversTable
            drivers={drivers}
            userRole={user?.role}
            onViewDriver={handleViewDriver}
            onDeleteDriver={deleteDriver}
          />
        </CardContent>
      </Card>

      <DriverStatusHistory />

      {/* Dialogs */}
      <CreateDriverDialog
        isOpen={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        onSuccess={() => {
          setShowCreateDialog(false);
          refetchDrivers();
        }}
      />

      {selectedDriver && (
        <EditDriverDialog
          isOpen={showEditDialog}
          onClose={() => {
            setShowEditDialog(false);
            setSelectedDriver(null);
          }}
          driver={selectedDriver}
          onSuccess={() => {
            setShowEditDialog(false);
            setSelectedDriver(null);
            refetchDrivers();
          }}
        />
      )}

      {selectedDriver && (
        <DeleteDriverDialog
          isOpen={showDeleteDialog}
          onClose={() => {
            setShowDeleteDialog(false);
            setSelectedDriver(null);
          }}
          onConfirm={handleDeleteDriver}
          driverName={selectedDriver.full_name}
          driverId={selectedDriver.id}
        />
      )}

      <MassDeleteDriversDialog
        isOpen={showMassDeleteDialog}
        onClose={() => setShowMassDeleteDialog(false)}
        onSuccess={handleMassDeleteSuccess}
      />

      <IntegrityCheckDialog
        isOpen={showIntegrityDialog}
        onClose={() => setShowIntegrityDialog(false)}
        drivers={drivers}
      />
    </div>
  );
};

export default DriversPage;
