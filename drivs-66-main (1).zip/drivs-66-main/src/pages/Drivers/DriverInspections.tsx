import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Camera, Car, FileText, Clock, CheckCircle, Calendar, MapPin, Smartphone, Play, Eye, User } from "lucide-react";
import NativeCameraCapture from "@/components/camera/NativeCameraCapture";
import { DriverHistoryModal } from "../Inspections/components/DriverHistoryModal";
import { DriverInspectionInfoCard } from "./components/DriverInspectionInfoCard";

interface CompletedInspection {
  id: number;
  type: string;
  date: string;
  time: string;
  location: string;
  photos: number;
  observations: string;
  status: "Aprovada" | "Pendente de Revisão" | "Rejeitada";
  vehiclePlate: string;
  vehicleModel: string;
  contractId: string;
  requestedBy?: string;
}

interface RequestedInspection {
  id: string;
  type: string;
  time: string;
  vehicle: string;
  driver: string;
  location: string;
  status: string;
  statusColor: string;
  requestedBy: string;
  description: string;
}

// Histórico completo de vistorias do motorista (todos os contratos)
const completedInspections: CompletedInspection[] = [
  {
    id: 1,
    type: "Vistoria Inicial",
    date: "2024-01-15",
    time: "09:30",
    location: "São Paulo - SP",
    photos: 14,
    observations: "Veículo em perfeitas condições",
    status: "Aprovada",
    vehiclePlate: "ABC-1234",
    vehicleModel: "Honda Civic",
    contractId: "CON-2024-001",
    requestedBy: "Auto Rental Plus"
  },
  {
    id: 2,
    type: "Vistoria de Manutenção",
    date: "2024-01-10",
    time: "14:15",
    location: "São Paulo - SP",
    photos: 5,
    observations: "Verificação dos pneus conforme solicitado",
    status: "Pendente de Revisão",
    vehiclePlate: "ABC-1234",
    vehicleModel: "Honda Civic",
    contractId: "CON-2024-001",
    requestedBy: "Auto Rental Plus"
  },
  {
    id: 3,
    type: "Vistoria de Entrega",
    date: "2024-01-05",
    time: "16:45",
    location: "São Paulo - SP",
    photos: 14,
    observations: "Veículo entregue nas mesmas condições",
    status: "Aprovada",
    vehiclePlate: "DEF-5678",
    vehicleModel: "Toyota Corolla",
    contractId: "CON-2023-005",
    requestedBy: "Auto Rental Plus"
  },
  {
    id: 4,
    type: "Vistoria Inicial",
    date: "2023-12-20",
    time: "10:00",
    location: "São Paulo - SP",
    photos: 14,
    observations: "Pequeno arranhão já existente documentado",
    status: "Aprovada",
    vehiclePlate: "DEF-5678",
    vehicleModel: "Toyota Corolla",
    contractId: "CON-2023-005",
    requestedBy: "Auto Rental Plus"
  }
];

const DriverInspections = () => {
  const { user } = useAuth();
  const [showNativeCamera, setShowNativeCamera] = useState(false);
  const [selectedInspection, setSelectedInspection] = useState<any>(null);
  const [showDriverHistory, setShowDriverHistory] = useState(false);
  const [selectedCompletedInspection, setSelectedCompletedInspection] = useState<CompletedInspection | null>(null);

  if (!user || user.role !== UserRole.DRIVER) {
    return <div>Acesso não autorizado</div>;
  }

  const driver = user as Driver;
  const isActiveDriver = !!driver.activeContract;
  const isDeactivatedDriver = driver.status === "deactivated";

  if (!isActiveDriver && !isDeactivatedDriver) {
    return (
      <div className="min-h-screen bg-background dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Card className="bg-card dark:bg-gray-800">
            <CardContent className="p-6 text-center">
              <p className="text-muted-foreground">Você precisa ter um contrato ativo para acessar as vistorias.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Vistorias solicitadas pela locadora apenas (do contrato ativo)
  const requestedInspections: RequestedInspection[] = [
    {
      id: "1",
      type: "Vistoria de Manutenção",
      time: "Hoje, 14:00",
      vehicle: "Honda Civic - ABC-1234",
      driver: driver.fullName,
      location: "São Paulo - SP",
      status: "Pendente",
      statusColor: "bg-red-100 text-red-800",
      requestedBy: "Auto Rental Plus",
      description: "Vistoria de manutenção preventiva - Verificação dos pneus e sistema de freios"
    },
    {
      id: "2",
      type: "Vistoria Eventual",
      time: "Quinta-feira, 15:30",
      vehicle: "Honda Civic - ABC-1234",
      driver: driver.fullName,
      location: "São Paulo - SP",
      status: "Agendada",
      statusColor: "bg-blue-100 text-blue-800",
      requestedBy: "Auto Rental Plus",
      description: "Verificação específica solicitada pela locadora após relato de ruído no motor"
    }
  ];

  const handleStartInspection = (inspection?: any) => {
    if (inspection) {
      setSelectedInspection(inspection);
    }
    setShowNativeCamera(true);
  };

  const handleViewDriverHistory = () => {
    setSelectedCompletedInspection(null);
    setShowDriverHistory(true);
  };

  const handleViewSpecificInspection = (inspection: CompletedInspection) => {
    setSelectedCompletedInspection(inspection);
    setShowDriverHistory(true);
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Vistoria Inicial":
        return "bg-blue-100 text-blue-800";
      case "Vistoria de Entrega":
        return "bg-green-100 text-green-800";
      case "Vistoria de Manutenção":
        return "bg-purple-100 text-purple-800";
      case "Vistoria Semanal":
        return "bg-orange-100 text-orange-800";
      case "Vistoria Eventual":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getInspectionType = (type: string): 'inicial' | 'entrega' | 'manutencao' | 'eventual' => {
    switch (type) {
      case "Vistoria Inicial":
        return "inicial";
      case "Vistoria de Entrega":
        return "entrega";
      case "Vistoria de Manutenção":
        return "manutencao";
      default:
        return "eventual";
    }
  };

  if (showNativeCamera) {
    return (
      <div className="min-h-screen bg-background dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <NativeCameraCapture
            inspectionId={selectedInspection?.id || Date.now()}
            vehiclePlate="ABC-1234"
            vehicleModel="Honda Civic"
            onComplete={() => {
              setShowNativeCamera(false);
              setSelectedInspection(null);
            }}
            inspectionType={selectedInspection ? getInspectionType(selectedInspection.type) : 'eventual'}
            title={selectedInspection?.type}
            description={selectedInspection?.description}
            deadline={selectedInspection?.time}
          />
        </div>
      </div>
    );
  }

  const getStatusBadge = (status: CompletedInspection["status"]) => {
    switch (status) {
      case "Aprovada":
        return <Badge className="bg-green-500 text-white">Aprovada</Badge>;
      case "Pendente de Revisão":
        return <Badge className="bg-yellow-500 text-white">Pendente de Revisão</Badge>;
      case "Rejeitada":
        return <Badge variant="destructive">Rejeitada</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const vehicleInfo = isDeactivatedDriver 
    ? `${driver.activeContract?.vehicleModel || "Honda Civic"} - ${(driver as any).deactivationInfo?.rentalCompany || "Auto Rental Plus"}`
    : `Honda Civic - Auto Rental Plus`;

  return (
    <div className="min-h-screen bg-background dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="space-y-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-foreground">Vistorias do Veículo</h1>
            <p className="text-lg text-muted-foreground mt-1">
              {vehicleInfo}
            </p>
            {isDeactivatedDriver && (
              <div className="mt-2">
                <Badge variant="destructive" className="text-sm">
                  Contrato Encerrado
                </Badge>
              </div>
            )}
          </div>

          {/* Para motoristas desativados, mostrar apenas o histórico sem cards de estatísticas */}
          {isDeactivatedDriver ? (
            <div className="space-y-6">
              <Card className="content-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Histórico Completo de Vistorias ({completedInspections.length})
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Todas as vistorias realizadas em seus contratos com a Auto Rental Plus
                  </p>
                </CardHeader>
                <CardContent>
                  {completedInspections.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Tipo</TableHead>
                            <TableHead>Veículo</TableHead>
                            <TableHead>Data/Hora</TableHead>
                            <TableHead>Contrato</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Fotos</TableHead>
                            <TableHead>Observações</TableHead>
                            <TableHead>Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {completedInspections.map((inspection) => (
                            <TableRow key={inspection.id}>
                              <TableCell>
                                <Badge className={getTypeColor(inspection.type)}>
                                  {inspection.type}
                                </Badge>
                              </TableCell>
                              <TableCell className="font-medium">
                                {inspection.vehiclePlate} - {inspection.vehicleModel}
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-1">
                                  <Calendar className="h-4 w-4 text-blue-500" />
                                  <span>
                                    {new Date(inspection.date).toLocaleDateString()} às {inspection.time}
                                  </span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                                  {inspection.contractId}
                                </span>
                              </TableCell>
                              <TableCell>
                                {getStatusBadge(inspection.status)}
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-1">
                                  <Camera className="h-4 w-4 text-blue-500" />
                                  <span>{inspection.photos}</span>
                                </div>
                              </TableCell>
                              <TableCell className="max-w-xs truncate">
                                {inspection.observations}
                              </TableCell>
                              <TableCell>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => handleViewSpecificInspection(inspection)}
                                  className="p-2"
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <p className="text-muted-foreground">
                        Nenhuma vistoria realizada ainda.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            /* Para motoristas ativos, mostrar as tabs normalmente */
            <Tabs defaultValue="solicitadas" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="solicitadas">Vistorias Solicitadas</TabsTrigger>
                <TabsTrigger value="historico">Histórico Completo</TabsTrigger>
              </TabsList>

              <TabsContent value="solicitadas" className="space-y-6">
                <Card className="border-l-2 border-l-orange-500">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5" />
                      Vistorias Solicitadas pela Locadora
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Vistorias específicas solicitadas pela Auto Rental Plus que você precisa realizar
                    </p>
                  </CardHeader>
                  <CardContent>
                    {requestedInspections.length > 0 ? (
                      <div className="space-y-4">
                        {requestedInspections.map((inspection) => (
                          <div key={inspection.id} className="flex items-center justify-between p-4 border rounded-lg bg-gray-50">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <Badge className={getTypeColor(inspection.type)}>
                                  {inspection.type}
                                </Badge>
                                <span className="font-medium text-lg">{inspection.time}</span>
                                <Badge className={inspection.statusColor}>
                                  {inspection.status}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-2 mb-1">
                                <Car className="h-4 w-4 text-gray-500" />
                                <p className="font-medium">{inspection.vehicle}</p>
                              </div>
                              <div className="flex items-center gap-2 mb-1">
                                <MapPin className="h-4 w-4 text-gray-500" />
                                <p className="text-sm text-muted-foreground">{inspection.location}</p>
                              </div>
                              <p className="text-sm text-muted-foreground mb-1">{inspection.description}</p>
                              <p className="text-xs text-muted-foreground">Solicitado por: {inspection.requestedBy}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button 
                                size="sm" 
                                className="flex items-center gap-2"
                                onClick={() => handleStartInspection(inspection)}
                              >
                                <Play className="h-4 w-4" />
                                Realizar
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                        <p className="text-muted-foreground">
                          Nenhuma vistoria solicitada pela locadora no momento.
                        </p>
                        <p className="text-sm text-muted-foreground mt-2">
                          Novas solicitações aparecerão aqui quando enviadas pela Auto Rental Plus.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Card informativo */}
                <DriverInspectionInfoCard />
              </TabsContent>

              <TabsContent value="historico" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="content-card content-card-green">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {completedInspections.filter(i => i.status === "Aprovada").length}
                      </div>
                      <p className="text-xs text-muted-foreground">Aprovadas</p>
                    </CardContent>
                  </Card>
                  <Card className="content-card content-card-yellow">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-yellow-600">
                        {completedInspections.filter(i => i.status === "Pendente de Revisão").length}
                      </div>
                      <p className="text-xs text-muted-foreground">Pendentes</p>
                    </CardContent>
                  </Card>
                  <Card className="content-card content-card-blue">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {completedInspections.length}
                      </div>
                      <p className="text-xs text-muted-foreground">Total</p>
                    </CardContent>
                  </Card>
                </div>

                <Card className="content-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="h-5 w-5" />
                      Histórico Completo de Vistorias ({completedInspections.length})
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Todas as vistorias realizadas em seus contratos com a Auto Rental Plus
                    </p>
                  </CardHeader>
                  <CardContent>
                    {completedInspections.length > 0 ? (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Tipo</TableHead>
                              <TableHead>Veículo</TableHead>
                              <TableHead>Data/Hora</TableHead>
                              <TableHead>Contrato</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Fotos</TableHead>
                              <TableHead>Observações</TableHead>
                              <TableHead>Ações</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {completedInspections.map((inspection) => (
                              <TableRow key={inspection.id}>
                                <TableCell>
                                  <Badge className={getTypeColor(inspection.type)}>
                                    {inspection.type}
                                  </Badge>
                                </TableCell>
                                <TableCell className="font-medium">
                                  {inspection.vehiclePlate} - {inspection.vehicleModel}
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-1">
                                    <Calendar className="h-4 w-4 text-blue-500" />
                                    <span>
                                      {new Date(inspection.date).toLocaleDateString()} às {inspection.time}
                                    </span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                                    {inspection.contractId}
                                  </span>
                                </TableCell>
                                <TableCell>
                                  {getStatusBadge(inspection.status)}
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-1">
                                    <Camera className="h-4 w-4 text-blue-500" />
                                    <span>{inspection.photos}</span>
                                  </div>
                                </TableCell>
                                <TableCell className="max-w-xs truncate">
                                  {inspection.observations}
                                </TableCell>
                                <TableCell>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => handleViewSpecificInspection(inspection)}
                                    className="p-2"
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <p className="text-muted-foreground">
                          Nenhuma vistoria realizada ainda.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}

          {/* Modal de histórico do motorista */}
          {showDriverHistory && (
            <DriverHistoryModal
              isOpen={showDriverHistory}
              onClose={() => {
                setShowDriverHistory(false);
                setSelectedCompletedInspection(null);
              }}
              driverName={driver.fullName}
              vehiclePlate="ABC-1234"
              vehicleModel="Honda Civic"
              selectedInspection={selectedCompletedInspection}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default DriverInspections;
