import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Car, XCircle } from "lucide-react";
import { VehicleHeader } from "./components/VehicleHeader";
import { VehicleInfoCard } from "./components/VehicleInfoCard";
import { VehiclePhotosCard } from "./components/VehiclePhotosCard";
import { VehicleMaintenanceCard } from "./components/VehicleMaintenanceCard";
import { VehicleInsuranceCard } from "./components/VehicleInsuranceCard";
import { VehicleDocumentsCard } from "./components/VehicleDocumentsCard";
import { VehicleSupportCard } from "./components/VehicleSupportCard";

const MyVehicle = () => {
  const { user } = useAuth();
  
  if (!user || user.role !== UserRole.DRIVER) {
    return (
      <div className="container py-6 px-4">
        <h1 className="text-2xl font-bold mb-6">Meu Veículo</h1>
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você não tem permissão para acessar esta página.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const driver = user as Driver;

  // Se o motorista está desativado, mostrar informações específicas
  if (driver.status === "deactivated") {
    const deactivationInfo = (driver as any).deactivationInfo;
    const contractInfo = driver.activeContract;

    return (
      <div className="container py-6 px-4">
        <h1 className="text-2xl font-bold mb-6">Meu Veículo</h1>
        
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-800">
              <XCircle className="h-5 w-5" />
              Contrato Desativado pela Locadora
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-red-700">
              <p className="mb-2">
                <strong>Locadora:</strong> {deactivationInfo?.rentalCompany || contractInfo?.companyName}
              </p>
              <p className="mb-2">
                <strong>Motivo:</strong> {deactivationInfo?.reason}
              </p>
              <p className="mb-2">
                <strong>Data da Desativação:</strong> {' '}
                {deactivationInfo?.deactivatedAt ? 
                  new Date(deactivationInfo.deactivatedAt).toLocaleDateString('pt-BR') : 
                  'Não informado'
                }
              </p>
            </div>

            {contractInfo && (
              <div className="mt-4 p-4 bg-white rounded-lg border">
                <h3 className="font-semibold mb-3 text-gray-800">Informações do Veículo (Contrato Encerrado)</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Car className="h-4 w-4 text-gray-600" />
                      <span className="text-gray-600">Modelo:</span>
                      <span className="font-medium">{contractInfo.vehicleModel}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Período do Contrato:</span>
                      <p className="font-medium">
                        {new Date(contractInfo.contractStart).toLocaleDateString('pt-BR')} até {' '}
                        {new Date(contractInfo.contractEnd).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <span className="text-gray-600">Status do Pagamento:</span>
                      <p className="font-medium capitalize">{contractInfo.paymentStatus}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Locadora:</span>
                      <p className="font-medium">{contractInfo.companyName}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <div className="text-yellow-800 text-sm">
                  <p className="font-medium mb-1">Atenção:</p>
                  <p>O acesso ao veículo foi suspenso devido ao encerramento do contrato. Para maiores informações, entre em contato com a locadora ou acesse a seção "Negociações" para resolver pendências.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!driver.activeContract) {
    return (
      <div className="container py-6 px-4">
        <h1 className="text-2xl font-bold mb-6">Meu Veículo</h1>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
              Nenhum Contrato Ativo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você não possui um contrato ativo no momento. Entre em contato com uma locadora para iniciar um novo contrato.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const vehicleInfo = {
    model: "Honda Civic",
    plate: "ABC-1234",
    year: "2023",
    color: "Prata",
    fuel: "Flex",
    mileage: "15.320 km",
    status: "Ativo"
  };

  const vehiclePhotos = [
    "/placeholder.svg",
    "/placeholder.svg", 
    "/placeholder.svg"
  ];

  return (
    <div className="container py-6 px-4 space-y-6">
      <VehicleHeader status={vehicleInfo.status} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <VehicleInfoCard vehicleInfo={vehicleInfo} />
        <VehiclePhotosCard photos={vehiclePhotos} />
        <VehicleMaintenanceCard />
        <VehicleInsuranceCard />
      </div>

      <VehicleDocumentsCard />
      <VehicleSupportCard />
    </div>
  );
};

export default MyVehicle;
