
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";

export const ActionsCard = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Ações Disponíveis</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex gap-4">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={() => window.location.reload()}
          >
            <RefreshCw className="h-4 w-4" />
            Atualizar Status
          </Button>
        </div>
        
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-sm text-blue-800">
            <strong>Dica:</strong> Certifique-se de que todos os documentos estejam legíveis e com boa qualidade. 
            Para o print do app, capture a tela mostrando claramente seu perfil completo com nome e foto.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
