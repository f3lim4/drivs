
import { Card, CardContent } from "@/components/ui/card";

interface Driver {
  rating: number;
  violations: number;
  available: boolean;
}

interface DriverStatsCardsProps {
  driver: Driver;
}

export const DriverStatsCards = ({ driver }: DriverStatsCardsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-blue-600">{driver.rating || 0}</div>
          <p className="text-sm text-muted-foreground">Avaliação</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-red-600">{driver.violations || 0}</div>
          <p className="text-sm text-muted-foreground">Infrações</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-green-600">
            {driver.available ? 'Sim' : 'Não'}
          </div>
          <p className="text-sm text-muted-foreground">Disponível</p>
        </CardContent>
      </Card>
    </div>
  );
};
