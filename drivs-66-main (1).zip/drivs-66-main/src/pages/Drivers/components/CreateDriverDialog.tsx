
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface CreateDriverDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const CreateDriverDialog = ({ isOpen, onClose, onSuccess }: CreateDriverDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Criar Novo Motorista</DialogTitle>
        </DialogHeader>
        <div className="p-4 text-center">
          <p>Funcionalidade em desenvolvimento</p>
          <Button onClick={onClose} className="mt-4">
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
