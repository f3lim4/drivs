
import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface DocumentViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentName: string;
  documentData: string;
}

export const DocumentViewModal = ({ isOpen, onClose, documentName, documentData }: DocumentViewModalProps) => {
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = documentData;
    link.download = `${documentName}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{documentName}</span>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex flex-col items-center space-y-4">
          {documentData ? (
            <>
              <div className="w-full max-w-3xl border rounded-lg overflow-hidden">
                <img 
                  src={documentData} 
                  alt={documentName}
                  className="w-full h-auto object-contain"
                  style={{ maxHeight: '70vh' }}
                />
              </div>
              
              <div className="flex gap-2">
                <Button onClick={handleDownload} variant="outline">
                  Baixar Documento
                </Button>
                <Button onClick={onClose}>
                  Fechar
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Documento não encontrado</p>
              <Button onClick={onClose} className="mt-4">
                Fechar
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
