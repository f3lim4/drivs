
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface Driver {
  id: string;
  full_name: string;
  status: string;
}

interface IntegrityCheckDialogProps {
  isOpen: boolean;
  onClose: () => void;
  drivers: Driver[];
}

export const IntegrityCheckDialog = ({ isOpen, onClose, drivers }: IntegrityCheckDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Verificação de Integridade</DialogTitle>
        </DialogHeader>
        <div className="p-4">
          <p>Total de motoristas: {drivers.length}</p>
          <p className="text-sm text-gray-600 mt-2">Funcionalidade em desenvolvimento</p>
          <Button onClick={onClose} className="mt-4">
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
