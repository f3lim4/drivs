
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Clock, CheckCircle, AlertTriangle } from "lucide-react";

interface DocumentStatusCardProps {
  driverData: any;
  approved: number;
  total: number;
  progressPercentage: number;
}

export const DocumentStatusCard = ({ driverData, approved, total, progressPercentage }: DocumentStatusCardProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Status da Análise
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">
            Progresso da Documentação
          </span>
          <span className="text-sm font-medium">
            {approved} de {total} documentos aprovados
          </span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>

        {driverData?.status === "under_review" || driverData?.status === "pending" ? (
          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div className="text-yellow-800">
                <p className="font-medium mb-1">Documentação em Análise</p>
                <p className="text-sm">
                  Sua documentação está sendo analisada pela nossa equipe. 
                  O processo pode levar até 2 dias úteis. Você será notificado assim que a análise for concluída.
                </p>
              </div>
            </div>
          </div>
        ) : driverData?.status === "rejected" ? (
          <div className="p-4 bg-red-50 rounded-lg border border-red-200">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
              <div className="text-red-800">
                <p className="font-medium mb-1">Documentação Rejeitada</p>
                <p className="text-sm">
                  {driverData.rejection_reason || "Alguns documentos foram rejeitados. Verifique os detalhes abaixo e reenvie os documentos necessários."}
                </p>
              </div>
            </div>
          </div>
        ) : driverData?.status === "approved" ? (
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div className="text-green-800">
                <p className="font-medium mb-1">Documentação Aprovada</p>
                <p className="text-sm">
                  Parabéns! Sua documentação foi aprovada. Você já pode utilizar todos os recursos da plataforma.
                </p>
              </div>
            </div>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
};
