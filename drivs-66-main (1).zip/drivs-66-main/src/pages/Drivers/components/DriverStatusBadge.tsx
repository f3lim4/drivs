
import { Badge } from "@/components/ui/badge";
import { DriverStatus } from "@/types";

interface DriverStatusBadgeProps {
  status: DriverStatus | string;
}

export const DriverStatusBadge = ({ status }: DriverStatusBadgeProps) => {
  console.log('🏷️ [STATUS BADGE] Status recebido:', status, 'Tipo:', typeof status);
  
  const statusConfig = {
    [DriverStatus.PENDING]: { label: "Em Aberto", variant: "outline" as const, className: "border-blue-500 text-blue-500" },
    [DriverStatus.UNDER_REVIEW]: { label: "Em Análise", variant: "outline" as const, className: "border-yellow-500 text-yellow-500" },
    [DriverStatus.APPROVED]: { label: "Aprovado", variant: "default" as const, className: "bg-green-500" },
    [DriverStatus.ACTIVE]: { label: "Ativo", variant: "default" as const, className: "bg-blue-500 text-white" },
    [DriverStatus.REJECTED]: { label: "Reprovado", variant: "destructive" as const, className: "" },
    [DriverStatus.DEACTIVATED]: { label: "Desativado", variant: "destructive" as const, className: "bg-red-500 text-white" },
    [DriverStatus.BLACKLISTED]: { label: "Negativado", variant: "destructive" as const, className: "bg-red-600" }
  };

  // Tratamento para status como string
  const normalizedStatus = typeof status === 'string' ? status as DriverStatus : status;
  console.log('🏷️ [STATUS BADGE] Status normalizado:', normalizedStatus);
  
  const config = statusConfig[normalizedStatus] || { 
    label: `Desconhecido (${status})`, 
    variant: "outline" as const, 
    className: "border-gray-500 text-gray-500" 
  };
  
  console.log('🏷️ [STATUS BADGE] Config final:', config);
  
  return (
    <Badge variant={config.variant} className={config.className}>
      {config.label}
    </Badge>
  );
};
