
import { Car } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface VehicleInfo {
  model: string;
  plate: string;
  year: string;
  color: string;
  fuel: string;
  mileage: string;
}

interface VehicleInfoCardProps {
  vehicleInfo: VehicleInfo;
}

export const VehicleInfoCard = ({ vehicleInfo }: VehicleInfoCardProps) => {
  return (
    <Card className="border-l-4 border-l-blue-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Car className="h-5 w-5" />
          Dados do Veículo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Modelo</p>
            <p className="font-semibold">{vehicleInfo.model}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Placa</p>
            <p className="font-semibold">{vehicleInfo.plate}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Ano</p>
            <p className="font-semibold">{vehicleInfo.year}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Cor</p>
            <p className="font-semibold">{vehicleInfo.color}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Combustível</p>
            <p className="font-semibold">{vehicleInfo.fuel}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Quilometragem</p>
            <p className="font-semibold">{vehicleInfo.mileage}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
