
import { Table, TableBody, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserRole, DriverStatus } from "@/types";
import { DriverTableRow } from "./DriverTableRow";

interface Driver {
  id: string;
  email?: string;
  role?: UserRole;
  full_name: string;
  cpf: string;
  rg: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  cnh: string;
  cnh_expires: string;
  date_of_birth?: string;
  status: DriverStatus;
  available: boolean;
  rating: number;
  violations: number;
  created_at: string;
  updated_at: string;
  rejection_reason?: string;
  rejection_date?: string;
  vehicleInfo?: string;
  company_name?: string;
  company_id?: string;
}

interface DriversTableProps {
  drivers: Driver[];
  userRole?: UserRole;
  onViewDriver: (driverId: string) => void;
  onDeleteDriver?: (driverId: string) => Promise<boolean>;
}

export const DriversTable = ({ drivers, userRole, onViewDriver, onDeleteDriver }: DriversTableProps) => {
  // Admin sempre mostra a coluna da locadora
  const showCompanyColumn = userRole === UserRole.ADMIN;

  console.log('🏢 [DRIVER TABLE] Exibindo coluna da locadora:', showCompanyColumn);
  console.log('👤 [DRIVER TABLE] Papel do usuário:', userRole);
  console.log('📊 [DRIVER TABLE] Dados dos motoristas:', drivers.map(d => ({
    name: d.full_name,
    company: d.company_name,
    status: d.status
  })));

  if (drivers.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-muted-foreground">Nenhum motorista encontrado</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Lista de Motoristas ({drivers.length})</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Motorista</TableHead>
                {showCompanyColumn && <TableHead>Locadora</TableHead>}
                <TableHead className="hidden sm:table-cell">Localização</TableHead>
                <TableHead className="hidden md:table-cell">CNH Vencimento</TableHead>
                <TableHead className="hidden md:table-cell">Data Nascimento</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden md:table-cell">Veículo</TableHead>
                {userRole !== UserRole.RENTAL_COMPANY && (
                  <TableHead className="hidden lg:table-cell">Violações</TableHead>
                )}
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {drivers.map((driver) => (
                <DriverTableRow
                  key={driver.id}
                  driver={driver}
                  userRole={userRole}
                  onViewDriver={() => onViewDriver(driver.id)}
                  onDeleteDriver={onDeleteDriver}
                  showCompanyColumn={showCompanyColumn}
                />
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
