
import { Car, CheckCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface VehicleHeaderProps {
  status: string;
}

export const VehicleHeader = ({ status }: VehicleHeaderProps) => {
  return (
    <div className="text-center space-y-2">
      <div className="flex items-center justify-center gap-3">
        <Car className="h-8 w-8 text-blue-600" />
        <h1 className="text-2xl font-bold">Meu Veículo</h1>
      </div>
      <p className="text-muted-foreground">Informações completas do seu veículo alugado</p>
      <Badge className="bg-green-100 text-green-800">
        <CheckCircle className="h-3 w-3 mr-1" />
        {status}
      </Badge>
    </div>
  );
};
