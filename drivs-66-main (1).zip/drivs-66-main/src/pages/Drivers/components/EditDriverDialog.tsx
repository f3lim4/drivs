
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface Driver {
  id: string;
  full_name: string;
  status: string;
  phone: string;
  email?: string;
}

interface EditDriverDialogProps {
  isOpen: boolean;
  onClose: () => void;
  driver: Driver;
  onSuccess: () => void;
}

export const EditDriverDialog = ({ isOpen, onClose, driver, onSuccess }: EditDriverDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Editar Motorista: {driver.full_name}</DialogTitle>
        </DialogHeader>
        <div className="p-4 text-center">
          <p>Funcionalidade em desenvolvimento</p>
          <Button onClick={onClose} className="mt-4">
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
