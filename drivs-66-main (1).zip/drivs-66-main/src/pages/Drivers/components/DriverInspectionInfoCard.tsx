
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Camera, FileText, Clock, CheckCircle, AlertTriangle, Info } from "lucide-react";

export const DriverInspectionInfoCard = () => {
  return (
    <Card className="content-card content-card-blue">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Info className="h-5 w-5" />
          Como Realizar suas Vistorias
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Vistorias Automáticas */}
          <div>
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Vistorias Obrigatórias
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-900/20">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="default">Vistoria Inicial</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  <strong>Quando:</strong> Antes de retirar o veículo
                </p>
                <p className="text-sm text-muted-foreground mb-2">
                  <strong>Objetivo:</strong> Documentar o estado do veículo no momento da retirada
                </p>
                <p className="text-sm text-muted-foreground">
                  <strong>Fotos:</strong> 14 fotos obrigatórias do veículo
                </p>
              </div>
              
              <div className="p-4 border rounded-lg bg-green-50 dark:bg-green-900/20">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary">Vistoria de Entrega</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  <strong>Quando:</strong> No momento da entrega do veículo
                </p>
                <p className="text-sm text-muted-foreground mb-2">
                  <strong>Objetivo:</strong> Registrar o estado final do veículo
                </p>
                <p className="text-sm text-muted-foreground">
                  <strong>Fotos:</strong> 14 fotos obrigatórias do veículo
                </p>
              </div>
            </div>
          </div>

          {/* Vistorias Solicitadas */}
          <div>
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <Clock className="h-4 w-4 text-orange-500" />
              Vistorias Solicitadas pela Locadora
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg bg-purple-50 dark:bg-purple-900/20">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline">Vistoria de Manutenção</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  <strong>Quando:</strong> Antes ou após manutenções
                </p>
                <p className="text-sm text-muted-foreground mb-2">
                  <strong>Objetivo:</strong> Verificar condições para manutenção
                </p>
                <p className="text-sm text-muted-foreground">
                  <strong>Fotos:</strong> Até 5 fotos específicas + observações
                </p>
              </div>
              
              <div className="p-4 border rounded-lg bg-yellow-50 dark:bg-yellow-900/20">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline">Vistoria Eventual</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  <strong>Quando:</strong> Situações específicas
                </p>
                <p className="text-sm text-muted-foreground mb-2">
                  <strong>Objetivo:</strong> Verificações pontuais
                </p>
                <p className="text-sm text-muted-foreground">
                  <strong>Fotos:</strong> Até 5 fotos específicas + observações
                </p>
              </div>
            </div>
          </div>

          {/* Instruções Importantes */}
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h5 className="font-medium mb-3 flex items-center gap-2">
              <Camera className="h-4 w-4 text-blue-600" />
              Dicas Importantes para as Fotos
            </h5>
            <div className="text-sm text-muted-foreground space-y-2">
              <p>• <strong>Boa iluminação:</strong> Tire fotos em locais bem iluminados, preferencialmente com luz natural</p>
              <p>• <strong>Foco nítido:</strong> Certifique-se de que a imagem está focada e clara</p>
              <p>• <strong>Ângulo adequado:</strong> Siga as instruções de cada foto (frente, lateral, etc.)</p>
              <p>• <strong>Detalhes visíveis:</strong> Para danos ou detalhes específicos, aproxime a câmera</p>
              <p>• <strong>Localização ativa:</strong> Mantenha o GPS ativo para registrar a localização das fotos</p>
            </div>
          </div>

          {/* Processo de Aprovação */}
          <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg">
            <h5 className="font-medium mb-2 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              O que acontece após enviar
            </h5>
            <div className="text-sm text-muted-foreground space-y-1">
              <p>• <strong>Análise automática:</strong> O sistema verifica se todas as fotos foram enviadas</p>
              <p>• <strong>Revisão da locadora:</strong> Suas fotos serão analisadas pela equipe da locadora</p>
              <p>• <strong>Feedback:</strong> Você receberá notificação sobre aprovação ou necessidade de refazer</p>
              <p>• <strong>Reenvio:</strong> Se necessário, você poderá refazer apenas as fotos rejeitadas</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
