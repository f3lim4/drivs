
import { TableCell, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Eye, Trash2 } from "lucide-react";
import { DriverStatus, UserRole } from "@/types";
import { DriverStatusBadge } from "./DriverStatusBadge";
import { useState } from "react";
import { toast } from "sonner";

interface Driver {
  id: string;
  email?: string;
  role?: UserRole;
  full_name: string;
  cpf: string;
  rg: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  cnh: string;
  cnh_expires: string;
  date_of_birth?: string;
  status: DriverStatus;
  available: boolean;
  rating: number;
  violations: number;
  created_at: string;
  updated_at: string;
  rejection_reason?: string;
  rejection_date?: string;
  vehicleInfo?: string;
  company_name?: string;
  company_id?: string;
}

interface DriverTableRowProps {
  driver: Driver;
  userRole?: UserRole;
  onViewDriver: () => void;
  onDeleteDriver?: (driverId: string) => Promise<boolean>;
  showCompanyColumn: boolean;
}

export const DriverTableRow = ({ 
  driver, 
  userRole, 
  onViewDriver, 
  onDeleteDriver, 
  showCompanyColumn 
}: DriverTableRowProps) => {
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    if (!onDeleteDriver) return;

    // Confirmar a exclusão
    const confirmMessage = `Tem certeza que deseja excluir o motorista "${driver.full_name}"?\n\nEsta ação não pode ser desfeita e removerá todos os dados relacionados.`;
    
    if (!window.confirm(confirmMessage)) {
      return;
    }

    setIsDeleting(true);
    
    try {
      console.log(`🗑️ [DRIVER ROW] Iniciando exclusão do motorista: ${driver.full_name}`);
      
      const success = await onDeleteDriver(driver.id);
      
      if (success) {
        console.log(`✅ [DRIVER ROW] Motorista ${driver.full_name} excluído com sucesso`);
        // O toast de sucesso já é mostrado no hook useDriverOperations
      } else {
        console.error(`❌ [DRIVER ROW] Falha na exclusão do motorista: ${driver.full_name}`);
        toast.error('Falha na exclusão do motorista');
      }
      
    } catch (error: any) {
      console.error(`❌ [DRIVER ROW] Erro ao excluir motorista ${driver.full_name}:`, error);
      
      // Não mostrar toast se o erro já foi tratado no hook
      if (!error.message.includes('permissão') && 
          !error.message.includes('encontrado') && 
          !error.message.includes('Sessão expirada')) {
        toast.error(`Erro ao excluir motorista: ${error.message}`);
      }
    } finally {
      setIsDeleting(false);
    }
  };

  // Mostrar botão de excluir apenas para admin
  const canDelete = userRole === UserRole.ADMIN && onDeleteDriver;

  return (
    <TableRow>
      <TableCell>
        <div>
          <div className="font-medium">{driver.full_name}</div>
          <div className="text-sm text-muted-foreground">{driver.phone}</div>
        </div>
      </TableCell>
      
      {showCompanyColumn && (
        <TableCell>
          <span className="text-sm">{driver.company_name || 'N/A'}</span>
        </TableCell>
      )}
      
      <TableCell className="hidden sm:table-cell">
        <div className="text-sm">
          <div>{driver.city}</div>
          <div className="text-muted-foreground">{driver.state}</div>
        </div>
      </TableCell>
      
      <TableCell className="hidden md:table-cell">
        <span className="text-sm">{driver.cnh_expires}</span>
      </TableCell>
      
      <TableCell className="hidden md:table-cell">
        <span className="text-sm">{driver.date_of_birth || 'N/A'}</span>
      </TableCell>
      
      <TableCell>
        <DriverStatusBadge status={driver.status} />
      </TableCell>
      
      <TableCell className="hidden md:table-cell">
        <span className="text-sm">{driver.vehicleInfo || 'N/A'}</span>
      </TableCell>
      
      {userRole !== UserRole.RENTAL_COMPANY && (
        <TableCell className="hidden lg:table-cell">
          <span className="text-sm">{driver.violations}</span>
        </TableCell>
      )}
      
      <TableCell>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onViewDriver}
            className="flex items-center gap-1"
            disabled={isDeleting}
          >
            <Eye className="h-4 w-4" />
            Ver
          </Button>
          
          {canDelete && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleDelete}
              disabled={isDeleting}
              className="flex items-center gap-1 text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className={`h-4 w-4 ${isDeleting ? 'animate-spin' : ''}`} />
              {isDeleting ? 'Excluindo...' : 'Excluir'}
            </Button>
          )}
        </div>
      </TableCell>
    </TableRow>
  );
};
