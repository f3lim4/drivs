
import { Wrench } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const VehicleMaintenanceCard = () => {
  return (
    <Card className="border-l-4 border-l-orange-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wrench className="h-5 w-5" />
          Manutenção
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="text-sm font-medium mb-2">Última Revisão</p>
          <p className="text-sm text-muted-foreground">Realizada em</p>
          <p className="font-semibold">15/05/2024</p>
        </div>
        <div className="border-t pt-4">
          <p className="text-sm font-medium mb-2">Próxima Revisão</p>
          <p className="text-sm text-muted-foreground">Agendada para</p>
          <p className="font-semibold">15/08/2024</p>
        </div>
      </CardContent>
    </Card>
  );
};
