
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Trash2, AlertTriangle, Shield, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface SecureMassDeleteDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface SecureMassDeleteResponse {
  success: boolean;
  erro?: string;
  code?: string;
  mensagem?: string;
  deletion_summary?: {
    deleted_drivers: number;
    deleted_registrations: number;
    deleted_contracts: number;
    deleted_payments: number;
    deleted_violations: number;
    deleted_inspections: number;
    deleted_maintenances: number;
  };
  records_before_deletion?: {
    drivers: number;
    registrations: number;
    contracts: number;
    payments: number;
    violations: number;
    inspections: number;
    maintenances: number;
  };
}

// Type guard function to check if the response matches our expected structure
const isSecureMassDeleteResponse = (data: any): data is SecureMassDeleteResponse => {
  return data && typeof data === 'object' && typeof data.success === 'boolean';
};

export const SecureMassDeleteDialog = ({ 
  isOpen, 
  onClose, 
  onSuccess 
}: SecureMassDeleteDialogProps) => {
  const [password, setPassword] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const { user } = useAuth();

  const handleClose = () => {
    setPassword("");
    setIsDeleting(false);
    onClose();
  };

  const handleSecureMassDelete = async () => {
    if (!user?.id) {
      toast.error("Usuário não autenticado");
      return;
    }

    if (user.role !== 'admin') {
      toast.error("Apenas administradores podem executar esta operação");
      return;
    }

    if (!password) {
      toast.error("Digite a senha de segurança");
      return;
    }

    setIsDeleting(true);

    try {
      console.log('🚨 [SECURE MASS DELETE] Iniciando exclusão massiva REAL com senha...');
      console.log('👤 [SECURE MASS DELETE] ID do usuário:', user.id);
      
      const { data: result, error } = await supabase
        .rpc('secure_mass_delete_all_data', {
          requester_user_id: user.id,
          security_password: password
        });

      if (error) {
        console.error('❌ [SECURE MASS DELETE] Erro na função RPC:', error);
        throw new Error(`Erro na exclusão massiva segura: ${error.message}`);
      }

      if (!result) {
        throw new Error('Resposta vazia da função de exclusão massiva segura');
      }

      console.log('📊 [SECURE MASS DELETE] Resultado bruto:', result);

      // Safely cast the result using our type guard
      if (!isSecureMassDeleteResponse(result)) {
        console.error('❌ [SECURE MASS DELETE] Resposta em formato inválido:', result);
        throw new Error('Resposta da função em formato inválido');
      }

      const response: SecureMassDeleteResponse = result;
      console.log('📊 [SECURE MASS DELETE] Resultado processado:', response);

      if (!response.success) {
        console.error('❌ [SECURE MASS DELETE] Exclusão falhou:', response);
        
        const errorMessages: Record<string, string> = {
          'INVALID_PASSWORD': 'Senha incorreta. Exclusão não autorizada.',
          'USER_NOT_FOUND': 'Usuário não encontrado no sistema',
          'INSUFFICIENT_PERMISSIONS': 'Você não tem permissão para esta operação',
          'MASS_DELETION_ERROR': 'Erro interno durante a exclusão massiva'
        };
        
        const friendlyMessage = errorMessages[response.code || ''] || response.erro || 'Erro desconhecido';
        throw new Error(friendlyMessage);
      }

      // Mostrar sucesso com detalhes
      if (response.deletion_summary) {
        console.log('📈 [SECURE MASS DELETE] Sumário da exclusão:', response.deletion_summary);
        
        const summary = response.deletion_summary;
        const totalDeleted = Object.values(summary).reduce((acc: number, val: any) => acc + (Number(val) || 0), 0);
        
        toast.success(`${response.mensagem} Total: ${totalDeleted} registros removidos permanentemente.`, {
          duration: 8000
        });

        // Mostrar detalhes no console
        console.log(`✅ [SECURE MASS DELETE] Registros excluídos:
        - Motoristas (drivers): ${summary.deleted_drivers}
        - Registros (registrations): ${summary.deleted_registrations}
        - Contratos: ${summary.deleted_contracts}
        - Pagamentos: ${summary.deleted_payments}
        - Violações: ${summary.deleted_violations}
        - Inspeções: ${summary.deleted_inspections}
        - Manutenções: ${summary.deleted_maintenances}
        - Total: ${totalDeleted}`);
      } else {
        toast.success(response.mensagem || 'Exclusão massiva segura concluída com sucesso!');
      }

      handleClose();
      onSuccess();
      
    } catch (error: any) {
      console.error('❌ [SECURE MASS DELETE] Erro crítico:', error);
      toast.error(error.message || 'Erro ao executar exclusão massiva segura');
    } finally {
      setIsDeleting(false);
    }
  };

  if (!user || user.role !== 'admin') {
    return null;
  }

  return (
    <AlertDialog open={isOpen} onOpenChange={handleClose}>
      <AlertDialogContent className="max-w-lg">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2 text-red-600">
            <Shield className="h-6 w-6" />
            EXCLUSÃO MASSIVA SEGURA
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-3">
            <div className="p-4 bg-red-50 border border-red-200 rounded-md">
              <div className="flex items-center gap-2 text-red-700 font-medium mb-2">
                <AlertTriangle className="h-4 w-4" />
                ATENÇÃO: Esta operação é IRREVERSÍVEL
              </div>
              <ul className="text-sm text-red-600 space-y-1">
                <li>• Excluirá TODOS os motoristas permanentemente</li>
                <li>• Removerá TODOS os contratos, pagamentos e violações</li>
                <li>• Apagará TODAS as inspeções e manutenções</li>
                <li>• TODOS os dados serão perdidos definitivamente</li>
                <li>• <strong>Contas de admin serão protegidas</strong></li>
              </ul>
            </div>
            
            <div className="p-3 bg-green-50 border border-green-200 rounded-md">
              <div className="flex items-center gap-2 text-green-700 font-medium mb-2">
                <Shield className="h-4 w-4" />
                Proteção de Admin Ativada
              </div>
              <div className="text-sm text-green-600">
                Sua sessão de admin será preservada após a operação.
              </div>
            </div>
            
            <div className="p-3 bg-gray-50 border rounded-md">
              <div className="flex items-center gap-2 text-gray-700 font-medium mb-2">
                <Lock className="h-4 w-4" />
                Autenticação com Senha Obrigatória
              </div>
              <div className="text-sm text-gray-600">
                Esta operação requer senha de segurança para confirmação.
              </div>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="security-password" className="text-sm font-medium">
              Digite a senha de segurança:
            </Label>
            <Input
              id="security-password"
              type="password"
              placeholder="Senha obrigatória..."
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isDeleting}
              className="font-mono"
            />
          </div>
          
          {password && password !== 'F3lim@4510' && (
            <div className="text-sm text-red-600">
              Senha incorreta. Verifique e tente novamente.
            </div>
          )}
        </div>

        <AlertDialogFooter className="flex flex-col sm:flex-row gap-2">
          <AlertDialogCancel onClick={handleClose} disabled={isDeleting}>
            Cancelar
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleSecureMassDelete}
            disabled={isDeleting || !password}
            className="bg-red-600 hover:bg-red-700"
          >
            {isDeleting ? (
              <>
                <Trash2 className="h-4 w-4 mr-2 animate-spin" />
                Executando Exclusão Protegida...
              </>
            ) : (
              <>
                <Trash2 className="h-4 w-4 mr-2" />
                EXECUTAR EXCLUSÃO SEGURA
              </>
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
