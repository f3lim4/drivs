
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const DriverStatusHistory = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Histórico de Status</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-gray-600">Funcionalidade em desenvolvimento</p>
      </CardContent>
    </Card>
  );
};
