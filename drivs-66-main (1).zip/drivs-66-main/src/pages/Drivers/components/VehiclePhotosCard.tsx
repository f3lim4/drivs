
import { Camera } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface VehiclePhotosCardProps {
  photos: string[];
}

export const VehiclePhotosCard = ({ photos }: VehiclePhotosCardProps) => {
  return (
    <Card className="border-l-4 border-l-purple-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="h-5 w-5" />
          Fotos do Veículo
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-3">
          {photos.map((photo, index) => (
            <div key={index} className="relative group">
              <img
                src={photo}
                alt={`Veículo ${index + 1}`}
                className="w-full h-20 object-cover rounded-lg border cursor-pointer hover:opacity-80 transition-opacity"
              />
              <p className="text-xs text-center mt-1">Veículo {index + 1}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
