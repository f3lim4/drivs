
import { Shield, Phone } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const VehicleInsuranceCard = () => {
  return (
    <Card className="border-l-4 border-l-green-500">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Seguro
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <p className="text-sm text-muted-foreground">Seguradora</p>
          <p className="font-semibold">Seguradora Premium</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Cobertura</p>
          <p className="font-semibold">Cobertura Completa</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Franquia</p>
          <p className="font-semibold">R$ 2.500,00</p>
        </div>
        <div className="border-t pt-3">
          <p className="text-sm text-muted-foreground">Emergência</p>
          <p className="font-semibold flex items-center gap-1">
            <Phone className="h-4 w-4" />
            (11) 99999-9999
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
