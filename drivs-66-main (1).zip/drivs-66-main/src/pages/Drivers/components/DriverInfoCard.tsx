
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText } from "lucide-react";

interface DriverInfoCardProps {
  driverData: any;
  userFullName?: string;
  userEmail?: string;
}

export const DriverInfoCard = ({ driverData, userFullName, userEmail }: DriverInfoCardProps) => {
  if (!driverData) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Informações do Cadastro
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="font-medium">Nome:</span> {driverData.full_name || userFullName}
          </div>
          <div>
            <span className="font-medium">Email:</span> {driverData.email || userEmail}
          </div>
          <div>
            <span className="font-medium">CPF:</span> {driverData.cpf}
          </div>
          <div>
            <span className="font-medium">Telefone:</span> {driverData.phone}
          </div>
          <div>
            <span className="font-medium">Status Geral:</span> 
            <span className={`ml-2 px-2 py-1 rounded text-xs ${
              driverData.status === 'approved' ? 'bg-green-100 text-green-800' :
              driverData.status === 'under_review' || driverData.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
              driverData.status === 'rejected' ? 'bg-red-100 text-red-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {driverData.status === 'approved' ? 'Aprovado' :
               driverData.status === 'under_review' ? 'Em Análise' :
               driverData.status === 'pending' ? 'Pendente' :
               driverData.status === 'rejected' ? 'Rejeitado' :
               'Desconhecido'}
            </span>
          </div>
          <div>
            <span className="font-medium">Fonte:</span> {driverData.source === 'registrations' ? 'Registro Pendente' : 'Usuário Ativo'}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
