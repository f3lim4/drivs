
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Clock, CheckCircle, AlertTriangle, Upload, Eye } from "lucide-react";

interface Document {
  id: number;
  name: string;
  field: string;
  status: string;
  uploadDate?: string;
  observation: string;
}

interface DocumentsListProps {
  documentsList: Document[];
  driverData: any;
  onViewDocument: (field: string, name: string) => void;
}

export const DocumentsList = ({ documentsList, driverData, onViewDocument }: DocumentsListProps) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            <CheckCircle className="h-3 w-3 mr-1" />
            Aprovado
          </Badge>
        );
      case "under_review":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            <Clock className="h-3 w-3 mr-1" />
            Em Análise
          </Badge>
        );
      case "rejected":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            <AlertTriangle className="h-3 w-3 mr-1" />
            Rejeitado
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">
            <Upload className="h-3 w-3 mr-1" />
            Pendente
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Documentos Obrigatórios</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {documentsList.map((document) => (
            <div key={document.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-4">
                <FileText className="h-5 w-5 text-muted-foreground" />
                <div>
                  <h3 className="font-medium">{document.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {document.uploadDate ? 
                      `Enviado em ${new Date(document.uploadDate).toLocaleDateString('pt-BR')}` : 
                      "Não enviado"
                    }
                  </p>
                  {document.observation && (
                    <p className="text-sm mt-1 text-gray-600">
                      {document.observation}
                    </p>
                  )}
                  {driverData && driverData[document.field] && (
                    <p className="text-xs text-green-600 mt-1">
                      ✓ Documento enviado
                    </p>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {getStatusBadge(document.status)}
                
                <div className="flex gap-2">
                  {document.status === "rejected" || document.status === "pending" ? (
                    <Button size="sm" variant="outline">
                      <Upload className="h-4 w-4 mr-1" />
                      {document.status === "rejected" ? "Reenviar" : "Enviar"}
                    </Button>
                  ) : (
                    driverData && driverData[document.field] && (
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => onViewDocument(document.field, document.name)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Ver
                      </Button>
                    )
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
