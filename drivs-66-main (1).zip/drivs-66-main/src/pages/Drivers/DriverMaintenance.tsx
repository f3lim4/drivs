
import { useAuth } from "@/contexts/AuthContext";
import { UserRole, Driver } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Wrench,
  Calendar,
  MapPin,
  Clock,
  AlertTriangle,
  CheckCircle,
  Car,
  Building
} from "lucide-react";

interface ScheduledMaintenance {
  id: string;
  type: "preventive" | "corrective" | "revision";
  description: string;
  scheduledDate: string;
  scheduledTime: string;
  location: string;
  serviceName: string;
  requestedBy: string;
  status: "pending" | "confirmed" | "overdue";
  notes?: string;
}

const mockDriverMaintenances: ScheduledMaintenance[] = [
  {
    id: "dm1",
    type: "revision",
    description: "Revisão de 50.000km",
    scheduledDate: "2025-01-25",
    scheduledTime: "09:00",
    location: "Rua das Flores, 123 - Centro",
    serviceName: "Auto Center Express",
    requestedBy: "Auto Rental Plus",
    status: "pending",
    notes: "Revisar filtros, óleo e sistema de freios"
  },
  {
    id: "dm2",
    type: "preventive",
    description: "Troca de pastilhas de freio",
    scheduledDate: "2025-02-10",
    scheduledTime: "14:00",
    location: "Av. Principal, 456 - Vila Nova",
    serviceName: "Central de Freios",
    requestedBy: "Auto Rental Plus",
    status: "confirmed",
    notes: "Pastilhas dianteiras apresentando desgaste"
  },
  {
    id: "dm3",
    type: "corrective",
    description: "Reparo no ar condicionado",
    scheduledDate: "2025-01-20",
    scheduledTime: "08:30",
    location: "Rua do Comércio, 789 - Centro",
    serviceName: "Oficina Especializada",
    requestedBy: "Auto Rental Plus",
    status: "overdue",
    notes: "Ar condicionado não está resfriando adequadamente"
  }
];

const DriverMaintenance = () => {
  const { user } = useAuth();
  
  if (!user || user.role !== UserRole.DRIVER) {
    return (
      <div className="container py-6 px-4">
        <h1 className="text-2xl font-bold mb-6">Manutenções</h1>
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você não tem permissão para acessar esta página.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const driver = user as Driver;

  if (!driver.activeContract) {
    return (
      <div className="container py-6 px-4">
        <h1 className="text-2xl font-bold mb-6">Manutenções</h1>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
              Nenhum Contrato Ativo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você não possui um contrato ativo no momento. As manutenções são gerenciadas pela locadora do seu contrato.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case "confirmed":
        return <Badge className="bg-green-100 text-green-800">Confirmada</Badge>;
      case "overdue":
        return <Badge className="bg-red-100 text-red-800">Atrasada</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "preventive":
        return "bg-blue-100 text-blue-800";
      case "corrective":
        return "bg-orange-100 text-orange-800";
      case "revision":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getMaintenanceTypeName = (type: string) => {
    switch (type) {
      case "preventive":
        return "Preventiva";
      case "corrective":
        return "Corretiva";
      case "revision":
        return "Revisão";
      default:
        return type;
    }
  };

  return (
    <div className="container py-6 px-4 space-y-6">
      <div className="flex items-center gap-3">
        <Wrench className="h-8 w-8 text-orange-600" />
        <div>
          <h1 className="text-2xl font-bold">Manutenções Agendadas</h1>
          <p className="text-muted-foreground">Manutenções solicitadas pela sua locadora</p>
        </div>
      </div>

      {/* Informações do Veículo */}
      <Card className="border-l-4 border-l-blue-500">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <Car className="h-5 w-5 text-blue-600" />
            <div>
              <p className="font-semibold">{driver.activeContract.vehicleModel}</p>
              <p className="text-sm text-muted-foreground flex items-center gap-1">
                <Building className="h-4 w-4" />
                Locadora: {driver.activeContract.companyName}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Manutenções */}
      {mockDriverMaintenances.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <Wrench className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Nenhuma manutenção agendada</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {mockDriverMaintenances.map((maintenance) => (
            <Card 
              key={maintenance.id} 
              className={`border-l-4 ${
                maintenance.status === "overdue" 
                  ? "border-l-red-500" 
                  : maintenance.status === "confirmed"
                  ? "border-l-green-500"
                  : "border-l-yellow-500"
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Badge className={getTypeColor(maintenance.type)}>
                      {getMaintenanceTypeName(maintenance.type)}
                    </Badge>
                    {getStatusBadge(maintenance.status)}
                    {maintenance.status === "overdue" && (
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                    )}
                  </div>
                </div>
                <CardTitle className="text-lg">{maintenance.description}</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span className="text-sm">
                      {new Date(maintenance.scheduledDate).toLocaleDateString('pt-BR')}
                    </span>
                    <Clock className="h-4 w-4 text-gray-500 ml-2" />
                    <span className="text-sm">{maintenance.scheduledTime}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4 text-gray-500" />
                    <span className="text-sm">{maintenance.serviceName}</span>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <span className="text-sm">{maintenance.location}</span>
                </div>
                
                {maintenance.notes && (
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      <strong>Observações:</strong> {maintenance.notes}
                    </p>
                  </div>
                )}
                
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">
                    Solicitado por: {maintenance.requestedBy}
                  </p>
                </div>

                {maintenance.status === "overdue" && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm text-red-700 font-medium">
                      ⚠️ Esta manutenção está atrasada. Entre em contato com a locadora.
                    </p>
                  </div>
                )}

                {maintenance.status === "pending" && (
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-sm text-yellow-700">
                      📅 Aguardando confirmação do agendamento.
                    </p>
                  </div>
                )}

                {maintenance.status === "confirmed" && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-700">
                      ✅ Manutenção confirmada. Compareça no local na data e horário agendados.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default DriverMaintenance;
