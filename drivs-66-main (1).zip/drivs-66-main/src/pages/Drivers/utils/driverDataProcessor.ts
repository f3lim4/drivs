
import { DriverStatus } from "@/types";

export const processDriversData = (driversData: any[]) => {
  return driversData.map((driver) => {
    console.log('🔍 [DRIVERS] Processando driver da tabela drivers:', {
      name: driver.full_name,
      company_id: driver.company_id,
      rental_companies: driver.rental_companies
    });
    
    return {
      ...driver,
      company_name: driver.rental_companies?.company_name || 'Sem Locadora',
      email: driver.email || '',
      status: driver.status as DriverStatus, // Garantir que seja do tipo DriverStatus
      source: 'drivers'
    };
  });
};

export const processRegistrationsData = (registrationsData: any[], existingDrivers: any[]) => {
  const existingDriverEmails = new Set(existingDrivers.map(d => d.email?.toLowerCase()));
  const existingDriverCpfs = new Set(existingDrivers.map(d => d.cpf));

  return registrationsData
    .filter(reg => {
      const emailExists = reg.email && existingDriverEmails.has(reg.email.toLowerCase());
      const cpfExists = reg.cpf && existingDriverCpfs.has(reg.cpf);
      return !emailExists && !cpfExists;
    })
    .map((reg) => {
      console.log('🔍 [REGISTRATIONS] Processando registro da tabela driver_registrations:', {
        name: reg.full_name,
        referral_company_id: reg.referral_company_id,
        status: reg.status,
        rental_companies: reg.rental_companies
      });

      return {
        id: reg.id,
        full_name: reg.full_name,
        cpf: reg.cpf,
        rg: '',
        phone: reg.phone,
        address: reg.address,
        city: reg.city,
        state: reg.state,
        cnh: reg.cnh || '',
        cnh_expires: reg.cnh_expires || null,
        status: reg.status as DriverStatus, // Garantir que seja do tipo DriverStatus
        available: false,
        rating: 0,
        violations: 0,
        profile_photo: null,
        app_screenshot: null,
        address_proof: null,
        rejection_reason: null,
        rejection_date: null,
        created_at: reg.created_at,
        updated_at: reg.updated_at,
        company_id: reg.referral_company_id,
        date_of_birth: reg.date_of_birth,
        email: reg.email || '',
        rental_companies: reg.rental_companies,
        company_name: reg.rental_companies?.company_name || 'Sem Locadora',
        source: 'registrations'
      };
    });
};

export const applyUserFilters = (drivers: any[], userRole: string, userId: string) => {
  if (userRole === 'rental_company') {
    const filtered = drivers.filter(driver => driver.company_id === userId);
    
    console.log(`🏢 [DRIVERS PAGE] Locadora ${userId}: Mostrando motoristas da locadora: ${filtered.length}`);
    console.log('📋 [DRIVERS PAGE] Motoristas filtrados:', filtered.map(d => ({
      name: d.full_name,
      email: d.email,
      status: d.status,
      source: d.source,
      company_id: d.company_id,
      company_name: d.company_name
    })));
    
    return filtered;
  }

  if (userRole === 'admin') {
    console.log(`👑 [DRIVERS PAGE] Admin: Mostrando todos os motoristas: ${drivers.length}`);
    console.log('📋 [DRIVERS PAGE] Todos os motoristas com empresas:', drivers.map(d => ({
      name: d.full_name,
      company_name: d.company_name,
      company_id: d.company_id,
      source: d.source
    })));
  }

  return drivers;
};
