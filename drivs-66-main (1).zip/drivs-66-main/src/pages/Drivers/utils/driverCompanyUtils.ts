
import { DriverStatus, UserRole } from "@/types";

// Mock de motoristas específicos para cada locadora
const companyDriversData = {
  "company-1": [
    {
      id: '1',
      fullName: 'João Silva Santos',
      email: 'joao.silva@email.com',
      role: UserRole.DRIVER,
      cpf: '123.456.789-00',
      rg: '12.345.678-9',
      phone: '(11) 99999-9999',
      address: 'Rua das Flores, 123',
      city: 'São Paulo',
      state: 'SP',
      cnh: '12345678901',
      cnh_expires: '2025-12-31',
      status: DriverStatus.APPROVED,
      available: true,
      rating: 4.8,
      violations: 0,
      created_at: '2024-01-15',
      updated_at: '2024-01-15'
    },
    {
      id: '2',
      fullName: 'Maria Oliveira Costa',
      email: 'maria.oliveira@email.com',
      role: UserRole.DRIVER,
      cpf: '987.654.321-00',
      rg: '98.765.432-1',
      phone: '(11) 88888-8888',
      address: 'Av. Paulista, 456',
      city: 'São Paulo',
      state: 'SP',
      cnh: '10987654321',
      cnh_expires: '2025-06-30',
      status: DriverStatus.APPROVED,
      available: true,
      rating: 4.9,
      violations: 0,
      created_at: '2024-02-01',
      updated_at: '2024-02-01'
    },
    {
      id: '3',
      fullName: 'Carlos Roberto Lima',
      email: 'carlos.lima@email.com',
      role: UserRole.DRIVER,
      cpf: '456.789.123-00',
      rg: '45.678.912-3',
      phone: '(11) 77777-7777',
      address: 'Rua Augusta, 789',
      city: 'São Paulo',
      state: 'SP',
      cnh: '98765432101',
      cnh_expires: '2025-09-15',
      status: DriverStatus.APPROVED,
      available: true,
      rating: 4.7,
      violations: 0,
      created_at: '2024-03-10',
      updated_at: '2024-03-10'
    }
  ]
};

export const getDriversByCompany = (companyId: string) => {
  console.log('Buscando motoristas para a locadora:', companyId);
  
  if (companyId === "company-1") {
    const drivers = companyDriversData["company-1"] || [];
    console.log('Motoristas encontrados para company-1:', drivers);
    return drivers;
  }
  
  // Para outras empresas, retornar array vazio por enquanto
  return [];
};

const getAllDrivers = () => {
  // Retorna todos os motoristas de todas as empresas
  return Object.values(companyDriversData).flat();
};
