
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface IntegrityCheckResult {
  driverId: string;
  existsInDrivers: boolean;
  existsInRegistrations: boolean;
  relatedRecords: {
    contracts: number;
    payments: number;
    violations: number;
    inspections: number;
    maintenances: number;
  };
  issues: string[];
}

export const useDriverIntegrityCheck = () => {
  const [checking, setChecking] = useState(false);
  const { user } = useAuth();

  const checkDriverIntegrity = async (driverId: string): Promise<IntegrityCheckResult> => {
    console.log(`🔍 [INTEGRITY CHECK] Verificando integridade do motorista: ${driverId}`);
    
    if (checking) {
      console.log('⚠️ [INTEGRITY CHECK] Verificação já em andamento, aguardando...');
      return {
        driverId,
        existsInDrivers: false,
        existsInRegistrations: false,
        relatedRecords: {
          contracts: 0,
          payments: 0,
          violations: 0,
          inspections: 0,
          maintenances: 0
        },
        issues: ['Verificação em andamento']
      };
    }

    // Verificar se o usuário está autenticado
    if (!user?.id) {
      console.log('❌ [INTEGRITY CHECK] Usuário não autenticado');
      return {
        driverId,
        existsInDrivers: false,
        existsInRegistrations: false,
        relatedRecords: {
          contracts: 0,
          payments: 0,
          violations: 0,
          inspections: 0,
          maintenances: 0
        },
        issues: ['Usuário não autenticado']
      };
    }

    setChecking(true);
    
    try {
      console.log(`🔍 [INTEGRITY CHECK] Usuário autenticado: ${user.email}, Role: ${user.role}`);

      // Verificar se a sessão está ativa de forma mais robusta
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session?.access_token) {
        console.error('❌ [INTEGRITY CHECK] Erro de sessão ou token ausente:', sessionError);
        return {
          driverId,
          existsInDrivers: false,
          existsInRegistrations: false,
          relatedRecords: {
            contracts: 0,
            payments: 0,
            violations: 0,
            inspections: 0,
            maintenances: 0
          },
          issues: ['Sessão expirada - faça login novamente']
        };
      }

      console.log(`✅ [INTEGRITY CHECK] Sessão válida para usuário: ${session.user.email}`);

      // Verificar integridade de forma simplificada - apenas contagem básica
      let existsInDrivers = false;
      let existsInRegistrations = false;
      const relatedRecords = {
        contracts: 0,
        payments: 0,
        violations: 0,
        inspections: 0,
        maintenances: 0
      };

      try {
        // Verificar existência nas tabelas principais
        const { data: driverData } = await supabase
          .from('drivers')
          .select('id')
          .eq('id', driverId)
          .maybeSingle();
        
        existsInDrivers = !!driverData;

        const { data: registrationData } = await supabase
          .from('driver_registrations')
          .select('id')
          .eq('id', driverId)
          .maybeSingle();
        
        existsInRegistrations = !!registrationData;

        // Contar registros relacionados de forma mais simples
        if (existsInDrivers || existsInRegistrations) {
          const [contractsRes, paymentsRes, violationsRes, inspectionsRes, maintenancesRes] = await Promise.allSettled([
            supabase.from('contracts').select('id', { count: 'exact', head: true }).eq('driver_id', driverId),
            supabase.from('payments').select('id', { count: 'exact', head: true }).eq('driver_id', driverId),
            supabase.from('violations').select('id', { count: 'exact', head: true }).eq('driver_id', driverId),
            supabase.from('inspections').select('id', { count: 'exact', head: true }).eq('driver_id', driverId),
            supabase.from('maintenances').select('id', { count: 'exact', head: true }).eq('driver_id', driverId)
          ]);

          relatedRecords.contracts = contractsRes.status === 'fulfilled' && !contractsRes.value.error ? 
                                   (contractsRes.value.count || 0) : 0;
          relatedRecords.payments = paymentsRes.status === 'fulfilled' && !paymentsRes.value.error ? 
                                  (paymentsRes.value.count || 0) : 0;
          relatedRecords.violations = violationsRes.status === 'fulfilled' && !violationsRes.value.error ? 
                                    (violationsRes.value.count || 0) : 0;
          relatedRecords.inspections = inspectionsRes.status === 'fulfilled' && !inspectionsRes.value.error ? 
                                     (inspectionsRes.value.count || 0) : 0;
          relatedRecords.maintenances = maintenancesRes.status === 'fulfilled' && !maintenancesRes.value.error ? 
                                      (maintenancesRes.value.count || 0) : 0;
        }

      } catch (error: any) {
        console.warn('⚠️ [INTEGRITY CHECK] Erro ao verificar registros relacionados:', error);
        // Continue com valores padrão
      }

      // Identificar problemas
      const issues: string[] = [];
      
      if (!existsInDrivers && !existsInRegistrations) {
        issues.push('Motorista não existe em nenhuma tabela principal');
      }
      
      if (existsInDrivers && existsInRegistrations) {
        issues.push('Motorista existe em ambas as tabelas (possível duplicação)');
      }
      
      const totalRelated = Object.values(relatedRecords).reduce((sum, count) => sum + count, 0);
      if (totalRelated > 0 && !existsInDrivers && !existsInRegistrations) {
        issues.push(`Registros órfãos encontrados (${totalRelated} registros relacionados sem motorista)`);
      }

      const result: IntegrityCheckResult = {
        driverId,
        existsInDrivers,
        existsInRegistrations,
        relatedRecords,
        issues
      };

      console.log('📊 [INTEGRITY CHECK] Resultado:', result);
      return result;
      
    } catch (error: any) {
      console.error('❌ [INTEGRITY CHECK] Erro na verificação:', error);
      
      // Verificar se é erro de autenticação
      if (error?.message?.includes('JWT') || 
          error?.message?.includes('session') || 
          error?.message?.includes('Invalid') ||
          error?.code === 'PGRST301') {
        return {
          driverId,
          existsInDrivers: false,
          existsInRegistrations: false,
          relatedRecords: {
            contracts: 0,
            payments: 0,
            violations: 0,
            inspections: 0,
            maintenances: 0
          },
          issues: ['Erro de autenticação - faça login novamente']
        };
      }
      
      // Retornar um resultado padrão em caso de erro
      return {
        driverId,
        existsInDrivers: false,
        existsInRegistrations: false,
        relatedRecords: {
          contracts: 0,
          payments: 0,
          violations: 0,
          inspections: 0,
          maintenances: 0
        },
        issues: ['Erro na verificação de integridade']
      };
    } finally {
      setChecking(false);
    }
  };

  const performBulkIntegrityCheck = async (driverIds: string[]) => {
    if (checking) {
      console.log('⚠️ [BULK INTEGRITY CHECK] Verificação já em andamento');
      return {
        total: 0,
        withIssues: 0,
        results: [],
        summary: []
      };
    }

    // Verificar autenticação antes de iniciar
    if (!user?.id) {
      console.log('❌ [BULK INTEGRITY CHECK] Usuário não autenticado');
      return {
        total: 0,
        withIssues: 0,
        results: [],
        summary: []
      };
    }

    setChecking(true);
    
    try {
      console.log(`🔍 [BULK INTEGRITY CHECK] Verificando ${driverIds.length} motoristas`);
      
      const results: IntegrityCheckResult[] = [];
      
      // Verificar em lotes menores para evitar sobrecarga
      for (let i = 0; i < driverIds.length; i += 5) {
        const batch = driverIds.slice(i, i + 5);
        const batchResults = await Promise.all(
          batch.map(async (id) => {
            try {
              return await checkDriverIntegrity(id);
            } catch (error) {
              console.error(`Erro ao verificar motorista ${id}:`, error);
              return {
                driverId: id,
                existsInDrivers: false,
                existsInRegistrations: false,
                relatedRecords: {
                  contracts: 0,
                  payments: 0,
                  violations: 0,
                  inspections: 0,
                  maintenances: 0
                },
                issues: ['Erro na verificação']
              };
            }
          })
        );
        results.push(...batchResults);
        
        // Pausa entre lotes
        if (i + 5 < driverIds.length) {
          await new Promise(resolve => setTimeout(resolve, 200));
        }
      }
      
      const issuesFound = results.filter(r => r.issues.length > 0);
      
      console.log(`📈 [BULK INTEGRITY CHECK] Concluído: ${issuesFound.length}/${driverIds.length} com problemas`);
      
      return {
        total: driverIds.length,
        withIssues: issuesFound.length,
        results,
        summary: issuesFound
      };
      
    } finally {
      setChecking(false);
    }
  };

  return {
    checking,
    checkDriverIntegrity,
    performBulkIntegrityCheck
  };
};
