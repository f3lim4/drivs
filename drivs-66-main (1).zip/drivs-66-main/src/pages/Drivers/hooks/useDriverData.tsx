
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { useDriverDataFetcher } from "./useDriverDataFetcher";
import { useDriverOperations } from "./useDriverOperations";
import { useDriverIntegrityCheck } from "./useDriverIntegrityCheck";
import { processDriversData, processRegistrationsData, applyUserFilters } from "../utils/driverDataProcessor";

export const useDriverData = () => {
  const { user } = useAuth();
  const [drivers, setDrivers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const { fetchDriversFromTable, fetchDriverRegistrations } = useDriverDataFetcher();
  const { deleteDriver: deleteDriverOperation } = useDriverOperations();
  const { checkDriverIntegrity } = useDriverIntegrityCheck();

  const loadDrivers = async () => {
    try {
      setLoading(true);
      console.log('📋 [DRIVERS PAGE] Carregando motoristas do banco de dados...');
      console.log('👤 [DRIVERS PAGE] Usuário:', { id: user?.id, role: user?.role });
      console.log('🔍 [DEBUG] Iniciando loadDrivers()');

      // Aguardar um pouco para garantir que qualquer operação anterior foi concluída
      await new Promise(resolve => setTimeout(resolve, 300));

      console.log('🔍 [DEBUG] Chamando fetchDriversFromTable e fetchDriverRegistrations');
      
      // Buscar dados das duas tabelas
      const [driversData, registrationsData] = await Promise.all([
        fetchDriversFromTable(),
        fetchDriverRegistrations()
      ]);

      console.log('📊 [DRIVERS PAGE] Dados brutos obtidos:', {
        drivers: driversData.length,
        registrations: registrationsData.length
      });
      
      console.log('🔍 [DEBUG] Dados brutos detalhados:', {
        driversData: driversData,
        registrationsData: registrationsData
      });

      // Processar dados das duas tabelas
      let allDrivers = processDriversData(driversData);
      const registrationDrivers = processRegistrationsData(registrationsData, allDrivers);
      allDrivers = [...allDrivers, ...registrationDrivers];

      // Aplicar filtros baseados no papel do usuário
      const filteredDrivers = applyUserFilters(allDrivers, user?.role || '', user?.id || '');

      console.log("✅ [DRIVERS PAGE] Motoristas carregados:", filteredDrivers.length);
      setDrivers(filteredDrivers);

    } catch (error: any) {
      console.error('❌ [DRIVERS PAGE] Erro ao carregar motoristas:', error);
      toast.error('Erro ao carregar motoristas');
      setDrivers([]);
    } finally {
      setLoading(false);
    }
  };

  const deleteDriver = async (driverId: string) => {
    try {
      console.log('🗑️ [DRIVERS PAGE] Iniciando processo de exclusão para:', driverId);
      
      // Verificar integridade antes da exclusão
      const integrityCheck = await checkDriverIntegrity(driverId);
      console.log('🔍 [DRIVERS PAGE] Verificação de integridade:', integrityCheck);
      
      if (integrityCheck.issues.length > 0) {
        console.warn('⚠️ [DRIVERS PAGE] Problemas de integridade detectados:', integrityCheck.issues);
      }
      
      // Manter lista original para possível restauração
      const originalDrivers = [...drivers];
      
      try {
        // Executar a exclusão no banco ANTES de atualizar a UI
        const result = await deleteDriverOperation(driverId, originalDrivers);
        
        console.log('✅ [DRIVERS PAGE] Exclusão bem-sucedida:', result);
        
        // Só remover da UI após confirmação da exclusão
        setDrivers(currentDrivers => {
          const updatedDrivers = currentDrivers.filter(driver => driver.id !== driverId);
          console.log('📋 [DRIVERS PAGE] Lista atualizada após exclusão confirmada:', updatedDrivers.length);
          return updatedDrivers;
        });
        
        // Mostrar sucesso com detalhes
        if (result.summary) {
          const totalDeleted = Object.values(result.summary).reduce((acc: number, val: any) => acc + (Number(val) || 0), 0);
          toast.success(`Motorista excluído com sucesso! ${totalDeleted} registros removidos.`);
        } else {
          toast.success('Motorista excluído com sucesso');
        }
        
        // Recarregar dados para garantir consistência após um delay
        setTimeout(() => {
          console.log('🔄 [DRIVERS PAGE] Recarregando dados para confirmar exclusão...');
          loadDrivers();
        }, 2000);
        
        return true;
      } catch (error: any) {
        // Se houve erro, não alterar a lista
        console.error('❌ [DRIVERS PAGE] Erro na exclusão, mantendo lista original');
        throw error;
      }
      
    } catch (error: any) {
      console.error('❌ [DRIVERS PAGE] Erro ao excluir motorista:', error);
      
      // Mensagens de erro mais específicas
      let errorMessage = 'Erro ao excluir motorista';
      
      if (error.message.includes('permissão')) {
        errorMessage = 'Você não tem permissão para excluir este motorista';
      } else if (error.message.includes('não encontrado')) {
        errorMessage = 'Motorista não encontrado';
      } else if (error.message.includes('registros relacionados') || error.message.includes('constraint')) {
        errorMessage = 'Não é possível excluir: existem registros relacionados (contratos, pagamentos, etc.)';
      } else if (error.message.includes('conexão') || error.message.includes('network')) {
        errorMessage = 'Erro de conexão. Verifique sua internet e tente novamente.';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
      throw error;
    }
  };

  // Função para forçar recarga completa
  const forceReload = async () => {
    console.log('🔄 [DRIVERS PAGE] Forçando recarga completa dos dados...');
    await loadDrivers();
  };

  useEffect(() => {
    loadDrivers();
  }, [user?.role, user?.id]);

  // Escutar eventos de refresh
  useEffect(() => {
    const handleRefresh = () => {
      console.log('🔄 [DRIVERS PAGE] Recebido evento de refresh, recarregando...');
      loadDrivers();
    };

    window.addEventListener('refreshDriversData', handleRefresh);
    
    return () => {
      window.removeEventListener('refreshDriversData', handleRefresh);
    };
  }, []);

  return { 
    drivers, 
    loading, 
    refetchDrivers: loadDrivers,
    deleteDriver,
    forceReload
  };
};
