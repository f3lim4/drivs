
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useDriverDocuments = (userId?: string) => {
  const [driverData, setDriverData] = useState<any>(null);
  const [selectedDocument, setSelectedDocument] = useState<{
    name: string;
    data: string;
  } | null>(null);

  const { data: realDriverData, isLoading } = useQuery({
    queryKey: ['driver-documents', userId],
    queryFn: async () => {
      if (!userId) return null;
      
      console.log('Buscando dados do motorista:', userId);
      
      // Primeiro, tentar buscar na tabela drivers
      let { data: driverRecord, error: driverError } = await supabase
        .from('drivers')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (driverError) {
        console.error('Erro ao buscar na tabela drivers:', driverError);
      }

      // Se não encontrou na tabela drivers, buscar na tabela driver_registrations
      if (!driverRecord) {
        console.log('Não encontrado na tabela drivers, buscando em driver_registrations...');
        const { data: registrationRecord, error: regError } = await supabase
          .from('driver_registrations')
          .select('*')
          .eq('id', userId)
          .maybeSingle();

        if (regError) {
          console.error('Erro ao buscar na tabela driver_registrations:', regError);
          return null;
        }

        if (registrationRecord) {
          console.log('Dados encontrados em driver_registrations:', registrationRecord);
          return {
            ...registrationRecord,
            source: 'registrations'
          };
        }
      }

      if (driverRecord) {
        console.log('Dados encontrados na tabela drivers:', driverRecord);
        return {
          ...driverRecord,
          source: 'drivers'
        };
      }

      return null;
    },
    enabled: !!userId,
  });

  useEffect(() => {
    if (realDriverData) {
      setDriverData(realDriverData);
    }
  }, [realDriverData]);

  const getDocumentStatus = (documentField: string) => {
    if (!driverData) return 'pending';
    
    const hasDocument = driverData[documentField];
    if (!hasDocument) return 'pending';
    
    // Se o motorista está aprovado, documentos estão aprovados
    if (driverData.status === 'approved') return 'approved';
    // Se está em análise, documentos estão em análise
    if (driverData.status === 'under_review' || driverData.status === 'pending') return 'under_review';
    // Se foi rejeitado, documentos foram rejeitados
    if (driverData.status === 'rejected') return 'rejected';
    
    return 'under_review';
  };

  const documentsList = [
    {
      id: 1,
      name: "CNH (Carteira Nacional de Habilitação)",
      field: "cnh_document",
      status: getDocumentStatus("cnh_document"),
      uploadDate: driverData?.created_at,
      observation: driverData?.status === 'rejected' ? 
        (driverData?.rejection_reason || "Documento rejeitado - solicitar reenvio") : 
        getDocumentStatus("cnh_document") === 'approved' ? "Documento aprovado" :
        getDocumentStatus("cnh_document") === 'under_review' ? "Documento em análise pela equipe" :
        "Aguardando envio"
    },
    {
      id: 2,
      name: "Comprovante de Residência",
      field: "address_proof",
      status: getDocumentStatus("address_proof"),
      uploadDate: driverData?.created_at,
      observation: driverData?.status === 'rejected' ? 
        (driverData?.rejection_reason || "Documento rejeitado - solicitar reenvio com melhor qualidade") : 
        getDocumentStatus("address_proof") === 'approved' ? "Documento aprovado" :
        getDocumentStatus("address_proof") === 'under_review' ? "Documento em análise pela equipe" :
        "Aguardando envio"
    },
    {
      id: 3,
      name: "Selfie com Documento",
      field: "selfie_document",
      status: getDocumentStatus("selfie_document"),
      uploadDate: driverData?.created_at,
      observation: driverData?.status === 'rejected' ? 
        (driverData?.rejection_reason || "Documento rejeitado") : 
        getDocumentStatus("selfie_document") === 'approved' ? "Documento aprovado" :
        getDocumentStatus("selfie_document") === 'under_review' ? "Documento em análise pela equipe" :
        "Aguardando envio"
    },
    {
      id: 4,
      name: "Print do perfil do app 99 ou Uber",
      field: "app_profile_screenshot",
      status: getDocumentStatus("app_profile_screenshot"),
      uploadDate: driverData?.created_at,
      observation: driverData?.status === 'rejected' ? 
        (driverData?.rejection_reason || "Documento rejeitado") : 
        getDocumentStatus("app_profile_screenshot") === 'approved' ? "Documento aprovado" :
        getDocumentStatus("app_profile_screenshot") === 'under_review' ? "Documento em análise pela equipe" :
        "Aguardando envio"
    }
  ];

  const getStatusCount = () => {
    const approved = documentsList.filter(doc => doc.status === "approved").length;
    const total = documentsList.length;
    return { approved, total };
  };

  const handleViewDocument = (documentField: string, documentName: string) => {
    if (driverData && driverData[documentField]) {
      setSelectedDocument({
        name: documentName,
        data: driverData[documentField]
      });
    }
  };

  return {
    driverData,
    isLoading,
    documentsList,
    selectedDocument,
    setSelectedDocument,
    getStatusCount,
    handleViewDocument
  };
};
