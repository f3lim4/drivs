
import { supabase } from "@/integrations/supabase/client";
import { UserRole } from "@/types";

export const useDriverDataFetcher = () => {
  const fetchDriversFromTable = async () => {
    try {
      const { data: driversData, error: driversError } = await supabase
        .from('drivers')
        .select(`
          *,
          rental_companies!drivers_company_id_fkey (
            id,
            company_name
          )
        `)
        .order('created_at', { ascending: false });

      if (driversError) {
        console.error('❌ [DRIVERS PAGE] Erro ao carregar motoristas da tabela drivers:', driversError);
        throw driversError;
      }

      console.log(`📊 [DRIVERS PAGE] Motoristas encontrados na tabela drivers: ${driversData?.length || 0}`);
      return driversData || [];
    } catch (error) {
      console.error('❌ [DRIVERS PAGE] Erro crítico ao buscar drivers:', error);
      throw error;
    }
  };

  const fetchDriverRegistrations = async () => {
    try {
      console.log('📋 [FETCH REGISTRATIONS] Buscando registros da tabela driver_registrations...');
      console.log('🔍 [DEBUG] Iniciando consulta para driver_registrations');
      
      // Usar query direta em vez de foreign key reference que pode ter problemas com RLS
      const { data: registrationsData, error: registrationsError } = await supabase
        .from('driver_registrations')
        .select('*')
        .order('created_at', { ascending: false });

      console.log('🔍 [DEBUG] Resultado da consulta driver_registrations:', {
        data: registrationsData,
        error: registrationsError,
        length: registrationsData?.length || 0
      });

      if (registrationsError) {
        console.error('❌ [DRIVERS PAGE] Erro ao carregar motoristas da tabela driver_registrations:', registrationsError);
        throw registrationsError;
      }

      console.log(`📊 [DRIVERS PAGE] Registros encontrados na tabela driver_registrations: ${registrationsData?.length || 0}`);
      
      // Buscar informações das locadoras separadamente se necessário
      if (registrationsData && registrationsData.length > 0) {
        const companyIds = registrationsData
          .map(reg => reg.referral_company_id)
          .filter(id => id !== null);
        
        if (companyIds.length > 0) {
          const { data: companiesData } = await supabase
            .from('rental_companies')
            .select('id, company_name')
            .in('id', companyIds);
          
          // Mapear nomes das empresas
          const companyMap = new Map(companiesData?.map(c => [c.id, c.company_name]) || []);
          
          // Adicionar informações da empresa aos registros
          registrationsData.forEach((reg: any) => {
            if (reg.referral_company_id) {
              reg.rental_companies = {
                id: reg.referral_company_id,
                company_name: companyMap.get(reg.referral_company_id) || 'Empresa não encontrada'
              };
            }
          });
        }
      }
      
      if (registrationsData && registrationsData.length > 0) {
        console.log('📋 [REGISTRATIONS] Primeiros registros:', registrationsData.slice(0, 3));
      }

      return registrationsData || [];
    } catch (error) {
      console.error('❌ [DRIVERS PAGE] Erro crítico ao buscar driver_registrations:', error);
      throw error;
    }
  };

  return {
    fetchDriversFromTable,
    fetchDriverRegistrations
  };
};
