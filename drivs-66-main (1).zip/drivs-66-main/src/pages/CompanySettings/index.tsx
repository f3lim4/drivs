
import React, { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCompanySettings } from "@/hooks/useCompanySettings";
import { 
  Building, 
  Image as ImageIcon,
  Loader2
} from "lucide-react";
import { CompanyInfoForm } from "./components/CompanyInfoForm";
import { LogoUploadSection } from "./components/LogoUploadSection";
import { LogoGuidelines } from "./components/LogoGuidelines";

const CompanySettings = () => {
  const { user } = useAuth();
  const { companyData, loading, isSubmitting, updateCompanyData, uploadLogo } = useCompanySettings();
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>("");
  const [uploadError, setUploadError] = useState<string>("");

  // Estados para os campos do formulário
  const [formData, setFormData] = useState({
    company_name: "",
    cnpj: "",
    email: "",
    phone: "",
    whatsapp: "",
    emergency_phone: "",
    address: "",
    cep: "",
    city: "",
    state: "",
    description: "",
    website: "",
    operating_hours: ""
  });

  // Atualizar formData quando companyData for carregado
  React.useEffect(() => {
    if (companyData) {
      setFormData({
        company_name: companyData.company_name,
        cnpj: companyData.cnpj,
        email: companyData.email || "",
        phone: companyData.phone,
        whatsapp: companyData.whatsapp || "",
        emergency_phone: companyData.emergency_phone || "",
        address: companyData.address,
        cep: companyData.cep || "",
        city: companyData.city || "",
        state: companyData.state || "",
        description: companyData.description || "",
        website: companyData.website || "",
        operating_hours: companyData.operating_hours || ""
      });
    }
  }, [companyData]);

  if (!user || (user.role !== UserRole.RENTAL_COMPANY && user.role !== UserRole.MANAGER)) {
    return (
      <div className="page-content">
        <Card className="content-card content-card-red">
          <CardContent className="p-6">
            <p className="text-center text-muted-foreground">Acesso não autorizado</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="page-content">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Carregando dados da locadora...</p>
          </div>
        </div>
      </div>
    );
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError("");
    
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Validar arquivo
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/svg+xml'];
      if (!allowedTypes.includes(file.type)) {
        setUploadError('Formato não suportado. Use PNG, JPG ou SVG.');
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        setUploadError('Arquivo muito grande. Máximo 5MB.');
        return;
      }
      
      setLogoFile(file);
      
      // Criar preview da imagem
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveCompanyInfo = async () => {
    await updateCompanyData(formData);
  };

  const handleSaveLogo = async () => {
    if (!logoFile) {
      setUploadError('Selecione um arquivo primeiro');
      return;
    }
    
    setUploadError("");
    const result = await uploadLogo(logoFile);
    
    if (result) {
      setLogoFile(null);
      setLogoPreview("");
    }
  };

  return (
    <div className="page-content">
      <div className="space-y-6">
        <div className="page-header">
          <div>
            <h1 className="page-title">Configurações da Locadora</h1>
            <p className="page-subtitle">
              Gerencie as informações e configurações da sua locadora
            </p>
          </div>
        </div>

        <Tabs defaultValue="info" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="info" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              Informações da Empresa
            </TabsTrigger>
            <TabsTrigger value="branding" className="flex items-center gap-2">
              <ImageIcon className="h-4 w-4" />
              Logo e Identidade
            </TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="space-y-6">
            <CompanyInfoForm
              formData={formData}
              isSubmitting={isSubmitting}
              onInputChange={handleInputChange}
              onSave={handleSaveCompanyInfo}
            />
          </TabsContent>

          <TabsContent value="branding" className="space-y-6">
            <LogoUploadSection
              companyData={companyData}
              logoFile={logoFile}
              logoPreview={logoPreview}
              uploadError={uploadError}
              isSubmitting={isSubmitting}
              onLogoChange={handleLogoChange}
              onSaveLogo={handleSaveLogo}
            />

            <LogoGuidelines />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CompanySettings;
