
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const LogoGuidelines: React.FC = () => {
  return (
    <Card className="content-card content-card-blue">
      <CardHeader>
        <CardTitle>Diretrizes para Logo</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 text-sm">
          <div>
            <h4 className="font-medium">Tamanho Recomendado:</h4>
            <p>300x100 pixels ou proporção 3:1</p>
          </div>
          <div>
            <h4 className="font-medium">Formatos Aceitos:</h4>
            <p>PNG (recomendado), JPG, SVG</p>
          </div>
          <div>
            <h4 className="font-medium">Qualidade:</h4>
            <p>Use imagens de alta qualidade com fundo transparente (PNG)</p>
          </div>
          <div>
            <h4 className="font-medium">Onde Aparece:</h4>
            <p>A logo será exibida no painel, relatórios e documentos da locadora</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
