
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Upload,
  Image as ImageIcon,
  Loader2,
  AlertCircle
} from "lucide-react";
import { CompanySettingsData } from "@/hooks/useCompanySettings";

interface LogoUploadSectionProps {
  companyData: CompanySettingsData | null;
  logoFile: File | null;
  logoPreview: string;
  uploadError: string;
  isSubmitting: boolean;
  onLogoChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSaveLogo: () => void;
}

export const LogoUploadSection: React.FC<LogoUploadSectionProps> = ({
  companyData,
  logoFile,
  logoPreview,
  uploadError,
  isSubmitting,
  onLogoChange,
  onSaveLogo
}) => {
  return (
    <Card className="content-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ImageIcon className="h-5 w-5" />
          Logo da Empresa
        </CardTitle>
        <CardDescription>
          Faça upload da logo da sua locadora
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Logo atual */}
        {companyData?.logo_url && (
          <div className="space-y-2">
            <Label>Logo Atual</Label>
            <div className="border rounded-lg p-4 bg-gray-50">
              <img
                src={companyData.logo_url}
                alt="Logo atual da empresa"
                className="max-h-24 object-contain"
                onError={(e) => {
                  console.error('Error loading logo:', e);
                  e.currentTarget.style.display = 'none';
                }}
              />
            </div>
          </div>
        )}

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="logo">Selecionar Nova Logo</Label>
            <Input
              id="logo"
              type="file"
              accept="image/*"
              onChange={onLogoChange}
            />
            <p className="text-sm text-muted-foreground">
              Formatos aceitos: PNG, JPG, SVG. Tamanho máximo: 5MB
            </p>
          </div>

          {uploadError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{uploadError}</AlertDescription>
            </Alert>
          )}

          {logoPreview && (
            <div className="space-y-2">
              <Label>Preview da Nova Logo</Label>
              <div className="border rounded-lg p-4 bg-gray-50">
                <img
                  src={logoPreview}
                  alt="Preview da nova logo"
                  className="max-h-24 object-contain"
                />
              </div>
            </div>
          )}

          <Button onClick={onSaveLogo} disabled={isSubmitting || !logoFile}>
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Fazendo Upload...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Salvar Logo
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
