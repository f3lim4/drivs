
import { DriverStatus } from "@/types";

export interface BlacklistRecord {
  id: string;
  driverId: string;
  driverName: string;
  driverCpf: string;
  companyId: string;
  reason: string;
  description: string;
  dateBlacklisted: Date;
  status: "active" | "resolved" | "disputed";
  amount?: number;
  contractId?: string;
}

export interface DeactivatedDriver {
  id: string;
  fullName: string;
  cpf: string;
  phone: string;
  email: string;
  status: DriverStatus;
  deactivationReason?: string;
}
