
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Eye } from "lucide-react";
import { BlacklistRecord } from "../types";
import { UserRole } from "@/types";

interface BlacklistTableProps {
  records: BlacklistRecord[];
  userRole?: UserRole;
  userId?: string;
}

export const BlacklistTable = ({ records, userRole, userId }: BlacklistTableProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [reasonFilter, setReasonFilter] = useState<string>("all");

  // Filtra os registros baseado nos critérios
  const filteredRecords = records.filter(record => {
    // Se o usuário for uma empresa, mostrar apenas seus registros
    if (userRole === UserRole.RENTAL_COMPANY && record.companyId !== userId) {
      return false;
    }
    
    const matchesSearch = 
      record.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.driverCpf.includes(searchTerm) ||
      record.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || record.status === statusFilter;
    const matchesReason = reasonFilter === "all" || record.reason === reasonFilter;
    
    return matchesSearch && matchesStatus && matchesReason;
  });

  const getStatusBadge = (status: BlacklistRecord["status"]) => {
    switch (status) {
      case "active":
        return <Badge variant="destructive">Ativo</Badge>;
      case "resolved":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Resolvido</Badge>;
      case "disputed":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Em Disputa</Badge>;
    }
  };

  const getReasonBadge = (reason: string) => {
    const reasons: { [key: string]: string } = {
      "damage": "Danos",
      "payment": "Inadimplência",
      "contract_violation": "Violação Contratual",
      "theft": "Roubo/Furto",
      "other": "Outros"
    };
    return <Badge variant="outline">{reasons[reason] || reason}</Badge>;
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("pt-BR");
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(amount);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Histórico de Negativações</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Filtros */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="flex-1 min-w-[200px]">
            <Input
              placeholder="Buscar por motorista, CPF ou descrição"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="w-full md:w-auto">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="active">Ativo</SelectItem>
                <SelectItem value="resolved">Resolvido</SelectItem>
                <SelectItem value="disputed">Em Disputa</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="w-full md:w-auto">
            <Select value={reasonFilter} onValueChange={setReasonFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtrar por motivo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os motivos</SelectItem>
                <SelectItem value="damage">Danos</SelectItem>
                <SelectItem value="payment">Inadimplência</SelectItem>
                <SelectItem value="contract_violation">Violação Contratual</SelectItem>
                <SelectItem value="theft">Roubo/Furto</SelectItem>
                <SelectItem value="other">Outros</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Tabela */}
        <div className="border rounded-md overflow-hidden">
          <Table>
            <TableCaption>Lista de motoristas negativados</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Motorista</TableHead>
                <TableHead>CPF</TableHead>
                <TableHead>Motivo</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRecords.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4 text-muted-foreground">
                    Nenhuma negativação encontrada
                  </TableCell>
                </TableRow>
              ) : (
                filteredRecords.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell>{formatDate(record.dateBlacklisted)}</TableCell>
                    <TableCell className="font-medium">{record.driverName}</TableCell>
                    <TableCell>{record.driverCpf}</TableCell>
                    <TableCell>{getReasonBadge(record.reason)}</TableCell>
                    <TableCell>
                      {record.amount ? formatCurrency(record.amount) : "-"}
                    </TableCell>
                    <TableCell>{getStatusBadge(record.status)}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4 mr-1" />
                        Detalhes
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
