
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { UserX, Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { DeactivatedDriver } from "../types";
import { mockDeactivatedDrivers } from "../data/mockData";

interface BlacklistDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export const BlacklistDialog = ({ isOpen, onOpenChange }: BlacklistDialogProps) => {
  const [selectedDriver, setSelectedDriver] = useState<DeactivatedDriver | null>(null);
  const [openDriverCombobox, setOpenDriverCombobox] = useState(false);
  const [newBlacklistData, setNewBlacklistData] = useState({
    reason: "",
    description: "",
    amount: "",
    contractId: ""
  });

  const handleSelectDeactivatedDriver = (driver: DeactivatedDriver) => {
    setSelectedDriver(driver);
    setOpenDriverCombobox(false);
    setNewBlacklistData({
      reason: "",
      description: "",
      amount: "",
      contractId: ""
    });
  };

  const handleClearSelection = () => {
    setSelectedDriver(null);
    setNewBlacklistData({
      reason: "",
      description: "",
      amount: "",
      contractId: ""
    });
  };

  const handleSubmitBlacklist = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDriver || !newBlacklistData.reason || !newBlacklistData.description) {
      toast.error("Selecione um motorista e preencha todos os campos obrigatórios");
      return;
    }

    console.log("Nova negativação:", {
      driverName: selectedDriver.fullName,
      driverCpf: selectedDriver.cpf,
      ...newBlacklistData
    });
    toast.success("Motorista negativado com sucesso!");
    onOpenChange(false);
    handleClearSelection();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <UserX className="h-4 w-4" />
          Nova Negativação
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Negativar Motorista</DialogTitle>
          <DialogDescription>
            Selecione um motorista desativado para negativar
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmitBlacklist} className="space-y-4">
          {/* Combobox para seleção de motorista */}
          <div className="space-y-2">
            <Label>Selecionar Motorista Desativado</Label>
            <Popover open={openDriverCombobox} onOpenChange={setOpenDriverCombobox}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={openDriverCombobox}
                  className="w-full justify-between"
                >
                  {selectedDriver
                    ? `${selectedDriver.fullName} - ${selectedDriver.cpf}`
                    : "Selecione um motorista..."}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0">
                <Command>
                  <CommandInput placeholder="Buscar motorista..." />
                  <CommandList>
                    <CommandEmpty>Nenhum motorista encontrado.</CommandEmpty>
                    <CommandGroup>
                      {mockDeactivatedDrivers.map((driver) => (
                        <CommandItem
                          key={driver.id}
                          value={`${driver.fullName} ${driver.cpf} ${driver.email}`}
                          onSelect={() => handleSelectDeactivatedDriver(driver)}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              selectedDriver?.id === driver.id ? "opacity-100" : "opacity-0"
                            )}
                          />
                          <div className="flex flex-col">
                            <span className="font-medium">{driver.fullName}</span>
                            <span className="text-sm text-muted-foreground">
                              {driver.cpf} - {driver.email}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {driver.deactivationReason}
                            </span>
                          </div>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {/* Motorista selecionado */}
          {selectedDriver && (
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-medium text-blue-900">Motorista Selecionado</h4>
                  <p className="text-sm text-blue-700">{selectedDriver.fullName}</p>
                  <p className="text-sm text-blue-700">CPF: {selectedDriver.cpf}</p>
                  <p className="text-sm text-blue-700">Email: {selectedDriver.email}</p>
                  <p className="text-sm text-blue-700">Motivo da desativação: {selectedDriver.deactivationReason}</p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleClearSelection}
                >
                  Remover
                </Button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="reason">Motivo</Label>
            <Select
              value={newBlacklistData.reason}
              onValueChange={(value) => setNewBlacklistData(prev => ({ ...prev, reason: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o motivo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="damage">Danos ao Veículo</SelectItem>
                <SelectItem value="payment">Inadimplência</SelectItem>
                <SelectItem value="contract_violation">Violação Contratual</SelectItem>
                <SelectItem value="theft">Roubo/Furto</SelectItem>
                <SelectItem value="other">Outros</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Descrição Detalhada</Label>
            <Textarea
              id="description"
              value={newBlacklistData.description}
              onChange={(e) => setNewBlacklistData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Descreva detalhadamente o motivo da negativação..."
              rows={3}
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Valor (opcional)</Label>
              <Input
                id="amount"
                type="number"
                value={newBlacklistData.amount}
                onChange={(e) => setNewBlacklistData(prev => ({ ...prev, amount: e.target.value }))}
                placeholder="0,00"
                step="0.01"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="contractId">ID do Contrato (opcional)</Label>
              <Input
                id="contractId"
                value={newBlacklistData.contractId}
                onChange={(e) => setNewBlacklistData(prev => ({ ...prev, contractId: e.target.value }))}
                placeholder="Ex: CTR-001"
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={!selectedDriver}>
              Confirmar Negativação
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
