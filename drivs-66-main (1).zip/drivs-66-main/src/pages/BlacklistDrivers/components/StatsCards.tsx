
import { Card, CardContent } from "@/components/ui/card";

interface StatsCardsProps {
  stats: {
    total: number;
    active: number;
    resolved: number;
    disputed: number;
  };
}

export const StatsCards = ({ stats }: StatsCardsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Total</p>
            <h3 className="text-3xl font-bold">{stats.total}</h3>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Ativos</p>
            <h3 className="text-3xl font-bold text-red-600">{stats.active}</h3>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Resolvidos</p>
            <h3 className="text-3xl font-bold text-green-600">{stats.resolved}</h3>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-sm font-medium text-muted-foreground">Em Disputa</p>
            <h3 className="text-3xl font-bold text-yellow-600">{stats.disputed}</h3>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
