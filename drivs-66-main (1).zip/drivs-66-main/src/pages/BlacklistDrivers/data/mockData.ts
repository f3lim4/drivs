
import { BlacklistRecord, DeactivatedDriver } from "../types";
import { DriverStatus } from "@/types";

export const mockBlacklistRecords: BlacklistRecord[] = [];

export const mockDeactivatedDrivers: DeactivatedDriver[] = [];
