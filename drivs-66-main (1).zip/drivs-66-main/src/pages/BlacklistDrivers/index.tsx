
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserRole } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatsCards } from "./components/StatsCards";
import { BlacklistDialog } from "./components/BlacklistDialog";
import { BlacklistTable } from "./components/BlacklistTable";
import { mockBlacklistRecords } from "./data/mockData";
import { calculateStats } from "./utils/statsCalculator";

const BlacklistDriversPage = () => {
  const { user } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Acesso apenas para empresas e administradores
  if (user?.role === UserRole.DRIVER) {
    return (
      <div className="container py-6">
        <h1 className="text-2xl font-bold mb-6">Lista Negra</h1>
        <Card>
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Você não tem permissão para acessar esta página. Apenas empresas de aluguel e administradores podem gerenciar a lista negra.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const stats = calculateStats(mockBlacklistRecords, user?.role, user?.id);

  return (
    <div className="container py-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Lista Negra</h1>
        <BlacklistDialog isOpen={isDialogOpen} onOpenChange={setIsDialogOpen} />
      </div>

      <StatsCards stats={stats} />
      
      <BlacklistTable 
        records={mockBlacklistRecords} 
        userRole={user?.role} 
        userId={user?.id} 
      />
    </div>
  );
};

export default BlacklistDriversPage;
