
import { BlacklistRecord } from "../types";
import { UserRole } from "@/types";

export const calculateStats = (
  records: BlacklistRecord[], 
  userRole?: UserRole, 
  userId?: string
) => {
  let filteredRecords = records;
  
  if (userRole === UserRole.RENTAL_COMPANY) {
    filteredRecords = records.filter(r => r.companyId === userId);
  }
  
  const total = filteredRecords.length;
  const active = filteredRecords.filter(r => r.status === "active").length;
  const resolved = filteredRecords.filter(r => r.status === "resolved").length;
  const disputed = filteredRecords.filter(r => r.status === "disputed").length;
  
  return { total, active, resolved, disputed };
};
