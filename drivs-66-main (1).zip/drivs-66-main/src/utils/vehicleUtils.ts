
const maskPlate = (plate: string): string => {
  if (!plate || plate.length < 8) return plate;
  
  // Para placas no formato ABC-1234 ou ABC1234
  const cleanPlate = plate.replace(/[^A-Z0-9]/g, '');
  
  if (cleanPlate.length >= 7) {
    // Mostra primeira letra e 2 últimos números
    const firstLetter = cleanPlate[0];
    const lastTwoNumbers = cleanPlate.slice(-2);
    const masked = `${firstLetter}**-**${lastTwoNumbers}`;
    return masked;
  }
  
  return plate;
};

export const generateVehicleImages = (baseImage: string): string[] => {
  // Gera 5 imagens variadas para cada veículo
  const imageVariations = [
    baseImage,
    "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=500&h=400&fit=crop",
    "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=500&h=400&fit=crop",
    "https://images.unsplash.com/photo-1494905998402-395d579af36f?w=500&h=400&fit=crop",
    "https://images.unsplash.com/photo-1590362891991-f776e747a588?w=500&h=400&fit=crop"
  ];
  
  return imageVariations;
};
