
export const validateCPF = (cpf: string): boolean => {
  console.log('🔍 [CPF VALIDATION] Validating CPF:', cpf);
  
  // Remove caracteres não numéricos
  const cleanCPF = cpf.replace(/\D/g, '');
  
  // Verifica se tem 11 dígitos
  if (cleanCPF.length !== 11) {
    console.log('❌ [CPF VALIDATION] Invalid length:', cleanCPF.length);
    return false;
  }
  
  // Verifica se todos os dígitos são iguais
  if (/^(\d)\1{10}$/.test(cleanCPF)) {
    console.log('❌ [CPF VALIDATION] All digits are the same');
    return false;
  }
  
  // Validação do primeiro dígito verificador
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cleanCPF[i]) * (10 - i);
  }
  let remainder = sum % 11;
  let digit1 = remainder < 2 ? 0 : 11 - remainder;
  
  if (parseInt(cleanCPF[9]) !== digit1) {
    console.log('❌ [CPF VALIDATION] First check digit invalid');
    return false;
  }
  
  // Validação do segundo dígito verificador
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cleanCPF[i]) * (11 - i);
  }
  remainder = sum % 11;
  let digit2 = remainder < 2 ? 0 : 11 - remainder;
  
  const isValid = parseInt(cleanCPF[10]) === digit2;
  console.log('✅ [CPF VALIDATION] Result:', isValid);
  return isValid;
};

export const validateCNH = (cnh: string): boolean => {
  console.log('🔍 [CNH VALIDATION] Validating CNH:', cnh);
  
  // Remove caracteres não numéricos
  const cleanCNH = cnh.replace(/\D/g, '');
  
  // Verifica se tem 11 dígitos
  if (cleanCNH.length !== 11) {
    console.log('❌ [CNH VALIDATION] Invalid length:', cleanCNH.length);
    return false;
  }
  
  // Verifica se todos os dígitos são iguais
  if (/^(\d)\1{10}$/.test(cleanCNH)) {
    console.log('❌ [CNH VALIDATION] All digits are the same');
    return false;
  }
  
  // Algoritmo de validação da CNH
  let sum = 0;
  let seq = cleanCNH.substring(0, 9);
  
  for (let i = 0; i < 9; i++) {
    sum += parseInt(seq[i]) * (9 - i);
  }
  
  let dv1 = sum % 11;
  if (dv1 >= 10) dv1 = 0;
  
  // Segundo dígito verificador
  sum = 0;
  seq = cleanCNH.substring(0, 9) + dv1;
  
  for (let i = 0; i < 10; i++) {
    sum += parseInt(seq[i]) * (1 + (i % 8));
  }
  
  let dv2 = sum % 11;
  if (dv2 >= 10) dv2 = 0;
  
  const isValid = parseInt(cleanCNH[9]) === dv1 && parseInt(cleanCNH[10]) === dv2;
  console.log('✅ [CNH VALIDATION] Result:', isValid);
  return isValid;
};

export const formatCPF = (cpf: string): string => {
  const cleanCPF = cpf.replace(/\D/g, '');
  
  // Aplica formatação gradual conforme o usuário digita
  if (cleanCPF.length <= 3) {
    return cleanCPF;
  } else if (cleanCPF.length <= 6) {
    return cleanCPF.replace(/(\d{3})(\d+)/, '$1.$2');
  } else if (cleanCPF.length <= 9) {
    return cleanCPF.replace(/(\d{3})(\d{3})(\d+)/, '$1.$2.$3');
  } else {
    return cleanCPF.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  }
};

const formatCNH = (cnh: string): string => {
  const cleanCNH = cnh.replace(/\D/g, '');
  return cleanCNH;
};
