
import * as React from "react"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined)

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }
    mql.addEventListener("change", onChange)
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    return () => mql.removeEventListener("change", onChange)
  }, [])

  // Adicionar classes CSS específicas para mobile com melhor otimização
  React.useEffect(() => {
    if (isMobile !== undefined) {
      const root = document.documentElement
      if (isMobile) {
        root.classList.add('mobile')
        root.classList.add('touch-manipulation')
        root.classList.add('tap-highlight-transparent')
        // Ajustar viewport height para mobile
        root.style.setProperty('--vh', `${window.innerHeight * 0.01}px`)
      } else {
        root.classList.remove('mobile')
        root.classList.remove('touch-manipulation')
        root.classList.remove('tap-highlight-transparent')
        root.style.removeProperty('--vh')
      }
    }
  }, [isMobile])

  // Listener para mudanças na altura da viewport (teclado mobile)
  React.useEffect(() => {
    const updateVh = () => {
      document.documentElement.style.setProperty('--vh', `${window.innerHeight * 0.01}px`)
    }
    
    if (isMobile) {
      window.addEventListener('resize', updateVh)
      window.addEventListener('orientationchange', updateVh)
      
      return () => {
        window.removeEventListener('resize', updateVh)
        window.removeEventListener('orientationchange', updateVh)
      }
    }
  }, [isMobile])

  return !!isMobile
}
