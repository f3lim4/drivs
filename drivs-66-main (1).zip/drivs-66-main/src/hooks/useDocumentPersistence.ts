
import { useState, useEffect } from 'react';

interface DocumentFields {
  cnhDocument: string;
  addressProof: string;
  selfieDocument: string;
  appProfileScreenshot: string;
}

export const useDocumentPersistence = () => {
  const [documents, setDocuments] = useState<DocumentFields>({
    cnhDocument: '',
    addressProof: '',
    selfieDocument: '',
    appProfileScreenshot: ''
  });

  // Carregar documentos dos cookies ao inicializar
  useEffect(() => {
    const loadFromCookies = () => {
      const cookies = document.cookie.split(';');
      const savedDocs: Partial<DocumentFields> = {};

      cookies.forEach(cookie => {
        const [name, value] = cookie.trim().split('=');
        if (name === 'doc_cnh_document' && value) {
          savedDocs.cnhDocument = decodeURIComponent(value);
        } else if (name === 'doc_comprovante_de_residência' && value) {
          savedDocs.addressProof = decodeURIComponent(value);
        } else if (name === 'doc_selfie_com_documento' && value) {
          savedDocs.selfieDocument = decodeURIComponent(value);
        } else if (name === 'doc_print_do_perfil_do_app_99_ou_uber' && value) {
          savedDocs.appProfileScreenshot = decodeURIComponent(value);
        }
      });

      setDocuments(prev => ({ ...prev, ...savedDocs }));
    };

    loadFromCookies();
  }, []);

  const updateDocument = (field: keyof DocumentFields, value: string) => {
    setDocuments(prev => ({ ...prev, [field]: value }));
  };

  const clearAllDocuments = () => {
    // Limpar cookies
    const cookieNames = [
      'doc_cnh_document',
      'doc_comprovante_de_residência', 
      'doc_selfie_com_documento',
      'doc_print_do_perfil_do_app_99_ou_uber'
    ];

    cookieNames.forEach(name => {
      document.cookie = `${name}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
    });

    setDocuments({
      cnhDocument: '',
      addressProof: '',
      selfieDocument: '',
      appProfileScreenshot: ''
    });
  };

  return {
    documents,
    updateDocument,
    clearAllDocuments
  };
};
