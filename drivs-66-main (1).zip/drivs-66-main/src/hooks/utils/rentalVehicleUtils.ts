
import { RentalCompanyVehicle } from "../types/vehicleTypes";

export const mapSupabaseToRentalVehicle = (data: any): RentalCompanyVehicle => {
  return {
    id: data.id,
    company_id: data.company_id,
    brand: data.brand,
    model: data.model,
    plate: data.plate,
    year: data.year,
    color: data.color,
    status: data.status as RentalCompanyVehicle['status'],
    vehicle_type: data.vehicle_type,
    fuel_type: data.fuel_type,
    transmission_type: data.transmission_type,
    mileage: data.mileage,
    weekly_value: data.weekly_value,
    deposit_value: data.deposit_value,
    vehicle_value: data.vehicle_value,
    is_financed: data.is_financed,
    monthly_installment: data.monthly_installment,
    monthly_insurance: data.monthly_insurance,
    monthly_tracker: data.monthly_tracker,
    ipva_value: data.ipva_value,
    km_type: data.km_type as RentalCompanyVehicle['km_type'],
    km_limit: data.km_limit,
    licensing_status: data.licensing_status as RentalCompanyVehicle['licensing_status'],
    document_expiry: data.document_expiry,
    maintenance_responsibility: data.maintenance_responsibility as RentalCompanyVehicle['maintenance_responsibility'],
    allow_reservation: data.allow_reservation,
    description: data.description,
    images: data.images,
    renavam: data.renavam,
    chassi: data.chassi,
    licensing_expiry: data.licensing_expiry,
    last_revision_km: data.last_revision_km,
    observations: data.observations,
    driver_id: data.driver_id,
    created_at: data.created_at,
    updated_at: data.updated_at
  };
};

export const sanitizeDataForSupabase = (data: any) => {
  // Remove campos de data que estão vazios ou undefined/null
  const sanitized = { ...data };
  
  // Lista de campos de data que podem estar vazios
  const dateFields = ['document_expiry', 'licensing_expiry'];
  
  dateFields.forEach(field => {
    if (sanitized[field] === "" || sanitized[field] === null || sanitized[field] === undefined) {
      delete sanitized[field];
    }
  });

  // Remove campos undefined que podem causar problemas
  Object.keys(sanitized).forEach(key => {
    if (sanitized[key] === undefined || 
        (typeof sanitized[key] === 'object' && sanitized[key] !== null && sanitized[key]._type === 'undefined')) {
      delete sanitized[key];
    }
  });

  return sanitized;
};

export const getCompanyId = (userId?: string) => {
  // Para usuário real de locadora, usar o UUID real
  if (userId && userId.length === 36 && userId.includes('-')) {
    return userId;
  }
  // Para usuário demo, usar o ID fixo da locadora
  return "550e8400-e29b-41d4-a716-446655440001";
};
