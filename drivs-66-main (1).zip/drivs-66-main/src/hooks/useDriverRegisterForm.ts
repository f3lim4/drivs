
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useDriverValidation } from "@/hooks/useDriverValidation";
import { useDocumentPersistence } from "@/hooks/useDocumentPersistence";
import { useDriverRegisterFormData } from "./useDriverRegisterFormData";
import { useDriverRegisterSubmission } from "./useDriverRegisterSubmission";

export const useDriverRegisterForm = () => {
  console.log('🔧 [DRIVER REGISTER HOOK] Iniciando hook...');
  
  const navigate = useNavigate();
  const { formData, referralId, handleInputChange } = useDriverRegisterFormData();
  const { validateUniqueFields, isValidating } = useDriverValidation();
  const { documents, updateDocument, clearAllDocuments } = useDocumentPersistence();
  const { loading, submitRegistration } = useDriverRegisterSubmission();

  console.log('📊 [DRIVER REGISTER HOOK] Estado dos hooks:', {
    hasFormData: !!formData,
    hasDocuments: !!documents,
    referralId,
    loading,
    isValidating
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('📤 [DRIVER REGISTER] Submetendo formulário...');

    try {
      if (formData.password !== formData.confirmPassword) {
        toast.error("As senhas não coincidem");
        return;
      }

      console.log('🔍 [DRIVER REGISTER] Validando campos únicos...');
      await validateUniqueFields({
        cpf: formData.cpf,
        cnh: formData.cnh,
        phone: formData.phone,
        email: formData.email
      });

      console.log('✅ [DRIVER REGISTER] Validação concluída, enviando cadastro...');
      await submitRegistration(formData, documents, referralId, clearAllDocuments);
    } catch (error: any) {
      console.error('❌ [DRIVER REGISTER] Erro na validação:', error);
      let errorMessage = "Erro ao realizar cadastro";
      
      if (error.message?.includes('já cadastrado') || error.message?.includes('já cadastrada')) {
        errorMessage = error.message;
      } else if (error.message?.includes('User already registered')) {
        errorMessage = "Este email já está cadastrado";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
    }
  };

  return {
    formData,
    documents,
    loading,
    isValidating,
    referralId,
    handleInputChange,
    handleSubmit,
    updateDocument,
    navigate
  };
};
