import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface CompanyUserData {
  id: string;
  company_id: string;
  user_id: string;
  name: string;
  email: string;
  role: 'manager' | 'inspector';
  active: boolean;
  permissions?: any;
  created_at: string;
  updated_at: string;
  last_login?: string;
}

export const useCompanyUsers = (companyId?: string) => {
  const [users, setUsers] = useState<CompanyUserData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchUsers = async () => {
    if (!companyId) return;
    
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('company_users')
        .select('*')
        .eq('company_id', companyId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const formattedData = data?.map(user => ({
        ...user,
        role: user.role as 'manager' | 'inspector'
      })) || [];
      
      setUsers(formattedData);
    } catch (error: any) {
      console.error('Error fetching company users:', error);
      toast.error('Erro ao carregar usuários da empresa');
    } finally {
      setLoading(false);
    }
  };

  const createUser = async (userData: { 
    name: string; 
    email: string; 
    password: string; 
    role: 'manager' | 'inspector';
    permissions?: any;
  }) => {
    if (!companyId) return;

    try {
      // Primeiro criar o usuário no auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password,
        options: {
          data: {
            full_name: userData.name,
            role: userData.role
          }
        }
      });

      if (authError) throw authError;

      if (authData.user) {
        // Depois criar o registro na tabela company_users
        const { error: insertError } = await supabase
          .from('company_users')
          .insert({
            company_id: companyId,
            user_id: authData.user.id,
            name: userData.name,
            email: userData.email,
            role: userData.role,
            permissions: userData.permissions,
            active: true
          });

        if (insertError) throw insertError;

        toast.success('Usuário criado com sucesso!');
        await fetchUsers();
      }
    } catch (error: any) {
      console.error('Error creating user:', error);
      toast.error('Erro ao criar usuário: ' + error.message);
    }
  };

  const toggleUserStatus = async (userId: string) => {
    try {
      const user = users.find(u => u.id === userId);
      if (!user) return;

      const { error } = await supabase
        .from('company_users')
        .update({ 
          active: !user.active,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (error) throw error;

      setUsers(prev => 
        prev.map(u => 
          u.id === userId 
            ? { ...u, active: !u.active }
            : u
        )
      );

      toast.success('Status do usuário atualizado!');
    } catch (error: any) {
      console.error('Error updating user status:', error);
      toast.error('Erro ao atualizar status do usuário');
    }
  };

  const deleteUser = async (userId: string) => {
    try {
      const user = users.find(u => u.id === userId);
      if (!user) return;

      const { error } = await supabase
        .from('company_users')
        .delete()
        .eq('id', userId);

      if (error) throw error;

      setUsers(prev => prev.filter(u => u.id !== userId));
      toast.success('Usuário removido com sucesso!');
    } catch (error: any) {
      console.error('Error deleting user:', error);
      toast.error('Erro ao remover usuário');
    }
  };

  useEffect(() => {
    if (companyId) {
      fetchUsers();
    }
  }, [companyId]);

  return {
    users,
    loading,
    createUser,
    toggleUserStatus,
    deleteUser,
    refetch: fetchUsers
  };
};
