
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { DriverRegisterFormData } from "./useDriverRegisterFormData";

export const useDriverRegisterSubmission = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const submitRegistration = async (
    formData: DriverRegisterFormData,
    documents: {
      cnhDocument: string;
      addressProof: string;
      selfieDocument: string;
      appProfileScreenshot: string;
    },
    referralId: string | null,
    clearAllDocuments: () => void
  ) => {
    setLoading(true);

    try {
      if (formData.password !== formData.confirmPassword) {
        toast.error("As senhas não coincidem");
        return;
      }

      console.log("=== INICIANDO CADASTRO DE MOTORISTA ===");
      console.log("Dados do formulário:", {
        email: formData.email,
        fullName: formData.fullName,
        cpf: formData.cpf,
        phone: formData.phone,
        referralId: referralId
      });

      console.log("Criando usuário no Supabase Auth...");

      // Criar usuário diretamente no Supabase Auth com confirmação automática
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email.toLowerCase().trim(),
        password: formData.password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: {
            full_name: formData.fullName,
            role: 'driver',
            cpf: formData.cpf,
            phone: formData.phone,
            address: formData.address,
            city: formData.city,
            state: formData.state,
            zip_code: formData.zipCode,
            cnh: formData.cnh,
            date_of_birth: formData.dateOfBirth
          }
        }
      });

      if (authError) {
        console.error('Erro ao criar usuário:', authError);
        
        // Se o Supabase rejeitar por rate limit de email ou outro problema de email
        if (authError.message?.includes('email rate limit exceeded') || 
            authError.message?.includes('rate limit') ||
            authError.code === 'over_email_send_rate_limit' ||
            authError.message?.includes('invalid') && authError.message?.includes('email')) {
          
          console.log('📧 Rate limit de email detectado, salvando em driver_registrations...');
          console.log('🏢 Salvando com referral_company_id:', referralId);
          
          const registrationData = {
            full_name: formData.fullName,
            email: formData.email.toLowerCase().trim(),
            phone: formData.phone,
            cpf: formData.cpf,
            address: formData.address,
            city: formData.city,
            state: formData.state,
            zip_code: formData.zipCode,
            date_of_birth: formData.dateOfBirth,
            cnh: formData.cnh,
            password_hash: formData.password,
            referral_company_id: referralId || null,
            status: 'pending',
            cnh_document: documents.cnhDocument || null,
            address_proof: documents.addressProof || null,
            selfie_document: documents.selfieDocument || null,
            app_profile_screenshot: documents.appProfileScreenshot || null
          };

          console.log('📝 Dados para inserção em driver_registrations:', registrationData);

          const { data: insertedData, error: registrationError } = await supabase
            .from('driver_registrations')
            .insert(registrationData)
            .select();

          if (registrationError) {
            console.error('❌ Erro ao inserir em driver_registrations:', registrationError);
            throw registrationError;
          }

          console.log('✅ Motorista salvo com sucesso em driver_registrations:', insertedData);
          
          // Verificar se foi realmente salvo
          if (referralId) {
            console.log('🔍 Verificando se o motorista foi salvo corretamente...');
            const { data: verificationData, error: verificationError } = await supabase
              .from('driver_registrations')
              .select('*')
              .eq('referral_company_id', referralId)
              .eq('email', formData.email.toLowerCase().trim());
            
            console.log('🔍 Verificação - dados encontrados:', verificationData);
            if (verificationError) {
              console.error('❌ Erro na verificação:', verificationError);
            }
          }
          
          clearAllDocuments();
          toast.success("Cadastro realizado com sucesso! Devido ao alto volume de cadastros, processaremos sua solicitação em breve. Entraremos em contato via WhatsApp.");
          
          // Disparar evento para atualizar listas
          window.dispatchEvent(new CustomEvent('refreshDriversData'));
          
          setTimeout(() => {
            navigate("/login");
          }, 2000);
          return;
        }
        
        throw authError;
      }

      if (authData.user) {
        console.log('✅ Usuário criado com sucesso no Auth:', authData.user.id);
        
        // Aguardar um momento para o trigger criar o perfil
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Fazer login automático após cadastro
        console.log('🔐 Fazendo login automático...');
        const { error: loginError } = await supabase.auth.signInWithPassword({
          email: formData.email.toLowerCase().trim(),
          password: formData.password
        });

        if (loginError) {
          console.error('❌ Erro no login automático:', loginError);
          toast.success("Cadastro realizado com sucesso! Você já pode fazer login.");
          setTimeout(() => {
            navigate("/login");
          }, 2000);
        } else {
          // Atualizar o registro do motorista com todos os campos e documentos
          const updateData = {
            full_name: formData.fullName,
            email: formData.email,
            phone: formData.phone,
            cpf: formData.cpf,
            address: formData.address,
            city: formData.city,
            state: formData.state,
            zip_code: formData.zipCode,
            cnh: formData.cnh,
            date_of_birth: formData.dateOfBirth,
            company_id: referralId, // Associar à empresa de referência
            cnh_document: documents.cnhDocument || null,
            address_proof: documents.addressProof || null,
            selfie_document: documents.selfieDocument || null,
            app_profile_screenshot: documents.appProfileScreenshot || null
          };

          console.log('📝 Atualizando dados na tabela drivers:', updateData);

          const { data: updateResult, error: updateError } = await supabase
            .from('drivers')
            .update(updateData)
            .eq('id', authData.user.id)
            .select();

          if (updateError) {
            console.error('❌ Erro ao atualizar dados do motorista:', updateError);
          } else {
            console.log('✅ Dados atualizados com sucesso na tabela drivers:', updateResult);
          }

          clearAllDocuments();
          
          // Disparar evento para atualizar listas
          window.dispatchEvent(new CustomEvent('refreshDriversData'));
          
          toast.success("Cadastro realizado com sucesso! Agora você pode enviar seus documentos.");
          setTimeout(() => {
            navigate("/motorista/documentos");
          }, 1000);
        }
      }
      
    } catch (error: any) {
      console.error('❌ Erro crítico no cadastro:', error);
      let errorMessage = "Erro ao realizar cadastro";
      
      if (error.message?.includes('já cadastrado') || error.message?.includes('já cadastrada')) {
        errorMessage = error.message;
      } else if (error.message?.includes('User already registered')) {
        errorMessage = "Este email já está cadastrado";
      } else if (error.message?.includes('email rate limit exceeded') || error.message?.includes('rate limit')) {
        errorMessage = "Muitas tentativas de cadastro. Tente novamente em alguns minutos.";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    submitRegistration
  };
};
