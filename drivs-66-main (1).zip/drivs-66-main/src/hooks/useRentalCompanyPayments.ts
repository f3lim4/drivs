
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

interface Payment {
  id: string;
  driver_id: string;
  driver_name: string;
  company_id: string;
  vehicle_info: string;
  vehicle_plate: string;
  due_date: string;
  amount: number;
  status: "paid" | "pending" | "overdue" | "partial";
  paid_date?: string;
  paid_amount?: number;
  payment_method?: string;
  description?: string;
}

interface VehicleExpense {
  id: string;
  company_id: string;
  vehicle_id?: string;
  vehicle_plate: string;
  expense_type: string;
  description: string;
  amount: number;
  expense_date: string;
  category: string;
}

export const useRentalCompanyPayments = () => {
  const { user } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [expenses, setExpenses] = useState<VehicleExpense[]>([]);
  const [loading, setLoading] = useState(true);

  const loadPayments = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Load payments
      const { data: paymentsData, error: paymentsError } = await supabase
        .from('payments')
        .select('*')
        .eq('company_id', user.id)
        .order('due_date', { ascending: false });

      if (paymentsError) {
        console.error('Error loading payments:', paymentsError);
      } else {
        // Type cast the status to ensure compatibility
        const typedPayments = (paymentsData || []).map(payment => ({
          ...payment,
          status: payment.status as "paid" | "pending" | "overdue" | "partial"
        }));
        setPayments(typedPayments);
      }

      // Load vehicle expenses
      const { data: expensesData, error: expensesError } = await supabase
        .from('vehicle_expenses')
        .select('*')
        .eq('company_id', user.id)
        .order('expense_date', { ascending: false });

      if (expensesError) {
        console.error('Error loading expenses:', expensesError);
      } else {
        setExpenses(expensesData || []);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const createPayment = async (paymentData: Omit<Payment, 'id'>) => {
    try {
      const { data, error } = await supabase
        .from('payments')
        .insert([{ ...paymentData, company_id: user?.id }])
        .select()
        .single();

      if (error) {
        console.error('Error creating payment:', error);
        throw error;
      }

      const typedPayment = {
        ...data,
        status: data.status as "paid" | "pending" | "overdue" | "partial"
      };
      setPayments(prev => [typedPayment, ...prev]);
      return typedPayment;
    } catch (error) {
      console.error('Error creating payment:', error);
      throw error;
    }
  };

  const updatePaymentStatus = async (paymentId: string, status: Payment['status'], paidAmount?: number) => {
    try {
      const updates: Partial<Payment> = {
        status,
        paid_amount: paidAmount,
        paid_date: status === 'paid' ? new Date().toISOString().split('T')[0] : undefined
      };

      const { error } = await supabase
        .from('payments')
        .update(updates)
        .eq('id', paymentId);

      if (error) {
        console.error('Error updating payment:', error);
        throw error;
      }

      setPayments(prev => prev.map(payment => 
        payment.id === paymentId 
          ? { ...payment, ...updates }
          : payment
      ));
    } catch (error) {
      console.error('Error updating payment:', error);
      throw error;
    }
  };

  const createVehicleExpense = async (expenseData: Omit<VehicleExpense, 'id'>) => {
    try {
      const { data, error } = await supabase
        .from('vehicle_expenses')
        .insert([{ ...expenseData, company_id: user?.id }])
        .select()
        .single();

      if (error) {
        console.error('Error creating expense:', error);
        throw error;
      }

      setExpenses(prev => [data, ...prev]);
      return data;
    } catch (error) {
      console.error('Error creating expense:', error);
      throw error;
    }
  };

  useEffect(() => {
    loadPayments();
  }, [user]);

  return {
    payments,
    expenses,
    loading,
    loadPayments,
    createPayment,
    updatePaymentStatus,
    createVehicleExpense
  };
};
