
import { useState } from "react";
import { validateCPF, validateCNH, formatCPF } from "@/utils/validation";
import { toast } from "sonner";

interface ValidationErrors {
  cpf?: string;
  cnh?: string;
  dateOfBirth?: string;
}

export const useDriverRegisterFormValidation = () => {
  const [validationErrors, setValidationErrors] = useState<ValidationErrors>({});

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>, onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void) => {
    const value = e.target.value;
    console.log('🔍 [CPF VALIDATION] Input value:', value);
    
    // Remove caracteres não numéricos e limita a 11 dígitos
    const cleanValue = value.replace(/\D/g, '').slice(0, 11);
    console.log('🧹 [CPF VALIDATION] Clean value:', cleanValue);
    
    // Aplica formatação apenas se há dígitos
    const formattedValue = cleanValue.length > 0 ? formatCPF(cleanValue) : '';
    console.log('💅 [CPF VALIDATION] Formatted value:', formattedValue);
    
    // Cria evento modificado com valor formatado
    const formattedEvent = { 
      ...e, 
      target: { 
        ...e.target, 
        name: 'cpf',
        value: formattedValue 
      } 
    };
    
    // Chama o onChange do formulário
    onInputChange(formattedEvent);
    
    // Valida apenas se tem 11 dígitos
    if (cleanValue.length === 11) {
      if (!validateCPF(cleanValue)) {
        setValidationErrors(prev => ({ ...prev, cpf: 'CPF inválido' }));
      } else {
        setValidationErrors(prev => ({ ...prev, cpf: undefined }));
      }
    } else if (cleanValue.length > 0) {
      // Remove erro se está digitando
      setValidationErrors(prev => ({ ...prev, cpf: undefined }));
    }
  };

  const handleCNHChange = (e: React.ChangeEvent<HTMLInputElement>, onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void) => {
    const value = e.target.value;
    console.log('🔍 [CNH VALIDATION] Input value:', value);
    
    // Remove caracteres não numéricos e limita a 11 dígitos
    const cleanValue = value.replace(/\D/g, '').slice(0, 11);
    console.log('🧹 [CNH VALIDATION] Clean value:', cleanValue);
    
    // Para CNH, mantém apenas números sem formatação adicional
    const formattedEvent = { 
      ...e, 
      target: { 
        ...e.target, 
        name: 'cnh',
        value: cleanValue 
      } 
    };
    
    // Chama o onChange do formulário
    onInputChange(formattedEvent);
    
    // Valida apenas se tem 11 dígitos
    if (cleanValue.length === 11) {
      if (!validateCNH(cleanValue)) {
        setValidationErrors(prev => ({ ...prev, cnh: 'CNH inválida' }));
      } else {
        setValidationErrors(prev => ({ ...prev, cnh: undefined }));
      }
    } else if (cleanValue.length > 0) {
      // Remove erro se está digitando
      setValidationErrors(prev => ({ ...prev, cnh: undefined }));
    }
  };

  const handleDateOfBirthChange = (e: React.ChangeEvent<HTMLInputElement>, onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void) => {
    console.log('📅 [DATE VALIDATION] Input value:', e.target.value);
    onInputChange(e);
    
    const value = e.target.value;
    if (value) {
      const birthDate = new Date(value);
      const today = new Date();
      const age = today.getFullYear() - birthDate.getFullYear();
      
      if (age < 18) {
        setValidationErrors(prev => ({ 
          ...prev, 
          dateOfBirth: 'Idade mínima de 18 anos' 
        }));
      } else if (age > 80) {
        setValidationErrors(prev => ({ 
          ...prev, 
          dateOfBirth: 'Idade máxima de 80 anos' 
        }));
      } else {
        setValidationErrors(prev => ({ ...prev, dateOfBirth: undefined }));
      }
    } else {
      setValidationErrors(prev => ({ ...prev, dateOfBirth: undefined }));
    }
  };

  const validateFormSubmission = (formData: any) => {
    console.log('✅ [FORM VALIDATION] Validating submission with data:', formData);
    
    const cpfValid = validateCPF(formData.cpf);
    const cnhValid = validateCNH(formData.cnh);
    
    if (!cpfValid) {
      toast.error('CPF inválido');
      return false;
    }
    
    if (!cnhValid) {
      toast.error('CNH inválida');
      return false;
    }

    if (validationErrors.dateOfBirth) {
      toast.error(validationErrors.dateOfBirth);
      return false;
    }
    
    console.log('✅ [FORM VALIDATION] All validations passed');
    return true;
  };

  return {
    validationErrors,
    handleCPFChange,
    handleCNHChange,
    handleDateOfBirthChange,
    validateFormSubmission
  };
};
