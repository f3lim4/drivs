
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { UserRole } from "@/types";

export interface CompanySettingsData {
  id: string;
  company_name: string;
  cnpj: string;
  email?: string;
  phone: string;
  whatsapp?: string;
  emergency_phone?: string;
  address: string;
  cep?: string;
  city?: string;
  state?: string;
  description?: string;
  website?: string;
  operating_hours?: string;
  logo_url?: string;
  plan?: string;
}

export const useCompanySettings = () => {
  const { user } = useAuth();
  const [companyData, setCompanyData] = useState<CompanySettingsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchCompanyData = async () => {
    // Para usuários admin demo, não tentar buscar dados
    if (user?.id === 'admin-demo-user') {
      console.log('Admin demo user - skipping company data fetch');
      setLoading(false);
      return;
    }

    // Só buscar dados para locadoras reais
    if (!user?.id || user.role !== UserRole.RENTAL_COMPANY) {
      console.log('Not a rental company user, skipping fetch');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      console.log('Fetching company data for user:', user.id);
      
      const { data, error } = await supabase
        .from('rental_companies')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) {
        console.error('Error fetching company data:', error);
        if (error.code !== 'PGRST116') {
          toast.error('Erro ao carregar dados da locadora');
        }
        return;
      }

      console.log('Company data fetched:', data);

      if (data) {
        setCompanyData({
          id: data.id,
          company_name: data.company_name || '',
          cnpj: data.cnpj || '',
          email: data.email || '',
          phone: data.phone || '',
          whatsapp: data.whatsapp || '',
          emergency_phone: data.emergency_phone || '',
          address: data.address || '',
          cep: data.cep || '',
          city: data.city || '',
          state: data.state || '',
          description: data.description || '',
          website: data.website || '',
          operating_hours: data.operating_hours || '',
          logo_url: data.logo_url || ''
        });
      }
    } catch (error) {
      console.error('Error in fetchCompanyData:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateCompanyData = async (updates: Partial<CompanySettingsData>) => {
    if (!user?.id) {
      toast.error('Usuário não autenticado');
      return false;
    }

    try {
      setIsSubmitting(true);
      console.log('Updating company data:', updates);
      
      const { error } = await supabase
        .from('rental_companies')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) {
        console.error('Error updating company data:', error);
        toast.error('Erro ao salvar informações');
        return false;
      }

      setCompanyData(prev => prev ? { ...prev, ...updates } : null);
      toast.success('Informações salvas com sucesso!');
      return true;
    } catch (error) {
      console.error('Error in updateCompanyData:', error);
      toast.error('Erro ao salvar informações');
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const uploadLogo = async (file: File) => {
    if (!user?.id) {
      toast.error('Usuário não autenticado');
      return null;
    }

    if (!file) {
      toast.error('Arquivo não selecionado');
      return null;
    }

    // Validar tipo de arquivo
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/svg+xml'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Formato de arquivo não suportado. Use PNG, JPG ou SVG.');
      return null;
    }

    // Validar tamanho (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Arquivo muito grande. Máximo 5MB.');
      return null;
    }

    try {
      setIsSubmitting(true);
      console.log('Starting logo upload for user:', user.id);
      console.log('File details:', { name: file.name, type: file.type, size: file.size });
      
      // Criar nome único para o arquivo
      const fileExt = file.name.split('.').pop()?.toLowerCase();
      const fileName = `${user.id}/logo.${fileExt}`;
      
      console.log('Upload filename:', fileName);

      // Primeiro, tentar deletar logo anterior se existir
      try {
        await supabase.storage
          .from('company-logos')
          .remove([fileName]);
        console.log('Previous logo removed (if existed)');
      } catch (deleteError) {
        console.log('No previous logo to delete or error removing:', deleteError);
      }

      // Fazer upload do arquivo
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('company-logos')
        .upload(fileName, file, {
          upsert: true,
          contentType: file.type
        });

      if (uploadError) {
        console.error('Upload error details:', uploadError);
        toast.error(`Erro ao fazer upload: ${uploadError.message}`);
        return null;
      }

      console.log('Upload successful:', uploadData);

      // Obter URL pública da logo
      const { data: urlData } = supabase.storage
        .from('company-logos')
        .getPublicUrl(fileName);

      const logoUrl = urlData.publicUrl;
      console.log('Logo URL generated:', logoUrl);

      // Atualizar URL da logo no banco
      const updateSuccess = await updateCompanyData({ logo_url: logoUrl });
      
      if (updateSuccess) {
        toast.success('Logo atualizada com sucesso!');
        return logoUrl;
      }
      
      return null;
    } catch (error) {
      console.error('Error in uploadLogo:', error);
      toast.error(`Erro ao fazer upload da logo: ${error}`);
      return null;
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    fetchCompanyData();
  }, [user?.id, user?.role]);

  return {
    companyData,
    loading,
    isSubmitting,
    updateCompanyData,
    uploadLogo,
    refetch: fetchCompanyData
  };
};
