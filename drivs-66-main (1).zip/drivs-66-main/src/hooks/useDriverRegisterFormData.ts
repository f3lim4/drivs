
import { useState } from "react";
import { useSearchParams } from "react-router-dom";

interface DriverRegisterFormData {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
  phone: string;
  cpf: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  dateOfBirth: string;
  cnh: string;
  referralCompanyId: string | null;
}

export const useDriverRegisterFormData = () => {
  const [searchParams] = useSearchParams();
  const referralId = searchParams.get('ref');
  
  const [formData, setFormData] = useState<DriverRegisterFormData>({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    cpf: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    dateOfBirth: "",
    cnh: "",
    referralCompanyId: referralId || null
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return {
    formData,
    referralId,
    handleInputChange
  };
};

export type { DriverRegisterFormData };
