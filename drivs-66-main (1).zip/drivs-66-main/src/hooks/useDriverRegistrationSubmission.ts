
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { DriverFormData } from "./useDriverRegistrationFormData";
import { validateFormData, getErrorMessage } from "./useDriverRegistrationSubmission/errorHandler";
import { handleAuthRegistration, handleDriverUpdate } from "./useDriverRegistrationSubmission/submissionHandler";
import { handleFallbackRegistration, isEmailRateLimitError } from "./useDriverRegistrationSubmission/fallbackHandler";
import { performAutoLogin } from "./useDriverRegistrationSubmission/loginHandler";

export const useDriverRegistrationSubmission = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const submitRegistration = async (
    formData: DriverFormData,
    documents: {
      cnhDocument: string;
      addressProof: string;
      selfieDocument: string;
      appProfileScreenshot: string;
    },
    referralId: string | null,
    clearAllDocuments: () => void
  ) => {
    setLoading(true);

    try {
      // Validate form data
      const validationError = validateFormData(formData);
      if (validationError) {
        toast.error(validationError);
        return;
      }

      // Try to create user with Supabase Auth
      const authData = await handleAuthRegistration(formData, documents, referralId);

      if (authData.user) {
        console.log('✅ Usuário criado com sucesso:', authData.user.id);
        
        // Wait for trigger to create profile
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Perform auto login
        const loginResult = await performAutoLogin(formData.email, formData.password);

        if (loginResult.success) {
          // Update driver data with documents and company association
          await handleDriverUpdate(authData.user.id, formData, documents, referralId);
          
          clearAllDocuments();
          
          // Dispatch refresh event
          window.dispatchEvent(new CustomEvent('refreshDriversData'));
          
          setTimeout(() => {
            navigate(loginResult.redirectTo);
          }, 1000);
        } else {
          setTimeout(() => {
            navigate(loginResult.redirectTo);
          }, 2000);
        }
      }
      
    } catch (error: any) {
      console.error('❌ Erro crítico no cadastro:', error);
      
      // Handle email rate limit by falling back to driver_registrations table
      if (isEmailRateLimitError(error)) {
        try {
          await handleFallbackRegistration(formData, documents, referralId, clearAllDocuments);
          setTimeout(() => {
            navigate("/login");
          }, 2000);
          return;
        } catch (fallbackError: any) {
          console.error('❌ Erro no fallback:', fallbackError);
          toast.error(getErrorMessage(fallbackError));
        }
      } else {
        toast.error(getErrorMessage(error));
      }
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    submitRegistration
  };
};
