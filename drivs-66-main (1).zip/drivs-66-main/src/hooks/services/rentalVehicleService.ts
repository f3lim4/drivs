
import { supabase } from "@/integrations/supabase/client";
import { RentalCompanyVehicle } from "../types/vehicleTypes";
import { mapSupabaseToRentalVehicle, sanitizeDataForSupabase } from "../utils/rentalVehicleUtils";

export const fetchVehiclesFromSupabase = async (companyId: string): Promise<RentalCompanyVehicle[]> => {
  console.log('Fetching vehicles for company ID:', companyId);

  const { data, error } = await supabase
    .from('rental_company_vehicles')
    .select('*')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching vehicles:', error);
    throw new Error('Erro ao carregar veículos: ' + error.message);
  }

  console.log('Vehicles loaded from Supabase:', data);
  return data ? data.map(mapSupabaseToRentalVehicle) : [];
};

export const createVehicleInSupabase = async (
  vehicleData: Omit<RentalCompanyVehicle, 'id' | 'created_at' | 'updated_at'>,
  companyId: string
): Promise<RentalCompanyVehicle> => {
  console.log('Creating vehicle with data:', vehicleData);
  console.log('Creating vehicle for company ID:', companyId);

  // Sanitizar dados antes de enviar
  const sanitizedData = sanitizeDataForSupabase({
    ...vehicleData,
    company_id: companyId
  });

  console.log('Sanitized data for Supabase:', sanitizedData);

  const { data, error } = await supabase
    .from('rental_company_vehicles')
    .insert([sanitizedData])
    .select()
    .single();

  if (error) {
    console.error('Error creating vehicle:', error);
    throw new Error('Erro ao cadastrar veículo: ' + error.message);
  }

  console.log('Vehicle created successfully:', data);
  return mapSupabaseToRentalVehicle(data);
};

export const updateVehicleInSupabase = async (
  vehicleId: string,
  updates: Partial<RentalCompanyVehicle>
): Promise<RentalCompanyVehicle> => {
  console.log('Updating vehicle:', vehicleId, updates);

  // Sanitizar dados antes de enviar
  const sanitizedUpdates = sanitizeDataForSupabase({
    ...updates,
    updated_at: new Date().toISOString()
  });

  const { data, error } = await supabase
    .from('rental_company_vehicles')
    .update(sanitizedUpdates)
    .eq('id', vehicleId)
    .select()
    .single();

  if (error) {
    console.error('Error updating vehicle:', error);
    throw new Error('Erro ao atualizar veículo: ' + error.message);
  }

  console.log('Vehicle updated successfully:', data);
  return mapSupabaseToRentalVehicle(data);
};

export const deleteVehicleFromSupabase = async (vehicleId: string): Promise<void> => {
  console.log('Deleting vehicle:', vehicleId);

  const { error } = await supabase
    .from('rental_company_vehicles')
    .delete()
    .eq('id', vehicleId);

  if (error) {
    console.error('Error deleting vehicle:', error);
    throw new Error('Erro ao excluir veículo: ' + error.message);
  }

  console.log('Vehicle deleted successfully');
};
