import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface CreateUserData {
  name: string;
  email: string;
  password: string;
}

interface CreateAdminData extends CreateUserData {
  confirmPassword: string;
}

export const useCreateSystemUsers = () => {
  const [loading, setLoading] = useState(false);

  const createRealAdmin = async (userData: CreateAdminData) => {
    try {
      setLoading(true);

      // Verificar se as senhas coincidem
      if (userData.password !== userData.confirmPassword) {
        toast.error("As senhas não coincidem");
        return false;
      }

      // Verificar se email já existe
      const { data: existingUser, error: checkError } = await supabase
        .from('admin_users')
        .select('id')
        .eq('email', userData.email)
        .maybeSingle();

      if (checkError) {
        console.error('Error checking existing email:', checkError);
        throw new Error('Erro ao verificar email');
      }

      if (existingUser) {
        toast.error("Já existe um administrador com este email");
        return false;
      }

      // Criar usuário no Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password,
        options: {
          data: {
            full_name: userData.name,
            role: 'admin'
          }
        }
      });

      if (authError) {
        if (authError.message?.includes('already registered')) {
          toast.error("Este email já está cadastrado no sistema");
          return false;
        }
        throw authError;
      }

      if (authData.user) {
        // Criar registro na tabela profiles
        const { error: profileError } = await supabase
          .from('profiles')
          .upsert({
            id: authData.user.id,
            full_name: userData.name,
            role: 'admin'
          });

        if (profileError) {
          console.error('Error creating profile:', profileError);
        }

        // Criar registro na tabela admin_users
        const { error: insertError } = await supabase
          .from('admin_users')
          .insert({
            user_id: authData.user.id,
            name: userData.name,
            email: userData.email,
            active: true
          });

        if (insertError) {
          if (insertError.message?.includes('duplicate key value violates unique constraint')) {
            toast.error("Este email já está cadastrado no sistema");
            return false;
          }
          throw insertError;
        }

        toast.success('Administrador criado com sucesso! Verifique seu email para confirmar a conta.');
        return true;
      }

      return false;
    } catch (error: any) {
      console.error('Error creating admin:', error);
      let errorMessage = "Erro ao criar administrador";
      
      if (error.message?.includes('already registered') || error.message?.includes('already been registered')) {
        errorMessage = "Este email já está cadastrado";
      } else if (error.message?.includes('invalid email')) {
        errorMessage = "Email inválido";
      } else if (error.message?.includes('weak password')) {
        errorMessage = "Senha muito fraca. Use pelo menos 6 caracteres";
      } else if (error.message?.includes('duplicate key value violates unique constraint')) {
        errorMessage = "Email já cadastrado no sistema";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const createAdministrator = async (userData: CreateUserData) => {
    try {
      setLoading(true);

      // Verificar se email já existe
      const { data: existingUser, error: checkError } = await supabase
        .from('admin_users')
        .select('id')
        .eq('email', userData.email)
        .maybeSingle();

      if (checkError) {
        console.error('Error checking existing email:', checkError);
        throw new Error('Erro ao verificar email');
      }

      if (existingUser) {
        toast.error("Já existe um administrador com este email");
        return false;
      }

      // Criar usuário no Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password,
        options: {
          data: {
            full_name: userData.name,
            role: 'admin'
          }
        }
      });

      if (authError) throw authError;

      if (authData.user) {
        // Criar registro na tabela admin_users
        const { error: insertError } = await supabase
          .from('admin_users')
          .insert({
            user_id: authData.user.id,
            name: userData.name,
            email: userData.email,
            active: true
          });

        if (insertError) {
          // Verificar se é erro de email duplicado
          if (insertError.message?.includes('duplicate key value violates unique constraint')) {
            toast.error("Este email já está cadastrado no sistema");
            return false;
          }
          throw insertError;
        }

        toast.success('Administrador criado com sucesso!');
        return true;
      }

      return false;
    } catch (error: any) {
      console.error('Error creating administrator:', error);
      let errorMessage = "Erro ao criar administrador";
      
      if (error.message?.includes('already registered') || error.message?.includes('already been registered')) {
        errorMessage = "Este email já está cadastrado";
      } else if (error.message?.includes('invalid email')) {
        errorMessage = "Email inválido";
      } else if (error.message?.includes('weak password')) {
        errorMessage = "Senha muito fraca";
      } else if (error.message?.includes('duplicate key value violates unique constraint')) {
        errorMessage = "Email já cadastrado no sistema";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const createAnalyst = async (userData: CreateUserData) => {
    try {
      setLoading(true);

      // Verificar se email já existe em admin_users (analistas também ficam nesta tabela)
      const { data: existingUser, error: checkError } = await supabase
        .from('admin_users')
        .select('id')
        .eq('email', userData.email)
        .maybeSingle();

      if (checkError) {
        console.error('Error checking existing email:', checkError);
        throw new Error('Erro ao verificar email');
      }

      if (existingUser) {
        toast.error("Já existe um usuário com este email");
        return false;
      }

      // Criar usuário no Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password,
        options: {
          data: {
            full_name: userData.name,
            role: 'analyst'
          }
        }
      });

      if (authError) throw authError;

      if (authData.user) {
        // Criar registro na tabela admin_users com role de analista
        const { error: insertError } = await supabase
          .from('admin_users')
          .insert({
            user_id: authData.user.id,
            name: userData.name,
            email: userData.email,
            active: true
          });

        if (insertError) {
          // Verificar se é erro de email duplicado
          if (insertError.message?.includes('duplicate key value violates unique constraint')) {
            toast.error("Este email já está cadastrado no sistema");
            return false;
          }
          throw insertError;
        }

        // Atualizar o perfil do usuário para analista
        const { error: profileError } = await supabase
          .from('profiles')
          .upsert({
            id: authData.user.id,
            full_name: userData.name,
            role: 'analyst'
          });

        if (profileError) {
          console.error('Error updating profile:', profileError);
          // Não falha se o perfil não puder ser atualizado
        }

        toast.success('Analista criado com sucesso!');
        return true;
      }

      return false;
    } catch (error: any) {
      console.error('Error creating analyst:', error);
      let errorMessage = "Erro ao criar analista";
      
      if (error.message?.includes('already registered') || error.message?.includes('already been registered')) {
        errorMessage = "Este email já está cadastrado";
      } else if (error.message?.includes('invalid email')) {
        errorMessage = "Email inválido";
      } else if (error.message?.includes('weak password')) {
        errorMessage = "Senha muito fraca";
      } else if (error.message?.includes('duplicate key value violates unique constraint')) {
        errorMessage = "Email já cadastrado no sistema";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    createRealAdmin,
    createAdministrator,
    createAnalyst,
    loading
  };
};
