
import { useState } from "react";
import { validateCPF, validateCNH, formatCPF } from "@/utils/validation";
import { toast } from "sonner";

interface ValidationErrors {
  cpf?: string;
  cnh?: string;
  dateOfBirth?: string;
  cnhExpires?: string;
}

export const useFormValidation = () => {
  const [validationErrors, setValidationErrors] = useState<ValidationErrors>({});

  const handleCPFChange = (value: string, onInputChange: (field: string, value: string) => void) => {
    const cleanValue = value.replace(/\D/g, '').slice(0, 11);
    const formattedValue = formatCPF(cleanValue);
    
    onInputChange('cpf', formattedValue);
    
    if (cleanValue.length === 11) {
      if (!validateCPF(cleanValue)) {
        setValidationErrors(prev => ({ ...prev, cpf: 'CPF inválido' }));
      } else {
        setValidationErrors(prev => ({ ...prev, cpf: undefined }));
      }
    } else {
      setValidationErrors(prev => ({ ...prev, cpf: undefined }));
    }
  };

  const handleCNHChange = (value: string, onInputChange: (field: string, value: string) => void) => {
    const cleanValue = value.replace(/\D/g, '').slice(0, 11);
    
    onInputChange('cnh', cleanValue);
    
    if (cleanValue.length === 11) {
      if (!validateCNH(cleanValue)) {
        setValidationErrors(prev => ({ ...prev, cnh: 'CNH inválida' }));
      } else {
        setValidationErrors(prev => ({ ...prev, cnh: undefined }));
      }
    } else {
      setValidationErrors(prev => ({ ...prev, cnh: undefined }));
    }
  };

  const handleDateOfBirthChange = (value: string, onInputChange: (field: string, value: string) => void) => {
    onInputChange('dateOfBirth', value);
    
    if (value) {
      const birthDate = new Date(value);
      const today = new Date();
      const age = today.getFullYear() - birthDate.getFullYear();
      
      if (age < 18) {
        setValidationErrors(prev => ({ 
          ...prev, 
          dateOfBirth: 'Idade mínima de 18 anos' 
        }));
      } else if (age > 80) {
        setValidationErrors(prev => ({ 
          ...prev, 
          dateOfBirth: 'Idade máxima de 80 anos' 
        }));
      } else {
        setValidationErrors(prev => ({ ...prev, dateOfBirth: undefined }));
      }
    } else {
      setValidationErrors(prev => ({ ...prev, dateOfBirth: undefined }));
    }
  };

  const handleCnhExpiresChange = (value: string, onInputChange: (field: string, value: string) => void) => {
    onInputChange('cnhExpires', value);
    
    if (value) {
      const expiryDate = new Date(value);
      const today = new Date();
      
      if (expiryDate <= today) {
        setValidationErrors(prev => ({ 
          ...prev, 
          cnhExpires: 'CNH vencida' 
        }));
      } else {
        setValidationErrors(prev => ({ ...prev, cnhExpires: undefined }));
      }
    } else {
      setValidationErrors(prev => ({ ...prev, cnhExpires: undefined }));
    }
  };

  const validateFormSubmission = (formData: any) => {
    const cpfValid = validateCPF(formData.cpf);
    const cnhValid = validateCNH(formData.cnh);
    
    if (!cpfValid) {
      toast.error('CPF inválido');
      return false;
    }
    
    if (!cnhValid) {
      toast.error('CNH inválida');
      return false;
    }

    if (validationErrors.dateOfBirth) {
      toast.error(validationErrors.dateOfBirth);
      return false;
    }

    if (validationErrors.cnhExpires) {
      toast.error(validationErrors.cnhExpires);
      return false;
    }
    
    return true;
  };

  return {
    validationErrors,
    handleCPFChange,
    handleCNHChange,
    handleDateOfBirthChange,
    handleCnhExpiresChange,
    validateFormSubmission
  };
};
