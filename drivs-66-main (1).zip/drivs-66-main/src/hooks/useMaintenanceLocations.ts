
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface MaintenanceLocation {
  id: string;
  company_id: string;
  name: string;
  address?: string;
  phone?: string;
  email?: string;
  specialties?: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useMaintenanceLocations = () => {
  const { user } = useAuth();
  const [locations, setLocations] = useState<MaintenanceLocation[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLocations = async () => {
    if (!user || user.role !== "rental_company") {
      setLoading(false);
      return;
    }

    try {
      console.log("Buscando locais para a empresa:", user.id);
      
      const { data, error } = await supabase
        .from("maintenance_locations")
        .select("*")
        .eq("company_id", user.id)
        .eq("is_active", true)
        .order("name");

      if (error) {
        console.error("Erro ao buscar locais:", error);
        throw error;
      }
      
      console.log("Locais encontrados:", data);
      setLocations(data || []);
    } catch (error) {
      console.error("Erro ao buscar locais de manutenção:", error);
      toast.error("Erro ao carregar locais de manutenção");
    } finally {
      setLoading(false);
    }
  };

  const createLocation = async (locationData: Omit<MaintenanceLocation, "id" | "company_id" | "created_at" | "updated_at">) => {
    if (!user) {
      toast.error("Usuário não autenticado");
      return;
    }

    try {
      console.log("=== CRIANDO LOCAL DE MANUTENÇÃO ===");
      console.log("Dados do local:", locationData);
      console.log("ID da empresa:", user.id);

      const dataToInsert = {
        ...locationData,
        company_id: user.id
      };

      console.log("Dados para inserir:", dataToInsert);

      const { data, error } = await supabase
        .from("maintenance_locations")
        .insert(dataToInsert)
        .select()
        .single();

      if (error) {
        console.error("Erro detalhado ao criar local:", error);
        toast.error(`Erro ao criar local: ${error.message}`);
        throw error;
      }

      console.log("Local criado com sucesso:", data);
      toast.success("Local criado com sucesso!");
      
      // Atualizar a lista imediatamente após criar
      await fetchLocations();
      return data;
    } catch (error: any) {
      console.error("Erro ao criar local:", error);
      throw error;
    }
  };

  const updateLocation = async (id: string, locationData: Partial<MaintenanceLocation>) => {
    if (!user) {
      toast.error("Usuário não autenticado");
      return;
    }

    try {
      console.log("Atualizando local:", id, locationData);

      const { data, error } = await supabase
        .from("maintenance_locations")
        .update(locationData)
        .eq("id", id)
        .eq("company_id", user.id)
        .select()
        .single();

      if (error) {
        console.error("Erro ao atualizar local:", error);
        throw error;
      }

      console.log("Local atualizado com sucesso:", data);
      toast.success("Local atualizado com sucesso!");
      await fetchLocations();
      return data;
    } catch (error: any) {
      console.error("Erro ao atualizar local:", error);
      toast.error(`Erro ao atualizar local: ${error.message || 'Erro desconhecido'}`);
      throw error;
    }
  };

  const deleteLocation = async (id: string) => {
    if (!user) {
      toast.error("Usuário não autenticado");
      return;
    }

    try {
      console.log("Excluindo local:", id);

      const { error } = await supabase
        .from("maintenance_locations")
        .update({ is_active: false })
        .eq("id", id)
        .eq("company_id", user.id);

      if (error) {
        console.error("Erro ao excluir local:", error);
        throw error;
      }

      console.log("Local excluído com sucesso");
      toast.success("Local excluído com sucesso!");
      await fetchLocations();
    } catch (error: any) {
      console.error("Erro ao excluir local:", error);
      toast.error(`Erro ao excluir local: ${error.message || 'Erro desconhecido'}`);
      throw error;
    }
  };

  useEffect(() => {
    fetchLocations();
  }, [user]);

  return { 
    locations, 
    loading, 
    createLocation, 
    updateLocation,
    deleteLocation,
    refetch: fetchLocations 
  };
};
