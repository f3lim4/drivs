
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export interface ViolationData {
  id: string;
  contract_id?: string;
  vehicle_id?: string;
  driver_id?: string;
  company_id: string;
  violation_type: string;
  location: string;
  date: string;
  description: string;
  points: number;
  amount: number;
  status: "pending" | "paid" | "contested" | "resolved";
  payment_deadline?: string;
  evidence_files?: string[];
  notes?: string;
  created_at: string;
  updated_at: string;
}

export const useViolationsData = () => {
  const { user } = useAuth();
  const [violations, setViolations] = useState<ViolationData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchViolations = async () => {
    try {
      setLoading(true);
      
      if (!user) {
        setViolations([]);
        return;
      }

      const { data, error } = await supabase
        .from('violations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching violations:', error);
        toast.error('Erro ao carregar infrações');
        return;
      }

      const formattedViolations: ViolationData[] = data?.map(violation => ({
        id: violation.id,
        contract_id: violation.contract_id,
        vehicle_id: violation.vehicle_id,
        driver_id: violation.driver_id,
        company_id: violation.company_id,
        violation_type: violation.violation_type,
        location: violation.location,
        date: violation.date,
        description: violation.description,
        points: violation.points || 0,
        amount: violation.amount,
        status: violation.status as "pending" | "paid" | "contested" | "resolved",
        payment_deadline: violation.payment_deadline,
        evidence_files: violation.evidence_files,
        notes: violation.notes,
        created_at: violation.created_at,
        updated_at: violation.updated_at
      })) || [];

      setViolations(formattedViolations);
    } catch (error) {
      console.error('Error in fetchViolations:', error);
      toast.error('Erro ao carregar infrações');
    } finally {
      setLoading(false);
    }
  };

  const createViolation = async (violationData: Omit<ViolationData, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('violations')
        .insert([{
          contract_id: violationData.contract_id,
          vehicle_id: violationData.vehicle_id,
          driver_id: violationData.driver_id,
          company_id: violationData.company_id,
          violation_type: violationData.violation_type,
          location: violationData.location,
          date: violationData.date,
          description: violationData.description,
          points: violationData.points,
          amount: violationData.amount,
          status: violationData.status,
          payment_deadline: violationData.payment_deadline,
          evidence_files: violationData.evidence_files,
          notes: violationData.notes
        }])
        .select()
        .single();

      if (error) {
        console.error('Error creating violation:', error);
        toast.error('Erro ao criar infração');
        return null;
      }

      toast.success('Infração criada com sucesso');
      await fetchViolations(); // Refresh the list
      return data;
    } catch (error) {
      console.error('Error in createViolation:', error);
      toast.error('Erro ao criar infração');
      return null;
    }
  };

  const updateViolationStatus = async (violationId: string, newStatus: ViolationData["status"]) => {
    try {
      const { error } = await supabase
        .from('violations')
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', violationId);

      if (error) {
        console.error('Error updating violation:', error);
        toast.error('Erro ao atualizar infração');
        return;
      }

      toast.success('Status da infração atualizado');
      await fetchViolations(); // Refresh the list
    } catch (error) {
      console.error('Error in updateViolationStatus:', error);
      toast.error('Erro ao atualizar infração');
    }
  };

  useEffect(() => {
    fetchViolations();
  }, [user]);

  return {
    violations,
    loading,
    fetchViolations,
    createViolation,
    updateViolationStatus
  };
};
