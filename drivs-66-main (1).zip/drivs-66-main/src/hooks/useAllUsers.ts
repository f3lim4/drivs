
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface AllUserData {
  id: string;
  name: string;
  email: string;
  role: string;
  active: boolean;
  created_at: string;
  updated_at: string;
  last_login?: string;
  company_name?: string;
  cpf?: string;
  cnpj?: string;
  phone?: string;
}

export const useAllUsers = () => {
  const [users, setUsers] = useState<AllUserData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAllUsers = async () => {
    try {
      setLoading(true);
      
      // Buscar apenas administradores
      const { data: adminUsers, error: adminError } = await supabase
        .from('admin_users')
        .select('*');

      if (adminError) throw adminError;

      // Consolidar apenas usuários administrativos
      const allUsers: AllUserData[] = [
        // Administradores
        ...(adminUsers || []).map(admin => ({
          id: admin.id,
          name: admin.name,
          email: admin.email,
          role: 'Administrador',
          active: admin.active,
          created_at: admin.created_at,
          updated_at: admin.updated_at,
          last_login: admin.last_login
        }))
      ];

      setUsers(allUsers);
    } catch (error: any) {
      console.error('Error fetching all users:', error);
      toast.error('Erro ao carregar usuários');
    } finally {
      setLoading(false);
    }
  };

  const deleteUser = async (userId: string, userRole: string) => {
    try {
      let error;

      switch (userRole) {
        case 'Administrador':
          ({ error } = await supabase
            .from('admin_users')
            .delete()
            .eq('id', userId));
          break;
        
        default:
          throw new Error('Tipo de usuário não suportado para exclusão');
      }

      if (error) throw error;

      setUsers(prev => prev.filter(u => u.id !== userId));
      toast.success('Usuário removido com sucesso!');
    } catch (error: any) {
      console.error('Error deleting user:', error);
      toast.error('Erro ao remover usuário');
    }
  };

  const toggleUserStatus = async (userId: string, userRole: string) => {
    try {
      const user = users.find(u => u.id === userId);
      if (!user) return;

      let error;

      switch (userRole) {
        case 'Administrador':
          ({ error } = await supabase
            .from('admin_users')
            .update({ 
              active: !user.active,
              updated_at: new Date().toISOString()
            })
            .eq('id', userId));
          break;
        
        default:
          throw new Error('Tipo de usuário não suportado para alteração de status');
      }

      if (error) throw error;

      setUsers(prev => 
        prev.map(u => 
          u.id === userId 
            ? { ...u, active: !u.active }
            : u
        )
      );

      toast.success('Status do usuário atualizado!');
    } catch (error: any) {
      console.error('Error updating user status:', error);
      toast.error('Erro ao atualizar status do usuário');
    }
  };

  useEffect(() => {
    fetchAllUsers();
  }, []);

  return {
    users,
    loading,
    deleteUser,
    toggleUserStatus,
    refetch: fetchAllUsers
  };
};
