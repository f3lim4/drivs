
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

interface MaintenanceType {
  id: string;
  name: string;
  description?: string;
  is_system_default: boolean;
  company_id?: string;
}

export const useMaintenanceTypes = () => {
  const { user } = useAuth();
  const [maintenanceTypes, setMaintenanceTypes] = useState<MaintenanceType[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMaintenanceTypes = async () => {
    try {
      const { data, error } = await supabase
        .from("maintenance_types")
        .select("*")
        .or(`is_system_default.eq.true,company_id.eq.${user?.id || 'null'}`)
        .eq("is_active", true)
        .order("is_system_default", { ascending: false });

      if (error) throw error;
      setMaintenanceTypes(data || []);
    } catch (error) {
      console.error("Erro ao buscar tipos de manutenção:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMaintenanceTypes();
  }, [user]);

  return { maintenanceTypes, loading, refetch: fetchMaintenanceTypes };
};
