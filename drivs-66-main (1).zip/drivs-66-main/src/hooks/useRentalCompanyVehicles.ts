
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { RentalCompanyVehicle } from "./types/vehicleTypes";
import { getCompanyId } from "./utils/rentalVehicleUtils";
import {
  fetchVehiclesFromSupabase,
  createVehicleInSupabase,
  updateVehicleInSupabase,
  deleteVehicleFromSupabase
} from "./services/rentalVehicleService";

export type { RentalCompanyVehicle } from "./types/vehicleTypes";

export const useRentalCompanyVehicles = () => {
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState<RentalCompanyVehicle[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchVehicles = async () => {
    try {
      setLoading(true);
      console.log('Fetching vehicles for user:', user?.id);
      
      const companyId = getCompanyId(user?.id);
      console.log('Using company ID:', companyId);

      const vehicleData = await fetchVehiclesFromSupabase(companyId);
      setVehicles(vehicleData);
    } catch (error: any) {
      console.error('Error fetching vehicles:', error);
      toast.error('Erro ao carregar veículos');
      setVehicles([]);
    } finally {
      setLoading(false);
    }
  };

  const createVehicle = async (vehicleData: Omit<RentalCompanyVehicle, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const companyId = getCompanyId(user?.id);
      const newVehicle = await createVehicleInSupabase(vehicleData, companyId);
      
      toast.success('Veículo cadastrado com sucesso!');
      
      // Atualizar a lista local
      setVehicles(prev => [newVehicle, ...prev]);
      return newVehicle;
    } catch (error: any) {
      console.error('Error creating vehicle:', error);
      toast.error(error.message || 'Erro ao cadastrar veículo');
      throw error;
    }
  };

  const updateVehicle = async (vehicleId: string, updates: Partial<RentalCompanyVehicle>) => {
    try {
      const updatedVehicle = await updateVehicleInSupabase(vehicleId, updates);
      
      toast.success('Veículo atualizado com sucesso!');
      
      // Atualizar a lista local
      setVehicles(prev =>
        prev.map(vehicle => 
          vehicle.id === vehicleId ? updatedVehicle : vehicle
        )
      );
      return updatedVehicle;
    } catch (error: any) {
      console.error('Error updating vehicle:', error);
      toast.error(error.message || 'Erro ao atualizar veículo');
      throw error;
    }
  };

  const deleteVehicle = async (vehicleId: string) => {
    try {
      await deleteVehicleFromSupabase(vehicleId);
      
      toast.success('Veículo excluído com sucesso!');
      
      // Atualizar a lista local
      setVehicles(prev => prev.filter(vehicle => vehicle.id !== vehicleId));
    } catch (error: any) {
      console.error('Error deleting vehicle:', error);
      toast.error(error.message || 'Erro ao excluir veículo');
      throw error;
    }
  };

  useEffect(() => {
    console.log('useEffect triggered, user:', user?.id);
    if (user?.id) {
      fetchVehicles();
    }
  }, [user?.id]);

  return {
    vehicles,
    loading,
    createVehicle,
    updateVehicle,
    deleteVehicle,
    refetch: fetchVehicles
  };
};
