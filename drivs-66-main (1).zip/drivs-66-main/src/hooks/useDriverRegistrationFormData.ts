
import { useState } from "react";
import { useSearchParams } from "react-router-dom";

interface DriverFormData {
  fullName: string;
  email: string;
  phone: string;
  cpf: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  cnh: string;
  cnhExpires: string;
  dateOfBirth: string;
  password: string;
  confirmPassword: string;
}

export const useDriverRegistrationFormData = () => {
  const [searchParams] = useSearchParams();
  const referralId = searchParams.get('ref');
  
  console.log('🔗 [REFERRAL] URL params:', window.location.search);
  console.log('🔗 [REFERRAL] Referral ID capturado:', referralId);
  
  const [formData, setFormData] = useState<DriverFormData>({
    fullName: "",
    email: "",
    phone: "",
    cpf: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    cnh: "",
    cnhExpires: "",
    dateOfBirth: "",
    password: "",
    confirmPassword: ""
  });

  const handleInputChange = (field: string, value: string) => {
    console.log(`Updating field ${field} with value:`, value);
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return {
    formData,
    referralId,
    handleInputChange
  };
};

export type { DriverFormData };
