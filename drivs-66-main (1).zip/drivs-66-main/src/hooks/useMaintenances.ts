
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface Maintenance {
  id: string;
  company_id: string;
  vehicle_id?: string;
  driver_id?: string;
  maintenance_type: string;
  description: string;
  scheduled_date?: string;
  completed_date?: string;
  completed_time?: string;
  estimated_cost: number;
  actual_cost: number;
  status: "scheduled" | "in_progress" | "completed" | "cancelled";
  location_id?: string;
  odometer: number;
  notes?: string;
  items: any[];
  created_at: string;
  updated_at: string;
  // Dados relacionados
  vehicle_info?: string;
  driver_name?: string;
  location_name?: string;
}

export const useMaintenances = () => {
  const { user } = useAuth();
  const [maintenances, setMaintenances] = useState<Maintenance[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMaintenances = async () => {
    if (!user || user.role !== "rental_company") {
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from("maintenances")
        .select("*")
        .eq("company_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      // Buscar informações dos veículos, motoristas e locais separadamente
      const processedMaintenances = await Promise.all(
        (data || []).map(async (maintenance) => {
          let vehicle_info = "Veículo não encontrado";
          let driver_name = undefined;
          let location_name = undefined;

          // Buscar informações do veículo
          if (maintenance.vehicle_id) {
            const { data: vehicleData } = await supabase
              .from("rental_company_vehicles")
              .select("brand, model, year, plate")
              .eq("id", maintenance.vehicle_id)
              .single();

            if (vehicleData) {
              vehicle_info = `${vehicleData.brand} ${vehicleData.model} ${vehicleData.year} - ${vehicleData.plate}`;
            }
          }

          // Buscar informações do motorista
          if (maintenance.driver_id) {
            const { data: driverData } = await supabase
              .from("drivers")
              .select("full_name")
              .eq("id", maintenance.driver_id)
              .single();

            if (driverData) {
              driver_name = driverData.full_name;
            }
          }

          // Buscar informações do local
          if (maintenance.location_id) {
            const { data: locationData } = await supabase
              .from("maintenance_locations")
              .select("name")
              .eq("id", maintenance.location_id)
              .single();

            if (locationData) {
              location_name = locationData.name;
            }
          }

          return {
            ...maintenance,
            vehicle_info,
            driver_name,
            location_name,
            status: maintenance.status as "scheduled" | "in_progress" | "completed" | "cancelled",
            items: Array.isArray(maintenance.items) ? maintenance.items : [],
            estimated_cost: maintenance.estimated_cost || 0,
            actual_cost: maintenance.actual_cost || 0,
            odometer: maintenance.odometer || 0
          };
        })
      );

      setMaintenances(processedMaintenances);
    } catch (error) {
      console.error("Erro ao buscar manutenções:", error);
      toast.error("Erro ao carregar manutenções");
    } finally {
      setLoading(false);
    }
  };

  const createMaintenance = async (maintenanceData: Partial<Maintenance>) => {
    if (!user) return;

    try {
      // Garantir que description é fornecida
      const dataToInsert = {
        ...maintenanceData,
        company_id: user.id,
        description: maintenanceData.description || "Manutenção registrada"
      };

      // Remover campos que não existem na tabela
      const { vehicle_info, driver_name, location_name, ...cleanData } = dataToInsert as any;

      const { data, error } = await supabase
        .from("maintenances")
        .insert(cleanData)
        .select()
        .single();

      if (error) throw error;

      toast.success("Manutenção criada com sucesso!");
      fetchMaintenances(); // Recarregar dados
      return data;
    } catch (error) {
      console.error("Erro ao criar manutenção:", error);
      toast.error("Erro ao criar manutenção");
      throw error;
    }
  };

  const updateMaintenance = async (id: string, updates: Partial<Maintenance>) => {
    try {
      // Remover campos que não existem na tabela
      const { vehicle_info, driver_name, location_name, ...cleanUpdates } = updates as any;

      const { error } = await supabase
        .from("maintenances")
        .update(cleanUpdates)
        .eq("id", id);

      if (error) throw error;

      toast.success("Manutenção atualizada com sucesso!");
      fetchMaintenances(); // Recarregar dados
    } catch (error) {
      console.error("Erro ao atualizar manutenção:", error);
      toast.error("Erro ao atualizar manutenção");
      throw error;
    }
  };

  useEffect(() => {
    fetchMaintenances();
  }, [user]);

  return {
    maintenances,
    loading,
    createMaintenance,
    updateMaintenance,
    refetch: fetchMaintenances
  };
};
