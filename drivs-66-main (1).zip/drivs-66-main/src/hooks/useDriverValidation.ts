
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useDriverValidation = () => {
  const [isValidating, setIsValidating] = useState(false);

  const validateUniqueFields = async (formData: {
    cpf: string;
    cnh: string;
    phone: string;
    email: string;
  }) => {
    setIsValidating(true);
    
    try {
      // Verificar CPF duplicado
      const { data: cpfExists } = await supabase
        .from('drivers')
        .select('id')
        .eq('cpf', formData.cpf)
        .maybeSingle();

      if (cpfExists) {
        throw new Error('CPF já cadastrado no sistema');
      }

      // Verificar CNH duplicada
      const { data: cnhExists } = await supabase
        .from('drivers')
        .select('id')
        .eq('cnh', formData.cnh)
        .maybeSingle();

      if (cnhExists) {
        throw new Error('CNH já cadastrada no sistema');
      }

      // Verificar telefone duplicado
      const { data: phoneExists } = await supabase
        .from('drivers')
        .select('id')
        .eq('phone', formData.phone)
        .maybeSingle();

      if (phoneExists) {
        throw new Error('Telefone já cadastrado no sistema');
      }

      // Para verificar email duplicado, vamos consultar a tabela profiles
      // que é criada automaticamente quando um usuário se registra
      const { data: profileExists } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', '00000000-0000-0000-0000-000000000000') // Query dummy para verificar se a tabela existe
        .limit(0);

      // Verificar se existe um motorista com esse email na tabela drivers
      // (para casos onde o registro foi feito diretamente na tabela drivers)
      const { data: driverWithEmail } = await supabase
        .from('drivers')
        .select('id')
        .eq('id', (
          await supabase
            .from('profiles')
            .select('id')
            .eq('id', '00000000-0000-0000-0000-000000000000')
            .limit(1)
        ).data?.[0]?.id || 'non-existent-id')
        .maybeSingle();

      // Simplificar: apenas verificar na tabela driver_registrations se o email já foi usado
      const { data: emailInRegistrations } = await supabase
        .from('driver_registrations')
        .select('id')
        .eq('email', formData.email.toLowerCase().trim())
        .maybeSingle();

      if (emailInRegistrations) {
        throw new Error('Email já cadastrado no sistema');
      }

      return true;
    } catch (error: any) {
      throw error;
    } finally {
      setIsValidating(false);
    }
  };

  return {
    validateUniqueFields,
    isValidating
  };
};
