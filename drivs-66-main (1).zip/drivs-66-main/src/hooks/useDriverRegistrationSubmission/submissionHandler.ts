
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { DriverFormData } from "../useDriverRegistrationFormData";

export const handleAuthRegistration = async (
  formData: DriverFormData,
  documents: {
    cnhDocument: string;
    addressProof: string;
    selfieDocument: string;
    appProfileScreenshot: string;
  },
  referralId: string | null
) => {
  console.log("=== CRIANDO USUÁRIO NO SUPABASE AUTH ===");
  console.log("CNH:", formData.cnh);
  console.log("CNH Expires:", formData.cnhExpires);
  console.log("CEP:", formData.zipCode);
  console.log("Email:", formData.email);
  console.log("Referral ID:", referralId);
  console.log("============================================");

  const { data: authData, error: authError } = await supabase.auth.signUp({
    email: formData.email.toLowerCase().trim(),
    password: formData.password,
    options: {
      emailRedirectTo: `${window.location.origin}/`,
      data: {
        full_name: formData.fullName,
        role: 'driver',
        cpf: formData.cpf,
        phone: formData.phone,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        zip_code: formData.zipCode,
        cnh: formData.cnh,
        cnh_expires: formData.cnhExpires,
        date_of_birth: formData.dateOfBirth
      }
    }
  });

  if (authError) {
    console.error('Erro ao criar usuário:', authError);
    throw authError;
  }

  return authData;
};

export const handleDriverUpdate = async (
  userId: string,
  formData: DriverFormData,
  documents: {
    cnhDocument: string;
    addressProof: string;
    selfieDocument: string;
    appProfileScreenshot: string;
  },
  referralId: string | null
) => {
  const updateData = {
    full_name: formData.fullName,
    email: formData.email,
    phone: formData.phone,
    cpf: formData.cpf,
    address: formData.address,
    city: formData.city,
    state: formData.state,
    zip_code: formData.zipCode,
    cnh: formData.cnh,
    cnh_expires: formData.cnhExpires || null,
    date_of_birth: formData.dateOfBirth,
    company_id: referralId, // IMPORTANTE: Associar à empresa de referência
    cnh_document: documents.cnhDocument || null,
    address_proof: documents.addressProof || null,
    selfie_document: documents.selfieDocument || null,
    app_profile_screenshot: documents.appProfileScreenshot || null
  };

  console.log('=== DADOS PARA ATUALIZAÇÃO NA TABELA DRIVERS ===');
  console.log('CNH para update:', updateData.cnh);
  console.log('CNH Expires para update:', updateData.cnh_expires);
  console.log('ZIP Code para update:', updateData.zip_code);
  console.log('Company ID para update:', updateData.company_id);
  console.log('===============================================');

  const { data: updateResult, error: updateError } = await supabase
    .from('drivers')
    .update(updateData)
    .eq('id', userId)
    .select();

  if (updateError) {
    console.error('❌ Erro ao atualizar dados do motorista:', updateError);
    throw updateError;
  }

  console.log('✅ Dados atualizados com sucesso na tabela drivers:', updateResult);
  
  // Verificar se a associação com a locadora funcionou
  if (referralId && updateResult && updateResult[0]) {
    console.log('🔍 Verificando associação final com a locadora...');
    const { data: finalVerification } = await supabase
      .from('drivers')
      .select(`
        *,
        rental_companies!drivers_company_id_fkey (
          id,
          company_name
        )
      `)
      .eq('id', userId);
    
    console.log('🔍 Verificação final:', finalVerification);
  }

  return updateResult;
};
