
export const getErrorMessage = (error: any): string => {
  let errorMessage = "Erro ao realizar cadastro";
  
  if (error.message?.includes('já cadastrado') || error.message?.includes('já cadastrada')) {
    errorMessage = error.message;
  } else if (error.message?.includes('User already registered')) {
    errorMessage = "Este email já está cadastrado";
  } else if (error.message?.includes('email rate limit exceeded') || error.message?.includes('rate limit')) {
    errorMessage = "Muitas tentativas de cadastro. Tente novamente em alguns minutos.";
  } else if (error.message) {
    errorMessage = error.message;
  }
  
  return errorMessage;
};

export const validateFormData = (formData: { password: string; confirmPassword: string }): string | null => {
  if (formData.password !== formData.confirmPassword) {
    return "As senhas não coincidem";
  }
  return null;
};
