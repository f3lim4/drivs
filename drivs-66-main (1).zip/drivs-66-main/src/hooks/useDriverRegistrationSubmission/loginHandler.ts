
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const performAutoLogin = async (email: string, password: string) => {
  console.log('🔐 Fazendo login automático...');
  const { error: loginError } = await supabase.auth.signInWithPassword({
    email: email.toLowerCase().trim(),
    password: password
  });

  if (loginError) {
    console.error('❌ Erro no login automático:', loginError);
    toast.success("Cadastro realizado com sucesso! Você já pode fazer login.");
    return { success: false, redirectTo: "/login" };
  }

  toast.success("Cadastro realizado com sucesso! Agora você pode enviar seus documentos.");
  return { success: true, redirectTo: "/motorista/documentos" };
};
