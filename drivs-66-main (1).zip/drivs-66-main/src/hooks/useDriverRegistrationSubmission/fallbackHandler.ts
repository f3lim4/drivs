
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { DriverFormData } from "../useDriverRegistrationFormData";

export const handleFallbackRegistration = async (
  formData: DriverFormData,
  documents: {
    cnhDocument: string;
    addressProof: string;
    selfieDocument: string;
    appProfileScreenshot: string;
  },
  referralId: string | null,
  clearAllDocuments: () => void
) => {
  console.log('Rate limit de email detectado, salvando em driver_registrations...');
  console.log('🏢 Salvando com referral_company_id:', referralId);
  
  const registrationData = {
    full_name: formData.fullName,
    email: formData.email.toLowerCase().trim(),
    phone: formData.phone,
    cpf: formData.cpf,
    address: formData.address,
    city: formData.city,
    state: formData.state,
    zip_code: formData.zipCode,
    date_of_birth: formData.dateOfBirth,
    cnh: formData.cnh,
    cnh_expires: formData.cnhExpires || null,
    password_hash: formData.password,
    referral_company_id: referralId || null,
    status: 'pending',
    cnh_document: documents.cnhDocument || null,
    address_proof: documents.addressProof || null,
    selfie_document: documents.selfieDocument || null,
    app_profile_screenshot: documents.appProfileScreenshot || null
  };

  console.log('=== DADOS PARA DRIVER_REGISTRATIONS ===');
  console.log('CNH no registro:', registrationData.cnh);
  console.log('CNH Expires no registro:', registrationData.cnh_expires);
  console.log('ZIP Code no registro:', registrationData.zip_code);
  console.log('Referral Company ID:', registrationData.referral_company_id);
  console.log('======================================');

  const { data: insertedData, error: registrationError } = await supabase
    .from('driver_registrations')
    .insert(registrationData)
    .select();

  if (registrationError) {
    console.error('Erro ao inserir em driver_registrations:', registrationError);
    throw registrationError;
  }

  console.log('✅ Dados salvos com sucesso em driver_registrations:', insertedData);
  
  // Verificar se foi realmente salvo com a locadora
  if (referralId && insertedData && insertedData[0]) {
    console.log('🔍 Verificando associação com a locadora...');
    const { data: verificationData, error: verificationError } = await supabase
      .from('driver_registrations')
      .select(`
        *,
        rental_companies!driver_registrations_referral_company_id_fkey (
          id,
          company_name
        )
      `)
      .eq('id', insertedData[0].id);
    
    console.log('🔍 Verificação - dados encontrados:', verificationData);
    if (verificationError) {
      console.error('❌ Erro na verificação:', verificationError);
    }
  }
  
  clearAllDocuments();
  toast.success("Cadastro realizado com sucesso! Devido ao alto volume de cadastros, processaremos sua solicitação em breve. Entraremos em contato via WhatsApp.");
  
  // Disparar evento para atualizar listas
  window.dispatchEvent(new CustomEvent('refreshDriversData'));
};

export const isEmailRateLimitError = (error: any): boolean => {
  return (
    error.message?.includes('email rate limit exceeded') || 
    error.message?.includes('rate limit') ||
    error.code === 'over_email_send_rate_limit' ||
    (error.message?.includes('invalid') && error.message?.includes('email'))
  );
};
