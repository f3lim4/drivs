
export interface RentalCompanyVehicle {
  id: string;
  company_id: string;
  brand: string;
  model: string;
  plate: string;
  year: number;
  color: string;
  status: "available" | "rented" | "maintenance" | "stopped" | "damaged" | "sold";
  vehicle_type: string;
  fuel_type?: string;
  transmission_type: string;
  mileage?: number;
  weekly_value: number;
  deposit_value: number;
  vehicle_value?: number;
  is_financed: boolean;
  monthly_installment?: number;
  monthly_insurance?: number;
  monthly_tracker?: number;
  ipva_value?: number;
  km_type: "limited" | "unlimited";
  km_limit?: number;
  licensing_status?: "up_to_date" | "overdue";
  document_expiry?: string;
  maintenance_responsibility?: "rental_company" | "fifty_fifty" | "driver";
  allow_reservation?: boolean;
  description?: string;
  images?: string[];
  renavam?: string;
  chassi?: string;
  licensing_expiry?: string;
  last_revision_km?: number;
  observations?: string;
  driver_id?: string;
  created_at: string;
  updated_at: string;
}
