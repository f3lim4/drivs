
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

interface VehicleWithDriver {
  id: string;
  vehicleId: string;
  driverId?: string;
  driverName?: string;
  name: string;
  odometer: number;
}

export const useRealVehiclesWithDrivers = () => {
  const { user } = useAuth();
  const [vehiclesWithDrivers, setVehiclesWithDrivers] = useState<VehicleWithDriver[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchVehiclesWithDrivers = async () => {
    if (!user || user.role !== "rental_company") {
      setLoading(false);
      return;
    }

    try {
      // Buscar veículos da locadora
      const { data: vehicles, error: vehiclesError } = await supabase
        .from("rental_company_vehicles")
        .select(`
          id,
          brand,
          model,
          year,
          plate,
          mileage,
          driver_id,
          drivers!left(id, full_name)
        `)
        .eq("company_id", user.id);

      if (vehiclesError) throw vehiclesError;

      const processedVehicles = vehicles?.map(vehicle => ({
        id: `${vehicle.id}-${vehicle.driver_id || 'no-driver'}`,
        vehicleId: vehicle.id,
        driverId: vehicle.driver_id || undefined,
        driverName: vehicle.drivers?.full_name || undefined,
        name: `${vehicle.brand} ${vehicle.model} ${vehicle.year} - ${vehicle.plate}`,
        odometer: vehicle.mileage || 0
      })) || [];

      setVehiclesWithDrivers(processedVehicles);
    } catch (error) {
      console.error("Erro ao buscar veículos:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVehiclesWithDrivers();
  }, [user]);

  return { vehiclesWithDrivers, loading, refetch: fetchVehiclesWithDrivers };
};
