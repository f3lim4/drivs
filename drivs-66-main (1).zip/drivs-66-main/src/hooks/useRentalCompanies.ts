
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface RentalCompanyData {
  id: string;
  company_name: string;
  cnpj: string;
  plan: "basic" | "premium" | "enterprise";
  payment_status: "paid" | "pending" | "overdue";
  due_date: string | null;
  vehicle_count: number;
  drivers_count: number;
  registration_date: string;
  is_active: boolean;
  email?: string;
  phone: string;
  address: string;
  verified: boolean;
  rating: number;
  logo?: string;
  permissions?: any;
  created_at: string;
  updated_at: string;
}

export const useRentalCompanies = () => {
  const [companies, setCompanies] = useState<RentalCompanyData[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCompanies = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('rental_companies')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedData = data?.map(company => ({
        id: company.id,
        company_name: company.company_name,
        cnpj: company.cnpj,
        plan: (company.plan || 'basic') as "basic" | "premium" | "enterprise",
        payment_status: (company.payment_status || 'pending') as "paid" | "pending" | "overdue",
        due_date: company.due_date,
        vehicle_count: company.vehicle_count || 0,
        drivers_count: company.drivers_count || 0,
        registration_date: company.registration_date || company.created_at?.split('T')[0],
        is_active: company.is_active ?? true,
        email: company.email,
        phone: company.phone,
        address: company.address,
        verified: company.verified || false,
        rating: company.rating || 0,
        logo: company.logo,
        permissions: company.permissions,
        created_at: company.created_at,
        updated_at: company.updated_at
      })) || [];

      setCompanies(formattedData);
    } catch (error: any) {
      console.error('Error fetching companies:', error);
      toast.error('Erro ao carregar locadoras');
    } finally {
      setLoading(false);
    }
  };

  const updateCompanyStatus = async (companyId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('rental_companies')
        .update({ is_active: isActive, updated_at: new Date().toISOString() })
        .eq('id', companyId);

      if (error) throw error;

      setCompanies(prev => 
        prev.map(company => 
          company.id === companyId 
            ? { ...company, is_active: isActive }
            : company
        )
      );

      toast.success('Status da locadora atualizado!');
    } catch (error: any) {
      console.error('Error updating company status:', error);
      toast.error('Erro ao atualizar status da locadora');
    }
  };

  const updateCompany = async (companyId: string, updates: Partial<RentalCompanyData>) => {
    try {
      const { error } = await supabase
        .from('rental_companies')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', companyId);

      if (error) throw error;

      setCompanies(prev =>
        prev.map(company => 
          company.id === companyId 
            ? { ...company, ...updates }
            : company
        )
      );

      toast.success('Locadora atualizada com sucesso!');
    } catch (error: any) {
      console.error('Error updating company:', error);
      toast.error('Erro ao atualizar locadora');
    }
  };

  const deleteCompany = async (companyId: string) => {
    try {
      const { error } = await supabase
        .from('rental_companies')
        .delete()
        .eq('id', companyId);

      if (error) throw error;

      setCompanies(prev => prev.filter(company => company.id !== companyId));
      toast.success('Locadora excluída com sucesso!');
    } catch (error: any) {
      console.error('Error deleting company:', error);
      toast.error('Erro ao excluir locadora');
    }
  };

  useEffect(() => {
    fetchCompanies();
  }, []);

  return {
    companies,
    loading,
    updateCompanyStatus,
    updateCompany,
    deleteCompany,
    refetch: fetchCompanies
  };
};
