type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      admin_users: {
        Row: {
          active: boolean
          created_at: string
          email: string
          id: string
          last_login: string | null
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          email: string
          id?: string
          last_login?: string | null
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean
          created_at?: string
          email?: string
          id?: string
          last_login?: string | null
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      approved_rental_companies: {
        Row: {
          address: string
          city: string
          cnpj: string
          company_name: string
          contact_name: string
          contact_phone: string
          contact_position: string | null
          created_at: string | null
          description: string | null
          drivers_count: number | null
          due_date: string | null
          email: string
          id: string
          is_active: boolean
          password_hash: string
          payment_status: string
          phone: string
          plan: string
          registration_date: string
          state: string
          trading_name: string | null
          trial_end_date: string
          trial_start_date: string
          updated_at: string | null
          vehicle_count: number | null
          verified: boolean
          website_url: string | null
          zip_code: string
        }
        Insert: {
          address: string
          city: string
          cnpj: string
          company_name: string
          contact_name: string
          contact_phone: string
          contact_position?: string | null
          created_at?: string | null
          description?: string | null
          drivers_count?: number | null
          due_date?: string | null
          email: string
          id?: string
          is_active?: boolean
          password_hash: string
          payment_status?: string
          phone: string
          plan?: string
          registration_date?: string
          state: string
          trading_name?: string | null
          trial_end_date?: string
          trial_start_date?: string
          updated_at?: string | null
          vehicle_count?: number | null
          verified?: boolean
          website_url?: string | null
          zip_code: string
        }
        Update: {
          address?: string
          city?: string
          cnpj?: string
          company_name?: string
          contact_name?: string
          contact_phone?: string
          contact_position?: string | null
          created_at?: string | null
          description?: string | null
          drivers_count?: number | null
          due_date?: string | null
          email?: string
          id?: string
          is_active?: boolean
          password_hash?: string
          payment_status?: string
          phone?: string
          plan?: string
          registration_date?: string
          state?: string
          trading_name?: string | null
          trial_end_date?: string
          trial_start_date?: string
          updated_at?: string | null
          vehicle_count?: number | null
          verified?: boolean
          website_url?: string | null
          zip_code?: string
        }
        Relationships: []
      }
      company_users: {
        Row: {
          active: boolean
          company_id: string
          created_at: string
          email: string
          id: string
          last_login: string | null
          name: string
          permissions: Json | null
          role: string
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean
          company_id: string
          created_at?: string
          email: string
          id?: string
          last_login?: string | null
          name: string
          permissions?: Json | null
          role: string
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean
          company_id?: string
          created_at?: string
          email?: string
          id?: string
          last_login?: string | null
          name?: string
          permissions?: Json | null
          role?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_users_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "rental_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      contracts: {
        Row: {
          company_id: string
          created_at: string
          document_url: string | null
          driver_id: string
          end_date: string
          id: string
          monthly_amount: number
          start_date: string
          status: string
          updated_at: string
          vehicle_id: string
        }
        Insert: {
          company_id: string
          created_at?: string
          document_url?: string | null
          driver_id: string
          end_date: string
          id?: string
          monthly_amount: number
          start_date: string
          status?: string
          updated_at?: string
          vehicle_id: string
        }
        Update: {
          company_id?: string
          created_at?: string
          document_url?: string | null
          driver_id?: string
          end_date?: string
          id?: string
          monthly_amount?: number
          start_date?: string
          status?: string
          updated_at?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contracts_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "rental_companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contracts_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "drivers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contracts_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      driver_registrations: {
        Row: {
          address: string
          address_proof: string | null
          app_profile_screenshot: string | null
          city: string
          cnh: string
          cnh_document: string | null
          cnh_expires: string | null
          cpf: string
          created_at: string | null
          date_of_birth: string | null
          email: string
          full_name: string
          id: string
          password_hash: string
          phone: string
          referral_company_id: string | null
          selfie_document: string | null
          state: string
          status: string
          updated_at: string | null
          zip_code: string
        }
        Insert: {
          address: string
          address_proof?: string | null
          app_profile_screenshot?: string | null
          city: string
          cnh: string
          cnh_document?: string | null
          cnh_expires?: string | null
          cpf: string
          created_at?: string | null
          date_of_birth?: string | null
          email: string
          full_name: string
          id?: string
          password_hash: string
          phone: string
          referral_company_id?: string | null
          selfie_document?: string | null
          state: string
          status?: string
          updated_at?: string | null
          zip_code: string
        }
        Update: {
          address?: string
          address_proof?: string | null
          app_profile_screenshot?: string | null
          city?: string
          cnh?: string
          cnh_document?: string | null
          cnh_expires?: string | null
          cpf?: string
          created_at?: string | null
          date_of_birth?: string | null
          email?: string
          full_name?: string
          id?: string
          password_hash?: string
          phone?: string
          referral_company_id?: string | null
          selfie_document?: string | null
          state?: string
          status?: string
          updated_at?: string | null
          zip_code?: string
        }
        Relationships: [
          {
            foreignKeyName: "driver_registrations_referral_company_id_fkey"
            columns: ["referral_company_id"]
            isOneToOne: false
            referencedRelation: "rental_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      drivers: {
        Row: {
          address: string
          address_proof: string | null
          app_profile_screenshot: string | null
          app_screenshot: string | null
          available: boolean | null
          city: string
          cnh: string
          cnh_document: string | null
          cnh_expires: string
          company_id: string | null
          cpf: string
          created_at: string
          date_of_birth: string | null
          email: string | null
          full_name: string
          id: string
          phone: string
          profile_photo: string | null
          rating: number | null
          rejection_date: string | null
          rejection_reason: string | null
          rg: string | null
          selfie_document: string | null
          state: string
          status: string
          updated_at: string
          violations: number | null
          zip_code: string | null
        }
        Insert: {
          address: string
          address_proof?: string | null
          app_profile_screenshot?: string | null
          app_screenshot?: string | null
          available?: boolean | null
          city: string
          cnh: string
          cnh_document?: string | null
          cnh_expires: string
          company_id?: string | null
          cpf: string
          created_at?: string
          date_of_birth?: string | null
          email?: string | null
          full_name: string
          id?: string
          phone: string
          profile_photo?: string | null
          rating?: number | null
          rejection_date?: string | null
          rejection_reason?: string | null
          rg?: string | null
          selfie_document?: string | null
          state: string
          status?: string
          updated_at?: string
          violations?: number | null
          zip_code?: string | null
        }
        Update: {
          address?: string
          address_proof?: string | null
          app_profile_screenshot?: string | null
          app_screenshot?: string | null
          available?: boolean | null
          city?: string
          cnh?: string
          cnh_document?: string | null
          cnh_expires?: string
          company_id?: string | null
          cpf?: string
          created_at?: string
          date_of_birth?: string | null
          email?: string | null
          full_name?: string
          id?: string
          phone?: string
          profile_photo?: string | null
          rating?: number | null
          rejection_date?: string | null
          rejection_reason?: string | null
          rg?: string | null
          selfie_document?: string | null
          state?: string
          status?: string
          updated_at?: string
          violations?: number | null
          zip_code?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "drivers_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "rental_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      inspections: {
        Row: {
          assigned_to: string
          company_id: string
          contract_id: string | null
          created_at: string
          driver_id: string | null
          id: string
          inspection_date: string
          inspector: string
          observations: string | null
          photos_count: number | null
          status: string
          type: string
          updated_at: string
          vehicle_id: string
        }
        Insert: {
          assigned_to?: string
          company_id: string
          contract_id?: string | null
          created_at?: string
          driver_id?: string | null
          id?: string
          inspection_date?: string
          inspector?: string
          observations?: string | null
          photos_count?: number | null
          status?: string
          type?: string
          updated_at?: string
          vehicle_id: string
        }
        Update: {
          assigned_to?: string
          company_id?: string
          contract_id?: string | null
          created_at?: string
          driver_id?: string | null
          id?: string
          inspection_date?: string
          inspector?: string
          observations?: string | null
          photos_count?: number | null
          status?: string
          type?: string
          updated_at?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "inspections_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "rental_companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inspections_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "drivers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inspections_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "rental_company_vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      maintenance_locations: {
        Row: {
          address: string | null
          company_id: string
          created_at: string
          email: string | null
          id: string
          is_active: boolean | null
          name: string
          phone: string | null
          specialties: string[] | null
          updated_at: string
        }
        Insert: {
          address?: string | null
          company_id: string
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          phone?: string | null
          specialties?: string[] | null
          updated_at?: string
        }
        Update: {
          address?: string | null
          company_id?: string
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          phone?: string | null
          specialties?: string[] | null
          updated_at?: string
        }
        Relationships: []
      }
      maintenance_types: {
        Row: {
          company_id: string | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean | null
          is_system_default: boolean | null
          name: string
        }
        Insert: {
          company_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          is_system_default?: boolean | null
          name: string
        }
        Update: {
          company_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          is_system_default?: boolean | null
          name?: string
        }
        Relationships: []
      }
      maintenances: {
        Row: {
          actual_cost: number | null
          company_id: string
          completed_date: string | null
          completed_time: string | null
          created_at: string
          description: string
          driver_id: string | null
          estimated_cost: number | null
          id: string
          items: Json | null
          location_id: string | null
          maintenance_type: string
          notes: string | null
          odometer: number | null
          scheduled_date: string | null
          status: string
          updated_at: string
          vehicle_id: string | null
        }
        Insert: {
          actual_cost?: number | null
          company_id: string
          completed_date?: string | null
          completed_time?: string | null
          created_at?: string
          description: string
          driver_id?: string | null
          estimated_cost?: number | null
          id?: string
          items?: Json | null
          location_id?: string | null
          maintenance_type: string
          notes?: string | null
          odometer?: number | null
          scheduled_date?: string | null
          status?: string
          updated_at?: string
          vehicle_id?: string | null
        }
        Update: {
          actual_cost?: number | null
          company_id?: string
          completed_date?: string | null
          completed_time?: string | null
          created_at?: string
          description?: string
          driver_id?: string | null
          estimated_cost?: number | null
          id?: string
          items?: Json | null
          location_id?: string | null
          maintenance_type?: string
          notes?: string | null
          odometer?: number | null
          scheduled_date?: string | null
          status?: string
          updated_at?: string
          vehicle_id?: string | null
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          company_id: string
          created_at: string
          description: string | null
          driver_id: string
          driver_name: string
          due_date: string
          id: string
          paid_amount: number | null
          paid_date: string | null
          payment_method: string | null
          status: string
          updated_at: string
          vehicle_info: string
          vehicle_plate: string
        }
        Insert: {
          amount: number
          company_id: string
          created_at?: string
          description?: string | null
          driver_id: string
          driver_name: string
          due_date: string
          id?: string
          paid_amount?: number | null
          paid_date?: string | null
          payment_method?: string | null
          status?: string
          updated_at?: string
          vehicle_info: string
          vehicle_plate: string
        }
        Update: {
          amount?: number
          company_id?: string
          created_at?: string
          description?: string | null
          driver_id?: string
          driver_name?: string
          due_date?: string
          id?: string
          paid_amount?: number | null
          paid_date?: string | null
          payment_method?: string | null
          status?: string
          updated_at?: string
          vehicle_info?: string
          vehicle_plate?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          role: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          role?: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          role?: string
          updated_at?: string
        }
        Relationships: []
      }
      rental_companies: {
        Row: {
          address: string
          cep: string | null
          city: string | null
          cnpj: string
          company_name: string
          created_at: string
          description: string | null
          drivers_count: number | null
          due_date: string | null
          email: string | null
          emergency_phone: string | null
          id: string
          is_active: boolean | null
          logo: string | null
          logo_url: string | null
          operating_hours: string | null
          payment_status: string | null
          permissions: Json | null
          phone: string
          plan: string | null
          rating: number | null
          registration_date: string | null
          state: string | null
          updated_at: string
          vehicle_count: number | null
          verified: boolean | null
          website: string | null
          whatsapp: string | null
        }
        Insert: {
          address: string
          cep?: string | null
          city?: string | null
          cnpj: string
          company_name: string
          created_at?: string
          description?: string | null
          drivers_count?: number | null
          due_date?: string | null
          email?: string | null
          emergency_phone?: string | null
          id?: string
          is_active?: boolean | null
          logo?: string | null
          logo_url?: string | null
          operating_hours?: string | null
          payment_status?: string | null
          permissions?: Json | null
          phone: string
          plan?: string | null
          rating?: number | null
          registration_date?: string | null
          state?: string | null
          updated_at?: string
          vehicle_count?: number | null
          verified?: boolean | null
          website?: string | null
          whatsapp?: string | null
        }
        Update: {
          address?: string
          cep?: string | null
          city?: string | null
          cnpj?: string
          company_name?: string
          created_at?: string
          description?: string | null
          drivers_count?: number | null
          due_date?: string | null
          email?: string | null
          emergency_phone?: string | null
          id?: string
          is_active?: boolean | null
          logo?: string | null
          logo_url?: string | null
          operating_hours?: string | null
          payment_status?: string | null
          permissions?: Json | null
          phone?: string
          plan?: string | null
          rating?: number | null
          registration_date?: string | null
          state?: string | null
          updated_at?: string
          vehicle_count?: number | null
          verified?: boolean | null
          website?: string | null
          whatsapp?: string | null
        }
        Relationships: []
      }
      rental_company_registrations: {
        Row: {
          address: string
          city: string
          cnpj: string
          company_name: string
          contact_name: string
          contact_phone: string
          contact_position: string | null
          created_at: string | null
          description: string | null
          email: string
          id: string
          password_hash: string
          phone: string
          state: string
          status: string
          trading_name: string | null
          updated_at: string | null
          website_url: string | null
          zip_code: string
        }
        Insert: {
          address: string
          city: string
          cnpj: string
          company_name: string
          contact_name: string
          contact_phone: string
          contact_position?: string | null
          created_at?: string | null
          description?: string | null
          email: string
          id?: string
          password_hash: string
          phone: string
          state: string
          status?: string
          trading_name?: string | null
          updated_at?: string | null
          website_url?: string | null
          zip_code: string
        }
        Update: {
          address?: string
          city?: string
          cnpj?: string
          company_name?: string
          contact_name?: string
          contact_phone?: string
          contact_position?: string | null
          created_at?: string | null
          description?: string | null
          email?: string
          id?: string
          password_hash?: string
          phone?: string
          state?: string
          status?: string
          trading_name?: string | null
          updated_at?: string | null
          website_url?: string | null
          zip_code?: string
        }
        Relationships: []
      }
      rental_company_vehicles: {
        Row: {
          allow_reservation: boolean | null
          brand: string
          chassi: string | null
          color: string
          company_id: string
          created_at: string
          deposit_value: number
          description: string | null
          document_expiry: string | null
          driver_id: string | null
          fuel_type: string | null
          id: string
          images: string[] | null
          ipva_value: number | null
          is_financed: boolean | null
          km_limit: number | null
          km_type: string
          last_revision_km: number | null
          licensing_expiry: string | null
          licensing_status: string | null
          maintenance_responsibility: string | null
          mileage: number | null
          model: string
          monthly_installment: number | null
          monthly_insurance: number | null
          monthly_tracker: number | null
          observations: string | null
          plate: string
          renavam: string | null
          status: string
          transmission_type: string
          updated_at: string
          vehicle_type: string
          vehicle_value: number | null
          weekly_value: number
          year: number
        }
        Insert: {
          allow_reservation?: boolean | null
          brand: string
          chassi?: string | null
          color: string
          company_id: string
          created_at?: string
          deposit_value: number
          description?: string | null
          document_expiry?: string | null
          driver_id?: string | null
          fuel_type?: string | null
          id?: string
          images?: string[] | null
          ipva_value?: number | null
          is_financed?: boolean | null
          km_limit?: number | null
          km_type?: string
          last_revision_km?: number | null
          licensing_expiry?: string | null
          licensing_status?: string | null
          maintenance_responsibility?: string | null
          mileage?: number | null
          model: string
          monthly_installment?: number | null
          monthly_insurance?: number | null
          monthly_tracker?: number | null
          observations?: string | null
          plate: string
          renavam?: string | null
          status?: string
          transmission_type: string
          updated_at?: string
          vehicle_type: string
          vehicle_value?: number | null
          weekly_value: number
          year: number
        }
        Update: {
          allow_reservation?: boolean | null
          brand?: string
          chassi?: string | null
          color?: string
          company_id?: string
          created_at?: string
          deposit_value?: number
          description?: string | null
          document_expiry?: string | null
          driver_id?: string | null
          fuel_type?: string | null
          id?: string
          images?: string[] | null
          ipva_value?: number | null
          is_financed?: boolean | null
          km_limit?: number | null
          km_type?: string
          last_revision_km?: number | null
          licensing_expiry?: string | null
          licensing_status?: string | null
          maintenance_responsibility?: string | null
          mileage?: number | null
          model?: string
          monthly_installment?: number | null
          monthly_insurance?: number | null
          monthly_tracker?: number | null
          observations?: string | null
          plate?: string
          renavam?: string | null
          status?: string
          transmission_type?: string
          updated_at?: string
          vehicle_type?: string
          vehicle_value?: number | null
          weekly_value?: number
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "rental_company_vehicles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "rental_companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rental_company_vehicles_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "drivers"
            referencedColumns: ["id"]
          },
        ]
      }
      security_audit_log: {
        Row: {
          action: string
          created_at: string | null
          id: string
          ip_address: unknown | null
          resource_id: string | null
          resource_type: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string | null
          id?: string
          ip_address?: unknown | null
          resource_id?: string | null
          resource_type: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string | null
          id?: string
          ip_address?: unknown | null
          resource_id?: string | null
          resource_type?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          accent_color: string | null
          banner_images: string[] | null
          created_at: string
          id: string
          primary_color: string | null
          secondary_color: string | null
          site_description: string | null
          site_keywords: string | null
          site_logo: string | null
          site_title: string
          updated_at: string
        }
        Insert: {
          accent_color?: string | null
          banner_images?: string[] | null
          created_at?: string
          id?: string
          primary_color?: string | null
          secondary_color?: string | null
          site_description?: string | null
          site_keywords?: string | null
          site_logo?: string | null
          site_title?: string
          updated_at?: string
        }
        Update: {
          accent_color?: string | null
          banner_images?: string[] | null
          created_at?: string
          id?: string
          primary_color?: string | null
          secondary_color?: string | null
          site_description?: string | null
          site_keywords?: string | null
          site_logo?: string | null
          site_title?: string
          updated_at?: string
        }
        Relationships: []
      }
      vehicle_expenses: {
        Row: {
          amount: number
          category: string
          company_id: string
          created_at: string
          description: string
          expense_date: string
          expense_type: string
          id: string
          updated_at: string
          vehicle_id: string | null
          vehicle_plate: string
        }
        Insert: {
          amount: number
          category?: string
          company_id: string
          created_at?: string
          description: string
          expense_date?: string
          expense_type: string
          id?: string
          updated_at?: string
          vehicle_id?: string | null
          vehicle_plate: string
        }
        Update: {
          amount?: number
          category?: string
          company_id?: string
          created_at?: string
          description?: string
          expense_date?: string
          expense_type?: string
          id?: string
          updated_at?: string
          vehicle_id?: string | null
          vehicle_plate?: string
        }
        Relationships: []
      }
      vehicles: {
        Row: {
          brand: string
          color: string
          company_id: string
          created_at: string
          daily_rate: number
          id: string
          model: string
          photo: string | null
          plate: string
          status: string
          updated_at: string
          year: number
        }
        Insert: {
          brand: string
          color: string
          company_id: string
          created_at?: string
          daily_rate: number
          id?: string
          model: string
          photo?: string | null
          plate: string
          status?: string
          updated_at?: string
          year: number
        }
        Update: {
          brand?: string
          color?: string
          company_id?: string
          created_at?: string
          daily_rate?: number
          id?: string
          model?: string
          photo?: string | null
          plate?: string
          status?: string
          updated_at?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "vehicles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "rental_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      violations: {
        Row: {
          amount: number
          company_id: string
          contract_id: string | null
          created_at: string | null
          date: string
          description: string
          driver_id: string | null
          evidence_files: string[] | null
          id: string
          location: string
          notes: string | null
          payment_deadline: string | null
          points: number | null
          status: string
          updated_at: string | null
          vehicle_id: string | null
          violation_type: string
        }
        Insert: {
          amount: number
          company_id: string
          contract_id?: string | null
          created_at?: string | null
          date: string
          description: string
          driver_id?: string | null
          evidence_files?: string[] | null
          id?: string
          location: string
          notes?: string | null
          payment_deadline?: string | null
          points?: number | null
          status?: string
          updated_at?: string | null
          vehicle_id?: string | null
          violation_type: string
        }
        Update: {
          amount?: number
          company_id?: string
          contract_id?: string | null
          created_at?: string | null
          date?: string
          description?: string
          driver_id?: string | null
          evidence_files?: string[] | null
          id?: string
          location?: string
          notes?: string | null
          payment_deadline?: string | null
          points?: number | null
          status?: string
          updated_at?: string | null
          vehicle_id?: string | null
          violation_type?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      delete_all_driver_data: {
        Args: { requester_user_id: string; confirmation_code: string }
        Returns: Json
      }
      delete_driver: {
        Args: { driver_id: string; requester_password: string }
        Returns: boolean
      }
      get_current_user_role: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_drivers_by_company: {
        Args: { company_id: string }
        Returns: {
          id: string
          full_name: string
          cpf: string
          rg: string
          phone: string
          address: string
          city: string
          state: string
          cnh: string
          cnh_expires: string
          status: string
          available: boolean
          rating: number
          violations: number
          created_at: string
          updated_at: string
          profile_photo: string
          app_screenshot: string
          address_proof: string
          rejection_reason: string
          rejection_date: string
        }[]
      }
      get_user_company_access: {
        Args: Record<PropertyKey, never>
        Returns: {
          company_id: string
          user_role: string
        }[]
      }
      get_user_email_by_id: {
        Args: { user_id: string }
        Returns: string
      }
      is_demo_mode_or_valid_company: {
        Args: { company_id_param: string }
        Returns: boolean
      }
      is_demo_mode_or_valid_maintenance_company: {
        Args: { company_id_param: string }
        Returns: boolean
      }
      log_security_event: {
        Args: {
          action_name: string
          resource_type_name: string
          resource_uuid?: string
          user_ip?: unknown
          agent?: string
        }
        Returns: undefined
      }
      safe_delete_driver: {
        Args: { driver_id: string; requester_user_id: string }
        Returns: Json
      }
      safe_delete_driver_demo: {
        Args: { driver_id: string }
        Returns: Json
      }
      secure_mass_delete_all_data: {
        Args: { requester_user_id: string; security_password: string }
        Returns: Json
      }
      update_driver_status: {
        Args: {
          driver_id: string
          new_status: string
          table_name: string
          user_id: string
        }
        Returns: boolean
      }
      user_belongs_to_company: {
        Args: { company_uuid: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

const Constants = {
  public: {
    Enums: {},
  },
} as const
